// Vineshroom SPEEN Circle -- Script v1
// Smooths the 2D CORRUPTION bang pads into attack/decay envelopes (bang + script.js envelope
// instead of native "bang smooth", for full control over the attack/decay shape -- matches the
// pattern already established in the Pigeon Hole family this scene's SPEEN architecture spawned).
// Also drives real camera controls: left-click-drag orbits the camera, right-click-drag zooms.
// Both ported from Pigeon Hole -- True Mesh's script.js (itself studied from Synesthesia's own
// 3D Orbit Camera example scene, whose _click/_muvc globals are confirmed real from that source).

var _corruptionEnv = 0.0;
var _blockGlitchEnv = 0.0;
var _shiftEnv = 0.0;
var _rgbShiftEnv = 0.0;
var _invertEnv = 0.0;
var _zoomPunchEnv = 0.0;
var _resetShroomsEnv = 0.0;

var attackRate = 50.0;   // bang envelope attack
var decayRate = 0.8;     // bang envelope decay

function envelope(current, target, dt) {
    if (target > current) {
        current += attackRate * dt;
        if (current > 1.0) current = 1.0;
    } else {
        current -= decayRate * dt;
        if (current < 0.0) current = 0.0;
    }
    return current;
}

// Left-click-drag orbit: updates viewYaw/viewPitch 1:1 with mouse movement (no lag -- a direct
// drag should feel immediate, unlike a bang-triggered camera transition which is right to ease).
var _prevClickL = false;
var _lastMouseX = 0.0, _lastMouseY = 0.0;
var _viewYaw = 0.0, _viewPitch = 0.0;
var dragSensitivity = 2.4;

// Right-click-drag zoom: a direct position delta (not the reference scene's hold-and-it-keeps-
// zooming joystick style, for the same 1:1-with-the-mouse feel as the orbit drag), with a short
// momentum-decay tail after release as the one deliberate carryover from that reference.
var _prevClickR = false;
var _lastMouseYR = 0.0;
var _zoomDrag = 0.0;
var _zoomVel = 0.0;
var zoomDragSensitivity = 4.0;
var zoomMomentumDecay = 0.9;

function setup() {
    setUniform('corruptionEnv', 0.0);
    setUniform('blockGlitchEnv', 0.0);
    setUniform('shiftEnv', 0.0);
    setUniform('rgbShiftEnv', 0.0);
    setUniform('invertEnv', 0.0);
    setUniform('zoomPunchEnv', 0.0);
    setUniform('resetShroomsEnv', 0.0);
    setUniform('viewYaw', 0.0);
    setUniform('viewPitch', 0.0);
    setUniform('zoomDrag', 0.0);
    console.log('[Vineshroom SPEEN Circle v4] Script loaded OK');
}

function update(dt) {
    _corruptionEnv = envelope(_corruptionEnv, corruptionBang, dt);
    _blockGlitchEnv = envelope(_blockGlitchEnv, blockGlitchBang, dt);
    _shiftEnv = envelope(_shiftEnv, shiftBang, dt);
    _rgbShiftEnv = envelope(_rgbShiftEnv, rgbShiftBang, dt);
    _invertEnv = envelope(_invertEnv, invertBang, dt);
    _zoomPunchEnv = envelope(_zoomPunchEnv, zoomPunchBang, dt);
    // resetShrooms: an obvious "panic button" -- fast attack snaps this to 1 almost instantly on the
    // bang, main.glsl uses (1 - resetShroomsEnv) to suppress every SHROOM CORRUPTION amount to 0
    // right then, and the same decay rate eases corruption back in over about a second afterward.
    _resetShroomsEnv = envelope(_resetShroomsEnv, resetShroomsBang, dt);

    var clickL = _click.x > 0.5;
    if (clickL && !_prevClickL) {
        _lastMouseX = _muvc.x;
        _lastMouseY = _muvc.y;
    }
    if (clickL) {
        var dx = _muvc.x - _lastMouseX;
        var dy = _muvc.y - _lastMouseY;
        _lastMouseX = _muvc.x;
        _lastMouseY = _muvc.y;
        _viewYaw -= dx * dragSensitivity;
        _viewPitch = Math.max(-1.4, Math.min(1.4, _viewPitch + dy * dragSensitivity));
    }
    _prevClickL = clickL;

    var clickR = _click.y > 0.5;
    if (clickR && !_prevClickR) {
        _lastMouseYR = _muvc.y;
    }
    if (clickR) {
        var dyR = _muvc.y - _lastMouseYR;
        _lastMouseYR = _muvc.y;
        _zoomVel = dyR * zoomDragSensitivity;
        _zoomDrag += _zoomVel;
    } else if (_zoomVel !== 0.0) {
        _zoomDrag += _zoomVel;
        _zoomVel *= zoomMomentumDecay;
        if (Math.abs(_zoomVel) < 0.0008) _zoomVel = 0.0;
    }
    _prevClickR = clickR;
    _zoomDrag = Math.max(-6.0, Math.min(6.0, _zoomDrag));

    setUniform('corruptionEnv', _corruptionEnv);
    setUniform('blockGlitchEnv', _blockGlitchEnv);
    setUniform('shiftEnv', _shiftEnv);
    setUniform('rgbShiftEnv', _rgbShiftEnv);
    setUniform('invertEnv', _invertEnv);
    setUniform('zoomPunchEnv', _zoomPunchEnv);
    setUniform('resetShroomsEnv', _resetShroomsEnv);
    setUniform('viewYaw', _viewYaw);
    setUniform('viewPitch', _viewPitch);
    setUniform('zoomDrag', _zoomDrag);
}
