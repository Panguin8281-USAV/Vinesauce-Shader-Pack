// Vineshroom SPEEN Circle
// Audio reactive 3D mushrooms with tie-dye background
// Version 4 (vineshroom_syn_main_v4)
// v4: ported TRAILS (feedback/bgEcho/edgeDetect/streak), 2D CORRUPTION additions (kaleidoscope,
// invert, zoomPunch, pixelSortWidth), a new SHROOM CORRUPTION bank (glitch/twist/warp/distort/fold --
// the raymarch-domain-warp analog of Pigeon Hole -- True Mesh's per-vertex mesh corruption, since a
// raymarched SDF can domain-warp the sample point directly rather than needing the mesh scene's
// per-vertex workaround), and LOW POLY (facet-normal blend, same technique as Pigeon Hole's own SDF
// flock scene) over from the Pigeon Hole family. Also real camera controls: left-drag orbit +
// right-drag zoom (ported from Pigeon Hole -- True Mesh's script.js, itself studied from Synesthesia's
// own 3D Orbit Camera example scene) replacing the old fixed-angle-only camera. All bang pads
// converted from native "bang smooth" to bang + script.js envelope, per established preference.

// ===== HELPER FUNCTIONS =====

mat2 rot(float a) {
    float c = cos(a);
    float s = sin(a);
    return mat2(c, -s, s, c);
}

float hash(float n) {
    return fract(sin(n) * 43758.5453);
}

float smin(float a, float b, float k) {
    float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
    return mix(b, a, h) - k * h * (1.0 - h);
}

float pendulum(float t, float rotations) {
    return sin(t * 0.5) * rotations * 2.0 * PI;
}

vec3 enhanceColor(vec3 col, float bright, float sat) {
    col *= bright;
    float gray = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(gray), col, sat);
    return col;
}

// ===== SHROOM CORRUPTION (3D) DOMAIN WARP =====

// The raymarch equivalent of Pigeon Hole -- True Mesh's per-vertex meshWarp/meshDistort/meshFold.
// That scene had to warp real triangle VERTICES because a ray-triangle test has no notion of
// "sample point along the ray" to re-warp -- but a raymarcher re-evaluates map() at a new p every
// step, so warping p directly here is the textbook, genuinely-correct version of the same trick
// (the mesh scene's own code comments note this is what it would have done if it could).
vec3 warpShroom(vec3 p, float warpAmt, float distortAmt, float foldAmt) {
    vec3 wp = p;
    if (warpAmt > 0.001) {
        // organic multi-frequency ripple/melt -- classic raymarching domain warp p += A*sin(freq*p+t)
        wp += vec3(
            sin(p.y * 4.5 + TIME * 2.0) * sin(p.z * 3.3 + TIME * 1.3),
            sin(p.z * 3.8 + TIME * 1.7) * sin(p.x * 4.7 + TIME * 2.1),
            sin(p.x * 3.4 + TIME * 1.1) * sin(p.y * 4.1 + TIME * 1.9)
        ) * warpAmt * 0.18;
    }
    if (distortAmt > 0.001) {
        // twist around the mushroom's own vertical axis, angle growing with height. Bounded
        // oscillation (sin(TIME*rate)) rather than a raw TIME*amt term -- a raw accumulating product
        // would wind tighter for as long as the scene has run, independent of the slider, the exact
        // runaway bug documented for this same technique in Pigeon Hole -- True Mesh's meshDistort.
        float twistAngle = wp.y * distortAmt * 1.6 + sin(TIME * 0.5) * distortAmt * 0.6;
        wp.xz = rot(twistAngle) * wp.xz;
    }
    if (foldAmt > 0.001) {
        // fractal mirror-fold (abs()-fold-and-rotate), same idea as party_doodad_dup's Kaleidoscopic-
        // IFS folding and Pigeon Hole -- True Mesh's meshFold -- crystalline/splintered look, blended
        // rather than switched at the threshold since abs() has a derivative kink that would pop.
        vec3 fp = wp;
        for (int i = 0; i < 2; i++) {
            fp = abs(fp);
            fp -= 0.28 * foldAmt;
            fp.xz = rot(0.9 + float(i) * 0.6) * fp.xz;
        }
        wp = mix(wp, fp, foldAmt);
    }
    return wp;
}

// ===== MUSHROOM GEOMETRY =====

float mushroomCap(vec3 p) {
    float stemH = 1.0;
    float capD = 1.25;
    float capH = 0.5;

    float baseHeight = 0.35 * stemH;
    float capRad = 0.5 * capD;

    vec3 capCenter = vec3(0.0, baseHeight + capH * 0.5, 0.0);
    vec3 ellipsoid = (p - capCenter) / vec3(capRad, capH, capRad);
    float sphere = length(ellipsoid) - 1.0;

    float cutPlane = -(p.y - baseHeight);
    return max(sphere, cutPlane);
}

float mushroomStem(vec3 p, float id) {
    float stemH = 1.0;
    float stemD = 1.2;

    float stemHeight = stemH * 0.35;
    float stemR = 0.15 * stemD;

    float flare = 1.0 + smoothstep(stemHeight, -stemHeight, p.y) * 0.4;
    float r = stemR * flare;

    float ridgeSeed = floor(id) * 12.34;
    float ridgeCount = 4.0 + floor(hash(ridgeSeed) * 5.0);
    float ridgeDepth = mix(0.025, 0.012, (ridgeCount - 4.0) / 4.0);

    float angle = atan(p.z, p.x);
    float ridges = sin(angle * ridgeCount) * ridgeDepth;

    float ridgeHeight = 0.7 + hash(ridgeSeed + 1.0) * 0.3;
    float ridgeFade = smoothstep(-stemHeight, stemHeight * ridgeHeight, p.y);
    ridges *= (1.0 - ridgeFade);

    float cylDist = length(p.xz) - r - ridges;
    float heightCut = abs(p.y) - stemHeight;

    return max(cylDist, heightCut);
}

float mushroom(vec3 p, float id) {
    float cap = mushroomCap(p);
    float stem = mushroomStem(p, id);
    return smin(cap, stem, 0.15);
}

float lightShroom(vec3 p) {
    float stemH = 1.0;
    float capD = 1.25;
    float capH = 0.5;
    float stemD = 1.2;

    float baseHeight = 0.35 * stemH;
    float capRad = 0.5 * capD;

    vec3 capCenter = vec3(0.0, baseHeight + capH * 0.5, 0.0);
    vec3 ellipsoid = (p - capCenter) / vec3(capRad, capH, capRad);
    float capDist = length(ellipsoid) - 1.0;
    float cutPlane = -(p.y - baseHeight);
    float cap = max(capDist, cutPlane);

    float stemHeight = stemH * 0.35;
    float stemR = 0.15 * stemD;
    float flare = 1.0 + smoothstep(stemHeight, -stemHeight, p.y) * 0.4;
    float r = stemR * flare;

    float cylDist = length(p.xz) - r;
    float heightCut = abs(p.y) - stemHeight;
    float stem = max(cylDist, heightCut);

    return smin(cap, stem, 0.15);
}

// ===== COLOR FUNCTIONS =====

float getColorId(float slot, float totalCount) {
    int count = int(totalCount);
    int s = int(slot);
    int pairs = count / 2;

    if(s < pairs) {
        return float(s);
    } else {
        return float(s - pairs + 6);
    }
}

vec3 getStemColor(float paletteId, float brightness, float saturation) {
    vec3 col;
    if(paletteId < 0.5) col = vec3(20.0, 60.0, 40.0) / 255.0;
    else if(paletteId < 1.5) col = vec3(40.0, 80.0, 100.0) / 255.0;
    else if(paletteId < 2.5) col = vec3(30.0, 50.0, 90.0) / 255.0;
    else if(paletteId < 3.5) col = vec3(60.0, 25.0, 80.0) / 255.0;
    else if(paletteId < 4.5) col = vec3(80.0, 30.0, 60.0) / 255.0;
    else if(paletteId < 5.5) col = vec3(80.0, 25.0, 30.0) / 255.0;
    else if(paletteId < 6.5) col = vec3(8.0, 77.0, 56.0) / 255.0;
    else if(paletteId < 7.5) col = vec3(20.0, 27.0, 55.0) / 255.0;
    else if(paletteId < 8.5) col = vec3(20.0, 27.0, 55.0) / 255.0;
    else if(paletteId < 9.5) col = vec3(71.0, 22.0, 75.0) / 255.0;
    else if(paletteId < 10.5) col = vec3(71.0, 22.0, 75.0) / 255.0;
    else col = vec3(126.0, 23.0, 30.0) / 255.0;

    return enhanceColor(col, brightness, saturation);
}

vec3 getCapColor(vec3 p, float paletteId, float tieDyeTurb, float tieDyeSpd, float brightness, float saturation) {
    // Use Presence instead of Level for smoother audio reactivity
    float turbulence = tieDyeTurb * (1.0 + syn_BassPresence * 0.08);
    float speed = tieDyeSpd * (1.0 + syn_MidPresence * 0.04);

    float t = 0.0;
    t += sin(p.x * turbulence + TIME * speed) * 0.5;
    t += sin(p.y * turbulence * 1.3 + TIME * speed * 0.7) * 0.3;
    t += sin(p.z * turbulence * 0.8 + TIME * speed * 1.2) * 0.4;
    t += sin((p.x + p.y) * turbulence * 0.5 + TIME * speed * 0.9) * 0.2;
    t += sin((p.y + p.z) * turbulence * 0.7 + TIME * speed * 0.6) * 0.2;
    t += syn_HighPresence * 0.03;
    t = fract(t);

    vec3 color;

    if(paletteId < 0.5) {
        vec3 veryDark = vec3(5.0, 25.0, 15.0) / 255.0;
        vec3 dark = vec3(20.0, 60.0, 40.0) / 255.0;
        vec3 med = vec3(40.0, 100.0, 60.0) / 255.0;
        if(t < 0.5) color = mix(veryDark, dark, t * 2.0);
        else color = mix(dark, med, (t - 0.5) * 2.0);
    }
    else if(paletteId < 1.5) {
        vec3 dark = vec3(15.0, 25.0, 50.0) / 255.0;
        vec3 med = vec3(30.0, 50.0, 90.0) / 255.0;
        vec3 teal = vec3(60.0, 180.0, 160.0) / 255.0;
        if(t < 0.5) color = mix(dark, med, t * 2.0);
        else color = mix(med, teal, (t - 0.5) * 2.0);
    }
    else if(paletteId < 2.5) {
        vec3 dark = vec3(15.0, 25.0, 50.0) / 255.0;
        vec3 med = vec3(35.0, 60.0, 100.0) / 255.0;
        vec3 blue = vec3(74.0, 122.0, 186.0) / 255.0;
        if(t < 0.5) color = mix(dark, med, t * 2.0);
        else color = mix(med, blue, (t - 0.5) * 2.0);
    }
    else if(paletteId < 3.5) {
        vec3 dark = vec3(35.0, 15.0, 50.0) / 255.0;
        vec3 med = vec3(75.0, 35.0, 100.0) / 255.0;
        vec3 purple = vec3(129.0, 76.0, 156.0) / 255.0;
        if(t < 0.5) color = mix(dark, med, t * 2.0);
        else color = mix(med, purple, (t - 0.5) * 2.0);
    }
    else if(paletteId < 4.5) {
        vec3 dark = vec3(35.0, 15.0, 50.0) / 255.0;
        vec3 med = vec3(70.0, 30.0, 90.0) / 255.0;
        vec3 red = vec3(180.0, 70.0, 60.0) / 255.0;
        if(t < 0.5) color = mix(dark, med, t * 2.0);
        else color = mix(med, red, (t - 0.5) * 2.0);
    }
    else if(paletteId < 5.5) {
        vec3 dark = vec3(60.0, 20.0, 25.0) / 255.0;
        vec3 med = vec3(120.0, 40.0, 40.0) / 255.0;
        vec3 red = vec3(220.0, 95.0, 89.0) / 255.0;
        if(t < 0.5) color = mix(dark, med, t * 2.0);
        else color = mix(med, red, (t - 0.5) * 2.0);
    }
    else if(paletteId < 6.5) {
        vec3 darkest = vec3(0.0, 24.0, 5.0) / 255.0;
        vec3 dark = vec3(7.0, 30.0, 22.0) / 255.0;
        vec3 med = vec3(8.0, 77.0, 56.0) / 255.0;
        vec3 light = vec3(180.0, 200.0, 80.0) / 255.0;
        if(t < 0.33) color = mix(darkest, dark, t * 3.0);
        else if(t < 0.67) color = mix(dark, med, (t - 0.33) * 3.0);
        else color = mix(med, light, (t - 0.67) * 3.0);
    }
    else if(paletteId < 7.5) {
        vec3 blueDark = vec3(5.0, 13.0, 26.0) / 255.0;
        vec3 blueMed = vec3(20.0, 27.0, 55.0) / 255.0;
        vec3 blueLight = vec3(74.0, 122.0, 186.0) / 255.0;
        vec3 greenLight = vec3(180.0, 200.0, 80.0) / 255.0;
        if(t < 0.33) color = mix(blueDark, blueMed, t * 3.0);
        else if(t < 0.67) color = mix(blueMed, blueLight, (t - 0.33) * 3.0);
        else color = mix(blueLight, greenLight, (t - 0.67) * 3.0);
    }
    else if(paletteId < 8.5) {
        vec3 dark = vec3(5.0, 13.0, 26.0) / 255.0;
        vec3 med = vec3(20.0, 27.0, 55.0) / 255.0;
        vec3 light = vec3(74.0, 122.0, 186.0) / 255.0;
        if(t < 0.5) color = mix(dark, med, t * 2.0);
        else color = mix(med, light, (t - 0.5) * 2.0);
    }
    else if(paletteId < 9.5) {
        vec3 dark = vec3(20.0, 20.0, 22.0) / 255.0;
        vec3 med = vec3(71.0, 22.0, 75.0) / 255.0;
        vec3 light = vec3(129.0, 76.0, 156.0) / 255.0;
        if(t < 0.5) color = mix(dark, med, t * 2.0);
        else color = mix(med, light, (t - 0.5) * 2.0);
    }
    else if(paletteId < 10.5) {
        vec3 purpleDark = vec3(20.0, 20.0, 22.0) / 255.0;
        vec3 purpleMed = vec3(71.0, 22.0, 75.0) / 255.0;
        vec3 purpleLight = vec3(129.0, 76.0, 156.0) / 255.0;
        vec3 redLight = vec3(220.0, 95.0, 89.0) / 255.0;
        if(t < 0.33) color = mix(purpleDark, purpleMed, t * 3.0);
        else if(t < 0.67) color = mix(purpleMed, purpleLight, (t - 0.33) * 3.0);
        else color = mix(purpleLight, redLight, (t - 0.67) * 3.0);
    }
    else {
        vec3 dark = vec3(71.0, 25.0, 25.0) / 255.0;
        vec3 med = vec3(126.0, 23.0, 30.0) / 255.0;
        vec3 light = vec3(220.0, 95.0, 89.0) / 255.0;
        if(t < 0.5) color = mix(dark, med, t * 2.0);
        else color = mix(med, light, (t - 0.5) * 2.0);
    }

    return enhanceColor(color, brightness, saturation);
}

vec3 getLightShroomColor(vec3 p, float brightness, float saturation) {
    float baseHeight = 0.35;

    if(p.y > baseHeight * 0.9) {
        float heightInCap = (p.y - baseHeight) / 0.5;

        vec3 yellowGreen = vec3(180.0, 200.0, 80.0) / 255.0;
        vec3 teal = vec3(60.0, 180.0, 160.0) / 255.0;

        vec3 col = mix(teal, yellowGreen, heightInCap);
        return enhanceColor(col, brightness, saturation);
    } else {
        return vec3(0.95, 0.95, 0.93);
    }
}

vec3 getBackgroundColor(vec3 rd, float tieDyeTurb, float tieDyeSpd, float bgBrightness, float bgSaturation) {
    float turbulence = tieDyeTurb * 0.5;
    float speed = tieDyeSpd * 0.3;

    float n = 0.0;
    n += sin(rd.x * turbulence + TIME * speed) * 0.5;
    n += sin(rd.y * turbulence * 1.3 + TIME * speed * 0.7) * 0.3;
    n += sin(rd.z * turbulence * 0.8 + TIME * speed * 1.2) * 0.4;
    n += sin((rd.x + rd.y) * turbulence * 0.5 + TIME * speed * 0.9) * 0.2;
    n += sin((rd.y + rd.z) * turbulence * 0.7 + TIME * speed * 0.6) * 0.2;

    // Smooth audio influence
    n += syn_BassPresence * 0.02 + syn_MidPresence * 0.01;
    n = fract(n);

    float colorIndex = n * 12.0;
    float blend = fract(colorIndex);
    int idx = int(floor(colorIndex));

    vec3 col1, col2;

    if(idx == 0) {
        col1 = vec3(40.0, 100.0, 60.0) / 255.0;
        col2 = vec3(180.0, 200.0, 80.0) / 255.0;
    } else if(idx == 1) {
        col1 = vec3(180.0, 200.0, 80.0) / 255.0;
        col2 = vec3(60.0, 180.0, 160.0) / 255.0;
    } else if(idx == 2) {
        col1 = vec3(60.0, 180.0, 160.0) / 255.0;
        col2 = vec3(74.0, 122.0, 186.0) / 255.0;
    } else if(idx == 3) {
        col1 = vec3(74.0, 122.0, 186.0) / 255.0;
        col2 = vec3(50.0, 90.0, 140.0) / 255.0;
    } else if(idx == 4) {
        col1 = vec3(50.0, 90.0, 140.0) / 255.0;
        col2 = vec3(74.0, 122.0, 186.0) / 255.0;
    } else if(idx == 5) {
        col1 = vec3(74.0, 122.0, 186.0) / 255.0;
        col2 = vec3(110.0, 60.0, 140.0) / 255.0;
    } else if(idx == 6) {
        col1 = vec3(110.0, 60.0, 140.0) / 255.0;
        col2 = vec3(129.0, 76.0, 156.0) / 255.0;
    } else if(idx == 7) {
        col1 = vec3(129.0, 76.0, 156.0) / 255.0;
        col2 = vec3(140.0, 50.0, 50.0) / 255.0;
    } else if(idx == 8) {
        col1 = vec3(140.0, 50.0, 50.0) / 255.0;
        col2 = vec3(220.0, 95.0, 89.0) / 255.0;
    } else if(idx == 9) {
        col1 = vec3(220.0, 95.0, 89.0) / 255.0;
        col2 = vec3(180.0, 70.0, 60.0) / 255.0;
    } else if(idx == 10) {
        col1 = vec3(180.0, 70.0, 60.0) / 255.0;
        col2 = vec3(220.0, 95.0, 89.0) / 255.0;
    } else {
        col1 = vec3(220.0, 95.0, 89.0) / 255.0;
        col2 = vec3(40.0, 100.0, 60.0) / 255.0;
    }

    vec3 bgColor = mix(col1, col2, smoothstep(0.0, 1.0, blend));
    bgColor = enhanceColor(bgColor, bgBrightness, bgSaturation);
    return bgColor * 0.3;
}

// media (video/image plugged into this layer) blends over the procedural tie-dye background, same
// _isMediaActive()/_textureMedia() pattern used by Motion Amplification and Pigeon Hole -- True Mesh.
// Uses the plain screen UV (_uv), not the per-RGB-split-channel ray offset, so the background layer
// doesn't itself fracture into misaligned copies when the RGB split corruption effect is active.
vec3 shroomBackground(vec3 rd, float tieDyeTurb, float tieDyeSpd, float bgBrightness, float bgSaturation, float mediaAmt) {
    vec3 col = getBackgroundColor(rd, tieDyeTurb, tieDyeSpd, bgBrightness, bgSaturation);
    if (mediaAmt > 0.001 && _isMediaActive()) {
        col = mix(col, _textureMedia(_uv).rgb, mediaAmt);
    }
    return col;
}

// Low-poly look: quantize the smooth normal onto a coarse set of discrete facet directions so
// lighting steps in flat patches instead of shading continuously -- same faceted-flat-shading trick
// used for GL Classics' Flower Box and Pigeon Hole's own SDF flock scene (the direct architectural
// sibling of this file). Guards against the all-zero case: a normal can floor to the zero vector
// right at certain facet boundaries, and normalize(0) is undefined.
vec3 facetNormal(vec3 n, float facets) {
    vec3 q = floor(n * facets + 0.5) / facets;
    return (dot(q, q) > 1e-8) ? normalize(q) : n;
}

float map(vec3 p, out vec3 objColor, out int isCap, float mushroomCount, float showLight, float speenActive, float speenXVal, float speenYVal, float speenZVal, float circleSpeed, float bobbingSpd, float bobbingAmt, float flipSpeen, float tieDyeTurb, float tieDyeSpd, float brightness, float saturation, float shroomWarpAmt, float shroomDistortAmt, float shroomFoldAmt) {
    objColor = vec3(0.0);
    isCap = 0;
    float minDist = 1000.0;

    float speenMultiplier = 1.0 + speenActive * 29.0;

    float actualSpeenX = speenXVal * speenMultiplier;
    float actualSpeenY = speenYVal * speenMultiplier;
    float actualSpeenZ = speenZVal * speenMultiplier;

    if(showLight > 0.5) {
        vec3 lp = p;

        float lightSpeenXAngle = pendulum(TIME, actualSpeenX * 0.5);
        float lightSpeenYAngle = pendulum(TIME * 1.1, actualSpeenY * 0.5);
        float lightSpeenZAngle = pendulum(TIME * 0.9, actualSpeenZ * 0.5);

        lp.yz = rot(lightSpeenXAngle) * lp.yz;
        lp.xz = rot(lightSpeenYAngle) * lp.xz;
        lp.xy = rot(lightSpeenZAngle) * lp.xy;

        float audioScale = 1.0 + syn_BassLevel * 0.08 + syn_BassHits * 0.05;
        lp /= audioScale;
        lp = warpShroom(lp, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt);

        float lightDist = lightShroom(lp) * audioScale;
        if(lightDist < minDist) {
            minDist = lightDist;
            objColor = getLightShroomColor(lp, brightness, saturation);
            isCap = 1;
        }
    }

    int count = int(clamp(mushroomCount, 1.0, 12.0));
    float circleRadius = 4.0;

    for(int i = 0; i < 12; i++) {
        if(i >= count) break;

        float slot = float(i);
        float angle = slot * 6.283 / mushroomCount + circleSpeed * TIME * speenMultiplier;

        float bobbingPhase = angle + TIME * bobbingSpd;
        float bobbingOffset = sin(bobbingPhase) * bobbingAmt;

        vec3 offset = vec3(cos(angle) * circleRadius, bobbingOffset, sin(angle) * circleRadius);

        vec3 mushroomP = p - offset;

        float posNegMultiplier = (flipSpeen > 0.5) ? (mod(slot, 2.0) < 0.5 ? 1.0 : -1.0) : 1.0;

        float speenXAngle = pendulum(TIME, actualSpeenX) * posNegMultiplier;
        float speenYAngle = pendulum(TIME * 1.1, actualSpeenY) * posNegMultiplier;
        float speenZAngle = pendulum(TIME * 0.9, actualSpeenZ) * posNegMultiplier;

        mushroomP.yz = rot(speenXAngle) * mushroomP.yz;
        mushroomP.xz = rot(speenYAngle) * mushroomP.xz;
        mushroomP.xy = rot(speenZAngle) * mushroomP.xy;

        float audioScale = 1.0 + syn_BassLevel * 0.06 + syn_BassHits * 0.04;
        mushroomP /= audioScale;
        mushroomP = warpShroom(mushroomP, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt);

        float mushroomDist = mushroom(mushroomP, slot) * audioScale;

        if(mushroomDist < minDist) {
            minDist = mushroomDist;

            float colorId = getColorId(slot, mushroomCount);
            float baseHeight = 0.35;

            if(mushroomP.y > baseHeight * 0.9) {
                objColor = getCapColor(mushroomP, colorId, tieDyeTurb, tieDyeSpd, brightness, saturation);
                isCap = 1;
            } else {
                objColor = getStemColor(colorId, brightness, saturation);
                isCap = 0;
            }
        }
    }

    return minDist;
}

vec3 calcNormal(vec3 p, float mushroomCount, float showLight, float speenActive, float speenXVal, float speenYVal, float speenZVal, float circleSpeed, float bobbingSpd, float bobbingAmt, float flipSpeen, float tieDyeTurb, float tieDyeSpd, float brightness, float saturation, float shroomWarpAmt, float shroomDistortAmt, float shroomFoldAmt) {
    vec2 e = vec2(0.001, 0.0);
    vec3 dumColor;
    int dumCap;
    return normalize(vec3(
        map(p + e.xyy, dumColor, dumCap, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, tieDyeTurb, tieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt) - map(p - e.xyy, dumColor, dumCap, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, tieDyeTurb, tieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt),
        map(p + e.yxy, dumColor, dumCap, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, tieDyeTurb, tieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt) - map(p - e.yxy, dumColor, dumCap, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, tieDyeTurb, tieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt),
        map(p + e.yyx, dumColor, dumCap, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, tieDyeTurb, tieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt) - map(p - e.yyx, dumColor, dumCap, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, tieDyeTurb, tieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt)
    ));
}

float raymarch(vec3 ro, vec3 rd, out vec3 objColor, out int isCap, float mushroomCount, float showLight, float speenActive, float speenXVal, float speenYVal, float speenZVal, float circleSpeed, float bobbingSpd, float bobbingAmt, float flipSpeen, float tieDyeTurb, float tieDyeSpd, float brightness, float saturation, float shroomWarpAmt, float shroomDistortAmt, float shroomFoldAmt) {
    float t = 0.0;
    for(int i = 0; i < 80; i++) {
        vec3 p = ro + rd * t;
        float d = map(p, objColor, isCap, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, tieDyeTurb, tieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt);
        if(d < 0.001) break;
        t += d;
        if(t > 60.0) break;
    }
    return t;
}

// Lightweight hit/miss + depth probe for edgeDetectAmount (see the TRAILS section in renderMain).
// A Sobel/gradient filter on the rendered image's LUMINANCE can't tell a true silhouette (background
// meets mushroom) from two neighboring points on the same smooth surface that just happen to shade
// differently -- both produce a real luminance jump. The correct signal is hit/miss and depth, so
// this just re-raymarches (no shading) at a few neighboring screen directions and lets renderMain
// compare hit flags and distances. Unlike Pigeon Hole -- True Mesh's version of this (which needed a
// separate cheap probe to skip an expensive shading pass), raymarch() here is already the "cheap"
// unshaded version, so the probe just calls it directly rather than duplicating it.
float silhouetteProbe(vec2 uv, vec3 ro, vec3 forward, vec3 right, vec3 up, float mushroomCount, float showLight, float speenActive, float speenXVal, float speenYVal, float speenZVal, float circleSpeed, float bobbingSpd, float bobbingAmt, float flipSpeen, float tieDyeTurb, float tieDyeSpd, float brightness, float saturation, float shroomWarpAmt, float shroomDistortAmt, float shroomFoldAmt, out float tOut) {
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    vec3 objColor;
    int isCap;
    float t = raymarch(ro, rd, objColor, isCap, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, tieDyeTurb, tieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt);
    tOut = t;
    return t < 60.0 ? 1.0 : 0.0;
}

vec3 screenBlend(vec3 base, vec3 add) {
    return 1.0 - (1.0 - base) * (1.0 - clamp(add, 0.0, 1.0));
}

// Renders one channel (a plain pass, or one of the 3 offset passes under RGB split corruption).
// Applies the SHROOM CORRUPTION ray-space effects (glitch/twist -- the 2 that displace/rotate the ray
// itself before the march, as opposed to warp/distort/fold which domain-warp the SDF sample point
// inside map()) and the low-poly facet blend, then shades and fogs into the background.
vec3 renderChannel(vec2 uv, vec3 ro, vec3 forward, vec3 right, vec3 up,
                    float mushroomCount, float showLight, float speenActive, float speenXVal, float speenYVal, float speenZVal,
                    float circleSpeed, float bobbingSpd, float bobbingAmt, float flipSpeen,
                    float shroomTieDyeTurb, float shroomTieDyeSpd, float brightness, float saturation,
                    float bgTieDyeTurb, float bgTieDyeSpd, float bgBrightness, float bgSaturation, float mediaAmt,
                    float lowPolyAmt, float lowPolyFacets,
                    float shroomWarpAmt, float shroomDistortAmt, float shroomFoldAmt,
                    float shroomGlitchAmt, float shroomGlitchRes, float shroomTwistAmt,
                    out float hitOut) {
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);

    vec3 marchRo = ro;
    vec3 marchRd = rd;

    // shroomGlitch: coarse screen-space cells randomly displace the ray before it ever reaches the
    // SDF, so chunks of the rendered circle appear to shatter/jump rather than the whole scene
    // wobbling uniformly. Genuinely different from the 2D CORRUPTION bank below, which only ever
    // shuffles the final 2D pixel after the 3D render is already done.
    if (shroomGlitchAmt > 0.001) {
        vec2 gCell = floor(uv * shroomGlitchRes);
        float gHash = hash(gCell.x * 13.1 + gCell.y * 7.3 + floor(TIME * 12.0));
        if (gHash > 1.0 - shroomGlitchAmt) {
            vec3 jitter = vec3(hash(gHash + 1.0) - 0.5, hash(gHash + 2.0) - 0.5, hash(gHash + 3.0) - 0.5);
            marchRo += jitter * 2.0;
        }
    }

    // shroomTwist: a second, genuinely different 3D corruption -- rotates the ray origin AND
    // direction together around the world origin per screen cell, so a triggered chunk reads as a
    // coherently twisted/sheared piece of the circle rather than a translated copy of it. Reuses
    // shroomGlitchRes for the cell grid so the two effects layer at matching scale.
    if (shroomTwistAmt > 0.001) {
        vec2 twCell = floor(uv * shroomGlitchRes);
        float twHash = hash(twCell.x * 19.3 + twCell.y * 5.9 + floor(TIME * 9.0));
        if (twHash > 1.0 - shroomTwistAmt) {
            float twistAngle = (twHash - 0.5) * 6.283;
            marchRo.xz = rot(twistAngle) * marchRo.xz;
            marchRd.xz = rot(twistAngle) * marchRd.xz;
        }
    }

    vec3 objColor;
    int isCap;
    float hitDist = raymarch(marchRo, marchRd, objColor, isCap, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt);

    vec3 bgColor = shroomBackground(rd, bgTieDyeTurb, bgTieDyeSpd, bgBrightness, bgSaturation, mediaAmt);
    hitOut = (hitDist < 60.0) ? 1.0 : 0.0;
    if (hitDist >= 60.0) return bgColor;

    vec3 p = marchRo + marchRd * hitDist;
    vec3 normal = calcNormal(p, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt);
    // Low-poly: blend toward the faceted normal rather than snapping, so the control sweeps smoothly
    // from the sculpted look into a flat-shaded one instead of popping between them.
    if (lowPolyAmt > 0.001) {
        normal = normalize(mix(normal, facetNormal(normal, lowPolyFacets), lowPolyAmt));
    }

    vec3 lightDir = normalize(vec3(1.0, 1.0, -0.5));
    float diff = max(dot(normal, lightDir), 0.0);
    float ambient = 0.45;

    vec3 col = objColor * (ambient + diff * 0.55);
    if (isCap == 1) {
        col += objColor * syn_HighHits * 0.5;
    }

    float fog = 1.0 - exp(-hitDist * 0.012);
    return mix(col, bgColor, fog);
}

vec4 renderMain() {
    vec2 uv = _uvc;

    float bobbingSpeed = bobbingXY.x;
    float bobbingAmount = bobbingXY.y;
    float mushroomSat = mushroomColors.x;
    float mushroomBright = mushroomColors.y;
    float bgSat = backgroundColors.x;
    float bgBright = backgroundColors.y;
    float camDistCtrl = cameraXY.x;
    float camHeightCtrl = cameraXY.y;

    // Map counter 0-7 to shroom counts: 0→2, 1→4, 2→6, 3→8, 4→10, 5→12, 6→12+light, 7→2(reset)
    float counterVal = mod(shroomCount, 7.0);
    float mushroomCount;
    float showLight;

    if(counterVal < 0.5) {
        mushroomCount = 2.0;
        showLight = 0.0;
    } else if(counterVal < 1.5) {
        mushroomCount = 4.0;
        showLight = 0.0;
    } else if(counterVal < 2.5) {
        mushroomCount = 6.0;
        showLight = 0.0;
    } else if(counterVal < 3.5) {
        mushroomCount = 8.0;
        showLight = 0.0;
    } else if(counterVal < 4.5) {
        mushroomCount = 10.0;
        showLight = 0.0;
    } else if(counterVal < 5.5) {
        mushroomCount = 12.0;
        showLight = 0.0;
    } else {
        mushroomCount = 12.0;
        showLight = 1.0;
    }

    float speenXVal = clamp(speenX, 0.0, 2.0);
    float speenYVal = clamp(speenY, 0.0, 2.0);
    float speenZVal = clamp(speenZ, 0.0, 2.0);
    float circleSpeed = clamp(speenR, 0.0, 2.0);
    float bobbingSpd = clamp(bobbingSpeed, 0.0, 3.0);
    float bobbingAmt = clamp(bobbingAmount, 0.0, 1.0);

    // Separate tie-dye controls for shrooms and background
    float shroomTieDyeTurb = clamp(shroomTieDyeTurbulence, 0.5, 10.0);
    float shroomTieDyeSpd = clamp(shroomTieDyeSpeed, 0.0, 3.0);
    float bgTieDyeTurb = clamp(bgTieDyeTurbulence, 0.5, 10.0);
    float bgTieDyeSpd = clamp(bgTieDyeSpeed, 0.0, 3.0);

    float brightness = clamp(mushroomBright, 0.5, 3.0);
    float saturation = clamp(mushroomSat, 0.5, 3.0);
    float bgBrightness = clamp(bgBright, 0.1, 2.0);
    float bgSaturation = clamp(bgSat, 0.5, 3.0);
    float speenActive = clamp(speenBang, 0.0, 1.0);
    float mediaAmt = clamp(backgroundMediaAmount, 0.0, 1.0);

    // LOW POLY -- facet-normal blend (same technique as Pigeon Hole's own SDF flock scene, the
    // direct architectural sibling of this file). lowPolyReactivity lets bass hits pulse the chunky
    // look in on top of the base amount instead of it only ever being a static setting.
    float lowPolyAmt = clamp(lowPolyAmount + lowPolyReactivity * syn_BassHits, 0.0, 1.0);
    float lowPolyFacets = clamp(lowPolyFacetCount, 2.0, 20.0);

    // SHROOM CORRUPTION (3D) -- resetShroomsBang is a panic button: instantly snaps every one of
    // these to 0 (fast-attack envelope) and eases them back over about a second, regardless of
    // where the sliders sit.
    float resetSuppress = 1.0 - clamp(resetShroomsEnv, 0.0, 1.0);
    float shroomGlitchAmt = clamp(shroomGlitch, 0.0, 1.0) * (0.3 + syn_BassHits * 1.7) * resetSuppress;
    float shroomGlitchRes = clamp(shroomGlitchResolution, 2.0, 24.0);
    float shroomTwistAmt = clamp(shroomTwist, 0.0, 1.0) * (0.3 + syn_BassHits * 1.7) * resetSuppress;
    // meshWarp/meshDistort/meshFold's audio swing in Pigeon Hole -- True Mesh (0.3-2.0x, shared with
    // the discrete-trigger glitch/twist) read as too violent once applied to a CONTINUOUS full-object
    // deformation instead of a probabilistic per-cell one -- toned to 0.85-1.15x here from the start
    // rather than shipping the too-strong version and waiting to hear it back.
    float shroomWarpAmt = clamp(shroomWarp, 0.0, 1.0) * (0.85 + syn_BassHits * 0.3) * resetSuppress;
    float shroomDistortAmt = clamp(shroomDistort, 0.0, 1.0) * (0.85 + syn_BassHits * 0.3) * resetSuppress;
    float shroomFoldAmt = clamp(shroomFold, 0.0, 1.0) * (0.85 + syn_BassHits * 0.3) * resetSuppress;

    // 2D CORRUPTION envelopes (smoothed in script.js from bang pads, not native "bang smooth" --
    // full control over the attack/decay shape, per established preference)
    float shatterAmt = clamp(corruptionEnv, 0.0, 1.0);
    float blockGlitchAmt = clamp(blockGlitchEnv, 0.0, 1.0);
    float shiftAmt = clamp(shiftEnv, 0.0, 1.0);
    float rgbSplitAmt = clamp(rgbShiftEnv, 0.0, 1.0);
    float invertAmt = clamp(invertEnv, 0.0, 1.0);
    float zoomPunchAmt = clamp(zoomPunchEnv, 0.0, 1.0);
    float pixelSortAmt = clamp(pixelSort, 0.0, 0.2);
    float pixelSortCols = clamp(pixelSortWidth, 2.0, 60.0);
    float scanlineAmt = clamp(scanlines, 0.0, 2.0);
    float blockGlitchSlider = clamp(blockGlitchAmount, 0.0, 1.0);
    float screenShakeSlider = clamp(screenShake, 0.0, 1.0);
    float rgbSplitSlider = clamp(rgbSplitAmount, 0.0, 1.0);

    // Audio reactivity - always active
    float audioBassCorrupt = syn_BassHits;
    float audioMidCorrupt = syn_MidHighHits;

    vec2 workingUV = uv;

    // CORRUPTION: Kaleidoscope, ported from Metal Shader -- wraps the angle around frame center into
    // kaleidoSegments repeating wedges.
    if(kaleidoscope > 0.5) {
        float kSeg = clamp(kaleidoSegments, 2.0, 16.0);
        float kAngle = atan(workingUV.y, workingUV.x);
        float kSegAngle = 6.28318530718 / kSeg;
        kAngle = mod(kAngle, kSegAngle);
        float kRadius = length(workingUV);
        workingUV = vec2(cos(kAngle), sin(kAngle)) * kRadius;
    }

    // CORRUPTION: zoomPunch -- a quick impact zoom-in pulse (envelope smoothed, no hard cut)
    if(zoomPunchAmt > 0.001) {
        workingUV *= 1.0 - zoomPunchAmt * 0.35;
    }

    // CORRUPTION: Shattered Glass Effect (from corruptionBang)
    if(shatterAmt > 0.01) {
        // Create polygon/shard boundaries
        vec2 shardCoord = floor(workingUV * 8.0);
        float shardHash = hash(shardCoord.x * 10.0 + shardCoord.y + floor(TIME * 0.5));

        // Each shard gets a random offset and rotation
        float shardAngle = shardHash * 6.28 * shatterAmt;
        float shardDist = (shardHash - 0.5) * 0.4 * shatterAmt;

        vec2 shardCenter = (shardCoord + 0.5) / 8.0;
        vec2 toCenter = workingUV - shardCenter;

        // Rotate around shard center
        float c = cos(shardAngle);
        float s = sin(shardAngle);
        mat2 rotMat = mat2(c, -s, s, c);
        toCenter = rotMat * toCenter;

        // Offset shard
        toCenter += vec2(cos(shardHash * 6.28), sin(shardHash * 6.28)) * shardDist;

        workingUV = shardCenter + toCenter;

        // Add shard edges/cracks
        vec2 shardEdge = fract(workingUV * 8.0);
        float edgeDist = min(min(shardEdge.x, 1.0 - shardEdge.x), min(shardEdge.y, 1.0 - shardEdge.y));
        if(edgeDist < 0.05 * shatterAmt) {
            workingUV += vec2(hash(shardHash + 10.0) - 0.5, hash(shardHash + 20.0) - 0.5) * 0.1;
        }
    }

    // CORRUPTION: Screen Shift/Shake (from shiftBang + slider + audio)
    float totalShake = shiftAmt + screenShakeSlider * audioBassCorrupt;
    if(totalShake > 0.01) {
        float shakeX = (hash(floor(TIME * 10.0)) - 0.5) * totalShake * 0.3;
        float shakeY = (hash(floor(TIME * 10.0) + 1.0) - 0.5) * totalShake * 0.2;
        workingUV += vec2(shakeX, shakeY);
    }

    // CORRUPTION: Pixel Sort Effect (slider + audio). pixelSortWidth: column count the screen is
    // sliced into -- lower = fewer, wider streaks, higher = many thin ones. Was hardcoded to 15.
    float totalPixelSort = pixelSortAmt + pixelSortAmt * audioMidCorrupt * 2.0;
    if(totalPixelSort > 0.001) {
        float sortLine = floor(workingUV.x * pixelSortCols);
        float sortShift = hash(sortLine + floor(TIME * 5.0)) * totalPixelSort * 2.0;
        workingUV.y += sortShift;
    }

    // CORRUPTION: Block Glitch (from bang + slider + audio)
    float totalBlockGlitch = max(blockGlitchAmt, blockGlitchSlider * audioBassCorrupt);
    if(totalBlockGlitch > 0.01) {
        vec2 blockCoord = floor(workingUV * 12.0);
        float blockHash = hash(blockCoord.x + blockCoord.y * 10.0 + floor(TIME * 3.0));
        if(blockHash > (0.85 - totalBlockGlitch * 0.3)) {
            vec2 offset = vec2(
                hash(blockHash) - 0.5,
                hash(blockHash + 1.0) - 0.5
            ) * 0.4 * totalBlockGlitch;
            workingUV += offset;
        }
    }

    // ----- camera -----
    // Real interactive controls: left-click-drag orbits the camera around the circle, right-click-
    // drag zooms -- both ported from Pigeon Hole -- True Mesh's script.js (itself studied from
    // Synesthesia's own 3D Orbit Camera example scene). The old camera only ever looked from a fixed
    // -Z angle with no way to see the circle from another side short of the automatic autoCamera
    // orbit -- cameraXY (Distance/Height) still sets the base framing, drag now actually orbits it.
    float camDistBase = clamp(camDistCtrl, 8.0, 30.0);
    float camHeight = clamp(camHeightCtrl, 0.0, 12.0);
    float camDist = clamp(camDistBase - zoomDrag * 3.0, 4.0, 40.0);

    vec3 lookAt = vec3(0.0, 1.0, 0.0);

    float camYaw = viewYaw;
    // clamped short of +-PI/2 to avoid the gimbal-lock singularity directly overhead/underneath,
    // where forward becomes parallel to the world-up reference and cross() degenerates
    float camPitch = clamp(viewPitch, -1.4, 1.4);
    vec3 orbitDir = vec3(sin(camYaw) * cos(camPitch), sin(camPitch), -cos(camYaw) * cos(camPitch));
    // camHeight - 1.0 reproduces the original fixed camera's absolute height at the resting
    // yaw=0/pitch=0 view (orbitDir=(0,0,-1) there, same as the old ro=(0,camHeight,-camDist))
    vec3 roStatic = lookAt + orbitDir * camDist + vec3(0.0, camHeight - 1.0, 0.0);

    float autoSpeed = clamp(autoCameraSpeed, 0.1, 2.0);
    float autoTime = TIME * autoSpeed;
    float orbitAngle = autoTime * 0.3;
    float autoDist = camDistBase + sin(autoTime * 0.5) * 3.0 + syn_BassLevel * 2.0;
    float autoHeight = camHeight + sin(autoTime * 0.7) * 1.5 + syn_MidLevel * 1.5 + syn_BassHits * 0.5;
    vec3 roAuto = vec3(cos(orbitAngle) * autoDist, autoHeight, sin(orbitAngle) * autoDist);

    vec3 ro = mix(roStatic, roAuto, clamp(autoCamera, 0.0, 1.0));

    vec3 forward = normalize(lookAt - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);

    // Check if we need RGB split
    float totalRGBSplit = rgbSplitAmt + rgbSplitSlider * audioBassCorrupt;

    vec3 col;
    // hitMask: 1 where a mushroom was actually hit, 0 on background -- lets bgEcho below mask itself
    // to background-only pixels instead of painting over the shrooms
    float hitMask;

    if(totalRGBSplit > 0.01) {
        // RGB Split - render with 3 slightly offset UVs (still 3x cost but necessary for real effect)
        float splitOffset = totalRGBSplit * 0.015;

        float hitR, hitB;
        float colR = renderChannel(workingUV + vec2(splitOffset, 0.0), ro, forward, right, up, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, bgTieDyeTurb, bgTieDyeSpd, bgBrightness, bgSaturation, mediaAmt, lowPolyAmt, lowPolyFacets, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt, shroomGlitchAmt, shroomGlitchRes, shroomTwistAmt, hitR).r;
        float colG = renderChannel(workingUV, ro, forward, right, up, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, bgTieDyeTurb, bgTieDyeSpd, bgBrightness, bgSaturation, mediaAmt, lowPolyAmt, lowPolyFacets, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt, shroomGlitchAmt, shroomGlitchRes, shroomTwistAmt, hitMask).g;
        float colB = renderChannel(workingUV - vec2(splitOffset, 0.0), ro, forward, right, up, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, bgTieDyeTurb, bgTieDyeSpd, bgBrightness, bgSaturation, mediaAmt, lowPolyAmt, lowPolyFacets, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt, shroomGlitchAmt, shroomGlitchRes, shroomTwistAmt, hitB).b;

        col = vec3(colR, colG, colB);
    } else {
        col = renderChannel(workingUV, ro, forward, right, up, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, bgTieDyeTurb, bgTieDyeSpd, bgBrightness, bgSaturation, mediaAmt, lowPolyAmt, lowPolyFacets, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt, shroomGlitchAmt, shroomGlitchRes, shroomTwistAmt, hitMask);
    }

    // CORRUPTION: Scanlines
    if(scanlineAmt > 0.01) {
        float scanline = sin(uv.y * RENDERSIZE.y * 2.0) * 0.5 + 0.5;
        col *= 1.0 - (scanline * scanlineAmt * 0.4);
    }

    // CORRUPTION: Shatter darkening on edges
    if(shatterAmt > 0.01) {
        vec2 shardEdge = fract(uv * 8.0);
        float edgeDist = min(min(shardEdge.x, 1.0 - shardEdge.x), min(shardEdge.y, 1.0 - shardEdge.y));
        if(edgeDist < 0.03) {
            col *= 1.0 - shatterAmt * 0.5;
        }
    }

    // CORRUPTION: invert -- quick color-inversion pulse (envelope smoothed -- a color-space flip,
    // not a brightness flash, so it doesn't run into the seizure-flashing concern a strobe would)
    if(invertAmt > 0.001) {
        col = mix(col, 1.0 - col, invertAmt);
    }

    // TRAILS: afterimage/feedback trail -- off by default. Classic phosphor-persistence mix() rather
    // than a screen-blend composite: screen blend fixes raw addition's lack of an upper bound, but
    // it's still a one-way brightening operator fed every frame, so it still creeps toward white over
    // a long session at high settings. mix() is a convex combination, structurally can't exceed
    // whichever input is brighter, stable at any trailAmt up to 1.
    float trailAmt = clamp(feedbackAmount, 0.0, 0.97) * (1.0 + syn_BassHits * 0.15);
    trailAmt = min(trailAmt, 0.985);
    if(trailAmt > 0.001) {
        vec3 prevCol = texture2D(syn_FinalPass, _uv).rgb;
        col = mix(col, prevCol, trailAmt);
    }

    // TRAILS: bgEcho -- a small zoom+rotate+kaleido-fold transform applied once per frame and left to
    // compound over many frames through the feedback texture, building a receding spiral of copies.
    // (Averaging several samples of one frame is a blur operation, not a "copies" effect, regardless
    // of how far apart the samples are -- this compounds across TIME instead, which is what actually
    // produces the nested-copies look, same lesson learned building this for Pigeon Hole.) Masked to
    // background-only pixels (hitMask==0) so it never paints over the mushrooms themselves.
    float echoAmt = clamp(bgEchoAmount, 0.0, 2.0);
    if(echoAmt > 0.001) {
        vec2 base = _uv - 0.5;
        float zoom = mix(1.0, 0.965, clamp(echoAmt * 0.5, 0.0, 1.0));
        vec2 sp = base * zoom;
        sp = rot(TIME * 0.06) * sp;
        float ang = atan(sp.y, sp.x);
        float r = length(sp);
        float segAngle = 6.28318 / 5.0;
        ang = mod(ang, segAngle);
        if(ang > segAngle * 0.5) ang = segAngle - ang;
        sp = vec2(cos(ang), sin(ang)) * r;
        vec2 sampleUV = clamp(sp + 0.5, 0.0, 1.0);
        vec3 echoSample = texture2D(syn_FinalPass, sampleUV).rgb;
        float echoBlend = clamp(echoAmt * (0.5 + syn_BassHits * 0.2), 0.0, 1.0) * (1.0 - hitMask);
        col = mix(col, echoSample, echoBlend);
    }

    // TRAILS: edgeDetect -- real silhouette/depth-based outline, not an image-luminance Sobel filter
    // (which can't distinguish a true silhouette from two neighboring points on the same smooth
    // surface shading differently). 4 extra hit-test raymarches per pixel when active -- genuinely
    // more expensive, but that's the real cost of a correct outline rather than shading noise.
    float edgeAmt = clamp(edgeDetectAmount, 0.0, 1.0);
    if(edgeAmt > 0.001) {
        float pixelStep = 1.3 / RENDERSIZE.y;
        float tC, tL, tR, tU, tD;
        float hC = silhouetteProbe(workingUV, ro, forward, right, up, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt, tC);
        float hL = silhouetteProbe(workingUV + vec2(-pixelStep, 0.0), ro, forward, right, up, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt, tL);
        float hR = silhouetteProbe(workingUV + vec2(pixelStep, 0.0), ro, forward, right, up, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt, tR);
        float hU = silhouetteProbe(workingUV + vec2(0.0, pixelStep), ro, forward, right, up, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt, tU);
        float hD = silhouetteProbe(workingUV + vec2(0.0, -pixelStep), ro, forward, right, up, mushroomCount, showLight, speenActive, speenXVal, speenYVal, speenZVal, circleSpeed, bobbingSpd, bobbingAmt, flipSpeen, shroomTieDyeTurb, shroomTieDyeSpd, brightness, saturation, shroomWarpAmt, shroomDistortAmt, shroomFoldAmt, tD);

        float hitEdge = abs(hC - hL) + abs(hC - hR) + abs(hC - hU) + abs(hC - hD);

        float depthEdge = 0.0;
        if(hC > 0.5 && hL > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tL));
        if(hC > 0.5 && hR > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tR));
        if(hC > 0.5 && hU > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tU));
        if(hC > 0.5 && hD > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tD));

        float edge = clamp(hitEdge + depthEdge * 0.5, 0.0, 1.0);
        vec3 edgeColor = vec3(0.3, 1.0, 0.9);
        col = mix(col, col + edgeColor * edge, edgeAmt);
    }

    // TRAILS: streak -- directional light-trail/comet smear, slowly rotating direction. A different
    // trail character from bgEcho's radial spiral (linear smear instead), same compound-through-
    // feedback principle. Whole-frame (not masked) since dragging the shrooms' own motion is the point.
    float streakAmt = clamp(streakAmount, 0.0, 1.0);
    if(streakAmt > 0.001) {
        float streakAngle = TIME * 0.15;
        vec2 streakDir = vec2(cos(streakAngle), sin(streakAngle));
        vec2 streakUV = clamp(_uv - streakDir * streakAmt * 0.02, 0.0, 1.0);
        vec3 streakSample = texture2D(syn_FinalPass, streakUV).rgb;
        col = mix(col, streakSample, streakAmt * (0.5 + syn_BassHits * 0.2));
    }

    return vec4(col, 1.0);
}
