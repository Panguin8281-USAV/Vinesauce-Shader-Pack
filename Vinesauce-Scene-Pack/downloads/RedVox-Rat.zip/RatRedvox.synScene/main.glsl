// RedVox Rat -- ray-traced mesh viewer
// Real .obj model, ray-traced per-pixel against the actual baked triangles (Moller-Trumbore),
// same technique proven in Pigeon Hole Mesh -- and deliberately built the SAME way that scene
// works: triangles are literal unrolled GLSL calls, not data-texture PNGs.
//
// History: this scene was first built on the Mesh Viewer Tool's data-texture pipeline (geometry
// packed into small PNGs, decoded with texture2D + 16-bit fixed-point unpacking). That pipeline's
// own README flagged an unverified risk up front: whether Synesthesia's IMAGES loader applies any
// gamma/color-space conversion on upload, which would scramble the exact integer byte values the
// format depends on. Loaded in-app, debugCalibration flashed RED on both this model and its sibling
// -- confirming that risk is real, not theoretical. Since the corruption happens in Synesthesia's
// own texture loader (outside this file's control), the fix isn't a packing tweak, it's not using a
// data texture for geometry at all. Switched to Pigeon Hole Mesh's approach instead: bake triangles
// as literal `triHit(...)` calls directly in GLSL source, and inverse-transform the RAY into local
// model space rather than transforming vertices -- so geometry is immune to any texture-loader
// behavior. The diffuse color texture is untouched by this switch: it's an ordinary photo texture
// that only needs to look right, not decode to exact bits, so the same IMAGES mechanism that broke
// for packed geometry data is fine for it.
// Version 1.5 (redvoxrat_syn_main_v2_0): Sam found the right pizza placement live in Synesthesia
// (pizzaScale=0.82, pizzaPosition=(2.00,-0.16), pizzaDepth=0.30, pizzaOrientation=(90,82.80)) and
// asked to lock it in -- baked those four values as PIZZA_SCALE/PIZZA_POSITION/PIZZA_DEPTH/
// PIZZA_ORIENTATION consts in pizzaHit() and removed the four adjustment controls from scene.json,
// since there's nothing left to tune. showPizza (the on/off toggle) stays.
// Version 1.4 (redvoxrat_syn_main_v1_9): Sam sent a real low-poly pizza model ("you suck at making
// pizza") -- replaced the entire hand-authored primitive wedge+pepperoni from v1.3 with a real baked
// mesh (392 triangles, converted offline from the source OBJ/MTL the same way this file's own rat
// mesh was baked -- see the PIZZA section's full comment below for the axis-remap analysis and why).
// Removed cylHitZ() (the Z-aligned capped-cylinder helper added in v1.3 for the old primitive
// pepperoni) since nothing uses it anymore with real mesh data -- unlike cylHit(), which predates
// this pizza feature entirely and stays as general-purpose infrastructure. Added pizzaOrientation
// (yaw/pitch) alongside the existing pizzaScale/pizzaPosition/pizzaDepth so the real mesh's
// orientation can also be nudged live, same reasoning as modelOrientation existing for the rat.
// Version 1.3 (redvoxrat_syn_main_v1_8): (1) pizza reworked at Sam's request -- was too small to
// spot and lying flat like it was on a table; rebuilt bigger (default size ~matches the rat's own
// local bounding box) and reoriented to hang down from a point (tip up, crust drooping below,
// cheese face toward the default camera), with pizzaScale/pizzaPosition/pizzaDepth controls so it
// can be dragged into place against the model's mouth live -- there's no real mouth/landmark data
// for this rat, so the shipped default is a starting guess, not a verified fit. Pepperoni now use a
// new cylHitZ() (a Z-aligned sibling of cylHit()) since they need to sit flush against the slice's
// now-vertical face instead of a horizontal one. (2) ported Pigeon Hole Mesh's background and style:
// shadeStyle gained a third option, Neon Blue/Red (near-black body + audio-reactive blue rim light),
// and the background is now style-aware (ratBackground(), replacing the old flat 2-tone gradient) --
// Neon gets Pigeon Hole Mesh's cold horizon + red laser-grid glow, Textured/Flat Lit get its warm
// bokeh-haze look. backgroundBrightness replaced by backgroundColors (sat+bright) + backgroundIntensity
// (glow strength), matching Pigeon Hole Mesh's exact control names.
// Version 1.2 (redvoxrat_syn_main_v1_7): added showPizza, a toggle-able easter-egg prop -- a slice
// of pizza built entirely from primitive flat shapes (see the PIZZA section below): an 8-triangle
// hand-authored wedge for the slice plus capped cylinders (cylHit(), already defined in this file
// but never actually used until now) for the pepperoni. Lives in the model's own local space just
// past its +X edge, so it inherits the exact same idle-spin/bob/SPEEN/wobble/mirror/corruption
// transform as the rat for free -- no separate positioning or animation code needed.
// Version 1.1 (redvoxrat_syn_main_v1_6): removed the DEBUG group (debugHoles, the hole-finder used
// while diagnosing the data-texture-vs-baked-triangle issue above -- no longer needed now that
// geometry is baked triangles, not a decodable data texture) and ported Pigeon Hole Mesh's full
// generic control set: SPEEN tumble, wobble, camera view-preset bangs, the TRAILS group
// (feedback/bgEcho/edgeDetect/streak), the full 2D CORRUPTION bank, a RAT CORRUPTION bank
// (meshGlitch/meshTwist/meshWarp/meshDistort/meshFold + resetModelBang), and N64/PS1-style
// LOW POLY (real vertex snapping + faceted normals, distinct from the existing facetShading color
// jitter). Left out anything specific to Pigeon Hole Mesh's own bird anatomy/dual-pose rig
// (pigeonStyle, pigeonPose, neckIridescence) since this template has no equivalent concept.
// Version 1.0 (redvoxrat_syn_main_v1_5)

// ===== HELPERS =====

mat2 rot(float a) {
    float c = cos(a);
    float s = sin(a);
    return mat2(c, -s, s, c);
}

float hash(float n) {
    return fract(sin(n) * 43758.5453);
}

// SPEEN oscillation, ported from Pigeon Hole Mesh (itself ported from Vineshroom SPEEN Circle) --
// a bounded sin-based swing rather than a raw TIME*amt accumulation, so it settles into a steady
// back-and-forth tumble instead of winding tighter the longer the scene runs.
float pendulum(float t, float rotations) {
    return sin(t * 0.5) * rotations * 2.0 * PI;
}

// Low-poly look, ported from Pigeon Hole Mesh: normal-faceting alone reads as flat-shaded but still
// smooth-SILHOUETTE -- real N64/PS1 chunkiness needs the actual GEOMETRY collapsed onto a coarse
// lattice too (see snapVertex below), not just the shading.
const float LOW_POLY_FACETS = 1.3;
vec3 facetNormal(vec3 n) {
    vec3 q = floor(n * LOW_POLY_FACETS + 0.5) / LOW_POLY_FACETS;
    return (dot(q, q) > 1e-8) ? normalize(q) : n;
}

// PS1-style vertex snapping: collapses vertex positions onto a coarse lattice, the other half of
// the "real geometry, not just shading" low-poly look. Ported from Pigeon Hole Mesh.
vec3 snapVertex(vec3 p, float amt) {
    if (amt < 0.001) return p;
    float grid = mix(400.0, 7.0, amt);
    return mix(p, floor(p * grid + 0.5) / grid, amt);
}

vec3 enhanceColor(vec3 col, float bright, float sat) {
    col *= bright;
    float gray = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(gray), col, sat);
    return col;
}

// composites new content over a faded feedback trail with a screen blend instead of raw addition --
// bounded to [0,1] regardless of how many times/how brightly it's applied. Not used by default here
// (no feedback trail control on this simple template), kept available since it's the proven-correct
// compositing pattern if a scene built on this template ever adds one (see [[synesthesia-prefs]]:
// screenBlend is safe for a single composite, NOT automatically safe for repeated frame-feedback --
// that needs a mix()-based moving average instead, since screenBlend alone still only pushes
// brighter, no decay term, and will converge to white over many frames).
vec3 screenBlend(vec3 base, vec3 add) {
    return 1.0 - (1.0 - base) * (1.0 - clamp(add, 0.0, 1.0));
}

// cheap reject: does the ray's line pass within `radius` of `center`? (line test, not segment --
// fine here since the camera always sits in front of the object at a sane working distance)
// NOTE: must NOT assume rd is unit-length -- renderChannel's inverse-scale ray trick feeds this
// a local-space direction of length 1/modelScale, not 1. The original version's `d2 = dot(oc,oc) -
// tca*tca` is only the true squared perpendicular distance when |rd|=1; above scale=1, |rd|<1
// shrinks tca faster than it should, so d2 drifts toward the full (non-perpendicular) distance and
// the cull test increasingly rejects rays that should actually hit -- the real bug behind "the model
// disappears at higher modelScale" (the real triHit() test is unaffected either way; only this
// cheap-reject shortcut assumed a unit direction). Dividing by dot(rd,rd) makes it exact for any rd.
bool raySphereNear(vec3 ro, vec3 rd, vec3 center, float radius) {
    vec3 oc = center - ro;
    float rd2 = max(dot(rd, rd), 1e-12);
    float tca = dot(oc, rd);
    float d2 = dot(oc, oc) - (tca * tca) / rd2;
    return d2 <= radius * radius;
}

// ===== RAY / MESH INTERSECTION =====

// Rat Corruption state (meshWarp/meshDistort/meshFold) plus lowPolyAmount's vertex-snap half, read
// directly by triHit() below (see renderChannel, which sets these once per render call). Plain
// globals rather than threading four more parameters through triHit() and its many hundred unrolled
// call sites -- ported straight from Pigeon Hole Mesh's identical pattern.
float gMeshWarpAmt = 0.0;
float gMeshDistortAmt = 0.0;
float gMeshFoldAmt = 0.0;
float gLowPolyAmt = 0.0;

// approximate centroid of the baked mesh data (measured directly off the triangle constants below),
// used as the pivot for meshDistort's twist and meshFold's mirror-fold
const vec3 MESH_PIVOT = vec3(0.0, 0.0, 0.0);

// Real per-vertex distortion, applied to a triangle's actual corners before intersecting -- the
// only way to get a genuine surface-varying warp out of a ray-TRIANGLE test (as opposed to
// raymarching an SDF, where the sample point can be warped at every step along the ray). Ported
// straight from Pigeon Hole Mesh.
vec3 warpVertex(vec3 p) {
    vec3 wp = p;
    if (gMeshWarpAmt > 0.001) {
        wp += vec3(
            sin(p.y * 4.5 + TIME * 2.0) * sin(p.z * 3.3 + TIME * 1.3),
            sin(p.z * 3.8 + TIME * 1.7) * sin(p.x * 4.7 + TIME * 2.1),
            sin(p.x * 3.4 + TIME * 1.1) * sin(p.y * 4.1 + TIME * 1.9)
        ) * gMeshWarpAmt * 0.16;
    }
    if (gMeshDistortAmt > 0.001) {
        float twistAngle = (wp.y - MESH_PIVOT.y) * gMeshDistortAmt * 1.8 + sin(TIME * 0.5) * gMeshDistortAmt * 0.6;
        wp.xz = rot(twistAngle) * wp.xz;
    }
    if (gMeshFoldAmt > 0.001) {
        vec3 fp = wp - MESH_PIVOT;
        for (int i = 0; i < 2; i++) {
            fp = abs(fp);
            fp -= 0.28 * gMeshFoldAmt;
            fp.xz = rot(0.9 + float(i) * 0.6) * fp.xz;
        }
        wp = mix(wp, fp + MESH_PIVOT, gMeshFoldAmt);
    }
    if (gLowPolyAmt > 0.001) {
        wp = snapVertex(wp, gLowPolyAmt);
    }
    return wp;
}

// Moller-Trumbore, exact and standard -- ported straight from Pigeon Hole Mesh's proven
// implementation. facetSeed is a per-triangle random value baked in at conversion time, used for
// the optional low-poly facet-tint style below. useFlat/flatColor carry that triangle's source
// .mtl material color, baked in at conversion time for whichever triangles came from a material
// with no texture of its own (a real bug found in practice: with only ONE shared diffuse atlas,
// a model with other, untextured materials -- e.g. a prop held in the hand -- had no meaningful
// UV for those triangles at all, so they sampled an unrelated, often-blank part of the atlas and
// read as "missing texture" even though nothing was actually broken about the UV data).
bool triHit(vec3 ro, vec3 rd, vec3 p0, vec3 p1, vec3 p2, vec3 n, vec2 uv0, vec2 uv1, vec2 uv2, float facetSeed,
            float useFlat, vec3 flatColor,
            inout float bestT, inout vec3 bestN, inout vec2 bestUV, inout float bestFacet,
            inout float bestUseFlat, inout vec3 bestFlatColor) {
    // meshWarp/meshDistort/meshFold/lowPolyAmount's snap are real per-vertex distortions, applied
    // to this triangle's actual corners before intersecting -- ported straight from Pigeon Hole
    // Mesh's identical warping approach.
    bool warping = gMeshWarpAmt > 0.001 || gMeshDistortAmt > 0.001 || gMeshFoldAmt > 0.001 || gLowPolyAmt > 0.001;
    if (warping) {
        p0 = warpVertex(p0);
        p1 = warpVertex(p1);
        p2 = warpVertex(p2);
    }
    vec3 e1 = p1 - p0;
    vec3 e2 = p2 - p0;
    vec3 h = cross(rd, e2);
    float a = dot(e1, h);
    if (abs(a) < 1e-7) return false;
    float f = 1.0 / a;
    vec3 s = ro - p0;
    float u = f * dot(s, h);
    if (u < 0.0 || u > 1.0) return false;
    vec3 q = cross(s, e1);
    float v = f * dot(rd, q);
    if (v < 0.0 || u + v > 1.0) return false;
    float t = f * dot(e2, q);
    if (t > 0.001 && t < bestT) {
        bestT = t;
        // Recompute the normal from the warped triangle itself so lighting responds to the actual
        // deformed surface, sign-matched against the original baked normal so a rare winding flip
        // under extreme distortion can't invert the lighting.
        if (warping) {
            vec3 nWarp = normalize(cross(e1, e2));
            bestN = (dot(nWarp, n) < 0.0) ? -nWarp : nWarp;
        } else {
            bestN = n;
        }
        bestUV = uv0 * (1.0 - u - v) + uv1 * u + uv2 * v;
        bestFacet = facetSeed;
        bestUseFlat = useFlat;
        bestFlatColor = flatColor;
        return true;
    }
    return false;
}

// Analytic ray/capped-cylinder intersection (Y-aligned in local space) -- for a hand-authored
// primitive standing in for a piece of source geometry that's genuinely simple (e.g. a bottle:
// two cylinders, body + cap) instead of baking it as hundreds of literal triangles. Side surface
// via the standard quadratic in XZ, two flat end-caps via a plane+radius test; whichever of the
// (up to 2) side roots and 2 cap hits is actually closest wins, same closest-hit convention as
// triHit so it can share bestT/bestN with the triangle mesh test seamlessly.
bool cylHit(vec3 ro, vec3 rd, vec3 c, float halfH, float r, vec3 tintColor,
            inout float bestT, inout vec3 bestN, inout float bestUseFlat, inout vec3 bestFlatColor) {
    vec3 oc = ro - c;
    bool hit = false;

    float a = rd.x * rd.x + rd.z * rd.z;
    if (a > 1e-9) {
        float b = 2.0 * (oc.x * rd.x + oc.z * rd.z);
        float cc = oc.x * oc.x + oc.z * oc.z - r * r;
        float disc = b * b - 4.0 * a * cc;
        if (disc >= 0.0) {
            float sq = sqrt(disc);
            float tNear = (-b - sq) / (2.0 * a);
            float tFar = (-b + sq) / (2.0 * a);
            for (int i = 0; i < 2; i++) {
                float t = (i == 0) ? tNear : tFar;
                if (t > 0.001 && t < bestT) {
                    float y = oc.y + rd.y * t;
                    if (abs(y) <= halfH) {
                        vec3 p = oc + rd * t;
                        bestT = t;
                        bestN = normalize(vec3(p.x, 0.0, p.z));
                        bestUseFlat = 1.0;
                        bestFlatColor = tintColor;
                        hit = true;
                    }
                }
            }
        }
    }

    for (int cap = 0; cap < 2; cap++) {
        float capY = (cap == 0) ? halfH : -halfH;
        if (abs(rd.y) > 1e-6) {
            float t = (capY - oc.y) / rd.y;
            if (t > 0.001 && t < bestT) {
                vec3 p = oc + rd * t;
                if (p.x * p.x + p.z * p.z <= r * r) {
                    bestT = t;
                    bestN = vec3(0.0, sign(capY), 0.0);
                    bestUseFlat = 1.0;
                    bestFlatColor = tintColor;
                    hit = true;
                }
            }
        }
    }
    return hit;
}

// ===== MESH DATA (generated by ../MeshImportTool/OBJtoMeshTexture.html's literal-GLSL sibling --
// see MeshConvert, run offline once per model. Triangles are literal calls, not a data texture --
// this is the whole point: immune to any IMAGES-loader corruption, since there's no packed data to
// corrupt. Regenerate this block, nothing else, to swap the model. ) =====

bool meshRayTest_RAT(vec3 ro, vec3 rd, inout float bestT, inout vec3 bestN, inout vec2 bestUV, inout float bestFacet, inout float bestUseFlat, inout vec3 bestFlatColor) {
    bool hit = false;
    if (!raySphereNear(ro, rd, vec3(0,0,0), 1.1673)) return false;
    // cluster 0 (23 tris)
    if (raySphereNear(ro, rd, vec3(0.1039,0.287,-0.2858), 0.4679)) {
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.1563), vec3(0.1176,0.2598,-0.169), vec3(0.1089,0.3724,-0.3084), vec3(-0.0651,0.7743,0.6295), vec2(0.4097,0.8361), vec2(0.5482,0.8523), vec2(0.5439,0.8967), 0.1829, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.1563), vec3(0.1089,0.3724,-0.3084), vec3(-0.0802,0.4256,-0.3036), vec3(0.1718,0.5376,0.8255), vec2(0.4097,0.8361), vec2(0.5439,0.8967), vec2(0.4506,0.9222), 0.7401, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1089,0.3724,-0.3084), vec3(0.1176,0.2598,-0.169), vec3(0.2328,0.2806,-0.1665), vec3(-0.1515,0.7643,0.6268), vec2(0.5439,0.8967), vec2(0.5482,0.8523), vec2(0.605,0.8623), 0.5644, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1089,0.3724,-0.3084), vec3(0.2328,0.2806,-0.1665), vec3(0.239,0.3799,-0.3075), vec3(-0.0511,0.8175,0.5736), vec2(0.5439,0.8967), vec2(0.605,0.8623), vec2(0.608,0.9003), 0.4547, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.239,0.3799,-0.3075), vec3(0.2328,0.2806,-0.1665), vec3(0.3542,0.3014,-0.1789), vec3(-0.0815,0.8165,0.5715), vec2(0.608,0.9003), vec2(0.605,0.8623), vec2(0.6743,0.8766), 0.2724, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.2806,-0.1665), vec3(0.2328,0.0642,-0.1665), vec3(0.3554,0.1196,-0.1789), vec3(0.1001,0,0.995), vec2(0.605,0.8623), vec2(0.605,0.7587), vec2(0.6654,0.7852), 0.8234, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.2806,-0.1665), vec3(0.3554,0.1196,-0.1789), vec3(0.3542,0.3014,-0.1789), vec3(0.101,0.0007,0.9949), vec2(0.605,0.8623), vec2(0.6654,0.7852), vec2(0.6743,0.8766), 0.7528, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0716,0.0171,-0.1563), vec3(0.1176,0.0163,-0.169), vec3(0.1176,0.2598,-0.169), vec3(0.0669,0,0.9978), vec2(0.4549,0.7361), vec2(0.5482,0.7357), vec2(0.5482,0.8523), 0.5038, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0716,0.0171,-0.1563), vec3(0.1176,0.2598,-0.169), vec3(-0.1632,0.2259,-0.1563), vec3(0.0429,0.0188,0.9989), vec2(0.4549,0.7361), vec2(0.5482,0.8523), vec2(0.4097,0.8361), 0.5234, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.2806,-0.1665), vec3(0.1176,0.2598,-0.169), vec3(0.1176,0.0163,-0.169), vec3(-0.0214,0,0.9998), vec2(0.605,0.8623), vec2(0.5482,0.8523), vec2(0.5482,0.7357), 0.5218, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.2806,-0.1665), vec3(0.1176,0.0163,-0.169), vec3(0.2328,0.0642,-0.1665), vec3(-0.0214,0,0.9998), vec2(0.605,0.8623), vec2(0.5482,0.7357), vec2(0.605,0.7587), 0.0199, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0716,0.0171,-0.1563), vec3(-0.1632,0.2259,-0.1563), vec3(-0.1866,0.1904,-0.0386), vec3(0.8763,0.3846,0.2901), vec2(0.4549,0.7361), vec2(0.4097,0.8361), vec2(0.3982,0.8016), 0.5923, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0716,0.0171,-0.1563), vec3(-0.1866,0.1904,-0.0386), vec3(-0.1076,-0.0227,-0.0216), vec3(0.8737,0.351,0.3369), vec2(0.4549,0.7361), vec2(0.3982,0.8016), vec2(0.4237,0.6995), 0.6111, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1089,0.3945,-0.3911), vec3(-0.0802,0.4477,-0.3911), vec3(-0.0802,0.4256,-0.3036), vec3(0.263,0.9353,0.2368), vec2(0.5439,0.9169), vec2(0.4506,0.9423), vec2(0.4506,0.9222), 0.4013, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1089,0.3945,-0.3911), vec3(-0.0802,0.4256,-0.3036), vec3(0.1089,0.3724,-0.3084), vec3(0.2679,0.9307,0.2491), vec2(0.5439,0.9169), vec2(0.4506,0.9222), vec2(0.5439,0.8967), 0.8491, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.239,0.402,-0.3911), vec3(0.1089,0.3945,-0.3911), vec3(0.1089,0.3724,-0.3084), vec3(-0.0555,0.9645,0.2581), vec2(0.608,0.9205), vec2(0.5439,0.9169), vec2(0.5439,0.8967), 0.3408, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.239,0.402,-0.3911), vec3(0.1089,0.3724,-0.3084), vec3(0.239,0.3799,-0.3075), vec3(-0.0574,0.9651,0.2555), vec2(0.608,0.9205), vec2(0.5439,0.8967), vec2(0.608,0.9003), 0.4224, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1089,0.3724,-0.4739), vec3(0.239,0.3799,-0.4748), vec3(0.2328,0.2806,-0.6158), vec3(-0.0511,0.8175,-0.5736), vec2(0.5439,0.8967), vec2(0.608,0.9003), vec2(0.605,0.8623), 0.2378, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1089,0.3724,-0.4739), vec3(0.2328,0.2806,-0.6158), vec3(0.1176,0.2598,-0.6133), vec3(-0.1515,0.7643,-0.6268), vec2(0.5439,0.8967), vec2(0.605,0.8623), vec2(0.5482,0.8523), 0.9873, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1089,0.3945,-0.3911), vec3(0.1089,0.3724,-0.4739), vec3(-0.0802,0.4256,-0.4787), vec3(0.2679,0.9307,-0.2491), vec2(0.5439,0.9169), vec2(0.5439,0.8967), vec2(0.4506,0.9222), 0.71, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1089,0.3945,-0.3911), vec3(-0.0802,0.4256,-0.4787), vec3(-0.0802,0.4477,-0.3911), vec3(0.263,0.9353,-0.2368), vec2(0.5439,0.9169), vec2(0.4506,0.9222), vec2(0.4506,0.9423), 0.8656, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.239,0.402,-0.3911), vec3(0.239,0.3799,-0.4748), vec3(0.1089,0.3724,-0.4739), vec3(-0.0574,0.9651,-0.2555), vec2(0.608,0.9205), vec2(0.608,0.9003), vec2(0.5439,0.8967), 0.852, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.239,0.402,-0.3911), vec3(0.1089,0.3724,-0.4739), vec3(0.1089,0.3945,-0.3911), vec3(-0.0555,0.9645,-0.2581), vec2(0.608,0.9205), vec2(0.5439,0.8967), vec2(0.5439,0.9169), 0.0435, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 1 (30 tris)
    if (raySphereNear(ro, rd, vec3(-0.8853,-0.4186,0.3819), 0.5001)) {
        if (triHit(ro, rd, vec3(-0.9428,-0.4384,0.1924), vec3(-0.9611,-0.376,0.2073), vec3(-0.9197,-0.3928,0.4509), vec3(0.9411,0.3085,-0.1384), vec2(0.6343,0.2751), vec2(0.6343,0.3095), vec2(0.5006,0.2997), 0.6281, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9428,-0.4384,0.1924), vec3(-0.9197,-0.3928,0.4509), vec3(-0.9106,-0.4341,0.4375), vec3(0.9585,0.2536,-0.1303), vec2(0.6343,0.2751), vec2(0.5006,0.2997), vec2(0.5006,0.2729), 0.9335, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9249,-0.4575,0.4581), vec3(-0.9714,-0.4553,0.2155), vec3(-0.9428,-0.4384,0.1924), vec3(0.4499,-0.8881,-0.0942), vec2(0.5006,0.2608), vec2(0.6343,0.2631), vec2(0.6343,0.2751), 0.2282, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9249,-0.4575,0.4581), vec3(-0.9428,-0.4384,0.1924), vec3(-0.9106,-0.4341,0.4375), vec3(0.8093,-0.5794,-0.0964), vec2(0.5006,0.2608), vec2(0.6343,0.2751), vec2(0.5006,0.2729), 0.7659, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9611,-0.376,0.2073), vec3(-0.9711,-0.3753,0.2154), vec3(-0.9247,-0.3947,0.4581), vec3(0.1091,0.9923,0.0583), vec2(0.6343,0.3095), vec2(0.6343,0.315), vec2(0.5006,0.3051), 0.1548, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9611,-0.376,0.2073), vec3(-0.9247,-0.3947,0.4581), vec3(-0.9197,-0.3928,0.4509), vec3(-0.2117,0.9719,0.1033), vec2(0.6343,0.3095), vec2(0.5006,0.3051), vec2(0.5006,0.2997), 0.9119, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-1,-0.4358,0.2385), vec3(-0.9391,-0.4457,0.4787), vec3(-0.9297,-0.3966,0.4653), vec3(-0.9368,0.2473,0.2477), vec2(0.6343,0.2751), vec2(0.5006,0.2729), vec2(0.5006,0.2997), 0.178, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-1,-0.4358,0.2385), vec3(-0.9297,-0.3966,0.4653), vec3(-0.9811,-0.3749,0.2235), vec3(-0.9136,0.339,0.2247), vec2(0.6343,0.2751), vec2(0.5006,0.2997), vec2(0.6343,0.3095), 0.3437, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9249,-0.4575,0.4581), vec3(-0.9391,-0.4457,0.4787), vec3(-1,-0.4358,0.2385), vec3(-0.5423,-0.8338,0.1032), vec2(0.5006,0.2608), vec2(0.5006,0.2729), vec2(0.6343,0.2751), 0.5637, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9249,-0.4575,0.4581), vec3(-1,-0.4358,0.2385), vec3(-0.9714,-0.4553,0.2155), vec3(-0.5111,-0.8548,0.0904), vec2(0.5006,0.2608), vec2(0.6343,0.2751), vec2(0.6343,0.2631), 0.3678, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9811,-0.3749,0.2235), vec3(-0.9297,-0.3966,0.4653), vec3(-0.9247,-0.3947,0.4581), vec3(-0.1897,0.9735,0.1278), vec2(0.6343,0.3095), vec2(0.5006,0.2997), vec2(0.5006,0.3051), 0.4043, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9811,-0.3749,0.2235), vec3(-0.9247,-0.3947,0.4581), vec3(-0.9711,-0.3753,0.2154), vec3(0.0942,0.9937,0.0613), vec2(0.6343,0.3095), vec2(0.5006,0.3051), vec2(0.6343,0.315), 0.5702, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9106,-0.4341,0.4375), vec3(-0.9197,-0.3928,0.4509), vec3(-0.6433,-0.4178,0.6468), vec3(0.5601,0.3645,-0.7439), vec2(0.5006,0.2729), vec2(0.5006,0.2997), vec2(0.366,0.2898), 0.1146, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9106,-0.4341,0.4375), vec3(-0.6433,-0.4178,0.6468), vec3(-0.6419,-0.4396,0.6357), vec3(0.5476,0.4067,-0.7313), vec2(0.5006,0.2729), vec2(0.366,0.2898), vec2(0.366,0.2707), 0.6396, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.644,-0.4659,0.6527), vec3(-0.9249,-0.4575,0.4581), vec3(-0.9106,-0.4341,0.4375), vec3(0.3732,-0.732,-0.57), vec2(0.366,0.2586), vec2(0.5006,0.2608), vec2(0.5006,0.2729), 0.9607, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.644,-0.4659,0.6527), vec3(-0.9106,-0.4341,0.4375), vec3(-0.6419,-0.4396,0.6357), vec3(0.5085,-0.4971,-0.7031), vec2(0.366,0.2586), vec2(0.5006,0.2729), vec2(0.366,0.2707), 0.2488, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.644,-0.4659,0.6527), vec3(-0.6461,-0.4609,0.6698), vec3(-0.9391,-0.4457,0.4787), vec3(-0.211,-0.9456,0.2478), vec2(0.366,0.2586), vec2(0.366,0.2707), vec2(0.5006,0.2729), 0.2622, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.644,-0.4659,0.6527), vec3(-0.9391,-0.4457,0.4787), vec3(-0.9249,-0.4575,0.4581), vec3(-0.2612,-0.9043,0.3377), vec2(0.366,0.2586), vec2(0.5006,0.2729), vec2(0.5006,0.2608), 0.7822, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9297,-0.3966,0.4653), vec3(-0.9391,-0.4457,0.4787), vec3(-0.6461,-0.4609,0.6698), vec3(-0.5066,0.3167,0.8019), vec2(0.5006,0.2997), vec2(0.5006,0.2729), vec2(0.366,0.2707), 0.854, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9297,-0.3966,0.4653), vec3(-0.6461,-0.4609,0.6698), vec3(-0.6448,-0.4249,0.6587), vec3(-0.5225,0.2693,0.809), vec2(0.5006,0.2997), vec2(0.366,0.2707), vec2(0.366,0.2898), 0.6398, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9247,-0.3947,0.4581), vec3(-0.9297,-0.3966,0.4653), vec3(-0.6448,-0.4249,0.6587), vec3(-0.0538,0.9736,0.2218), vec2(0.5006,0.3051), vec2(0.5006,0.2997), vec2(0.366,0.2898), 0.08, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9247,-0.3947,0.4581), vec3(-0.6448,-0.4249,0.6587), vec3(-0.644,-0.4214,0.6527), vec3(-0.2489,0.8443,0.4745), vec2(0.5006,0.3051), vec2(0.366,0.2898), vec2(0.366,0.2952), 0.498, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9197,-0.3928,0.4509), vec3(-0.9247,-0.3947,0.4581), vec3(-0.644,-0.4214,0.6527), vec3(-0.0548,0.9756,0.2127), vec2(0.5006,0.2997), vec2(0.5006,0.3051), vec2(0.366,0.2952), 0.8087, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9197,-0.3928,0.4509), vec3(-0.644,-0.4214,0.6527), vec3(-0.6433,-0.4178,0.6468), vec3(-0.2603,0.841,0.4743), vec2(0.5006,0.2997), vec2(0.366,0.2952), vec2(0.366,0.2898), 0.7384, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8859,-0.4367,-0.0664), vec3(-0.9611,-0.376,0.2073), vec3(-0.9428,-0.4384,0.1924), vec3(0.9507,0.2278,0.2104), vec2(0.8086,0.2971), vec2(0.6343,0.3095), vec2(0.6343,0.2751), 0.0885, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9714,-0.4553,0.2155), vec3(-0.8859,-0.4367,-0.0664), vec3(-0.9428,-0.4384,0.1924), vec3(0.5766,-0.8079,0.1216), vec2(0.6343,0.2631), vec2(0.8086,0.2971), vec2(0.6343,0.2751), 0.4332, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9714,-0.4553,0.2155), vec3(-1,-0.4358,0.2385), vec3(-0.9523,-0.4421,-0.1032), vec3(-0.6001,-0.7969,-0.069), vec2(0.6343,0.2631), vec2(0.6343,0.2751), vec2(0.8086,0.2971), 0.9852, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9933,-0.3498,-0.0354), vec3(-1,-0.4358,0.2385), vec3(-0.9811,-0.3749,0.2235), vec3(-0.947,0.3123,0.0749), vec2(0.7757,0.3446), vec2(0.6343,0.2751), vec2(0.6343,0.3095), 0.9077, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9799,-0.3476,-0.0303), vec3(-0.9811,-0.3749,0.2235), vec3(-0.9711,-0.3753,0.2154), vec3(0.1304,0.9857,0.1067), vec2(0.7757,0.35), vec2(0.6343,0.3095), vec2(0.6343,0.315), 0.4815, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9665,-0.3454,-0.0252), vec3(-0.9711,-0.3753,0.2154), vec3(-0.9611,-0.376,0.2073), vec3(0.162,0.9788,0.1251), vec2(0.7757,0.3446), vec2(0.6343,0.315), vec2(0.6343,0.3095), 0.3512, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 2 (17 tris)
    if (raySphereNear(ro, rd, vec3(-0.7952,0.0285,-0.4873), 0.5286)) {
        if (triHit(ro, rd, vec3(-0.7319,0.1705,-0.2511), vec3(-0.7774,0.1928,-0.3342), vec3(-0.9138,-0.0625,-0.1986), vec3(-0.6227,0.5995,0.5029), vec2(0.1091,0.8381), vec2(0.1091,0.8583), vec2(0.0449,0.7528), 0.491, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7319,0.1705,-0.2511), vec3(-0.9138,-0.0625,-0.1986), vec3(-0.8918,-0.0846,-0.1738), vec3(-0.3942,0.4839,0.7813), vec2(0.1091,0.8381), vec2(0.0449,0.7528), vec2(0.0449,0.7326), 0.0766, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5876,0.1935,-0.6976), vec3(-0.8716,0.0161,-0.5731), vec3(-0.8233,0.1705,-0.4168), vec3(-0.6065,0.6515,-0.4558), vec2(0.2184,0.8327), vec2(0.1225,0.7728), vec2(0.1091,0.8381), 0.9104, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5876,0.1935,-0.6976), vec3(-0.8233,0.1705,-0.4168), vec3(-0.5564,0.3591,-0.5175), vec3(-0.6208,0.6277,-0.4697), vec2(0.2184,0.8327), vec2(0.1091,0.8381), vec2(0.2184,0.9004), 0.2937, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8716,0.0161,-0.5731), vec3(-0.9817,-0.1376,-0.2571), vec3(-0.9357,-0.0846,-0.2234), vec3(-0.7674,0.6396,0.0437), vec2(0.1225,0.7728), vec2(0.0515,0.6993), vec2(0.0449,0.7326), 0.3411, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8716,0.0161,-0.5731), vec3(-0.9357,-0.0846,-0.2234), vec3(-0.8233,0.1705,-0.4168), vec3(-0.9308,0.3594,-0.0669), vec2(0.1225,0.7728), vec2(0.0449,0.7326), vec2(0.1091,0.8381), 0.6167, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9299,-0.2319,-0.5631), vec3(-0.9817,-0.1376,-0.2571), vec3(-0.9016,0.011,-0.5817), vec3(-0.9757,0.0986,-0.1957), vec2(0.1056,0.6574), vec2(0.0515,0.6993), vec2(0.1117,0.7528), 0.5946, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6697,-0.1266,-0.7465), vec3(-0.9299,-0.2319,-0.5631), vec3(-0.9016,0.011,-0.5817), vec3(-0.5773,0.0048,-0.8165), vec2(0.1985,0.6864), vec2(0.1056,0.6574), vec2(0.1117,0.7528), 0.5136, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6697,-0.1266,-0.7465), vec3(-0.9016,0.011,-0.5817), vec3(-0.6182,0.1804,-0.7452), vec3(-0.539,0.094,-0.8371), vec2(0.1985,0.6864), vec2(0.1117,0.7528), vec2(0.206,0.8083), 0.2834, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3736,-0.0274,-0.7689), vec3(-0.6697,-0.1266,-0.7465), vec3(-0.6182,0.1804,-0.7452), vec3(-0.0814,0.0179,-0.9965), vec2(0.3085,0.7162), vec2(0.1985,0.6864), vec2(0.206,0.8083), 0.9402, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5956,-0.4411,-0.5774), vec3(-0.9299,-0.2319,-0.5631), vec3(-0.6697,-0.1266,-0.7465), vec3(-0.3505,-0.5061,-0.788), vec2(0.2141,0.5366), vec2(0.1056,0.6574), vec2(0.1985,0.6864), 0.9556, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8716,0.0161,-0.5731), vec3(-0.9016,0.011,-0.5817), vec3(-0.9817,-0.1376,-0.2571), vec3(-0.2545,0.9016,0.3499), vec2(0.1225,0.7728), vec2(0.1117,0.7528), vec2(0.0515,0.6993), 0.1395, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5876,0.1935,-0.6976), vec3(-0.6182,0.1804,-0.7452), vec3(-0.9016,0.011,-0.5817), vec3(-0.4822,0.8734,0.0687), vec2(0.2184,0.8327), vec2(0.206,0.8083), vec2(0.1117,0.7528), 0.6994, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5876,0.1935,-0.6976), vec3(-0.9016,0.011,-0.5817), vec3(-0.8716,0.0161,-0.5731), vec3(-0.2846,0.8127,0.5085), vec2(0.2184,0.8327), vec2(0.1117,0.7528), vec2(0.1225,0.7728), 0.0817, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8233,0.1705,-0.4168), vec3(-0.9357,-0.0846,-0.2234), vec3(-0.9138,-0.0625,-0.1986), vec3(-0.8098,0.5367,0.2372), vec2(0.1091,0.8381), vec2(0.0449,0.7326), vec2(0.0449,0.7528), 0.9874, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8233,0.1705,-0.4168), vec3(-0.9138,-0.0625,-0.1986), vec3(-0.7774,0.1928,-0.3342), vec3(-0.7777,0.5634,0.2791), vec2(0.1091,0.8381), vec2(0.0449,0.7528), vec2(0.1091,0.8583), 0.5315, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5564,0.3591,-0.5175), vec3(-0.8233,0.1705,-0.4168), vec3(-0.7774,0.1928,-0.3342), vec3(-0.5539,0.8284,0.0835), vec2(0.2184,0.9004), vec2(0.1091,0.8381), vec2(0.1091,0.8583), 0.3999, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 3 (80 tris)
    if (raySphereNear(ro, rd, vec3(0.5018,-0.4466,-0.5274), 0.3587)) {
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.6018), vec3(0.5061,-0.4767,-0.5902), vec3(0.5091,-0.4767,-0.4577), vec3(0,-1,0), vec2(0.7285,0.4996), vec2(0.759,0.4996), vec2(0.7621,0.4996), 0.5974, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.6018), vec3(0.5091,-0.4767,-0.4577), vec3(0.4897,-0.4767,-0.4617), vec3(0,-1,0), vec2(0.7285,0.4996), vec2(0.7621,0.4996), vec2(0.7317,0.4996), 0.4472, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.5303), vec3(0.5329,-0.4767,-0.492), vec3(0.5091,-0.4767,-0.4577), vec3(0,-1,0), vec2(0.7852,0.4996), vec2(0.7873,0.4996), vec2(0.7621,0.4996), 0.4642, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.5303), vec3(0.5091,-0.4767,-0.4577), vec3(0.5061,-0.4767,-0.5902), vec3(0,-1,0), vec2(0.7852,0.4996), vec2(0.7621,0.4996), vec2(0.759,0.4996), 0.0048, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.6018), vec3(0.4897,-0.4767,-0.4617), vec3(0.4285,-0.4767,-0.4987), vec3(0,-1,0), vec2(0.7285,0.4996), vec2(0.7317,0.4996), vec2(0.7015,0.4996), 0.729, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.6018), vec3(0.4285,-0.4767,-0.4987), vec3(0.4262,-0.4767,-0.5502), vec3(0,-1,0), vec2(0.7285,0.4996), vec2(0.7015,0.4996), vec2(0.7004,0.4996), 0.3331, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.282,-0.246,-0.4674), vec3(0.4143,-0.4325,-0.5021), vec3(0.4499,-0.4183,-0.4999), vec3(0.0098,-0.176,0.9843), vec2(0.6293,0.6101), vec2(0.6945,0.5208), vec2(0.712,0.5276), 0.2358, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3435,-0.1954,-0.6034), vec3(0.4462,-0.4062,-0.5727), vec3(0.4106,-0.4203,-0.5791), vec3(0.1952,-0.0478,-0.9796), vec2(0.6596,0.6343), vec2(0.7102,0.5334), vec2(0.6927,0.5266), 0.8196, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4028,-0.1875,-0.54), vec3(0.477,-0.4021,-0.5398), vec3(0.4462,-0.4062,-0.5727), vec3(0.6945,0.2393,-0.6785), vec2(0.6773,0.6381), vec2(0.7139,0.5353), vec2(0.7102,0.5334), 0.9801, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4028,-0.1875,-0.54), vec3(0.4462,-0.4062,-0.5727), vec3(0.3435,-0.1954,-0.6034), vec3(0.6945,0.2393,-0.6785), vec2(0.6773,0.6381), vec2(0.7102,0.5334), vec2(0.6596,0.6343), 0.2686, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3506,-0.2187,-0.4632), vec3(0.4499,-0.4183,-0.4999), vec3(0.4794,-0.4053,-0.5187), vec3(0.5056,0.0939,0.8576), vec2(0.6631,0.6232), vec2(0.712,0.5276), vec2(0.7266,0.5338), 0.0872, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4075,-0.1937,-0.4995), vec3(0.4794,-0.4053,-0.5187), vec3(0.477,-0.4021,-0.5398), vec3(0.9434,0.3261,-0.0604), vec2(0.6911,0.6351), vec2(0.7266,0.5338), vec2(0.7139,0.5353), 0.5307, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4075,-0.1937,-0.4995), vec3(0.477,-0.4021,-0.5398), vec3(0.4028,-0.1875,-0.54), vec3(0.9434,0.3261,-0.0604), vec2(0.6911,0.6351), vec2(0.7139,0.5353), vec2(0.6773,0.6381), 0.3795, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2749,-0.2226,-0.6158), vec3(0.4106,-0.4203,-0.5791), vec3(0.3776,-0.4352,-0.5507), vec3(-0.4547,-0.4541,-0.7662), vec2(0.6258,0.6213), vec2(0.6927,0.5266), vec2(0.6764,0.5195), 0.6832, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2114,-0.2512,-0.5611), vec3(0.3776,-0.4352,-0.5507), vec3(0.379,-0.4396,-0.5224), vec3(-0.7383,-0.6709,-0.069), vec2(0.5944,0.6076), vec2(0.6764,0.5195), vec2(0.6771,0.5174), 0.7651, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.214,-0.2596,-0.5066), vec3(0.379,-0.4396,-0.5224), vec3(0.4143,-0.4325,-0.5021), vec3(-0.3861,-0.4259,0.8183), vec2(0.5957,0.6036), vec2(0.6771,0.5174), vec2(0.6945,0.5208), 0.6217, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4143,-0.4325,-0.5021), vec3(0.4897,-0.4557,-0.4617), vec3(0.5091,-0.4557,-0.4577), vec3(-0.1379,0.7249,0.6749), vec2(0.6945,0.5208), vec2(0.7317,0.5096), vec2(0.7621,0.5096), 0.6138, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4143,-0.4325,-0.5021), vec3(0.5091,-0.4557,-0.4577), vec3(0.4499,-0.4183,-0.4999), vec3(-0.2553,0.5172,0.8169), vec2(0.6945,0.5208), vec2(0.7621,0.5096), vec2(0.712,0.5276), 0.1297, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4462,-0.4062,-0.5727), vec3(0.5061,-0.4557,-0.5902), vec3(0.4833,-0.4557,-0.6018), vec3(0.3445,0.6543,-0.6732), vec2(0.7102,0.5334), vec2(0.759,0.5096), vec2(0.7285,0.5096), 0.4584, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4462,-0.4062,-0.5727), vec3(0.4833,-0.4557,-0.6018), vec3(0.4106,-0.4203,-0.5791), vec3(-0.0361,0.4864,-0.873), vec2(0.7102,0.5334), vec2(0.7285,0.5096), vec2(0.6927,0.5266), 0.5818, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.477,-0.4021,-0.5398), vec3(0.5309,-0.4557,-0.5303), vec3(0.5061,-0.4557,-0.5902), vec3(0.6997,0.6531,-0.2897), vec2(0.7139,0.5353), vec2(0.7852,0.5096), vec2(0.759,0.5096), 0.1739, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.477,-0.4021,-0.5398), vec3(0.5061,-0.4557,-0.5902), vec3(0.4462,-0.4062,-0.5727), vec3(0.453,0.729,-0.5132), vec2(0.7139,0.5353), vec2(0.759,0.5096), vec2(0.7102,0.5334), 0.2722, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4499,-0.4183,-0.4999), vec3(0.5091,-0.4557,-0.4577), vec3(0.5329,-0.4557,-0.492), vec3(0.3758,0.8892,0.2611), vec2(0.712,0.5276), vec2(0.7621,0.5096), vec2(0.7873,0.5096), 0.9342, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4499,-0.4183,-0.4999), vec3(0.5329,-0.4557,-0.492), vec3(0.4794,-0.4053,-0.5187), vec3(0.208,0.6216,0.7552), vec2(0.712,0.5276), vec2(0.7873,0.5096), vec2(0.7266,0.5338), 0.6186, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4794,-0.4053,-0.5187), vec3(0.5329,-0.4557,-0.492), vec3(0.5309,-0.4557,-0.5303), vec3(0.6948,0.7183,-0.0359), vec2(0.7266,0.5338), vec2(0.7873,0.5096), vec2(0.7852,0.5096), 0.6627, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4794,-0.4053,-0.5187), vec3(0.5309,-0.4557,-0.5303), vec3(0.477,-0.4021,-0.5398), vec3(0.7021,0.7116,0.0263), vec2(0.7266,0.5338), vec2(0.7852,0.5096), vec2(0.7139,0.5353), 0.8418, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4106,-0.4203,-0.5791), vec3(0.4833,-0.4557,-0.6018), vec3(0.4262,-0.4557,-0.5502), vec3(-0.498,-0.6694,-0.5513), vec2(0.6927,0.5266), vec2(0.7285,0.5096), vec2(0.7004,0.5096), 0.3562, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4106,-0.4203,-0.5791), vec3(0.4262,-0.4557,-0.5502), vec3(0.3776,-0.4352,-0.5507), vec3(-0.2794,-0.6781,-0.6798), vec2(0.6927,0.5266), vec2(0.7004,0.5096), vec2(0.6764,0.5195), 0.8389, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3776,-0.4352,-0.5507), vec3(0.4262,-0.4557,-0.5502), vec3(0.4285,-0.4557,-0.4987), vec3(-0.3897,-0.9208,0.0174), vec2(0.6764,0.5195), vec2(0.7004,0.5096), vec2(0.7015,0.5096), 0.4587, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3776,-0.4352,-0.5507), vec3(0.4285,-0.4557,-0.4987), vec3(0.379,-0.4396,-0.5224), vec3(-0.2479,-0.9591,-0.1365), vec2(0.6764,0.5195), vec2(0.7015,0.5096), vec2(0.6771,0.5174), 0.2683, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.379,-0.4396,-0.5224), vec3(0.4285,-0.4557,-0.4987), vec3(0.4897,-0.4557,-0.4617), vec3(-0.4915,-0.3147,0.8121), vec2(0.6771,0.5174), vec2(0.7015,0.5096), vec2(0.7317,0.5096), 0.589, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.379,-0.4396,-0.5224), vec3(0.4897,-0.4557,-0.4617), vec3(0.4143,-0.4325,-0.5021), vec3(-0.4876,-0.0695,0.8703), vec2(0.6771,0.5174), vec2(0.7317,0.5096), vec2(0.6945,0.5208), 0.0384, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4897,-0.4557,-0.4617), vec3(0.4897,-0.4767,-0.4617), vec3(0.5091,-0.4767,-0.4577), vec3(-0.2002,0,0.9798), vec2(0.7317,0.5096), vec2(0.7317,0.4996), vec2(0.7621,0.4996), 0.3551, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4897,-0.4557,-0.4617), vec3(0.5091,-0.4767,-0.4577), vec3(0.5091,-0.4557,-0.4577), vec3(-0.2002,0,0.9798), vec2(0.7317,0.5096), vec2(0.7621,0.4996), vec2(0.7621,0.5096), 0.8811, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5358,-0.4646,-0.6184), vec3(0.5358,-0.4788,-0.6184), vec3(0.528,-0.4788,-0.6216), vec3(0.3888,0,-0.9213), vec2(0.759,0.5096), vec2(0.759,0.4996), vec2(0.7285,0.4996), 0.1932, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5358,-0.4646,-0.6184), vec3(0.528,-0.4788,-0.6216), vec3(0.528,-0.4646,-0.6216), vec3(0.3888,0,-0.9213), vec2(0.759,0.5096), vec2(0.7285,0.4996), vec2(0.7285,0.5096), 0.9097, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5982,-0.4646,-0.5479), vec3(0.5982,-0.4788,-0.5479), vec3(0.5897,-0.4788,-0.5648), vec3(0.8937,0,-0.4487), vec2(0.7852,0.5096), vec2(0.7852,0.4996), vec2(0.759,0.4996), 0.6495, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5982,-0.4646,-0.5479), vec3(0.5897,-0.4788,-0.5648), vec3(0.5897,-0.4646,-0.5648), vec3(0.8937,0,-0.4487), vec2(0.7852,0.5096), vec2(0.759,0.4996), vec2(0.759,0.5096), 0.7593, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.584,-0.4646,-0.4169), vec3(0.584,-0.4788,-0.4169), vec3(0.5921,-0.4788,-0.4266), vec3(0.7648,0,0.6443), vec2(0.7621,0.5096), vec2(0.7621,0.4996), vec2(0.7873,0.4996), 0.0675, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.584,-0.4646,-0.4169), vec3(0.5921,-0.4788,-0.4266), vec3(0.5921,-0.4646,-0.4266), vec3(0.7648,0,0.6443), vec2(0.7621,0.5096), vec2(0.7873,0.4996), vec2(0.7873,0.5096), 0.6749, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6138,-0.4646,-0.4882), vec3(0.6138,-0.4788,-0.4882), vec3(0.6131,-0.4788,-0.4989), vec3(0.998,0,-0.0625), vec2(0.7873,0.5096), vec2(0.7873,0.4996), vec2(0.7852,0.4996), 0.9401, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6138,-0.4646,-0.4882), vec3(0.6131,-0.4788,-0.4989), vec3(0.6131,-0.4646,-0.4989), vec3(0.998,0,-0.0625), vec2(0.7873,0.5096), vec2(0.7852,0.4996), vec2(0.7852,0.5096), 0.5766, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4557,-0.6018), vec3(0.4833,-0.4767,-0.6018), vec3(0.4262,-0.4767,-0.5502), vec3(-0.6704,0,-0.742), vec2(0.7285,0.5096), vec2(0.7285,0.4996), vec2(0.7004,0.4996), 0.5414, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4557,-0.6018), vec3(0.4262,-0.4767,-0.5502), vec3(0.4262,-0.4557,-0.5502), vec3(-0.6704,0,-0.742), vec2(0.7285,0.5096), vec2(0.7004,0.4996), vec2(0.7004,0.5096), 0.6332, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4262,-0.4557,-0.5502), vec3(0.4262,-0.4767,-0.5502), vec3(0.4285,-0.4767,-0.4987), vec3(-0.999,0,0.0446), vec2(0.7004,0.5096), vec2(0.7004,0.4996), vec2(0.7015,0.4996), 0.62, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4262,-0.4557,-0.5502), vec3(0.4285,-0.4767,-0.4987), vec3(0.4285,-0.4557,-0.4987), vec3(-0.999,0,0.0446), vec2(0.7004,0.5096), vec2(0.7015,0.4996), vec2(0.7015,0.5096), 0.9624, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4285,-0.4557,-0.4987), vec3(0.4285,-0.4767,-0.4987), vec3(0.4897,-0.4767,-0.4617), vec3(-0.5178,0,0.8555), vec2(0.7015,0.5096), vec2(0.7015,0.4996), vec2(0.7317,0.4996), 0.9146, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4285,-0.4557,-0.4987), vec3(0.4897,-0.4767,-0.4617), vec3(0.4897,-0.4557,-0.4617), vec3(-0.5178,0,0.8555), vec2(0.7015,0.5096), vec2(0.7317,0.4996), vec2(0.7317,0.5096), 0.0302, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4557,-0.5902), vec3(0.5061,-0.4767,-0.5902), vec3(0.5358,-0.4788,-0.6184), vec3(0.6887,0,0.7251), vec2(0.759,0.5096), vec2(0.759,0.4996), vec2(0.759,0.4996), 0.8189, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4557,-0.5902), vec3(0.5358,-0.4788,-0.6184), vec3(0.5358,-0.4646,-0.6184), vec3(0.6887,0,0.7251), vec2(0.759,0.5096), vec2(0.759,0.4996), vec2(0.759,0.5096), 0.9026, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4767,-0.5902), vec3(0.4833,-0.4767,-0.6018), vec3(0.528,-0.4788,-0.6216), vec3(-0.0252,-0.9985,0.0492), vec2(0.759,0.4996), vec2(0.7285,0.4996), vec2(0.7285,0.4996), 0.3174, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4767,-0.5902), vec3(0.528,-0.4788,-0.6216), vec3(0.5358,-0.4788,-0.6184), vec3(-0.0218,-0.9984,0.0516), vec2(0.759,0.4996), vec2(0.7285,0.4996), vec2(0.759,0.4996), 0.1483, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.6018), vec3(0.4833,-0.4557,-0.6018), vec3(0.528,-0.4646,-0.6216), vec3(-0.4056,0,-0.9141), vec2(0.7285,0.4996), vec2(0.7285,0.5096), vec2(0.7285,0.5096), 0.9982, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.6018), vec3(0.528,-0.4646,-0.6216), vec3(0.528,-0.4788,-0.6216), vec3(-0.4056,0,-0.9141), vec2(0.7285,0.4996), vec2(0.7285,0.5096), vec2(0.7285,0.4996), 0.5927, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4557,-0.6018), vec3(0.5061,-0.4557,-0.5902), vec3(0.5358,-0.4646,-0.6184), vec3(0.1014,0.9749,-0.1981), vec2(0.7285,0.5096), vec2(0.759,0.5096), vec2(0.759,0.5096), 0.7331, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4557,-0.6018), vec3(0.5358,-0.4646,-0.6184), vec3(0.528,-0.4646,-0.6216), vec3(0.0934,0.9707,-0.2213), vec2(0.7285,0.5096), vec2(0.759,0.5096), vec2(0.7285,0.5096), 0.6034, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4557,-0.5303), vec3(0.5309,-0.4767,-0.5303), vec3(0.5982,-0.4788,-0.5479), vec3(0.2533,0,0.9674), vec2(0.7852,0.5096), vec2(0.7852,0.4996), vec2(0.7852,0.4996), 0.7567, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4557,-0.5303), vec3(0.5982,-0.4788,-0.5479), vec3(0.5982,-0.4646,-0.5479), vec3(0.2533,0,0.9674), vec2(0.7852,0.5096), vec2(0.7852,0.4996), vec2(0.7852,0.5096), 0.592, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.5303), vec3(0.5061,-0.4767,-0.5902), vec3(0.5897,-0.4788,-0.5648), vec3(-0.0288,-0.9995,0.0119), vec2(0.7852,0.4996), vec2(0.759,0.4996), vec2(0.759,0.4996), 0.306, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.5303), vec3(0.5897,-0.4788,-0.5648), vec3(0.5982,-0.4788,-0.5479), vec3(-0.0277,-0.9995,0.0139), vec2(0.7852,0.4996), vec2(0.759,0.4996), vec2(0.7852,0.4996), 0.1925, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4767,-0.5902), vec3(0.5061,-0.4557,-0.5902), vec3(0.5897,-0.4646,-0.5648), vec3(0.2907,0,-0.9568), vec2(0.759,0.4996), vec2(0.759,0.5096), vec2(0.759,0.5096), 0.0877, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4767,-0.5902), vec3(0.5897,-0.4646,-0.5648), vec3(0.5897,-0.4788,-0.5648), vec3(0.2907,0,-0.9568), vec2(0.759,0.4996), vec2(0.759,0.5096), vec2(0.759,0.4996), 0.384, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4557,-0.5902), vec3(0.5309,-0.4557,-0.5303), vec3(0.5982,-0.4646,-0.5479), vec3(0.1173,0.9919,-0.0486), vec2(0.759,0.5096), vec2(0.7852,0.5096), vec2(0.7852,0.5096), 0.8906, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4557,-0.5902), vec3(0.5982,-0.4646,-0.5479), vec3(0.5897,-0.4646,-0.5648), vec3(0.1233,0.9904,-0.0619), vec2(0.759,0.5096), vec2(0.7852,0.5096), vec2(0.759,0.5096), 0.4117, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5091,-0.4557,-0.4577), vec3(0.5091,-0.4767,-0.4577), vec3(0.584,-0.4788,-0.4169), vec3(-0.4783,0,0.8782), vec2(0.7621,0.5096), vec2(0.7621,0.4996), vec2(0.7621,0.4996), 0.2867, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5091,-0.4557,-0.4577), vec3(0.584,-0.4788,-0.4169), vec3(0.584,-0.4646,-0.4169), vec3(-0.4783,0,0.8782), vec2(0.7621,0.5096), vec2(0.7621,0.4996), vec2(0.7621,0.5096), 0.0121, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5091,-0.4767,-0.4577), vec3(0.5329,-0.4767,-0.492), vec3(0.5921,-0.4788,-0.4266), vec3(-0.0201,-0.9997,-0.014), vec2(0.7621,0.4996), vec2(0.7873,0.4996), vec2(0.7873,0.4996), 0.0176, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5091,-0.4767,-0.4577), vec3(0.5921,-0.4788,-0.4266), vec3(0.584,-0.4788,-0.4169), vec3(-0.0193,-0.9997,-0.0162), vec2(0.7621,0.4996), vec2(0.7873,0.4996), vec2(0.7621,0.4996), 0.5469, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4767,-0.492), vec3(0.5329,-0.4557,-0.492), vec3(0.5921,-0.4646,-0.4266), vec3(0.7413,0,-0.6712), vec2(0.7873,0.4996), vec2(0.7873,0.5096), vec2(0.7873,0.5096), 0.5191, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4767,-0.492), vec3(0.5921,-0.4646,-0.4266), vec3(0.5921,-0.4788,-0.4266), vec3(0.7413,0,-0.6712), vec2(0.7873,0.4996), vec2(0.7873,0.5096), vec2(0.7873,0.4996), 0.3571, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4557,-0.492), vec3(0.5091,-0.4557,-0.4577), vec3(0.584,-0.4646,-0.4169), vec3(0.085,0.9946,0.0591), vec2(0.7873,0.5096), vec2(0.7621,0.5096), vec2(0.7621,0.5096), 0.3375, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4557,-0.492), vec3(0.584,-0.4646,-0.4169), vec3(0.5921,-0.4646,-0.4266), vec3(0.0768,0.9949,0.0647), vec2(0.7873,0.5096), vec2(0.7621,0.5096), vec2(0.7873,0.5096), 0.0655, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4557,-0.492), vec3(0.5329,-0.4767,-0.492), vec3(0.6138,-0.4788,-0.4882), vec3(-0.0471,0,0.9989), vec2(0.7873,0.5096), vec2(0.7873,0.4996), vec2(0.7873,0.4996), 0.0891, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4557,-0.492), vec3(0.6138,-0.4788,-0.4882), vec3(0.6138,-0.4646,-0.4882), vec3(-0.0471,0,0.9989), vec2(0.7873,0.5096), vec2(0.7873,0.4996), vec2(0.7873,0.5096), 0.9605, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4767,-0.492), vec3(0.5309,-0.4767,-0.5303), vec3(0.6131,-0.4788,-0.4989), vec3(-0.0261,-0.9997,0.0013), vec2(0.7873,0.4996), vec2(0.7852,0.4996), vec2(0.7852,0.4996), 0.0648, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4767,-0.492), vec3(0.6131,-0.4788,-0.4989), vec3(0.6138,-0.4788,-0.4882), vec3(-0.0261,-0.9997,0.0016), vec2(0.7873,0.4996), vec2(0.7852,0.4996), vec2(0.7873,0.4996), 0.2156, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.5303), vec3(0.5309,-0.4557,-0.5303), vec3(0.6131,-0.4646,-0.4989), vec3(0.3561,0,-0.9344), vec2(0.7852,0.4996), vec2(0.7852,0.5096), vec2(0.7852,0.5096), 0.5306, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.5303), vec3(0.6131,-0.4646,-0.4989), vec3(0.6131,-0.4788,-0.4989), vec3(0.3561,0,-0.9344), vec2(0.7852,0.4996), vec2(0.7852,0.5096), vec2(0.7852,0.4996), 0.4861, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4557,-0.5303), vec3(0.5329,-0.4557,-0.492), vec3(0.6138,-0.4646,-0.4882), vec3(0.1087,0.9941,-0.0056), vec2(0.7852,0.5096), vec2(0.7873,0.5096), vec2(0.7873,0.5096), 0.3411, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4557,-0.5303), vec3(0.6138,-0.4646,-0.4882), vec3(0.6131,-0.4646,-0.4989), vec3(0.1093,0.994,-0.0068), vec2(0.7852,0.5096), vec2(0.7873,0.5096), vec2(0.7852,0.5096), 0.0957, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 4 (84 tris)
    if (raySphereNear(ro, rd, vec3(0.8954,0.3038,-0.3911), 0.2897)) {
        if (triHit(ro, rd, vec3(0.662,0.4579,-0.3422), vec3(0.661,0.3957,-0.2685), vec3(0.8013,0.3646,-0.3098), vec3(0.3383,0.7166,0.6099), vec2(0.818,0.949), vec2(0.8088,0.9078), vec2(0.8808,0.8997), 0.384, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.662,0.4579,-0.3422), vec3(0.8013,0.3646,-0.3098), vec3(0.8004,0.4252,-0.3417), vec3(0.1068,0.4642,0.8793), vec2(0.818,0.949), vec2(0.8808,0.8997), vec2(0.8804,0.9318), 0.9224, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8004,0.4252,-0.3417), vec3(0.8013,0.3646,-0.3098), vec3(0.8922,0.3364,-0.3264), vec3(0.2934,0.4486,0.8442), vec2(0.8804,0.9318), vec2(0.8808,0.8997), vec2(0.9231,0.8862), 0.4616, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8004,0.4252,-0.3417), vec3(0.8922,0.3364,-0.3264), vec3(0.8894,0.374,-0.3518), vec3(0.392,0.5342,0.749), vec2(0.8804,0.9318), vec2(0.9231,0.8862), vec2(0.9237,0.9048), 0.2241, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8894,0.374,-0.3518), vec3(0.8922,0.3364,-0.3264), vec3(0.9471,0.3259,-0.3351), vec3(0.232,0.5556,0.7984), vec2(0.9237,0.9048), vec2(0.9231,0.8862), vec2(0.9502,0.8812), 0.1791, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8894,0.374,-0.3518), vec3(0.9471,0.3259,-0.3351), vec3(0.9448,0.3585,-0.357), vec3(0.2317,0.5553,0.7987), vec2(0.9237,0.9048), vec2(0.9502,0.8812), vec2(0.9506,0.8956), 0.9775, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9448,0.3585,-0.357), vec3(0.9471,0.3259,-0.3351), vec3(0.9898,0.3304,-0.367), vec3(0.4791,0.5142,0.7113), vec2(0.9506,0.8956), vec2(0.9502,0.8812), vec2(0.9761,0.8857), 0.3363, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9448,0.3585,-0.357), vec3(0.9898,0.3304,-0.367), vec3(0.9919,0.3413,-0.3704), vec3(0.3395,0.2191,0.9147), vec2(0.9506,0.8956), vec2(0.9761,0.8857), vec2(0.9691,0.8889), 0.19, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8013,0.3646,-0.3098), vec3(0.661,0.3957,-0.2685), vec3(0.6595,0.2615,-0.2597), vec3(0.2942,0.0592,0.9539), vec2(0.8808,0.8997), vec2(0.8088,0.9078), vec2(0.8154,0.8532), 0.5228, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8013,0.3646,-0.3098), vec3(0.6595,0.2615,-0.2597), vec3(0.8028,0.2525,-0.2857), vec3(0.1873,0.2091,0.9598), vec2(0.8808,0.8997), vec2(0.8154,0.8532), vec2(0.8861,0.8488), 0.0647, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8922,0.3364,-0.3264), vec3(0.8013,0.3646,-0.3098), vec3(0.8028,0.2525,-0.2857), vec3(0.2376,0.2075,0.9489), vec2(0.9231,0.8862), vec2(0.8808,0.8997), vec2(0.8861,0.8488), 0.5186, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8922,0.3364,-0.3264), vec3(0.8028,0.2525,-0.2857), vec3(0.8967,0.2607,-0.3173), vec3(0.3065,0.1311,0.9428), vec2(0.9231,0.8862), vec2(0.8861,0.8488), vec2(0.9177,0.8605), 0.3715, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9471,0.3259,-0.3351), vec3(0.8922,0.3364,-0.3264), vec3(0.8967,0.2607,-0.3173), vec3(0.1786,0.1274,0.9756), vec2(0.9502,0.8812), vec2(0.9231,0.8862), vec2(0.9177,0.8605), 0.1451, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9471,0.3259,-0.3351), vec3(0.8967,0.2607,-0.3173), vec3(0.9509,0.2682,-0.3272), vec3(0.1589,0.143,0.9769), vec2(0.9502,0.8812), vec2(0.9177,0.8605), vec2(0.9447,0.8634), 0.7762, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9898,0.3304,-0.367), vec3(0.9471,0.3259,-0.3351), vec3(0.9509,0.2682,-0.3272), vec3(0.5831,0.1463,0.7991), vec2(0.9761,0.8857), vec2(0.9502,0.8812), vec2(0.9447,0.8634), 0.1897, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9898,0.3304,-0.367), vec3(0.9509,0.2682,-0.3272), vec3(0.9863,0.3075,-0.367), vec3(0.7969,-0.12,0.5921), vec2(0.9761,0.8857), vec2(0.9447,0.8634), vec2(0.974,0.8756), 0.5363, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8028,0.2525,-0.2857), vec3(0.6724,0.1524,-0.3479), vec3(0.7984,0.1634,-0.3475), vec3(0.0471,-0.5711,0.8195), vec2(0.8861,0.8488), vec2(0.8218,0.8294), vec2(0.8785,0.8242), 0.8945, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8967,0.2607,-0.3173), vec3(0.8028,0.2525,-0.2857), vec3(0.7984,0.1634,-0.3475), vec3(0.3095,-0.5525,0.7739), vec2(0.9177,0.8605), vec2(0.8861,0.8488), vec2(0.8785,0.8242), 0.9306, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8967,0.2607,-0.3173), vec3(0.7984,0.1634,-0.3475), vec3(0.8629,0.1947,-0.356), vec3(0.3859,-0.6055,0.696), vec2(0.9177,0.8605), vec2(0.8785,0.8242), vec2(0.907,0.8344), 0.1363, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9509,0.2682,-0.3272), vec3(0.8967,0.2607,-0.3173), vec3(0.8629,0.1947,-0.356), vec3(0.2234,-0.5753,0.7868), vec2(0.9447,0.8634), vec2(0.9177,0.8605), vec2(0.907,0.8344), 0.9688, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9509,0.2682,-0.3272), vec3(0.8629,0.1947,-0.356), vec3(0.9392,0.2066,-0.3604), vec3(0.126,-0.4886,0.8634), vec2(0.9447,0.8634), vec2(0.907,0.8344), vec2(0.9423,0.8395), 0.7347, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9863,0.3075,-0.367), vec3(0.9509,0.2682,-0.3272), vec3(0.9392,0.2066,-0.3604), vec3(0.8445,-0.3691,0.3882), vec2(0.974,0.8756), vec2(0.9447,0.8634), vec2(0.9423,0.8395), 0.1278, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9863,0.3075,-0.367), vec3(0.9392,0.2066,-0.3604), vec3(0.9829,0.2684,-0.3721), vec3(0.4534,-0.1543,0.8778), vec2(0.974,0.8756), vec2(0.9423,0.8395), vec2(0.9684,0.8639), 0.1745, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8004,0.4352,-0.3911), vec3(0.662,0.4579,-0.3422), vec3(0.8004,0.4252,-0.3417), vec3(0.2252,0.955,0.193), vec2(0.8849,0.9364), vec2(0.818,0.949), vec2(0.8804,0.9318), 0.4176, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8894,0.384,-0.3911), vec3(0.8004,0.4352,-0.3911), vec3(0.8004,0.4252,-0.3417), vec3(0.4909,0.8539,0.1726), vec2(0.9288,0.9118), vec2(0.8849,0.9364), vec2(0.8804,0.9318), 0.8061, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8894,0.384,-0.3911), vec3(0.8004,0.4252,-0.3417), vec3(0.8894,0.374,-0.3518), vec3(0.505,0.8366,0.2124), vec2(0.9288,0.9118), vec2(0.8804,0.9318), vec2(0.9237,0.9048), 0.1045, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9448,0.3623,-0.3911), vec3(0.8894,0.384,-0.3911), vec3(0.8894,0.374,-0.3518), vec3(0.3555,0.9059,0.23), vec2(0.9561,0.9014), vec2(0.9288,0.9118), vec2(0.9237,0.9048), 0.8427, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9448,0.3623,-0.3911), vec3(0.8894,0.374,-0.3518), vec3(0.9448,0.3585,-0.357), vec3(0.2774,0.9549,0.1056), vec2(0.9561,0.9014), vec2(0.9237,0.9048), vec2(0.9506,0.8956), 0.9364, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9919,0.3448,-0.3911), vec3(0.9448,0.3623,-0.3911), vec3(0.9448,0.3585,-0.357), vec3(0.3468,0.9323,0.1031), vec2(0.9793,0.893), vec2(0.9561,0.9014), vec2(0.9506,0.8956), 0.3168, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9919,0.3448,-0.3911), vec3(0.9448,0.3585,-0.357), vec3(0.9919,0.3413,-0.3704), vec3(0.3773,0.9134,0.153), vec2(0.9793,0.893), vec2(0.9506,0.8956), vec2(0.9691,0.8889), 0.4741, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(1,0.3304,-0.3911), vec3(0.9919,0.3448,-0.3911), vec3(0.9919,0.3413,-0.3704), vec3(0.8698,0.4867,0.0815), vec2(0.9833,0.8861), vec2(0.9793,0.893), vec2(0.9691,0.8889), 0.2237, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(1,0.3304,-0.3911), vec3(0.9919,0.3413,-0.3704), vec3(0.9898,0.3304,-0.367), vec3(0.9193,-0.0605,0.389), vec2(0.9833,0.8861), vec2(0.9691,0.8889), vec2(0.9761,0.8857), 0.2852, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9966,0.3075,-0.3911), vec3(1,0.3304,-0.3911), vec3(0.9898,0.3304,-0.367), vec3(0.9122,-0.1373,0.386), vec2(0.9816,0.8752), vec2(0.9833,0.8861), vec2(0.9761,0.8857), 0.2502, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9966,0.3075,-0.3911), vec3(0.9898,0.3304,-0.367), vec3(0.9863,0.3075,-0.367), vec3(0.9122,-0.1373,0.386), vec2(0.9816,0.8752), vec2(0.9761,0.8857), vec2(0.974,0.8756), 0.738, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9829,0.257,-0.3911), vec3(0.9966,0.3075,-0.3911), vec3(0.9863,0.3075,-0.367), vec3(0.8935,-0.2423,0.3781), vec2(0.9709,0.8571), vec2(0.9816,0.8752), vec2(0.974,0.8756), 0.6625, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9829,0.257,-0.3911), vec3(0.9863,0.3075,-0.367), vec3(0.9829,0.2684,-0.3721), vec3(0.9937,-0.0963,0.058), vec2(0.9709,0.8571), vec2(0.974,0.8756), vec2(0.9684,0.8639), 0.2473, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9392,0.2066,-0.3604), vec3(0.9392,0.1951,-0.3911), vec3(0.9829,0.257,-0.3911), vec3(0.7988,-0.5637,0.2103), vec2(0.9423,0.8395), vec2(0.9494,0.8274), vec2(0.9709,0.8571), 0.7865, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9392,0.2066,-0.3604), vec3(0.9829,0.257,-0.3911), vec3(0.9829,0.2684,-0.3721), vec3(0.804,-0.5095,0.3065), vec2(0.9423,0.8395), vec2(0.9709,0.8571), vec2(0.9684,0.8639), 0.5096, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8629,0.1947,-0.356), vec3(0.8629,0.1789,-0.3911), vec3(0.9392,0.1951,-0.3911), vec3(0.1902,-0.8952,0.4031), vec2(0.907,0.8344), vec2(0.9073,0.8165), vec2(0.9494,0.8274), 0.6222, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8629,0.1947,-0.356), vec3(0.9392,0.1951,-0.3911), vec3(0.9392,0.2066,-0.3604), vec3(0.1635,-0.9243,0.3449), vec2(0.907,0.8344), vec2(0.9494,0.8274), vec2(0.9423,0.8395), 0.7238, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7984,0.1634,-0.3475), vec3(0.7984,0.136,-0.3911), vec3(0.8629,0.1789,-0.3911), vec3(0.4909,-0.7382,0.4627), vec2(0.8785,0.8242), vec2(0.8839,0.7931), vec2(0.9073,0.8165), 0.0253, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7984,0.1634,-0.3475), vec3(0.8629,0.1789,-0.3911), vec3(0.8629,0.1947,-0.356), vec3(0.4453,-0.8164,0.3676), vec2(0.8785,0.8242), vec2(0.9073,0.8165), vec2(0.907,0.8344), 0.7805, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.662,0.4579,-0.4401), vec3(0.8004,0.4252,-0.4406), vec3(0.8013,0.3646,-0.4725), vec3(0.1067,0.4642,-0.8793), vec2(0.818,0.949), vec2(0.8804,0.9318), vec2(0.8808,0.8997), 0.6268, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.662,0.4579,-0.4401), vec3(0.8013,0.3646,-0.4725), vec3(0.661,0.3957,-0.5138), vec3(0.3383,0.7166,-0.6099), vec2(0.818,0.949), vec2(0.8808,0.8997), vec2(0.8088,0.9078), 0.9348, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8004,0.4252,-0.4406), vec3(0.8894,0.374,-0.4305), vec3(0.8922,0.3364,-0.4559), vec3(0.392,0.5342,-0.7489), vec2(0.8804,0.9318), vec2(0.9237,0.9048), vec2(0.9231,0.8862), 0.8348, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8004,0.4252,-0.4406), vec3(0.8922,0.3364,-0.4559), vec3(0.8013,0.3646,-0.4725), vec3(0.2934,0.4486,-0.8442), vec2(0.8804,0.9318), vec2(0.9231,0.8862), vec2(0.8808,0.8997), 0.7935, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8894,0.374,-0.4305), vec3(0.9448,0.3585,-0.4252), vec3(0.9471,0.3259,-0.4472), vec3(0.2317,0.5553,-0.7988), vec2(0.9237,0.9048), vec2(0.9506,0.8956), vec2(0.9502,0.8812), 0.7221, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8894,0.374,-0.4305), vec3(0.9471,0.3259,-0.4472), vec3(0.8922,0.3364,-0.4559), vec3(0.232,0.5556,-0.7984), vec2(0.9237,0.9048), vec2(0.9502,0.8812), vec2(0.9231,0.8862), 0.8044, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9448,0.3585,-0.4252), vec3(0.9919,0.3413,-0.4119), vec3(0.9898,0.3304,-0.4153), vec3(0.3395,0.2191,-0.9147), vec2(0.9506,0.8956), vec2(0.9691,0.8889), vec2(0.9761,0.8857), 0.5721, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9448,0.3585,-0.4252), vec3(0.9898,0.3304,-0.4153), vec3(0.9471,0.3259,-0.4472), vec3(0.4791,0.5142,-0.7114), vec2(0.9506,0.8956), vec2(0.9761,0.8857), vec2(0.9502,0.8812), 0.3961, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8013,0.3646,-0.4725), vec3(0.8028,0.2525,-0.4966), vec3(0.6595,0.2615,-0.5226), vec3(0.1873,0.2091,-0.9598), vec2(0.8808,0.8997), vec2(0.8861,0.8488), vec2(0.8154,0.8532), 0.6327, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8013,0.3646,-0.4725), vec3(0.6595,0.2615,-0.5226), vec3(0.661,0.3957,-0.5138), vec3(0.2942,0.0592,-0.9539), vec2(0.8808,0.8997), vec2(0.8154,0.8532), vec2(0.8088,0.9078), 0.5107, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8922,0.3364,-0.4559), vec3(0.8967,0.2607,-0.465), vec3(0.8028,0.2525,-0.4966), vec3(0.3065,0.1311,-0.9428), vec2(0.9231,0.8862), vec2(0.9177,0.8605), vec2(0.8861,0.8488), 0.9119, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8922,0.3364,-0.4559), vec3(0.8028,0.2525,-0.4966), vec3(0.8013,0.3646,-0.4725), vec3(0.2376,0.2075,-0.9489), vec2(0.9231,0.8862), vec2(0.8861,0.8488), vec2(0.8808,0.8997), 0.7181, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9471,0.3259,-0.4472), vec3(0.9509,0.2682,-0.4551), vec3(0.8967,0.2607,-0.465), vec3(0.1589,0.143,-0.9769), vec2(0.9502,0.8812), vec2(0.9447,0.8634), vec2(0.9177,0.8605), 0.1041, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9471,0.3259,-0.4472), vec3(0.8967,0.2607,-0.465), vec3(0.8922,0.3364,-0.4559), vec3(0.1786,0.1274,-0.9756), vec2(0.9502,0.8812), vec2(0.9177,0.8605), vec2(0.9231,0.8862), 0.2813, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9898,0.3304,-0.4153), vec3(0.9863,0.3075,-0.4153), vec3(0.9509,0.2682,-0.4551), vec3(0.7969,-0.12,-0.5921), vec2(0.9761,0.8857), vec2(0.974,0.8756), vec2(0.9447,0.8634), 0.8995, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9898,0.3304,-0.4153), vec3(0.9509,0.2682,-0.4551), vec3(0.9471,0.3259,-0.4472), vec3(0.583,0.1463,-0.7992), vec2(0.9761,0.8857), vec2(0.9447,0.8634), vec2(0.9502,0.8812), 0.6354, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8028,0.2525,-0.4966), vec3(0.7984,0.1634,-0.4348), vec3(0.6724,0.1524,-0.4344), vec3(0.0471,-0.5711,-0.8195), vec2(0.8861,0.8488), vec2(0.8785,0.8242), vec2(0.8218,0.8294), 0.9138, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8967,0.2607,-0.465), vec3(0.8629,0.1947,-0.4263), vec3(0.7984,0.1634,-0.4348), vec3(0.3859,-0.6055,-0.696), vec2(0.9177,0.8605), vec2(0.907,0.8344), vec2(0.8785,0.8242), 0.0734, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8967,0.2607,-0.465), vec3(0.7984,0.1634,-0.4348), vec3(0.8028,0.2525,-0.4966), vec3(0.3095,-0.5525,-0.7739), vec2(0.9177,0.8605), vec2(0.8785,0.8242), vec2(0.8861,0.8488), 0.1276, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9509,0.2682,-0.4551), vec3(0.9392,0.2066,-0.4219), vec3(0.8629,0.1947,-0.4263), vec3(0.126,-0.4886,-0.8634), vec2(0.9447,0.8634), vec2(0.9423,0.8395), vec2(0.907,0.8344), 0.0688, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9509,0.2682,-0.4551), vec3(0.8629,0.1947,-0.4263), vec3(0.8967,0.2607,-0.465), vec3(0.2234,-0.5753,-0.7868), vec2(0.9447,0.8634), vec2(0.907,0.8344), vec2(0.9177,0.8605), 0.0497, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9863,0.3075,-0.4153), vec3(0.9829,0.2684,-0.4102), vec3(0.9392,0.2066,-0.4219), vec3(0.4534,-0.1543,-0.8778), vec2(0.974,0.8756), vec2(0.9684,0.8639), vec2(0.9423,0.8395), 0.2538, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9863,0.3075,-0.4153), vec3(0.9392,0.2066,-0.4219), vec3(0.9509,0.2682,-0.4551), vec3(0.8445,-0.3691,-0.3882), vec2(0.974,0.8756), vec2(0.9423,0.8395), vec2(0.9447,0.8634), 0.5413, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8004,0.4352,-0.3911), vec3(0.8004,0.4252,-0.4406), vec3(0.662,0.4579,-0.4401), vec3(0.2252,0.955,-0.193), vec2(0.8849,0.9364), vec2(0.8804,0.9318), vec2(0.818,0.949), 0.5436, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8894,0.384,-0.3911), vec3(0.8894,0.374,-0.4305), vec3(0.8004,0.4252,-0.4406), vec3(0.505,0.8366,-0.2124), vec2(0.9288,0.9118), vec2(0.9237,0.9048), vec2(0.8804,0.9318), 0.4146, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8894,0.384,-0.3911), vec3(0.8004,0.4252,-0.4406), vec3(0.8004,0.4352,-0.3911), vec3(0.4909,0.8539,-0.1726), vec2(0.9288,0.9118), vec2(0.8804,0.9318), vec2(0.8849,0.9364), 0.4097, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9448,0.3623,-0.3911), vec3(0.9448,0.3585,-0.4252), vec3(0.8894,0.374,-0.4305), vec3(0.2774,0.9549,-0.1056), vec2(0.9561,0.9014), vec2(0.9506,0.8956), vec2(0.9237,0.9048), 0.939, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9448,0.3623,-0.3911), vec3(0.8894,0.374,-0.4305), vec3(0.8894,0.384,-0.3911), vec3(0.3555,0.9059,-0.2301), vec2(0.9561,0.9014), vec2(0.9237,0.9048), vec2(0.9288,0.9118), 0.1112, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9919,0.3448,-0.3911), vec3(0.9919,0.3413,-0.4119), vec3(0.9448,0.3585,-0.4252), vec3(0.3773,0.9134,-0.153), vec2(0.9793,0.893), vec2(0.9691,0.8889), vec2(0.9506,0.8956), 0.8214, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9919,0.3448,-0.3911), vec3(0.9448,0.3585,-0.4252), vec3(0.9448,0.3623,-0.3911), vec3(0.3468,0.9323,-0.1031), vec2(0.9793,0.893), vec2(0.9506,0.8956), vec2(0.9561,0.9014), 0.7654, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(1,0.3304,-0.3911), vec3(0.9898,0.3304,-0.4153), vec3(0.9919,0.3413,-0.4119), vec3(0.9193,-0.0605,-0.389), vec2(0.9833,0.8861), vec2(0.9761,0.8857), vec2(0.9691,0.8889), 0.9853, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(1,0.3304,-0.3911), vec3(0.9919,0.3413,-0.4119), vec3(0.9919,0.3448,-0.3911), vec3(0.8698,0.4867,-0.0815), vec2(0.9833,0.8861), vec2(0.9691,0.8889), vec2(0.9793,0.893), 0.7871, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9966,0.3075,-0.3911), vec3(0.9863,0.3075,-0.4153), vec3(0.9898,0.3304,-0.4153), vec3(0.9122,-0.1373,-0.386), vec2(0.9816,0.8752), vec2(0.974,0.8756), vec2(0.9761,0.8857), 0.8433, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9966,0.3075,-0.3911), vec3(0.9898,0.3304,-0.4153), vec3(1,0.3304,-0.3911), vec3(0.9122,-0.1373,-0.386), vec2(0.9816,0.8752), vec2(0.9761,0.8857), vec2(0.9833,0.8861), 0.5876, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9829,0.257,-0.3911), vec3(0.9829,0.2684,-0.4102), vec3(0.9863,0.3075,-0.4153), vec3(0.9937,-0.0963,-0.058), vec2(0.9709,0.8571), vec2(0.9684,0.8639), vec2(0.974,0.8756), 0.3885, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9829,0.257,-0.3911), vec3(0.9863,0.3075,-0.4153), vec3(0.9966,0.3075,-0.3911), vec3(0.8935,-0.2423,-0.3781), vec2(0.9709,0.8571), vec2(0.974,0.8756), vec2(0.9816,0.8752), 0.5029, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9392,0.2066,-0.4219), vec3(0.9829,0.2684,-0.4102), vec3(0.9829,0.257,-0.3911), vec3(0.804,-0.5095,-0.3065), vec2(0.9423,0.8395), vec2(0.9684,0.8639), vec2(0.9709,0.8571), 0.486, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9392,0.2066,-0.4219), vec3(0.9829,0.257,-0.3911), vec3(0.9392,0.1951,-0.3911), vec3(0.7988,-0.5637,-0.2103), vec2(0.9423,0.8395), vec2(0.9709,0.8571), vec2(0.9494,0.8274), 0.7462, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8629,0.1947,-0.4263), vec3(0.9392,0.2066,-0.4219), vec3(0.9392,0.1951,-0.3911), vec3(0.1635,-0.9243,-0.3449), vec2(0.907,0.8344), vec2(0.9423,0.8395), vec2(0.9494,0.8274), 0.2247, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8629,0.1947,-0.4263), vec3(0.9392,0.1951,-0.3911), vec3(0.8629,0.1789,-0.3911), vec3(0.1902,-0.8952,-0.4031), vec2(0.907,0.8344), vec2(0.9494,0.8274), vec2(0.9073,0.8165), 0.5926, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7984,0.1634,-0.4348), vec3(0.8629,0.1947,-0.4263), vec3(0.8629,0.1789,-0.3911), vec3(0.4453,-0.8164,-0.3676), vec2(0.8785,0.8242), vec2(0.907,0.8344), vec2(0.9073,0.8165), 0.4036, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7984,0.1634,-0.4348), vec3(0.8629,0.1789,-0.3911), vec3(0.7984,0.136,-0.3911), vec3(0.4909,-0.7382,-0.4627), vec2(0.8785,0.8242), vec2(0.9073,0.8165), vec2(0.8839,0.7931), 0.2167, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 5 (12 tris)
    if (raySphereNear(ro, rd, vec3(-0.3722,-0.4911,0.7147), 0.2947)) {
        if (triHit(ro, rd, vec3(-0.6419,-0.4396,0.6357), vec3(-0.6433,-0.4178,0.6468), vec3(-0.1548,-0.5218,0.7642), vec3(0.2981,0.4478,-0.843), vec2(0.366,0.2707), vec2(0.366,0.2898), vec2(0.0503,0.2739), 0.8099, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6419,-0.4396,0.6357), vec3(-0.1548,-0.5218,0.7642), vec3(-0.1542,-0.5308,0.7596), vec3(0.2982,0.4505,-0.8415), vec2(0.366,0.2707), vec2(0.0503,0.2739), vec2(0.0503,0.2706), 0.5384, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1548,-0.5433,0.7642), vec3(-0.644,-0.4659,0.6527), vec3(-0.6419,-0.4396,0.6357), vec3(0.1027,-0.5473,-0.8306), vec2(0.0503,0.2585), vec2(0.366,0.2586), vec2(0.366,0.2707), 0.7648, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1548,-0.5433,0.7642), vec3(-0.6419,-0.4396,0.6357), vec3(-0.1542,-0.5308,0.7596), vec3(0.1688,-0.3496,-0.9215), vec2(0.0503,0.2585), vec2(0.366,0.2707), vec2(0.0503,0.2706), 0.2522, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1548,-0.5218,0.7642), vec3(-0.1548,-0.5433,0.7642), vec3(-0.1542,-0.5308,0.7596), vec3(0.9925,0,0.1223), vec2(0.0503,0.2739), vec2(0.0503,0.2585), vec2(0.0503,0.2706), 0.2748, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6433,-0.4178,0.6468), vec3(-0.644,-0.4214,0.6527), vec3(-0.1548,-0.5218,0.7642), vec3(0.0564,0.8522,0.5201), vec2(0.366,0.2898), vec2(0.366,0.2952), vec2(0.0503,0.2739), 0.5854, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6461,-0.4609,0.6698), vec3(-0.1554,-0.5308,0.7689), vec3(-0.1548,-0.5218,0.7642), vec3(-0.1125,0.4592,0.8812), vec2(0.366,0.2707), vec2(0.0503,0.2706), vec2(0.0503,0.2739), 0.9616, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6461,-0.4609,0.6698), vec3(-0.1548,-0.5218,0.7642), vec3(-0.6448,-0.4249,0.6587), vec3(-0.1447,0.2966,0.944), vec2(0.366,0.2707), vec2(0.0503,0.2739), vec2(0.366,0.2898), 0.9107, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1548,-0.5433,0.7642), vec3(-0.1554,-0.5308,0.7689), vec3(-0.6461,-0.4609,0.6698), vec3(-0.2328,-0.3476,0.9083), vec2(0.0503,0.2585), vec2(0.0503,0.2706), vec2(0.366,0.2707), 0.735, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1548,-0.5433,0.7642), vec3(-0.6461,-0.4609,0.6698), vec3(-0.644,-0.4659,0.6527), vec3(-0.2063,-0.9464,0.2486), vec2(0.0503,0.2585), vec2(0.366,0.2707), vec2(0.366,0.2586), 0.0799, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1548,-0.5218,0.7642), vec3(-0.1554,-0.5308,0.7689), vec3(-0.1548,-0.5433,0.7642), vec3(0.9925,0,0.1226), vec2(0.0503,0.2739), vec2(0.0503,0.2706), vec2(0.0503,0.2585), 0.9786, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6448,-0.4249,0.6587), vec3(-0.1548,-0.5218,0.7642), vec3(-0.644,-0.4214,0.6527), vec3(0.0572,0.8536,0.5178), vec2(0.366,0.2898), vec2(0.0503,0.2739), vec2(0.366,0.2952), 0.5729, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 6 (80 tris)
    if (raySphereNear(ro, rd, vec3(-0.1293,-0.3983,-0.2491), 0.4995)) {
        if (triHit(ro, rd, vec3(-0.213,-0.3295,-0.1993), vec3(-0.4989,-0.1266,-0.0864), vec3(-0.5133,-0.4411,-0.2734), vec3(-0.0226,-0.5101,0.8598), vec2(0.3851,0.5701), vec2(0.1985,0.6864), vec2(0.2141,0.5366), 0.1849, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0805,-0.2963,-0.1915), vec3(-0.1076,-0.0227,-0.0216), vec3(-0.3594,-0.0274,-0.0269), vec3(-0.0081,-0.5281,0.8491), vec2(0.4179,0.6003), vec2(0.4237,0.6995), vec2(0.3085,0.7162), 0.7249, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0805,-0.2963,-0.1915), vec3(-0.3594,-0.0274,-0.0269), vec3(-0.213,-0.3295,-0.1993), vec3(0.0661,-0.4701,0.8801), vec2(0.4179,0.6003), vec2(0.3085,0.7162), vec2(0.3851,0.5701), 0.2232, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.3114), vec3(0.1176,0.0163,-0.169), vec3(-0.0716,0.0171,-0.1563), vec3(0.0565,-0.485,0.8727), vec2(0.4621,0.6317), vec2(0.5482,0.7357), vec2(0.4549,0.7361), 0.184, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5051,-0.4245,-0.3385), vec3(-0.1871,-0.3009,-0.2963), vec3(-0.213,-0.3295,-0.1993), vec3(0.3763,-0.9112,-0.1676), vec2(0.2263,0.5731), vec2(0.3979,0.6122), vec2(0.3851,0.5701), 0.2605, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5051,-0.4245,-0.3385), vec3(-0.213,-0.3295,-0.1993), vec3(-0.5133,-0.4411,-0.2734), vec3(0.3822,-0.9056,-0.1838), vec2(0.2263,0.5731), vec2(0.3851,0.5701), vec2(0.2141,0.5366), 0.0708, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.3114), vec3(-0.0716,0.0171,-0.1563), vec3(-0.1076,-0.0227,-0.0216), vec3(0.9687,-0.08,0.2349), vec2(0.4621,0.6317), vec2(0.4549,0.7361), vec2(0.4237,0.6995), 0.5104, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.3114), vec3(-0.1076,-0.0227,-0.0216), vec3(-0.0805,-0.2963,-0.1915), vec3(0.9821,-0.0193,0.1875), vec2(0.4621,0.6317), vec2(0.4237,0.6995), vec2(0.4179,0.6003), 0.2199, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.192,-0.455,-0.2816), vec3(-0.1529,-0.4609,-0.2917), vec3(-0.1688,-0.4609,-0.2112), vec3(-0.1566,-0.9872,-0.0308), vec2(0.3955,0.51), vec2(0.4148,0.5072), vec2(0.407,0.5072), 0.4665, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.192,-0.455,-0.2816), vec3(-0.1688,-0.4609,-0.2112), vec3(-0.2094,-0.4552,-0.2164), vec3(-0.1352,-0.9901,-0.0382), vec2(0.3955,0.51), vec2(0.407,0.5072), vec2(0.3869,0.5099), 0.4141, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1871,-0.3009,-0.2963), vec3(-0.0569,-0.2602,-0.3114), vec3(-0.1416,-0.3586,-0.2965), vec3(-0.093,-0.0704,-0.9932), vec2(0.3979,0.6122), vec2(0.4621,0.6317), vec2(0.4204,0.5562), 0.0024, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1871,-0.3009,-0.2963), vec3(-0.1416,-0.3586,-0.2965), vec3(-0.1952,-0.3732,-0.2852), vec3(-0.1707,-0.1318,-0.9765), vec2(0.3979,0.6122), vec2(0.4204,0.5562), vec2(0.394,0.5492), 0.3674, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.3114), vec3(-0.0805,-0.2963,-0.1915), vec3(-0.1545,-0.3748,-0.2064), vec3(0.732,-0.6786,-0.0604), vec2(0.4621,0.6317), vec2(0.4179,0.6003), vec2(0.4005,0.5484), 0.9786, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.3114), vec3(-0.1545,-0.3748,-0.2064), vec3(-0.1416,-0.3586,-0.2965), vec3(0.7571,-0.6532,-0.0093), vec2(0.4621,0.6317), vec2(0.4005,0.5484), vec2(0.4204,0.5562), 0.5729, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0805,-0.2963,-0.1915), vec3(-0.213,-0.3295,-0.1993), vec3(-0.2132,-0.3944,-0.2122), vec3(-0.0084,-0.1961,0.9805), vec2(0.4179,0.6003), vec2(0.3851,0.5701), vec2(0.3851,0.539), 0.1974, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0805,-0.2963,-0.1915), vec3(-0.2132,-0.3944,-0.2122), vec3(-0.1545,-0.3748,-0.2064), vec3(-0.0517,-0.1392,0.9889), vec2(0.4179,0.6003), vec2(0.3851,0.539), vec2(0.4005,0.5484), 0.4411, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.213,-0.3295,-0.1993), vec3(-0.1871,-0.3009,-0.2963), vec3(-0.1952,-0.3732,-0.2852), vec3(-0.9687,0.0713,-0.2376), vec2(0.3851,0.5701), vec2(0.3979,0.6122), vec2(0.394,0.5492), 0.6922, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.213,-0.3295,-0.1993), vec3(-0.1952,-0.3732,-0.2852), vec3(-0.2132,-0.3944,-0.2122), vec3(-0.973,0.0471,-0.2261), vec2(0.3851,0.5701), vec2(0.394,0.5492), vec2(0.3851,0.539), 0.4095, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1904,-0.4083,-0.2816), vec3(-0.1439,-0.4021,-0.2917), vec3(-0.1529,-0.4609,-0.2917), vec3(-0.2171,0.0331,-0.9756), vec2(0.3963,0.5324), vec2(0.4192,0.5353), vec2(0.4148,0.5072), 0.1499, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1904,-0.4083,-0.2816), vec3(-0.1529,-0.4609,-0.2917), vec3(-0.192,-0.455,-0.2816), vec3(-0.2496,0.0086,-0.9683), vec2(0.3963,0.5324), vec2(0.4148,0.5072), vec2(0.3955,0.51), 0.7378, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0131,-0.4483,-0.2747), vec3(-0.0168,-0.4499,-0.256), vec3(-0.0165,-0.4621,-0.2576), vec3(0.9812,0,0.1931), vec2(0.4812,0.5263), vec2(0.4781,0.5246), vec2(0.4784,0.5119), 0.6049, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0131,-0.4483,-0.2747), vec3(-0.0165,-0.4621,-0.2576), vec3(-0.0131,-0.4621,-0.2747), vec3(0.9812,0,0.1931), vec2(0.4812,0.5263), vec2(0.4784,0.5119), vec2(0.4812,0.5119), 0.2768, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1583,-0.4118,-0.2112), vec3(-0.2136,-0.4271,-0.2164), vec3(-0.2094,-0.4552,-0.2164), vec3(-0.0902,-0.0135,0.9958), vec2(0.3986,0.5307), vec2(0.3849,0.5234), vec2(0.3869,0.5099), 0.5239, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1583,-0.4118,-0.2112), vec3(-0.2094,-0.4552,-0.2164), vec3(-0.1688,-0.4609,-0.2112), vec3(-0.1235,0.0262,0.992), vec2(0.3986,0.5307), vec2(0.3869,0.5099), vec2(0.407,0.5072), 0.317, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2136,-0.4271,-0.2164), vec3(-0.1904,-0.4083,-0.2816), vec3(-0.192,-0.455,-0.2816), vec3(-0.9445,0.0324,-0.3268), vec2(0.3849,0.5234), vec2(0.3963,0.5324), vec2(0.3955,0.51), 0.4386, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2136,-0.4271,-0.2164), vec3(-0.192,-0.455,-0.2816), vec3(-0.2094,-0.4552,-0.2164), vec3(-0.9562,-0.143,-0.2555), vec2(0.3849,0.5234), vec2(0.3955,0.51), vec2(0.3869,0.5099), 0.1434, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1216,-0.4373,-0.2335), vec3(-0.1583,-0.4118,-0.2112), vec3(-0.126,-0.4398,-0.2112), vec3(0.6392,0.7406,0.2074), vec2(0.4755,0.5232), vec2(0.3986,0.5307), vec2(0.4734,0.522), 0.0748, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1583,-0.4118,-0.2112), vec3(-0.1688,-0.4609,-0.2112), vec3(-0.126,-0.461,-0.2112), vec3(0,0,1), vec2(0.3986,0.5307), vec2(0.407,0.5072), vec2(0.4734,0.5119), 0.2855, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1583,-0.4118,-0.2112), vec3(-0.126,-0.461,-0.2112), vec3(-0.126,-0.4398,-0.2112), vec3(0,0,1), vec2(0.3986,0.5307), vec2(0.4734,0.5119), vec2(0.4734,0.522), 0.2798, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1158,-0.461,-0.2627), vec3(-0.1529,-0.4609,-0.2917), vec3(-0.1101,-0.461,-0.2917), vec3(-0.0025,-1,-0.0005), vec2(0.4784,0.5119), vec2(0.4148,0.5072), vec2(0.4812,0.5119), 0.4832, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1529,-0.4609,-0.2917), vec3(-0.1439,-0.4021,-0.2917), vec3(-0.1101,-0.4309,-0.2917), vec3(0,0,-1), vec2(0.4148,0.5072), vec2(0.4192,0.5353), vec2(0.4812,0.5263), 0.785, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1529,-0.4609,-0.2917), vec3(-0.1101,-0.4309,-0.2917), vec3(-0.1101,-0.461,-0.2917), vec3(0,0,-1), vec2(0.4148,0.5072), vec2(0.4812,0.5263), vec2(0.4812,0.5119), 0.1663, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3242,-0.3377,-0.4085), vec3(-0.1291,-0.2924,-0.3911), vec3(-0.0569,-0.2602,-0.3114), vec3(0.2044,-0.9579,0.2018), vec2(0.3282,0.5695), vec2(0.4265,0.5879), vec2(0.4621,0.6317), 0.0406, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3242,-0.3377,-0.4085), vec3(-0.0569,-0.2602,-0.3114), vec3(-0.1871,-0.3009,-0.2963), vec3(0.2934,-0.9549,-0.0457), vec2(0.3282,0.5695), vec2(0.4621,0.6317), vec2(0.3979,0.6122), 0.5669, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5297,-0.4523,-0.4306), vec3(-0.3242,-0.3377,-0.4085), vec3(-0.1871,-0.3009,-0.2963), vec3(0.4867,-0.809,-0.3296), vec2(0.2263,0.5304), vec2(0.3282,0.5695), vec2(0.3979,0.6122), 0.6251, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5297,-0.4523,-0.4306), vec3(-0.1871,-0.3009,-0.2963), vec3(-0.5051,-0.4245,-0.3385), vec3(0.3338,-0.9234,0.1893), vec2(0.2263,0.5304), vec2(0.3979,0.6122), vec2(0.2263,0.5731), 0.995, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1291,-0.2924,-0.3911), vec3(0.1027,-0.226,-0.3911), vec3(0.1027,-0.1962,-0.3157), vec3(0.2576,-0.899,0.3543), vec2(0.4265,0.5879), vec2(0.5409,0.6197), vec2(0.5409,0.6624), 0.4523, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1291,-0.2924,-0.3911), vec3(0.1027,-0.1962,-0.3157), vec3(-0.0569,-0.2602,-0.3114), vec3(0.3725,-0.9273,0.0372), vec2(0.4265,0.5879), vec2(0.5409,0.6624), vec2(0.4621,0.6317), 0.0817, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1416,-0.3586,-0.2965), vec3(-0.1545,-0.3748,-0.2064), vec3(-0.1583,-0.4118,-0.2112), vec3(0.9858,-0.1183,0.1193), vec2(0.4204,0.5562), vec2(0.4005,0.5484), vec2(0.3986,0.5307), 0.5719, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1416,-0.3586,-0.2965), vec3(-0.1583,-0.4118,-0.2112), vec3(-0.1439,-0.4021,-0.2917), vec3(0.9845,-0.0335,0.1721), vec2(0.4204,0.5562), vec2(0.3986,0.5307), vec2(0.4192,0.5353), 0.8134, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1952,-0.3732,-0.2852), vec3(-0.1416,-0.3586,-0.2965), vec3(-0.1439,-0.4021,-0.2917), vec3(-0.1804,-0.098,-0.9787), vec2(0.394,0.5492), vec2(0.4204,0.5562), vec2(0.4192,0.5353), 0.9048, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1952,-0.3732,-0.2852), vec3(-0.1439,-0.4021,-0.2917), vec3(-0.1904,-0.4083,-0.2816), vec3(-0.1953,-0.1257,-0.9727), vec2(0.394,0.5492), vec2(0.4192,0.5353), vec2(0.3963,0.5324), 0.5905, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2132,-0.3944,-0.2122), vec3(-0.1952,-0.3732,-0.2852), vec3(-0.1904,-0.4083,-0.2816), vec3(-0.9472,-0.1574,-0.2793), vec2(0.3851,0.539), vec2(0.394,0.5492), vec2(0.3963,0.5324), 0.2965, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2132,-0.3944,-0.2122), vec3(-0.1904,-0.4083,-0.2816), vec3(-0.2136,-0.4271,-0.2164), vec3(-0.9456,0.0537,-0.321), vec2(0.3851,0.539), vec2(0.3963,0.5324), vec2(0.3849,0.5234), 0.3183, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1545,-0.3748,-0.2064), vec3(-0.2132,-0.3944,-0.2122), vec3(-0.2136,-0.4271,-0.2164), vec3(-0.0566,-0.1251,0.9905), vec2(0.4005,0.5484), vec2(0.3851,0.539), vec2(0.3849,0.5234), 0.6533, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1545,-0.3748,-0.2064), vec3(-0.2136,-0.4271,-0.2164), vec3(-0.1583,-0.4118,-0.2112), vec3(-0.0599,-0.1215,0.9908), vec2(0.4005,0.5484), vec2(0.3849,0.5234), vec2(0.3986,0.5307), 0.8771, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0241,-0.4639,-0.2189), vec3(-0.0242,-0.4531,-0.2182), vec3(-0.0268,-0.4542,-0.2051), vec3(0.9812,-0.0001,0.1932), vec2(0.4757,0.5119), vec2(0.4755,0.5232), vec2(0.4734,0.522), 0.6014, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0241,-0.4639,-0.2189), vec3(-0.0268,-0.4542,-0.2051), vec3(-0.0268,-0.4639,-0.2051), vec3(0.9812,0,0.1931), vec2(0.4757,0.5119), vec2(0.4734,0.522), vec2(0.4734,0.5119), 0.2273, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0188,-0.4632,-0.2457), vec3(-0.0191,-0.451,-0.2441), vec3(-0.0222,-0.4524,-0.2285), vec3(0.9812,0,0.1931), vec2(0.4784,0.5119), vec2(0.4781,0.5246), vec2(0.4755,0.5232), 0.242, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0188,-0.4632,-0.2457), vec3(-0.0222,-0.4524,-0.2285), vec3(-0.0221,-0.4632,-0.2292), vec3(0.9812,0,0.1931), vec2(0.4784,0.5119), vec2(0.4755,0.5232), vec2(0.4757,0.5119), 0.4602, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1439,-0.4021,-0.2917), vec3(-0.1164,-0.4344,-0.2599), vec3(-0.1101,-0.4309,-0.2917), vec3(0.6349,0.7443,0.2069), vec2(0.4192,0.5353), vec2(0.4781,0.5246), vec2(0.4812,0.5263), 0.5315, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1439,-0.4021,-0.2917), vec3(-0.1583,-0.4118,-0.2112), vec3(-0.1216,-0.4373,-0.2335), vec3(0.6384,0.7421,0.2043), vec2(0.4192,0.5353), vec2(0.3986,0.5307), vec2(0.4755,0.5232), 0.262, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1439,-0.4021,-0.2917), vec3(-0.1216,-0.4373,-0.2335), vec3(-0.1164,-0.4344,-0.2599), vec3(0.6349,0.7443,0.2069), vec2(0.4192,0.5353), vec2(0.4755,0.5232), vec2(0.4781,0.5246), 0.7175, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1688,-0.4609,-0.2112), vec3(-0.1213,-0.461,-0.2346), vec3(-0.126,-0.461,-0.2112), vec3(-0.0025,-1,-0.0005), vec2(0.407,0.5072), vec2(0.4757,0.5119), vec2(0.4734,0.5119), 0.2124, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1688,-0.4609,-0.2112), vec3(-0.1529,-0.4609,-0.2917), vec3(-0.1158,-0.461,-0.2627), vec3(-0.0025,-1,-0.0005), vec2(0.407,0.5072), vec2(0.4148,0.5072), vec2(0.4784,0.5119), 0.5609, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1688,-0.4609,-0.2112), vec3(-0.1158,-0.461,-0.2627), vec3(-0.1213,-0.461,-0.2346), vec3(-0.0025,-1,-0.0005), vec2(0.407,0.5072), vec2(0.4784,0.5119), vec2(0.4757,0.5119), 0.9329, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1101,-0.4309,-0.2917), vec3(-0.1164,-0.4344,-0.2599), vec3(-0.0168,-0.4499,-0.256), vec3(0.1465,0.9797,0.1367), vec2(0.4812,0.5263), vec2(0.4781,0.5246), vec2(0.4781,0.5246), 0.7174, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1101,-0.4309,-0.2917), vec3(-0.0168,-0.4499,-0.256), vec3(-0.0131,-0.4483,-0.2747), vec3(0.1552,0.9812,0.1147), vec2(0.4812,0.5263), vec2(0.4781,0.5246), vec2(0.4812,0.5263), 0.5358, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1164,-0.4344,-0.2599), vec3(-0.1158,-0.461,-0.2627), vec3(-0.0165,-0.4621,-0.2576), vec3(-0.052,-0.105,0.9931), vec2(0.4781,0.5246), vec2(0.4784,0.5119), vec2(0.4784,0.5119), 0.431, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1164,-0.4344,-0.2599), vec3(-0.0165,-0.4621,-0.2576), vec3(-0.0168,-0.4499,-0.256), vec3(-0.06,-0.1345,0.9891), vec2(0.4781,0.5246), vec2(0.4784,0.5119), vec2(0.4781,0.5246), 0.8338, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1158,-0.461,-0.2627), vec3(-0.1101,-0.461,-0.2917), vec3(-0.0131,-0.4621,-0.2747), vec3(-0.0104,-0.9999,-0.002), vec2(0.4784,0.5119), vec2(0.4812,0.5119), vec2(0.4812,0.5119), 0.6776, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1158,-0.461,-0.2627), vec3(-0.0131,-0.4621,-0.2747), vec3(-0.0165,-0.4621,-0.2576), vec3(-0.0104,-0.9999,-0.002), vec2(0.4784,0.5119), vec2(0.4812,0.5119), vec2(0.4784,0.5119), 0.0947, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1101,-0.461,-0.2917), vec3(-0.1101,-0.4309,-0.2917), vec3(-0.0131,-0.4483,-0.2747), vec3(0.1728,0,-0.985), vec2(0.4812,0.5119), vec2(0.4812,0.5263), vec2(0.4812,0.5263), 0.953, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1101,-0.461,-0.2917), vec3(-0.0131,-0.4483,-0.2747), vec3(-0.0131,-0.4621,-0.2747), vec3(0.1728,0,-0.985), vec2(0.4812,0.5119), vec2(0.4812,0.5263), vec2(0.4812,0.5119), 0.9314, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1213,-0.461,-0.2346), vec3(-0.1216,-0.4373,-0.2335), vec3(-0.0242,-0.4531,-0.2182), vec3(0.1625,0.0496,-0.9855), vec2(0.4757,0.5119), vec2(0.4755,0.5232), vec2(0.4755,0.5232), 0.6378, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1213,-0.461,-0.2346), vec3(-0.0242,-0.4531,-0.2182), vec3(-0.0241,-0.4639,-0.2189), vec3(0.1613,0.0636,-0.9849), vec2(0.4757,0.5119), vec2(0.4755,0.5232), vec2(0.4757,0.5119), 0.1186, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1216,-0.4373,-0.2335), vec3(-0.126,-0.4398,-0.2112), vec3(-0.0268,-0.4542,-0.2051), vec3(0.1343,0.9818,0.1345), vec2(0.4755,0.5232), vec2(0.4734,0.522), vec2(0.4734,0.522), 0.1934, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1216,-0.4373,-0.2335), vec3(-0.0268,-0.4542,-0.2051), vec3(-0.0242,-0.4531,-0.2182), vec3(0.1413,0.9836,0.1121), vec2(0.4755,0.5232), vec2(0.4734,0.522), vec2(0.4755,0.5232), 0.1198, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.126,-0.4398,-0.2112), vec3(-0.126,-0.461,-0.2112), vec3(-0.0268,-0.4639,-0.2051), vec3(-0.0615,0,0.9981), vec2(0.4734,0.522), vec2(0.4734,0.5119), vec2(0.4734,0.5119), 0.7105, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.126,-0.4398,-0.2112), vec3(-0.0268,-0.4639,-0.2051), vec3(-0.0268,-0.4542,-0.2051), vec3(-0.0615,0,0.9981), vec2(0.4734,0.522), vec2(0.4734,0.5119), vec2(0.4734,0.522), 0.9099, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.126,-0.461,-0.2112), vec3(-0.1213,-0.461,-0.2346), vec3(-0.0241,-0.4639,-0.2189), vec3(-0.0289,-0.9996,-0.0057), vec2(0.4734,0.5119), vec2(0.4757,0.5119), vec2(0.4757,0.5119), 0.9368, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.126,-0.461,-0.2112), vec3(-0.0241,-0.4639,-0.2189), vec3(-0.0268,-0.4639,-0.2051), vec3(-0.0289,-0.9996,-0.0057), vec2(0.4734,0.5119), vec2(0.4757,0.5119), vec2(0.4734,0.5119), 0.3428, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1158,-0.461,-0.2627), vec3(-0.1164,-0.4344,-0.2599), vec3(-0.0191,-0.451,-0.2441), vec3(0.177,0.1061,-0.9785), vec2(0.4784,0.5119), vec2(0.4781,0.5246), vec2(0.4781,0.5246), 0.7954, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1158,-0.461,-0.2627), vec3(-0.0191,-0.451,-0.2441), vec3(-0.0188,-0.4632,-0.2457), vec3(0.1734,0.1357,-0.9755), vec2(0.4784,0.5119), vec2(0.4781,0.5246), vec2(0.4784,0.5119), 0.9411, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1164,-0.4344,-0.2599), vec3(-0.1216,-0.4373,-0.2335), vec3(-0.0222,-0.4524,-0.2285), vec3(0.1415,0.9806,0.1358), vec2(0.4781,0.5246), vec2(0.4755,0.5232), vec2(0.4755,0.5232), 0.1181, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1164,-0.4344,-0.2599), vec3(-0.0222,-0.4524,-0.2285), vec3(-0.0191,-0.451,-0.2441), vec3(0.1492,0.9823,0.1136), vec2(0.4781,0.5246), vec2(0.4755,0.5232), vec2(0.4781,0.5246), 0.5063, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1216,-0.4373,-0.2335), vec3(-0.1213,-0.461,-0.2346), vec3(-0.0221,-0.4632,-0.2292), vec3(-0.0554,-0.0491,0.9973), vec2(0.4755,0.5232), vec2(0.4757,0.5119), vec2(0.4757,0.5119), 0.4324, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1216,-0.4373,-0.2335), vec3(-0.0221,-0.4632,-0.2292), vec3(-0.0222,-0.4524,-0.2285), vec3(-0.059,-0.0632,0.9963), vec2(0.4755,0.5232), vec2(0.4757,0.5119), vec2(0.4755,0.5232), 0.0975, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1213,-0.461,-0.2346), vec3(-0.1158,-0.461,-0.2627), vec3(-0.0188,-0.4632,-0.2457), vec3(-0.022,-0.9997,-0.0043), vec2(0.4757,0.5119), vec2(0.4784,0.5119), vec2(0.4784,0.5119), 0.336, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1213,-0.461,-0.2346), vec3(-0.0188,-0.4632,-0.2457), vec3(-0.0221,-0.4632,-0.2292), vec3(-0.022,-0.9997,-0.0043), vec2(0.4757,0.5119), vec2(0.4784,0.5119), vec2(0.4757,0.5119), 0.3802, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 7 (17 tris)
    if (raySphereNear(ro, rd, vec3(-0.4959,0.0962,-0.1119), 0.5289)) {
        if (triHit(ro, rd, vec3(-0.4964,0.1935,-0.1337), vec3(-0.5281,0.3591,-0.3065), vec3(-0.7319,0.1705,-0.2511), vec3(-0.3963,0.6255,0.6721), vec2(0.2184,0.8327), vec2(0.2184,0.9004), vec2(0.1091,0.8381), 0.2236, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4964,0.1935,-0.1337), vec3(-0.7319,0.1705,-0.2511), vec3(-0.6322,0.0161,-0.1253), vec3(-0.4426,0.3773,0.8135), vec2(0.2184,0.8327), vec2(0.1091,0.8381), vec2(0.1225,0.7728), 0.9339, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6322,0.0161,-0.1253), vec3(-0.7319,0.1705,-0.2511), vec3(-0.8918,-0.0846,-0.1738), vec3(-0.3319,0.4579,0.8247), vec2(0.1225,0.7728), vec2(0.1091,0.8381), vec2(0.0449,0.7326), 0.7782, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4989,-0.1266,-0.0864), vec3(-0.5155,0.1804,-0.0764), vec3(-0.6411,0.011,-0.0957), vec3(-0.1017,-0.038,0.9941), vec2(0.1985,0.6864), vec2(0.206,0.8083), vec2(0.1117,0.7528), 0.9751, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4989,-0.1266,-0.0864), vec3(-0.6411,0.011,-0.0957), vec3(-0.6462,-0.23,-0.0854), vec3(-0.0232,0.0435,0.9988), vec2(0.1985,0.6864), vec2(0.1117,0.7528), vec2(0.1056,0.6574), 0.2621, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3594,-0.0274,-0.0269), vec3(-0.3526,0.2757,-0.0228), vec3(-0.5155,0.1804,-0.0764), vec3(-0.3093,-0.006,0.951), vec2(0.3085,0.7162), vec2(0.3163,0.8424), vec2(0.206,0.8083), 0.6802, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3594,-0.0274,-0.0269), vec3(-0.5155,0.1804,-0.0764), vec3(-0.4989,-0.1266,-0.0864), vec3(-0.3615,-0.05,0.931), vec2(0.3085,0.7162), vec2(0.206,0.8083), vec2(0.1985,0.6864), 0.4575, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1076,-0.0227,-0.0216), vec3(-0.1866,0.1904,-0.0386), vec3(-0.3526,0.2757,-0.0228), vec3(0.1643,0.1391,0.9766), vec2(0.4237,0.6995), vec2(0.3982,0.8016), vec2(0.3163,0.8424), 0.178, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1076,-0.0227,-0.0216), vec3(-0.3526,0.2757,-0.0228), vec3(-0.3594,-0.0274,-0.0269), vec3(-0.0211,-0.0131,0.9997), vec2(0.4237,0.6995), vec2(0.3163,0.8424), vec2(0.3085,0.7162), 0.8113, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.213,-0.3295,-0.1993), vec3(-0.3594,-0.0274,-0.0269), vec3(-0.4989,-0.1266,-0.0864), vec3(-0.0134,-0.5004,0.8657), vec2(0.3851,0.5701), vec2(0.3085,0.7162), vec2(0.1985,0.6864), 0.6317, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6322,0.0161,-0.1253), vec3(-0.8639,-0.1376,-0.124), vec3(-0.6411,0.011,-0.0957), vec3(-0.5527,0.8331,-0.0208), vec2(0.1225,0.7728), vec2(0.0515,0.6993), vec2(0.1117,0.7528), 0.1022, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4964,0.1935,-0.1337), vec3(-0.6322,0.0161,-0.1253), vec3(-0.6411,0.011,-0.0957), vec3(-0.79,0.5986,-0.1325), vec2(0.2184,0.8327), vec2(0.1225,0.7728), vec2(0.1117,0.7528), 0.1325, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4964,0.1935,-0.1337), vec3(-0.6411,0.011,-0.0957), vec3(-0.5155,0.1804,-0.0764), vec3(-0.79,0.6001,-0.1255), vec2(0.2184,0.8327), vec2(0.1117,0.7528), vec2(0.206,0.8083), 0.4562, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3285,0.3017,-0.1119), vec3(-0.4964,0.1935,-0.1337), vec3(-0.5155,0.1804,-0.0764), vec3(-0.5428,0.8398,0.0118), vec2(0.3282,0.8724), vec2(0.2184,0.8327), vec2(0.206,0.8083), 0.0948, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3285,0.3017,-0.1119), vec3(-0.5155,0.1804,-0.0764), vec3(-0.3526,0.2757,-0.0228), vec3(-0.5275,0.8432,0.1039), vec2(0.3282,0.8724), vec2(0.206,0.8083), vec2(0.3163,0.8424), 0.7032, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.1563), vec3(-0.3526,0.2757,-0.0228), vec3(-0.1866,0.1904,-0.0386), vec3(0.4552,0.8235,0.3386), vec2(0.4097,0.8361), vec2(0.3163,0.8424), vec2(0.3982,0.8016), 0.824, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5281,0.3591,-0.3065), vec3(-0.7774,0.1928,-0.3342), vec3(-0.7319,0.1705,-0.2511), vec3(-0.5236,0.7058,0.4771), vec2(0.2184,0.9004), vec2(0.1091,0.8583), vec2(0.1091,0.8381), 0.3066, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 8 (19 tris)
    if (raySphereNear(ro, rd, vec3(-0.1833,0.1322,-0.6641), 0.5682)) {
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.626), vec3(-0.0802,0.4256,-0.4787), vec3(0.1089,0.3724,-0.4739), vec3(0.1718,0.5376,-0.8255), vec2(0.4097,0.8361), vec2(0.4506,0.9222), vec2(0.5439,0.8967), 0.9201, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.626), vec3(0.1089,0.3724,-0.4739), vec3(0.1176,0.2598,-0.6133), vec3(-0.0651,0.7743,-0.6295), vec2(0.4097,0.8361), vec2(0.5439,0.8967), vec2(0.5482,0.8523), 0.3017, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.626), vec3(-0.3285,0.3017,-0.6704), vec3(-0.3396,0.4483,-0.4952), vec3(0.466,0.693,-0.5501), vec2(0.4097,0.8361), vec2(0.3282,0.8724), vec2(0.3227,0.9331), 0.1623, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3736,-0.0274,-0.7689), vec3(-0.6182,0.1804,-0.7452), vec3(-0.3526,0.2757,-0.7595), vec3(-0.0665,0.0355,-0.9972), vec2(0.3085,0.7162), vec2(0.206,0.8083), vec2(0.3163,0.8424), 0.9779, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1076,-0.0227,-0.7607), vec3(-0.3736,-0.0274,-0.7689), vec3(-0.3526,0.2757,-0.7595), vec3(0.0301,0.0289,-0.9991), vec2(0.4237,0.6995), vec2(0.3085,0.7162), vec2(0.3163,0.8424), 0.1791, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1076,-0.0227,-0.7607), vec3(-0.3526,0.2757,-0.7595), vec3(-0.1866,0.1904,-0.7437), vec3(0.1643,0.1391,-0.9766), vec2(0.4237,0.6995), vec2(0.3163,0.8424), vec2(0.3847,0.8016), 0.143, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0716,0.0171,-0.626), vec3(-0.1632,0.2259,-0.626), vec3(0.1176,0.2598,-0.6133), vec3(0.0429,0.0188,-0.9989), vec2(0.4549,0.7361), vec2(0.4097,0.8361), vec2(0.5482,0.8523), 0.7044, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0716,0.0171,-0.626), vec3(0.1176,0.2598,-0.6133), vec3(0.1176,0.0163,-0.6133), vec3(0.0669,0,-0.9978), vec2(0.4549,0.7361), vec2(0.5482,0.8523), vec2(0.5482,0.7357), 0.5966, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.2806,-0.6158), vec3(0.1176,0.0163,-0.6133), vec3(0.1176,0.2598,-0.6133), vec3(-0.0214,0,-0.9998), vec2(0.605,0.8623), vec2(0.5482,0.7357), vec2(0.5482,0.8523), 0.6802, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.213,-0.3295,-0.583), vec3(-0.6697,-0.1266,-0.7465), vec3(-0.3736,-0.0274,-0.7689), vec3(0.0964,-0.4839,-0.8698), vec2(0.3851,0.5701), vec2(0.1985,0.6864), vec2(0.3085,0.7162), 0.4844, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0805,-0.2963,-0.5908), vec3(-0.3736,-0.0274,-0.7689), vec3(-0.1076,-0.0227,-0.7607), vec3(0.0354,-0.5247,-0.8506), vec2(0.4179,0.6003), vec2(0.3085,0.7162), vec2(0.4237,0.6995), 0.7548, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.4709), vec3(-0.0716,0.0171,-0.626), vec3(0.1176,0.0163,-0.6133), vec3(0.0565,-0.485,-0.8727), vec2(0.4621,0.6317), vec2(0.4549,0.7361), vec2(0.5482,0.7357), 0.7712, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3285,0.3017,-0.6704), vec3(-0.3526,0.2757,-0.7595), vec3(-0.6182,0.1804,-0.7452), vec3(-0.3409,0.9231,-0.1779), vec2(0.3282,0.8724), vec2(0.3163,0.8424), vec2(0.206,0.8083), 0.3791, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3285,0.3017,-0.6704), vec3(-0.6182,0.1804,-0.7452), vec3(-0.5876,0.1935,-0.6976), vec3(-0.3848,0.923,-0.0076), vec2(0.3282,0.8724), vec2(0.206,0.8083), vec2(0.2184,0.8327), 0.351, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0716,0.0171,-0.626), vec3(-0.1076,-0.0227,-0.7607), vec3(-0.1866,0.1904,-0.7437), vec3(0.8737,0.351,-0.3369), vec2(0.4549,0.7361), vec2(0.4237,0.6995), vec2(0.3847,0.8016), 0.2062, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0716,0.0171,-0.626), vec3(-0.1866,0.1904,-0.7437), vec3(-0.1632,0.2259,-0.626), vec3(0.8763,0.3846,-0.2901), vec2(0.4549,0.7361), vec2(0.3847,0.8016), vec2(0.4097,0.8361), 0.4493, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.626), vec3(-0.1866,0.1904,-0.7437), vec3(-0.3526,0.2757,-0.7595), vec3(0.4552,0.8235,-0.3386), vec2(0.4097,0.8361), vec2(0.3847,0.8016), vec2(0.3163,0.8424), 0.3241, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.626), vec3(-0.3526,0.2757,-0.7595), vec3(-0.3285,0.3017,-0.6704), vec3(0.4676,0.8061,-0.3627), vec2(0.4097,0.8361), vec2(0.3163,0.8424), vec2(0.3282,0.8724), 0.2727, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.4709), vec3(-0.1076,-0.0227,-0.7607), vec3(-0.0716,0.0171,-0.626), vec3(0.9687,-0.08,-0.2349), vec2(0.4621,0.6317), vec2(0.4237,0.6995), vec2(0.4549,0.7361), 0.697, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 9 (81 tris)
    if (raySphereNear(ro, rd, vec3(0.4819,0.4526,-0.3933), 0.3832)) {
        if (triHit(ro, rd, vec3(0.239,0.3799,-0.3075), vec3(0.3542,0.3014,-0.1789), vec3(0.348,0.4377,-0.312), vec3(-0.3186,0.6549,0.6853), vec2(0.608,0.9003), vec2(0.6743,0.8766), vec2(0.6665,0.9287), 0.7796, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.348,0.4377,-0.312), vec3(0.3542,0.3014,-0.1789), vec3(0.4455,0.3023,-0.2258), vec3(0.3354,0.666,0.6663), vec2(0.5946,0.9105), vec2(0.58,0.8605), vec2(0.6087,0.8623), 0.5556, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.348,0.4377,-0.312), vec3(0.4455,0.3023,-0.2258), vec3(0.4464,0.4904,-0.3295), vec3(-0.1026,0.4809,0.8708), vec2(0.5946,0.9105), vec2(0.6087,0.8623), vec2(0.626,0.9215), 0.0459, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.449,0.5433,-0.2305), vec3(0.4507,0.5273,-0.2136), vec3(0.5138,0.5316,-0.2208), vec3(0.0287,0.7298,0.6831), vec2(0.7116,0.9881), vec2(0.7124,0.9805), vec2(0.7436,0.9825), 0.396, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.449,0.5433,-0.2305), vec3(0.5138,0.5316,-0.2208), vec3(0.5121,0.5428,-0.2332), vec3(0.034,0.7452,0.6659), vec2(0.7116,0.9881), vec2(0.7436,0.9825), vec2(0.7427,0.9879), 0.9863, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.4867,-0.3461), vec3(0.5503,0.3366,-0.2702), vec3(0.661,0.3957,-0.2685), vec3(-0.2475,0.4384,0.864), vec2(0.7676,0.951), vec2(0.7616,0.8891), vec2(0.8088,0.9078), 0.5848, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.4867,-0.3461), vec3(0.661,0.3957,-0.2685), vec3(0.662,0.4579,-0.3422), vec3(0.1722,0.7513,0.6371), vec2(0.7676,0.951), vec2(0.8088,0.9078), vec2(0.818,0.949), 0.66, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4464,0.4904,-0.3295), vec3(0.4455,0.3023,-0.2258), vec3(0.4652,0.3449,-0.2501), vec3(0.0353,0.4826,0.8751), vec2(0.626,0.9215), vec2(0.6087,0.8623), vec2(0.6175,0.8745), 0.8377, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4464,0.4904,-0.3295), vec3(0.4652,0.3449,-0.2501), vec3(0.4585,0.4804,-0.3074), vec3(-0.8237,0.186,0.5357), vec2(0.626,0.9215), vec2(0.6175,0.8745), vec2(0.6311,0.9156), 0.8957, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4455,0.3023,-0.2258), vec3(0.5503,0.3366,-0.2702), vec3(0.529,0.3571,-0.2774), vec3(0.1943,0.4996,0.8442), vec2(0.7099,0.8727), vec2(0.7616,0.8891), vec2(0.7511,0.8989), 0.6324, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4455,0.3023,-0.2258), vec3(0.529,0.3571,-0.2774), vec3(0.4652,0.3449,-0.2501), vec3(0.3089,0.3593,0.8806), vec2(0.7099,0.8727), vec2(0.7511,0.8989), vec2(0.7196,0.8931), 0.5344, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.3366,-0.2702), vec3(0.5512,0.4867,-0.3461), vec3(0.5386,0.4796,-0.3125), vec3(0.9066,0.1862,0.3787), vec2(0.6904,0.9544), vec2(0.648,0.94), vec2(0.6528,0.9321), 0.8862, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.3366,-0.2702), vec3(0.5386,0.4796,-0.3125), vec3(0.529,0.3571,-0.2774), vec3(-0.0567,0.2792,0.9586), vec2(0.6904,0.9544), vec2(0.6528,0.9321), vec2(0.6862,0.9467), 0.9696, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.4867,-0.3461), vec3(0.4464,0.4904,-0.3295), vec3(0.4585,0.4804,-0.3074), vec3(0.0906,0.9263,0.3659), vec2(0.648,0.94), vec2(0.626,0.9215), vec2(0.6311,0.9156), 0.351, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.4867,-0.3461), vec3(0.4585,0.4804,-0.3074), vec3(0.5386,0.4796,-0.3125), vec3(0.0243,0.9763,0.2151), vec2(0.648,0.94), vec2(0.6311,0.9156), vec2(0.6528,0.9321), 0.7617, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4585,0.4804,-0.3074), vec3(0.4652,0.3449,-0.2501), vec3(0.423,0.4448,-0.2437), vec3(-0.761,-0.2842,-0.5832), vec2(0.6311,0.9156), vec2(0.6175,0.8745), vec2(0.6365,0.8908), 0.7166, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4585,0.4804,-0.3074), vec3(0.423,0.4448,-0.2437), vec3(0.4305,0.5113,-0.2576), vec3(-0.8723,-0.0049,-0.489), vec2(0.6311,0.9156), vec2(0.6365,0.8908), vec2(0.6429,0.9002), 0.7389, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4652,0.3449,-0.2501), vec3(0.529,0.3571,-0.2774), vec3(0.5428,0.4483,-0.2497), vec3(0.4239,-0.3216,0.8467), vec2(0.7196,0.8931), vec2(0.7511,0.8989), vec2(0.7579,0.9426), 0.0866, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4652,0.3449,-0.2501), vec3(0.5428,0.4483,-0.2497), vec3(0.423,0.4448,-0.2437), vec3(0.0509,-0.0423,0.9978), vec2(0.7196,0.8931), vec2(0.7579,0.9426), vec2(0.6988,0.941), 0.6374, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.529,0.3571,-0.2774), vec3(0.5386,0.4796,-0.3125), vec3(0.5503,0.5109,-0.2598), vec3(0.9821,-0.1188,-0.1459), vec2(0.6862,0.9467), vec2(0.6528,0.9321), vec2(0.6626,0.9191), 0.35, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.529,0.3571,-0.2774), vec3(0.5503,0.5109,-0.2598), vec3(0.5428,0.4483,-0.2497), vec3(0.9893,-0.1286,-0.0687), vec2(0.6862,0.9467), vec2(0.6626,0.9191), vec2(0.6726,0.9266), 0.3697, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5386,0.4796,-0.3125), vec3(0.4585,0.4804,-0.3074), vec3(0.4305,0.5113,-0.2576), vec3(-0.0254,0.843,-0.5373), vec2(0.6528,0.9321), vec2(0.6311,0.9156), vec2(0.6429,0.9002), 0.7856, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5386,0.4796,-0.3125), vec3(0.4305,0.5113,-0.2576), vec3(0.5503,0.5109,-0.2598), vec3(-0.0067,0.86,-0.5102), vec2(0.6528,0.9321), vec2(0.6429,0.9002), vec2(0.6626,0.9191), 0.654, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4305,0.5113,-0.2576), vec3(0.423,0.4448,-0.2437), vec3(0.4507,0.5273,-0.2136), vec3(-0.9171,0.1772,0.3572), vec2(0.7025,0.9562), vec2(0.6988,0.941), vec2(0.7124,0.9805), 0.4123, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4305,0.5113,-0.2576), vec3(0.4507,0.5273,-0.2136), vec3(0.449,0.5433,-0.2305), vec3(-0.9109,0.251,0.3275), vec2(0.7025,0.9562), vec2(0.7124,0.9805), vec2(0.7116,0.9881), 0.8321, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.423,0.4448,-0.2437), vec3(0.5428,0.4483,-0.2497), vec3(0.5138,0.5316,-0.2208), vec3(0.0564,-0.3091,0.9493), vec2(0.6988,0.941), vec2(0.7579,0.9426), vec2(0.7436,0.9825), 0.1349, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.423,0.4448,-0.2437), vec3(0.5138,0.5316,-0.2208), vec3(0.4507,0.5273,-0.2136), vec3(0.1311,-0.3785,0.9163), vec2(0.6988,0.941), vec2(0.7436,0.9825), vec2(0.7124,0.9805), 0.3089, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5428,0.4483,-0.2497), vec3(0.5503,0.5109,-0.2598), vec3(0.5121,0.5428,-0.2332), vec3(0.6036,0.0577,0.7952), vec2(0.7579,0.9426), vec2(0.7615,0.956), vec2(0.7427,0.9879), 0.4176, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5428,0.4483,-0.2497), vec3(0.5121,0.5428,-0.2332), vec3(0.5138,0.5316,-0.2208), vec3(0.9495,0.2866,0.1275), vec2(0.7579,0.9426), vec2(0.7427,0.9879), vec2(0.7436,0.9825), 0.2329, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.5109,-0.2598), vec3(0.4305,0.5113,-0.2576), vec3(0.449,0.5433,-0.2305), vec3(-0.012,0.6514,-0.7587), vec2(0.6626,0.9191), vec2(0.6429,0.9002), vec2(0.6537,0.894), 0.1633, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.5109,-0.2598), vec3(0.449,0.5433,-0.2305), vec3(0.5121,0.5428,-0.2332), vec3(-0.029,0.6207,-0.7835), vec2(0.6626,0.9191), vec2(0.6537,0.894), vec2(0.6646,0.905), 0.6682, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.348,0.4599,-0.3911), vec3(0.239,0.402,-0.3911), vec3(0.239,0.3799,-0.3075), vec3(-0.4564,0.8601,0.2277), vec2(0.6687,0.9529), vec2(0.608,0.9205), vec2(0.608,0.9003), 0.5278, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.348,0.4599,-0.3911), vec3(0.239,0.3799,-0.3075), vec3(0.348,0.4377,-0.312), vec3(-0.4469,0.8614,0.2413), vec2(0.6687,0.9529), vec2(0.608,0.9003), vec2(0.6665,0.9287), 0.9672, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4464,0.5042,-0.3911), vec3(0.348,0.4599,-0.3911), vec3(0.348,0.4377,-0.312), vec3(-0.3977,0.8835,0.2475), vec2(0.6191,0.9386), vec2(0.5915,0.9313), vec2(0.5946,0.9105), 0.2147, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4464,0.5042,-0.3911), vec3(0.348,0.4377,-0.312), vec3(0.4464,0.4904,-0.3295), vec3(-0.4352,0.8786,0.1968), vec2(0.6191,0.9386), vec2(0.5946,0.9105), vec2(0.626,0.9215), 0.7337, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.5005,-0.3911), vec3(0.4464,0.5042,-0.3911), vec3(0.4464,0.4904,-0.3295), vec3(0.0345,0.9752,0.2184), vec2(0.6422,0.9518), vec2(0.6191,0.9386), vec2(0.626,0.9215), 0.6431, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.5005,-0.3911), vec3(0.4464,0.4904,-0.3295), vec3(0.5512,0.4867,-0.3461), vec3(0.0798,0.9531,0.2919), vec2(0.6422,0.9518), vec2(0.626,0.9215), vec2(0.648,0.94), 0.6947, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.662,0.4801,-0.3911), vec3(0.5512,0.5005,-0.3911), vec3(0.5512,0.4867,-0.3461), vec3(0.1732,0.9417,0.2884), vec2(0.8166,0.9579), vec2(0.7639,0.9675), vec2(0.7676,0.951), 0.4429, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.662,0.4801,-0.3911), vec3(0.5512,0.4867,-0.3461), vec3(0.662,0.4579,-0.3422), vec3(0.2164,0.8896,0.4023), vec2(0.8166,0.9579), vec2(0.7676,0.951), vec2(0.818,0.949), 0.712, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8004,0.4352,-0.3911), vec3(0.662,0.4801,-0.3911), vec3(0.662,0.4579,-0.3422), vec3(0.2834,0.8738,0.3951), vec2(0.8849,0.9364), vec2(0.8166,0.9579), vec2(0.818,0.949), 0.3893, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.239,0.3799,-0.4748), vec3(0.348,0.4377,-0.4702), vec3(0.3542,0.3014,-0.6034), vec3(-0.3186,0.6549,-0.6853), vec2(0.608,0.9003), vec2(0.6665,0.9287), vec2(0.6743,0.8766), 0.7292, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.239,0.3799,-0.4748), vec3(0.3542,0.3014,-0.6034), vec3(0.2328,0.2806,-0.6158), vec3(-0.0815,0.8165,-0.5715), vec2(0.608,0.9003), vec2(0.6743,0.8766), vec2(0.605,0.8623), 0.2974, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.348,0.4377,-0.4702), vec3(0.4464,0.4904,-0.4528), vec3(0.4455,0.3023,-0.5565), vec3(-0.1026,0.4809,-0.8708), vec2(0.5946,0.9105), vec2(0.626,0.9215), vec2(0.6087,0.8623), 0.0612, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.348,0.4377,-0.4702), vec3(0.4455,0.3023,-0.5565), vec3(0.3542,0.3014,-0.6034), vec3(0.3354,0.666,-0.6663), vec2(0.5946,0.9105), vec2(0.6087,0.8623), vec2(0.58,0.8605), 0.8191, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.449,0.5433,-0.5518), vec3(0.5121,0.5428,-0.5491), vec3(0.5138,0.5316,-0.5615), vec3(0.034,0.7452,-0.666), vec2(0.7116,0.9881), vec2(0.7427,0.9879), vec2(0.7436,0.9825), 0.9741, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.449,0.5433,-0.5518), vec3(0.5138,0.5316,-0.5615), vec3(0.4507,0.5273,-0.5687), vec3(0.0287,0.7297,-0.6831), vec2(0.7116,0.9881), vec2(0.7436,0.9825), vec2(0.7124,0.9805), 0.5721, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.4867,-0.4362), vec3(0.662,0.4579,-0.4401), vec3(0.661,0.3957,-0.5138), vec3(0.1722,0.7513,-0.6371), vec2(0.7676,0.951), vec2(0.818,0.949), vec2(0.8088,0.9078), 0.3263, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.4867,-0.4362), vec3(0.661,0.3957,-0.5138), vec3(0.5503,0.3366,-0.5121), vec3(-0.2475,0.4384,-0.864), vec2(0.7676,0.951), vec2(0.8088,0.9078), vec2(0.7616,0.8891), 0.7823, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4464,0.4904,-0.4528), vec3(0.4585,0.4804,-0.4749), vec3(0.4652,0.3449,-0.5322), vec3(-0.8237,0.186,-0.5357), vec2(0.626,0.9215), vec2(0.6311,0.9156), vec2(0.6175,0.8745), 0.3698, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4464,0.4904,-0.4528), vec3(0.4652,0.3449,-0.5322), vec3(0.4455,0.3023,-0.5565), vec3(0.0353,0.4826,-0.8751), vec2(0.626,0.9215), vec2(0.6175,0.8745), vec2(0.6087,0.8623), 0.7796, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4455,0.3023,-0.5565), vec3(0.4652,0.3449,-0.5322), vec3(0.529,0.3571,-0.5049), vec3(0.3089,0.3593,-0.8806), vec2(0.7099,0.8727), vec2(0.7196,0.8931), vec2(0.7511,0.8989), 0.1006, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4455,0.3023,-0.5565), vec3(0.529,0.3571,-0.5049), vec3(0.5503,0.3366,-0.5121), vec3(0.1943,0.4996,-0.8442), vec2(0.7099,0.8727), vec2(0.7511,0.8989), vec2(0.7616,0.8891), 0.8965, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.3366,-0.5121), vec3(0.529,0.3571,-0.5049), vec3(0.5386,0.4796,-0.4698), vec3(-0.0567,0.2792,-0.9586), vec2(0.6904,0.9544), vec2(0.6862,0.9467), vec2(0.6528,0.9321), 0.2605, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.3366,-0.5121), vec3(0.5386,0.4796,-0.4698), vec3(0.5512,0.4867,-0.4362), vec3(0.9066,0.1862,-0.3787), vec2(0.6904,0.9544), vec2(0.6528,0.9321), vec2(0.648,0.94), 0.1519, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.4867,-0.4362), vec3(0.5386,0.4796,-0.4698), vec3(0.4585,0.4804,-0.4749), vec3(0.0243,0.9763,-0.2151), vec2(0.648,0.94), vec2(0.6528,0.9321), vec2(0.6311,0.9156), 0.9557, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.4867,-0.4362), vec3(0.4585,0.4804,-0.4749), vec3(0.4464,0.4904,-0.4528), vec3(0.0906,0.9263,-0.3659), vec2(0.648,0.94), vec2(0.6311,0.9156), vec2(0.626,0.9215), 0.8522, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4585,0.4804,-0.4749), vec3(0.4305,0.5113,-0.5247), vec3(0.423,0.4448,-0.5386), vec3(-0.8723,-0.0049,0.489), vec2(0.6311,0.9156), vec2(0.6429,0.9002), vec2(0.6365,0.8908), 0.8796, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4585,0.4804,-0.4749), vec3(0.423,0.4448,-0.5386), vec3(0.4652,0.3449,-0.5322), vec3(-0.761,-0.2842,0.5832), vec2(0.6311,0.9156), vec2(0.6365,0.8908), vec2(0.6175,0.8745), 0.4733, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4652,0.3449,-0.5322), vec3(0.423,0.4448,-0.5386), vec3(0.5428,0.4483,-0.5326), vec3(0.0509,-0.0423,-0.9978), vec2(0.7196,0.8931), vec2(0.6988,0.941), vec2(0.7579,0.9426), 0.0661, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4652,0.3449,-0.5322), vec3(0.5428,0.4483,-0.5326), vec3(0.529,0.3571,-0.5049), vec3(0.4239,-0.3216,-0.8467), vec2(0.7196,0.8931), vec2(0.7579,0.9426), vec2(0.7511,0.8989), 0.3656, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.529,0.3571,-0.5049), vec3(0.5428,0.4483,-0.5326), vec3(0.5503,0.5109,-0.5225), vec3(0.9893,-0.1286,0.0687), vec2(0.6862,0.9467), vec2(0.6726,0.9266), vec2(0.6626,0.9191), 0.6678, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.529,0.3571,-0.5049), vec3(0.5503,0.5109,-0.5225), vec3(0.5386,0.4796,-0.4698), vec3(0.9821,-0.1188,0.1459), vec2(0.6862,0.9467), vec2(0.6626,0.9191), vec2(0.6528,0.9321), 0.1654, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5386,0.4796,-0.4698), vec3(0.5503,0.5109,-0.5225), vec3(0.4305,0.5113,-0.5247), vec3(-0.0067,0.86,0.5102), vec2(0.6528,0.9321), vec2(0.6626,0.9191), vec2(0.6429,0.9002), 0.6458, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5386,0.4796,-0.4698), vec3(0.4305,0.5113,-0.5247), vec3(0.4585,0.4804,-0.4749), vec3(-0.0254,0.843,0.5373), vec2(0.6528,0.9321), vec2(0.6429,0.9002), vec2(0.6311,0.9156), 0.7516, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4305,0.5113,-0.5247), vec3(0.449,0.5433,-0.5518), vec3(0.4507,0.5273,-0.5687), vec3(-0.9109,0.251,-0.3275), vec2(0.7025,0.9562), vec2(0.7116,0.9881), vec2(0.7124,0.9805), 0.8536, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4305,0.5113,-0.5247), vec3(0.4507,0.5273,-0.5687), vec3(0.423,0.4448,-0.5386), vec3(-0.9171,0.1772,-0.3572), vec2(0.7025,0.9562), vec2(0.7124,0.9805), vec2(0.6988,0.941), 0.3496, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.423,0.4448,-0.5386), vec3(0.4507,0.5273,-0.5687), vec3(0.5138,0.5316,-0.5615), vec3(0.1311,-0.3785,-0.9163), vec2(0.6988,0.941), vec2(0.7124,0.9805), vec2(0.7436,0.9825), 0.8397, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.423,0.4448,-0.5386), vec3(0.5138,0.5316,-0.5615), vec3(0.5428,0.4483,-0.5326), vec3(0.0564,-0.3091,-0.9494), vec2(0.6988,0.941), vec2(0.7436,0.9825), vec2(0.7579,0.9426), 0.9642, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5428,0.4483,-0.5326), vec3(0.5138,0.5316,-0.5615), vec3(0.5121,0.5428,-0.5491), vec3(0.9495,0.2866,-0.1275), vec2(0.7579,0.9426), vec2(0.7436,0.9825), vec2(0.7427,0.9879), 0.6098, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5428,0.4483,-0.5326), vec3(0.5121,0.5428,-0.5491), vec3(0.5503,0.5109,-0.5225), vec3(0.6036,0.0577,-0.7952), vec2(0.7579,0.9426), vec2(0.7427,0.9879), vec2(0.7615,0.956), 0.3321, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.5109,-0.5225), vec3(0.5121,0.5428,-0.5491), vec3(0.449,0.5433,-0.5518), vec3(-0.029,0.6207,0.7835), vec2(0.6626,0.9191), vec2(0.6646,0.905), vec2(0.6537,0.894), 0.79, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.5109,-0.5225), vec3(0.449,0.5433,-0.5518), vec3(0.4305,0.5113,-0.5247), vec3(-0.012,0.6514,0.7587), vec2(0.6626,0.9191), vec2(0.6537,0.894), vec2(0.6429,0.9002), 0.4797, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.348,0.4599,-0.3911), vec3(0.348,0.4377,-0.4702), vec3(0.239,0.3799,-0.4748), vec3(-0.4469,0.8614,-0.2413), vec2(0.6687,0.9529), vec2(0.6665,0.9287), vec2(0.608,0.9003), 0.3754, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.348,0.4599,-0.3911), vec3(0.239,0.3799,-0.4748), vec3(0.239,0.402,-0.3911), vec3(-0.4564,0.8601,-0.2277), vec2(0.6687,0.9529), vec2(0.608,0.9003), vec2(0.608,0.9205), 0.9821, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4464,0.5042,-0.3911), vec3(0.4464,0.4904,-0.4528), vec3(0.348,0.4377,-0.4702), vec3(-0.4352,0.8786,-0.1968), vec2(0.6191,0.9386), vec2(0.626,0.9215), vec2(0.5946,0.9105), 0.6312, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4464,0.5042,-0.3911), vec3(0.348,0.4377,-0.4702), vec3(0.348,0.4599,-0.3911), vec3(-0.3977,0.8835,-0.2475), vec2(0.6191,0.9386), vec2(0.5946,0.9105), vec2(0.5915,0.9313), 0.5417, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.5005,-0.3911), vec3(0.5512,0.4867,-0.4362), vec3(0.4464,0.4904,-0.4528), vec3(0.0798,0.9531,-0.2919), vec2(0.6422,0.9518), vec2(0.648,0.94), vec2(0.626,0.9215), 0.7642, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5512,0.5005,-0.3911), vec3(0.4464,0.4904,-0.4528), vec3(0.4464,0.5042,-0.3911), vec3(0.0345,0.9752,-0.2184), vec2(0.6422,0.9518), vec2(0.626,0.9215), vec2(0.6191,0.9386), 0.7548, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.662,0.4801,-0.3911), vec3(0.662,0.4579,-0.4401), vec3(0.5512,0.4867,-0.4362), vec3(0.2164,0.8896,-0.4023), vec2(0.8166,0.9579), vec2(0.818,0.949), vec2(0.7676,0.951), 0.4735, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.662,0.4801,-0.3911), vec3(0.5512,0.4867,-0.4362), vec3(0.5512,0.5005,-0.3911), vec3(0.1732,0.9417,-0.2884), vec2(0.8166,0.9579), vec2(0.7676,0.951), vec2(0.7639,0.9675), 0.0848, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8004,0.4352,-0.3911), vec3(0.662,0.4579,-0.4401), vec3(0.662,0.4801,-0.3911), vec3(0.2834,0.8738,-0.3952), vec2(0.8849,0.9364), vec2(0.818,0.949), vec2(0.8166,0.9579), 0.9256, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 10 (51 tris)
    if (raySphereNear(ro, rd, vec3(-0.841,-0.3189,-0.2047), 0.4949)) {
        if (triHit(ro, rd, vec3(-0.6322,0.0161,-0.1253), vec3(-0.8918,-0.0846,-0.1738), vec3(-0.8639,-0.1376,-0.124), vec3(-0.3516,0.5365,0.7672), vec2(0.1225,0.7728), vec2(0.0449,0.7326), vec2(0.0515,0.6993), 0.9007, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6462,-0.23,-0.0854), vec3(-0.6411,0.011,-0.0957), vec3(-0.8639,-0.1376,-0.124), vec3(-0.1558,0.0457,0.9867), vec2(0.1056,0.6574), vec2(0.1117,0.7528), vec2(0.0515,0.6993), 0.1755, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6462,-0.23,-0.0854), vec3(-0.8639,-0.1376,-0.124), vec3(-0.8631,-0.2157,-0.1248), vec3(-0.1797,-0.0118,0.9836), vec2(0.1056,0.6574), vec2(0.0515,0.6993), vec2(0.0521,0.6735), 0.4295, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7151,-0.3687,-0.2334), vec3(-0.6462,-0.23,-0.0854), vec3(-0.8631,-0.2157,-0.1248), vec3(-0.1747,-0.6767,0.7153), vec2(0.1141,0.5467), vec2(0.1056,0.6574), vec2(0.0521,0.6735), 0.4039, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7151,-0.3687,-0.2334), vec3(-0.8631,-0.2157,-0.1248), vec3(-0.8382,-0.3374,-0.2084), vec3(0.0242,-0.5629,0.8262), vec2(0.1141,0.5467), vec2(0.0521,0.6735), vec2(0.0498,0.6265), 0.5172, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5133,-0.4411,-0.2734), vec3(-0.4989,-0.1266,-0.0864), vec3(-0.6462,-0.23,-0.0854), vec3(0.35,-0.4905,0.7981), vec2(0.2141,0.5366), vec2(0.1985,0.6864), vec2(0.1056,0.6574), 0.8701, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5133,-0.4411,-0.2734), vec3(-0.6462,-0.23,-0.0854), vec3(-0.7151,-0.3687,-0.2334), vec3(-0.1108,-0.699,0.7065), vec2(0.2141,0.5366), vec2(0.1056,0.6574), vec2(0.1141,0.5467), 0.6111, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8382,-0.3374,-0.2084), vec3(-0.7613,-0.4014,-0.2448), vec3(-0.7151,-0.3687,-0.2334), vec3(0.0756,-0.4221,0.9034), vec2(0.0498,0.6265), vec2(0.1237,0.5786), vec2(0.1141,0.5467), 0.6268, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7613,-0.4014,-0.2448), vec3(-0.5051,-0.4245,-0.3385), vec3(-0.5133,-0.4411,-0.2734), vec3(-0.1824,-0.9469,-0.2648), vec2(0.1237,0.5786), vec2(0.2263,0.5731), vec2(0.2141,0.5366), 0.2127, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7613,-0.4014,-0.2448), vec3(-0.5133,-0.4411,-0.2734), vec3(-0.7151,-0.3687,-0.2334), vec3(0.0447,-0.3849,0.9219), vec2(0.1237,0.5786), vec2(0.2141,0.5366), vec2(0.1141,0.5467), 0.1759, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7613,-0.4014,-0.2448), vec3(-0.8382,-0.3374,-0.2084), vec3(-0.9665,-0.3454,-0.0252), vec3(0.6811,0.5351,0.4998), vec2(0.9667,0.3171), vec2(0.904,0.3764), vec2(0.7757,0.3446), 0.5913, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7613,-0.4014,-0.2448), vec3(-0.9665,-0.3454,-0.0252), vec3(-0.8859,-0.4367,-0.0664), vec3(0.7231,0.3756,0.5797), vec2(0.9667,0.3171), vec2(0.7757,0.3446), vec2(0.8086,0.2971), 0.4545, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7547,-0.4784,-0.3449), vec3(-0.5297,-0.4523,-0.4306), vec3(-0.5051,-0.4245,-0.3385), vec3(0.1996,-0.9516,0.2336), vec2(0.1237,0.5359), vec2(0.2263,0.5304), vec2(0.2263,0.5731), 0.1693, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7547,-0.4784,-0.3449), vec3(-0.5051,-0.4245,-0.3385), vec3(-0.7613,-0.4014,-0.2448), vec3(0.1525,-0.7783,0.6091), vec2(0.1237,0.5359), vec2(0.2263,0.5731), vec2(0.1237,0.5786), 0.403, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9177,-0.4607,-0.0864), vec3(-0.7547,-0.4784,-0.3449), vec3(-0.7613,-0.4014,-0.2448), vec3(0.6871,-0.5531,0.4712), vec2(0.8086,0.2851), vec2(0.9667,0.305), vec2(0.9667,0.3171), 0.303, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9177,-0.4607,-0.0864), vec3(-0.7613,-0.4014,-0.2448), vec3(-0.8859,-0.4367,-0.0664), vec3(0.5122,-0.8371,0.1921), vec2(0.8086,0.2851), vec2(0.9667,0.3171), vec2(0.8086,0.2971), 0.3686, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8382,-0.3374,-0.2084), vec3(-0.9063,-0.3037,-0.2083), vec3(-0.9799,-0.3476,-0.0303), vec3(0.4123,0.8301,0.3753), vec2(0.904,0.3764), vec2(0.904,0.3818), vec2(0.7757,0.35), 0.2399, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8382,-0.3374,-0.2084), vec3(-0.9799,-0.3476,-0.0303), vec3(-0.9665,-0.3454,-0.0252), vec3(-0.1417,0.9883,-0.0562), vec2(0.904,0.3764), vec2(0.7757,0.35), vec2(0.7757,0.3446), 0.3626, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.922,-0.2239,-0.1914), vec3(-0.9063,-0.3037,-0.2083), vec3(-0.8382,-0.3374,-0.2084), vec3(-0.1108,-0.2275,0.9675), vec2(0.0395,0.6735), vec2(0.0498,0.6265), vec2(0.0498,0.6265), 0.0765, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.922,-0.2239,-0.1914), vec3(-0.8382,-0.3374,-0.2084), vec3(-0.8631,-0.2157,-0.1248), vec3(-0.6002,-0.5326,0.5968), vec2(0.0395,0.6735), vec2(0.0498,0.6265), vec2(0.0521,0.6735), 0.6368, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9228,-0.1376,-0.1906), vec3(-0.922,-0.2239,-0.1914), vec3(-0.8631,-0.2157,-0.1248), vec3(-0.7479,-0.0136,0.6637), vec2(0.0389,0.7168), vec2(0.0395,0.6735), vec2(0.0521,0.6735), 0.1254, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9228,-0.1376,-0.1906), vec3(-0.8631,-0.2157,-0.1248), vec3(-0.8639,-0.1376,-0.124), vec3(-0.7487,-0.015,0.6627), vec2(0.0389,0.7168), vec2(0.0521,0.6735), vec2(0.0515,0.6993), 0.1239, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9138,-0.0625,-0.1986), vec3(-0.9228,-0.1376,-0.1906), vec3(-0.8639,-0.1376,-0.124), vec3(-0.7392,0.1594,0.6543), vec2(0.0449,0.7528), vec2(0.0389,0.7168), vec2(0.0515,0.6993), 0.1158, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9138,-0.0625,-0.1986), vec3(-0.8639,-0.1376,-0.124), vec3(-0.8918,-0.0846,-0.1738), vec3(-0.2957,0.5673,0.7686), vec2(0.0449,0.7528), vec2(0.0515,0.6993), vec2(0.0449,0.7326), 0.7305, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9299,-0.2319,-0.5631), vec3(-0.9808,-0.2281,-0.2579), vec3(-0.9817,-0.1376,-0.2571), vec3(-0.9863,-0.0082,-0.1646), vec2(0.1056,0.6574), vec2(0.0521,0.6735), vec2(0.0515,0.6993), 0.9995, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8339,-0.3978,-0.4294), vec3(-0.8998,-0.3414,-0.2704), vec3(-0.9808,-0.2281,-0.2579), vec3(-0.8131,-0.5659,-0.1366), vec2(0.1141,0.5467), vec2(0.0498,0.6265), vec2(0.0521,0.6735), 0.9279, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8339,-0.3978,-0.4294), vec3(-0.9808,-0.2281,-0.2579), vec3(-0.9299,-0.2319,-0.5631), vec3(-0.8102,-0.572,-0.1281), vec2(0.1141,0.5467), vec2(0.0521,0.6735), vec2(0.1056,0.6574), 0.3015, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5956,-0.4411,-0.5774), vec3(-0.8339,-0.3978,-0.4294), vec3(-0.9299,-0.2319,-0.5631), vec3(-0.4631,-0.703,-0.5398), vec2(0.2141,0.5366), vec2(0.1141,0.5467), vec2(0.1056,0.6574), 0.0453, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8998,-0.3414,-0.2704), vec3(-0.8339,-0.3978,-0.4294), vec3(-0.8296,-0.4258,-0.3751), vec3(-0.855,-0.4853,-0.1826), vec2(0.0498,0.6265), vec2(0.1141,0.5467), vec2(0.1237,0.5786), 0.5709, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8296,-0.4258,-0.3751), vec3(-0.8339,-0.3978,-0.4294), vec3(-0.5956,-0.4411,-0.5774), vec3(-0.3962,-0.8288,-0.3952), vec2(0.1237,0.5786), vec2(0.1141,0.5467), vec2(0.2141,0.5366), 0.9025, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8296,-0.4258,-0.3751), vec3(-0.5956,-0.4411,-0.5774), vec3(-0.5561,-0.4245,-0.5256), vec3(0.1236,-0.9684,0.2166), vec2(0.1237,0.5786), vec2(0.2141,0.5366), vec2(0.2263,0.5731), 0.4242, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8296,-0.4258,-0.3751), vec3(-0.9523,-0.4421,-0.1032), vec3(-0.9933,-0.3498,-0.0354), vec3(-0.9049,-0.0972,-0.4143), vec2(0.9667,0.3171), vec2(0.8086,0.2971), vec2(0.7757,0.3446), 0.1837, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8296,-0.4258,-0.3751), vec3(-0.9933,-0.3498,-0.0354), vec3(-0.8998,-0.3414,-0.2704), vec3(-0.8864,-0.2877,-0.3628), vec2(0.9667,0.3171), vec2(0.7757,0.3446), vec2(0.904,0.3764), 0.5096, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7547,-0.4784,-0.3449), vec3(-0.8296,-0.4258,-0.3751), vec3(-0.5561,-0.4245,-0.5256), vec3(-0.3084,-0.764,-0.5667), vec2(0.1237,0.5359), vec2(0.1237,0.5786), vec2(0.2263,0.5731), 0.2108, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7547,-0.4784,-0.3449), vec3(-0.5561,-0.4245,-0.5256), vec3(-0.5297,-0.4523,-0.4306), vec3(0.0043,-0.9596,-0.2814), vec2(0.1237,0.5359), vec2(0.2263,0.5731), vec2(0.2263,0.5304), 0.3218, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9177,-0.4607,-0.0864), vec3(-0.9523,-0.4421,-0.1032), vec3(-0.8296,-0.4258,-0.3751), vec3(-0.3751,-0.8997,-0.2234), vec2(0.8086,0.2851), vec2(0.8086,0.2971), vec2(0.9667,0.3171), 0.5804, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9177,-0.4607,-0.0864), vec3(-0.8296,-0.4258,-0.3751), vec3(-0.7547,-0.4784,-0.3449), vec3(-0.4872,-0.8368,-0.2499), vec2(0.8086,0.2851), vec2(0.9667,0.3171), vec2(0.9667,0.305), 0.9384, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8998,-0.3414,-0.2704), vec3(-0.9933,-0.3498,-0.0354), vec3(-0.9799,-0.3476,-0.0303), vec3(-0.1528,0.9879,-0.0257), vec2(0.904,0.3764), vec2(0.7757,0.3446), vec2(0.7757,0.35), 0.6292, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8998,-0.3414,-0.2704), vec3(-0.9799,-0.3476,-0.0303), vec3(-0.9063,-0.3037,-0.2083), vec3(-0.8995,0.3254,-0.2916), vec2(0.904,0.3764), vec2(0.7757,0.35), vec2(0.904,0.3818), 0.0186, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.922,-0.2239,-0.1914), vec3(-0.9808,-0.2281,-0.2579), vec3(-0.8998,-0.3414,-0.2704), vec3(-0.6268,-0.5126,0.5869), vec2(0.0395,0.6735), vec2(0.0521,0.6735), vec2(0.0498,0.6265), 0.9424, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.922,-0.2239,-0.1914), vec3(-0.8998,-0.3414,-0.2704), vec3(-0.9063,-0.3037,-0.2083), vec3(-0.9804,-0.1962,0.0175), vec2(0.0395,0.6735), vec2(0.0498,0.6265), vec2(0.0498,0.6265), 0.9319, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9228,-0.1376,-0.1906), vec3(-0.9817,-0.1376,-0.2571), vec3(-0.9808,-0.2281,-0.2579), vec3(-0.7488,-0.013,0.6627), vec2(0.0389,0.7168), vec2(0.0515,0.6993), vec2(0.0521,0.6735), 0.1267, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9228,-0.1376,-0.1906), vec3(-0.9808,-0.2281,-0.2579), vec3(-0.922,-0.2239,-0.1914), vec3(-0.7483,-0.0136,0.6632), vec2(0.0389,0.7168), vec2(0.0521,0.6735), vec2(0.0395,0.6735), 0.9313, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9138,-0.0625,-0.1986), vec3(-0.9357,-0.0846,-0.2234), vec3(-0.9817,-0.1376,-0.2571), vec3(-0.7988,0.5672,0.2002), vec2(0.0449,0.7528), vec2(0.0449,0.7326), vec2(0.0515,0.6993), 0.2135, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9138,-0.0625,-0.1986), vec3(-0.9817,-0.1376,-0.2571), vec3(-0.9228,-0.1376,-0.1906), vec3(-0.7392,0.1594,0.6543), vec2(0.0449,0.7528), vec2(0.0515,0.6993), vec2(0.0389,0.7168), 0.094, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8859,-0.4367,-0.0664), vec3(-0.9665,-0.3454,-0.0252), vec3(-0.9611,-0.376,0.2073), vec3(0.7631,0.6428,0.0669), vec2(0.8086,0.2971), vec2(0.7757,0.3446), vec2(0.6343,0.3095), 0.1169, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9714,-0.4553,0.2155), vec3(-0.9177,-0.4607,-0.0864), vec3(-0.8859,-0.4367,-0.0664), vec3(0.5529,-0.8255,0.1132), vec2(0.6343,0.2631), vec2(0.8086,0.2851), vec2(0.8086,0.2971), 0.667, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9714,-0.4553,0.2155), vec3(-0.9523,-0.4421,-0.1032), vec3(-0.9177,-0.4607,-0.0864), vec3(-0.4483,-0.8916,-0.0638), vec2(0.6343,0.2631), vec2(0.8086,0.2971), vec2(0.8086,0.2851), 0.2586, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9933,-0.3498,-0.0354), vec3(-0.9523,-0.4421,-0.1032), vec3(-1,-0.4358,0.2385), vec3(-0.9376,-0.3246,-0.1248), vec2(0.7757,0.3446), vec2(0.8086,0.2971), vec2(0.6343,0.2751), 0.5582, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9799,-0.3476,-0.0303), vec3(-0.9933,-0.3498,-0.0354), vec3(-0.9811,-0.3749,0.2235), vec3(-0.1999,0.9743,0.1039), vec2(0.7757,0.35), vec2(0.7757,0.3446), vec2(0.6343,0.3095), 0.2581, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9665,-0.3454,-0.0252), vec3(-0.9799,-0.3476,-0.0303), vec3(-0.9711,-0.3753,0.2154), vec3(-0.205,0.9717,0.1171), vec2(0.7757,0.3446), vec2(0.7757,0.35), vec2(0.6343,0.315), 0.7914, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 11 (57 tris)
    if (raySphereNear(ro, rd, vec3(0.2896,-0.1432,-0.4076), 0.4851)) {
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.3114), vec3(0.1027,-0.1962,-0.3157), vec3(0.1176,0.0163,-0.169), vec3(0.2465,-0.5621,0.7895), vec2(0.4621,0.6317), vec2(0.5409,0.6624), vec2(0.5482,0.7357), 0.1465, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,-0.1555,-0.3149), vec3(0.3554,-0.1001,-0.3191), vec3(0.3506,-0.2187,-0.3191), vec3(-0.0348,0.0014,-0.9994), vec2(0.605,0.6819), vec2(0.6654,0.7084), vec2(0.6631,0.6232), 0.4252, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,-0.1555,-0.3149), vec3(0.3506,-0.2187,-0.3191), vec3(0.282,-0.246,-0.3149), vec3(-0.0501,-0.0273,-0.9984), vec2(0.605,0.6819), vec2(0.6631,0.6232), vec2(0.6293,0.6101), 0.1622, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,0.1196,-0.1789), vec3(0.2328,0.0642,-0.1665), vec3(0.2749,-0.2226,-0.1665), vec3(0.0939,0.0138,0.9955), vec2(0.6654,0.7852), vec2(0.605,0.7587), vec2(0.6258,0.6213), 0.4914, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,0.1196,-0.1789), vec3(0.2749,-0.2226,-0.1665), vec3(0.3435,-0.1954,-0.1789), vec3(0.1797,-0.0068,0.9837), vec2(0.6654,0.7852), vec2(0.6258,0.6213), vec2(0.6596,0.6343), 0.7022, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4537,0.1677,-0.2258), vec3(0.3554,0.1196,-0.1789), vec3(0.3435,-0.1954,-0.1789), vec3(0.4371,-0.0165,0.8992), vec2(0.7024,0.8082), vec2(0.6654,0.7852), vec2(0.6596,0.6343), 0.096, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4537,0.1677,-0.2258), vec3(0.3435,-0.1954,-0.1789), vec3(0.4028,-0.1875,-0.2423), vec3(0.7322,-0.1359,0.6674), vec2(0.7024,0.8082), vec2(0.6596,0.6343), vec2(0.6773,0.6381), 0.3275, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,-0.1001,-0.3191), vec3(0.4471,-0.033,-0.335), vec3(0.4075,-0.1937,-0.2828), vec3(0.0738,-0.3245,-0.943), vec2(0.6654,0.7084), vec2(0.7107,0.7406), vec2(0.6911,0.6351), 0.8432, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,-0.1001,-0.3191), vec3(0.4075,-0.1937,-0.2828), vec3(0.3506,-0.2187,-0.3191), vec3(0.5444,-0.0219,-0.8385), vec2(0.6654,0.7084), vec2(0.6911,0.6351), vec2(0.6631,0.6232), 0.1944, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4471,-0.033,-0.335), vec3(0.4537,0.1677,-0.2258), vec3(0.4028,-0.1875,-0.2423), vec3(0.9654,-0.1483,0.2145), vec2(0.7107,0.7406), vec2(0.7024,0.8082), vec2(0.6773,0.6381), 0.3357, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4471,-0.033,-0.335), vec3(0.4028,-0.1875,-0.2423), vec3(0.4075,-0.1937,-0.2828), vec3(0.9708,-0.1931,0.1425), vec2(0.7107,0.7406), vec2(0.6773,0.6381), vec2(0.6911,0.6351), 0.9342, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.0642,-0.1665), vec3(0.1176,0.0163,-0.169), vec3(0.2114,-0.2512,-0.2212), vec3(0.0512,-0.1739,0.9834), vec2(0.605,0.7587), vec2(0.5482,0.7357), vec2(0.5944,0.6076), 0.2233, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.0642,-0.1665), vec3(0.2114,-0.2512,-0.2212), vec3(0.2749,-0.2226,-0.1665), vec3(-0.6253,-0.0919,0.775), vec2(0.605,0.7587), vec2(0.5944,0.6076), vec2(0.6258,0.6213), 0.6969, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1176,0.0163,-0.169), vec3(0.1027,-0.1962,-0.3157), vec3(0.214,-0.2596,-0.2756), vec3(-0.5211,-0.4599,0.719), vec2(0.5482,0.7357), vec2(0.5409,0.6624), vec2(0.5957,0.6036), 0.5901, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1176,0.0163,-0.169), vec3(0.214,-0.2596,-0.2756), vec3(0.2114,-0.2512,-0.2212), vec3(-0.9432,-0.3322,0.0071), vec2(0.5482,0.7357), vec2(0.5957,0.6036), vec2(0.5944,0.6076), 0.5007, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1027,-0.1962,-0.3157), vec3(0.2328,-0.1555,-0.3149), vec3(0.282,-0.246,-0.3149), vec3(0.0055,0.003,-1), vec2(0.5409,0.6624), vec2(0.605,0.6819), vec2(0.6293,0.6101), 0.8975, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1027,-0.1962,-0.3157), vec3(0.282,-0.246,-0.3149), vec3(0.214,-0.2596,-0.2756), vec3(-0.2067,-0.7555,-0.6217), vec2(0.5409,0.6624), vec2(0.6293,0.6101), vec2(0.5957,0.6036), 0.8569, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.282,-0.246,-0.3149), vec3(0.3506,-0.2187,-0.3191), vec3(0.4499,-0.4183,-0.2824), vec3(0.0098,-0.176,-0.9843), vec2(0.6293,0.6101), vec2(0.6631,0.6232), vec2(0.712,0.5276), 0.5391, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2114,-0.2512,-0.2212), vec3(0.214,-0.2596,-0.2756), vec3(0.379,-0.4396,-0.2599), vec3(-0.7383,-0.6709,0.069), vec2(0.5944,0.6076), vec2(0.5957,0.6036), vec2(0.6771,0.5174), 0.7488, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.214,-0.2596,-0.2756), vec3(0.282,-0.246,-0.3149), vec3(0.4143,-0.4325,-0.2802), vec3(-0.3861,-0.4259,-0.8183), vec2(0.5957,0.6036), vec2(0.6293,0.6101), vec2(0.6945,0.5208), 0.3432, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,-0.1001,-0.3191), vec3(0.3554,-0.1299,-0.3911), vec3(0.4471,-0.0627,-0.3911), vec3(0.5605,-0.7656,0.3158), vec2(0.6654,0.7084), vec2(0.6654,0.6657), vec2(0.7107,0.6979), 0.7708, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,-0.1001,-0.3191), vec3(0.4471,-0.0627,-0.3911), vec3(0.4471,-0.033,-0.335), vec3(0.5887,-0.7144,0.3782), vec2(0.6654,0.7084), vec2(0.7107,0.6979), vec2(0.7107,0.7406), 0.4489, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,-0.1555,-0.3149), vec3(0.2328,-0.1853,-0.3911), vec3(0.3554,-0.1299,-0.3911), vec3(0.3878,-0.8588,0.3348), vec2(0.605,0.6819), vec2(0.605,0.6392), vec2(0.6654,0.6657), 0.8804, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,-0.1555,-0.3149), vec3(0.3554,-0.1299,-0.3911), vec3(0.3554,-0.1001,-0.3191), vec3(0.3954,-0.8491,0.3502), vec2(0.605,0.6819), vec2(0.6654,0.6657), vec2(0.6654,0.7084), 0.462, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1027,-0.1962,-0.3157), vec3(0.1027,-0.226,-0.3911), vec3(0.2328,-0.1853,-0.3911), vec3(0.2796,-0.8932,0.3521), vec2(0.5409,0.6624), vec2(0.5409,0.6197), vec2(0.605,0.6392), 0.7776, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1027,-0.1962,-0.3157), vec3(0.2328,-0.1853,-0.3911), vec3(0.2328,-0.1555,-0.3149), vec3(0.2779,-0.895,0.3489), vec2(0.5409,0.6624), vec2(0.605,0.6392), vec2(0.605,0.6819), 0.7616, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.2806,-0.6158), vec3(0.3554,0.1196,-0.6034), vec3(0.2328,0.0642,-0.6158), vec3(0.1001,0,-0.995), vec2(0.605,0.8623), vec2(0.6654,0.7852), vec2(0.605,0.7587), 0.1792, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.2806,-0.6158), vec3(0.2328,0.0642,-0.6158), vec3(0.1176,0.0163,-0.6133), vec3(-0.0214,0,-0.9998), vec2(0.605,0.8623), vec2(0.605,0.7587), vec2(0.5482,0.7357), 0.9685, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.4709), vec3(0.1176,0.0163,-0.6133), vec3(0.1027,-0.1962,-0.4666), vec3(0.2465,-0.5621,-0.7895), vec2(0.4621,0.6317), vec2(0.5482,0.7357), vec2(0.5409,0.6624), 0.869, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,-0.1555,-0.4674), vec3(0.282,-0.246,-0.4674), vec3(0.3506,-0.2187,-0.4632), vec3(-0.0501,-0.0273,0.9984), vec2(0.605,0.6819), vec2(0.6293,0.6101), vec2(0.6631,0.6232), 0.6054, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,-0.1555,-0.4674), vec3(0.3506,-0.2187,-0.4632), vec3(0.3554,-0.1001,-0.4632), vec3(-0.0348,0.0014,0.9994), vec2(0.605,0.6819), vec2(0.6631,0.6232), vec2(0.6654,0.7084), 0.3928, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,0.1196,-0.6034), vec3(0.3435,-0.1954,-0.6034), vec3(0.2749,-0.2226,-0.6158), vec3(0.1797,-0.0068,-0.9837), vec2(0.6654,0.7852), vec2(0.6596,0.6343), vec2(0.6258,0.6213), 0.3946, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,0.1196,-0.6034), vec3(0.2749,-0.2226,-0.6158), vec3(0.2328,0.0642,-0.6158), vec3(0.0939,0.0138,-0.9955), vec2(0.6654,0.7852), vec2(0.6258,0.6213), vec2(0.605,0.7587), 0.865, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4537,0.1677,-0.5565), vec3(0.4028,-0.1875,-0.54), vec3(0.3435,-0.1954,-0.6034), vec3(0.7322,-0.1359,-0.6674), vec2(0.7024,0.8082), vec2(0.6773,0.6381), vec2(0.6596,0.6343), 0.4922, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4537,0.1677,-0.5565), vec3(0.3435,-0.1954,-0.6034), vec3(0.3554,0.1196,-0.6034), vec3(0.4371,-0.0165,-0.8992), vec2(0.7024,0.8082), vec2(0.6596,0.6343), vec2(0.6654,0.7852), 0.03, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,-0.1001,-0.4632), vec3(0.3506,-0.2187,-0.4632), vec3(0.4075,-0.1937,-0.4995), vec3(0.5444,-0.0219,0.8385), vec2(0.6654,0.7084), vec2(0.6631,0.6232), vec2(0.6911,0.6351), 0.1654, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,-0.1001,-0.4632), vec3(0.4075,-0.1937,-0.4995), vec3(0.4471,-0.033,-0.4473), vec3(0.0738,-0.3244,0.943), vec2(0.6654,0.7084), vec2(0.6911,0.6351), vec2(0.7107,0.7406), 0.2664, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4471,-0.033,-0.4473), vec3(0.4075,-0.1937,-0.4995), vec3(0.4028,-0.1875,-0.54), vec3(0.9708,-0.1931,-0.1425), vec2(0.7107,0.7406), vec2(0.6911,0.6351), vec2(0.6773,0.6381), 0.6705, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4471,-0.033,-0.4473), vec3(0.4028,-0.1875,-0.54), vec3(0.4537,0.1677,-0.5565), vec3(0.9654,-0.1483,-0.2145), vec2(0.7107,0.7406), vec2(0.6773,0.6381), vec2(0.7024,0.8082), 0.0855, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.0642,-0.6158), vec3(0.2749,-0.2226,-0.6158), vec3(0.2114,-0.2512,-0.5611), vec3(-0.6253,-0.0919,-0.775), vec2(0.605,0.7587), vec2(0.6258,0.6213), vec2(0.5944,0.6076), 0.9117, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.0642,-0.6158), vec3(0.2114,-0.2512,-0.5611), vec3(0.1176,0.0163,-0.6133), vec3(0.0512,-0.1739,-0.9834), vec2(0.605,0.7587), vec2(0.5944,0.6076), vec2(0.5482,0.7357), 0.4027, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1176,0.0163,-0.6133), vec3(0.2114,-0.2512,-0.5611), vec3(0.214,-0.2596,-0.5066), vec3(-0.9432,-0.3322,-0.0071), vec2(0.5482,0.7357), vec2(0.5944,0.6076), vec2(0.5957,0.6036), 0.9997, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1176,0.0163,-0.6133), vec3(0.214,-0.2596,-0.5066), vec3(0.1027,-0.1962,-0.4666), vec3(-0.5211,-0.4599,-0.719), vec2(0.5482,0.7357), vec2(0.5957,0.6036), vec2(0.5409,0.6624), 0.4162, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1027,-0.1962,-0.4666), vec3(0.214,-0.2596,-0.5066), vec3(0.282,-0.246,-0.4674), vec3(-0.2067,-0.7555,0.6217), vec2(0.5409,0.6624), vec2(0.5957,0.6036), vec2(0.6293,0.6101), 0.0037, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1027,-0.1962,-0.4666), vec3(0.282,-0.246,-0.4674), vec3(0.2328,-0.1555,-0.4674), vec3(0.0055,0.003,1), vec2(0.5409,0.6624), vec2(0.6293,0.6101), vec2(0.605,0.6819), 0.1299, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.282,-0.246,-0.4674), vec3(0.4499,-0.4183,-0.4999), vec3(0.3506,-0.2187,-0.4632), vec3(0.0098,-0.176,0.9843), vec2(0.6293,0.6101), vec2(0.712,0.5276), vec2(0.6631,0.6232), 0.885, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3435,-0.1954,-0.6034), vec3(0.4106,-0.4203,-0.5791), vec3(0.2749,-0.2226,-0.6158), vec3(0.1952,-0.0478,-0.9796), vec2(0.6596,0.6343), vec2(0.6927,0.5266), vec2(0.6258,0.6213), 0.6509, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3506,-0.2187,-0.4632), vec3(0.4794,-0.4053,-0.5187), vec3(0.4075,-0.1937,-0.4995), vec3(0.5056,0.0939,0.8576), vec2(0.6631,0.6232), vec2(0.7266,0.5338), vec2(0.6911,0.6351), 0.241, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2749,-0.2226,-0.6158), vec3(0.3776,-0.4352,-0.5507), vec3(0.2114,-0.2512,-0.5611), vec3(-0.4547,-0.4541,-0.7662), vec2(0.6258,0.6213), vec2(0.6764,0.5195), vec2(0.5944,0.6076), 0.236, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2114,-0.2512,-0.5611), vec3(0.379,-0.4396,-0.5224), vec3(0.214,-0.2596,-0.5066), vec3(-0.7383,-0.6709,-0.069), vec2(0.5944,0.6076), vec2(0.6771,0.5174), vec2(0.5957,0.6036), 0.0725, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.214,-0.2596,-0.5066), vec3(0.4143,-0.4325,-0.5021), vec3(0.282,-0.246,-0.4674), vec3(-0.3861,-0.4259,0.8183), vec2(0.5957,0.6036), vec2(0.6945,0.5208), vec2(0.6293,0.6101), 0.8032, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,-0.1001,-0.4632), vec3(0.4471,-0.033,-0.4473), vec3(0.4471,-0.0627,-0.3911), vec3(0.5887,-0.7144,-0.3782), vec2(0.6654,0.7084), vec2(0.7107,0.7406), vec2(0.7107,0.6979), 0.5437, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3554,-0.1001,-0.4632), vec3(0.4471,-0.0627,-0.3911), vec3(0.3554,-0.1299,-0.3911), vec3(0.5605,-0.7656,-0.3158), vec2(0.6654,0.7084), vec2(0.7107,0.6979), vec2(0.6654,0.6657), 0.496, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,-0.1555,-0.4674), vec3(0.3554,-0.1001,-0.4632), vec3(0.3554,-0.1299,-0.3911), vec3(0.3954,-0.8491,-0.3502), vec2(0.605,0.6819), vec2(0.6654,0.7084), vec2(0.6654,0.6657), 0.1695, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,-0.1555,-0.4674), vec3(0.3554,-0.1299,-0.3911), vec3(0.2328,-0.1853,-0.3911), vec3(0.3878,-0.8588,-0.3348), vec2(0.605,0.6819), vec2(0.6654,0.6657), vec2(0.605,0.6392), 0.9396, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1027,-0.1962,-0.4666), vec3(0.2328,-0.1555,-0.4674), vec3(0.2328,-0.1853,-0.3911), vec3(0.2779,-0.895,-0.3489), vec2(0.5409,0.6624), vec2(0.605,0.6819), vec2(0.605,0.6392), 0.5308, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1027,-0.1962,-0.4666), vec3(0.2328,-0.1853,-0.3911), vec3(0.1027,-0.226,-0.3911), vec3(0.2796,-0.8932,-0.3521), vec2(0.5409,0.6624), vec2(0.605,0.6392), vec2(0.5409,0.6197), 0.5915, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 12 (83 tris)
    if (raySphereNear(ro, rd, vec3(0.4962,-0.4408,-0.2539), 0.3506)) {
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.1805), vec3(0.4897,-0.4767,-0.3206), vec3(0.5091,-0.4767,-0.3246), vec3(0,-1,0), vec2(0.7285,0.4996), vec2(0.7317,0.4996), vec2(0.7621,0.4996), 0.7234, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.1805), vec3(0.5091,-0.4767,-0.3246), vec3(0.5061,-0.4767,-0.1921), vec3(0,-1,0), vec2(0.7285,0.4996), vec2(0.7621,0.4996), vec2(0.759,0.4996), 0.2144, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.252), vec3(0.5061,-0.4767,-0.1921), vec3(0.5091,-0.4767,-0.3246), vec3(0,-1,0), vec2(0.7852,0.4996), vec2(0.759,0.4996), vec2(0.7621,0.4996), 0.2026, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.252), vec3(0.5091,-0.4767,-0.3246), vec3(0.5329,-0.4767,-0.2903), vec3(0,-1,0), vec2(0.7852,0.4996), vec2(0.7621,0.4996), vec2(0.7873,0.4996), 0.6812, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.1805), vec3(0.4262,-0.4767,-0.2321), vec3(0.4285,-0.4767,-0.2836), vec3(0,-1,0), vec2(0.7285,0.4996), vec2(0.7004,0.4996), vec2(0.7015,0.4996), 0.411, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.1805), vec3(0.4285,-0.4767,-0.2836), vec3(0.4897,-0.4767,-0.3206), vec3(0,-1,0), vec2(0.7285,0.4996), vec2(0.7015,0.4996), vec2(0.7317,0.4996), 0.2044, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.282,-0.246,-0.3149), vec3(0.4499,-0.4183,-0.2824), vec3(0.4143,-0.4325,-0.2802), vec3(0.0098,-0.176,-0.9843), vec2(0.6293,0.6101), vec2(0.712,0.5276), vec2(0.6945,0.5208), 0.2945, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3435,-0.1954,-0.1789), vec3(0.2749,-0.2226,-0.1665), vec3(0.4106,-0.4203,-0.2032), vec3(0.1952,-0.0478,0.9796), vec2(0.6596,0.6343), vec2(0.6258,0.6213), vec2(0.6927,0.5266), 0.9792, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3435,-0.1954,-0.1789), vec3(0.4106,-0.4203,-0.2032), vec3(0.4462,-0.4062,-0.2096), vec3(0.1952,-0.0478,0.9796), vec2(0.6596,0.6343), vec2(0.6927,0.5266), vec2(0.7102,0.5334), 0.7699, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4028,-0.1875,-0.2423), vec3(0.3435,-0.1954,-0.1789), vec3(0.4462,-0.4062,-0.2096), vec3(0.6945,0.2393,0.6785), vec2(0.6773,0.6381), vec2(0.6596,0.6343), vec2(0.7102,0.5334), 0.8716, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4028,-0.1875,-0.2423), vec3(0.4462,-0.4062,-0.2096), vec3(0.477,-0.4021,-0.2425), vec3(0.6945,0.2393,0.6785), vec2(0.6773,0.6381), vec2(0.7102,0.5334), vec2(0.7139,0.5353), 0.5847, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3506,-0.2187,-0.3191), vec3(0.4075,-0.1937,-0.2828), vec3(0.4794,-0.4053,-0.2636), vec3(0.5056,0.0939,-0.8576), vec2(0.6631,0.6232), vec2(0.6911,0.6351), vec2(0.7266,0.5338), 0.7153, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3506,-0.2187,-0.3191), vec3(0.4794,-0.4053,-0.2636), vec3(0.4499,-0.4183,-0.2824), vec3(0.5056,0.0939,-0.8576), vec2(0.6631,0.6232), vec2(0.7266,0.5338), vec2(0.712,0.5276), 0.7526, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4075,-0.1937,-0.2828), vec3(0.4028,-0.1875,-0.2423), vec3(0.477,-0.4021,-0.2425), vec3(0.9434,0.3261,0.0604), vec2(0.6911,0.6351), vec2(0.6773,0.6381), vec2(0.7139,0.5353), 0.1802, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4075,-0.1937,-0.2828), vec3(0.477,-0.4021,-0.2425), vec3(0.4794,-0.4053,-0.2636), vec3(0.9434,0.3261,0.0604), vec2(0.6911,0.6351), vec2(0.7139,0.5353), vec2(0.7266,0.5338), 0.8297, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2749,-0.2226,-0.1665), vec3(0.2114,-0.2512,-0.2212), vec3(0.3776,-0.4352,-0.2316), vec3(-0.4546,-0.4541,0.7662), vec2(0.6258,0.6213), vec2(0.5944,0.6076), vec2(0.6764,0.5195), 0.1553, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2749,-0.2226,-0.1665), vec3(0.3776,-0.4352,-0.2316), vec3(0.4106,-0.4203,-0.2032), vec3(-0.4547,-0.4541,0.7662), vec2(0.6258,0.6213), vec2(0.6764,0.5195), vec2(0.6927,0.5266), 0.9898, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2114,-0.2512,-0.2212), vec3(0.379,-0.4396,-0.2599), vec3(0.3776,-0.4352,-0.2316), vec3(-0.7383,-0.6709,0.069), vec2(0.5944,0.6076), vec2(0.6771,0.5174), vec2(0.6764,0.5195), 0.0365, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.214,-0.2596,-0.2756), vec3(0.4143,-0.4325,-0.2802), vec3(0.379,-0.4396,-0.2599), vec3(-0.3861,-0.4259,-0.8183), vec2(0.5957,0.6036), vec2(0.6945,0.5208), vec2(0.6771,0.5174), 0.1513, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4143,-0.4325,-0.2802), vec3(0.4499,-0.4183,-0.2824), vec3(0.5091,-0.4557,-0.3246), vec3(-0.2553,0.5173,-0.8169), vec2(0.6945,0.5208), vec2(0.712,0.5276), vec2(0.7621,0.5096), 0.666, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4143,-0.4325,-0.2802), vec3(0.5091,-0.4557,-0.3246), vec3(0.4897,-0.4557,-0.3206), vec3(-0.1379,0.7249,-0.6749), vec2(0.6945,0.5208), vec2(0.7621,0.5096), vec2(0.7317,0.5096), 0.7823, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4462,-0.4062,-0.2096), vec3(0.4106,-0.4203,-0.2032), vec3(0.4833,-0.4557,-0.1805), vec3(-0.0361,0.4864,0.873), vec2(0.7102,0.5334), vec2(0.6927,0.5266), vec2(0.7285,0.5096), 0.8455, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4462,-0.4062,-0.2096), vec3(0.4833,-0.4557,-0.1805), vec3(0.5061,-0.4557,-0.1921), vec3(0.3445,0.6543,0.6732), vec2(0.7102,0.5334), vec2(0.7285,0.5096), vec2(0.759,0.5096), 0.52, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.477,-0.4021,-0.2425), vec3(0.4462,-0.4062,-0.2096), vec3(0.5061,-0.4557,-0.1921), vec3(0.453,0.729,0.5132), vec2(0.7139,0.5353), vec2(0.7102,0.5334), vec2(0.759,0.5096), 0.7643, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.477,-0.4021,-0.2425), vec3(0.5061,-0.4557,-0.1921), vec3(0.5309,-0.4557,-0.252), vec3(0.6997,0.6531,0.2897), vec2(0.7139,0.5353), vec2(0.759,0.5096), vec2(0.7852,0.5096), 0.6973, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4499,-0.4183,-0.2824), vec3(0.4794,-0.4053,-0.2636), vec3(0.5329,-0.4557,-0.2903), vec3(0.208,0.6216,-0.7552), vec2(0.712,0.5276), vec2(0.7266,0.5338), vec2(0.7873,0.5096), 0.1132, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4499,-0.4183,-0.2824), vec3(0.5329,-0.4557,-0.2903), vec3(0.5091,-0.4557,-0.3246), vec3(0.3758,0.8892,-0.2611), vec2(0.712,0.5276), vec2(0.7873,0.5096), vec2(0.7621,0.5096), 0.5975, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4794,-0.4053,-0.2636), vec3(0.477,-0.4021,-0.2425), vec3(0.5309,-0.4557,-0.252), vec3(0.7021,0.7116,-0.0263), vec2(0.7266,0.5338), vec2(0.7139,0.5353), vec2(0.7852,0.5096), 0.8858, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4794,-0.4053,-0.2636), vec3(0.5309,-0.4557,-0.252), vec3(0.5329,-0.4557,-0.2903), vec3(0.6948,0.7183,0.0359), vec2(0.7266,0.5338), vec2(0.7852,0.5096), vec2(0.7873,0.5096), 0.6855, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4106,-0.4203,-0.2032), vec3(0.3776,-0.4352,-0.2316), vec3(0.4262,-0.4557,-0.2321), vec3(-0.2794,-0.6781,0.6798), vec2(0.6927,0.5266), vec2(0.6764,0.5195), vec2(0.7004,0.5096), 0.4933, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4106,-0.4203,-0.2032), vec3(0.4262,-0.4557,-0.2321), vec3(0.4833,-0.4557,-0.1805), vec3(-0.498,-0.6694,0.5513), vec2(0.6927,0.5266), vec2(0.7004,0.5096), vec2(0.7285,0.5096), 0.5014, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3776,-0.4352,-0.2316), vec3(0.379,-0.4396,-0.2599), vec3(0.4285,-0.4557,-0.2836), vec3(-0.2479,-0.9591,0.1365), vec2(0.6764,0.5195), vec2(0.6771,0.5174), vec2(0.7015,0.5096), 0.0477, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3776,-0.4352,-0.2316), vec3(0.4285,-0.4557,-0.2836), vec3(0.4262,-0.4557,-0.2321), vec3(-0.3897,-0.9208,-0.0174), vec2(0.6764,0.5195), vec2(0.7015,0.5096), vec2(0.7004,0.5096), 0.9142, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.379,-0.4396,-0.2599), vec3(0.4143,-0.4325,-0.2802), vec3(0.4897,-0.4557,-0.3206), vec3(-0.4876,-0.0695,-0.8703), vec2(0.6771,0.5174), vec2(0.6945,0.5208), vec2(0.7317,0.5096), 0.7398, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.379,-0.4396,-0.2599), vec3(0.4897,-0.4557,-0.3206), vec3(0.4285,-0.4557,-0.2836), vec3(-0.4915,-0.3147,-0.812), vec2(0.6771,0.5174), vec2(0.7317,0.5096), vec2(0.7015,0.5096), 0.6501, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4897,-0.4557,-0.3206), vec3(0.5091,-0.4557,-0.3246), vec3(0.5091,-0.4767,-0.3246), vec3(-0.2002,0,-0.9798), vec2(0.7317,0.5096), vec2(0.7621,0.5096), vec2(0.7621,0.4996), 0.5471, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4897,-0.4557,-0.3206), vec3(0.5091,-0.4767,-0.3246), vec3(0.4897,-0.4767,-0.3206), vec3(-0.2002,0,-0.9798), vec2(0.7317,0.5096), vec2(0.7621,0.4996), vec2(0.7317,0.4996), 0.9946, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5358,-0.4646,-0.1639), vec3(0.528,-0.4646,-0.1606), vec3(0.528,-0.4788,-0.1606), vec3(0.3888,0,0.9213), vec2(0.759,0.5096), vec2(0.7285,0.5096), vec2(0.7285,0.4996), 0.7877, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5358,-0.4646,-0.1639), vec3(0.528,-0.4788,-0.1606), vec3(0.5358,-0.4788,-0.1639), vec3(0.3888,0,0.9213), vec2(0.759,0.5096), vec2(0.7285,0.4996), vec2(0.759,0.4996), 0.1464, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5982,-0.4646,-0.2344), vec3(0.5897,-0.4646,-0.2175), vec3(0.5897,-0.4788,-0.2175), vec3(0.8937,0,0.4487), vec2(0.7852,0.5096), vec2(0.759,0.5096), vec2(0.759,0.4996), 0.3508, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5982,-0.4646,-0.2344), vec3(0.5897,-0.4788,-0.2175), vec3(0.5982,-0.4788,-0.2344), vec3(0.8937,0,0.4487), vec2(0.7852,0.5096), vec2(0.759,0.4996), vec2(0.7852,0.4996), 0.2059, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.584,-0.4646,-0.3654), vec3(0.5921,-0.4646,-0.3557), vec3(0.5921,-0.4788,-0.3557), vec3(0.7648,0,-0.6443), vec2(0.7621,0.5096), vec2(0.7873,0.5096), vec2(0.7873,0.4996), 0.5366, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.584,-0.4646,-0.3654), vec3(0.5921,-0.4788,-0.3557), vec3(0.584,-0.4788,-0.3654), vec3(0.7648,0,-0.6443), vec2(0.7621,0.5096), vec2(0.7873,0.4996), vec2(0.7621,0.4996), 0.4687, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6138,-0.4646,-0.2941), vec3(0.6131,-0.4646,-0.2833), vec3(0.6131,-0.4788,-0.2833), vec3(0.998,0,0.0625), vec2(0.7873,0.5096), vec2(0.7852,0.5096), vec2(0.7852,0.4996), 0.6197, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6138,-0.4646,-0.2941), vec3(0.6131,-0.4788,-0.2833), vec3(0.6138,-0.4788,-0.2941), vec3(0.998,0,0.0625), vec2(0.7873,0.5096), vec2(0.7852,0.4996), vec2(0.7873,0.4996), 0.2009, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4557,-0.1805), vec3(0.4262,-0.4557,-0.2321), vec3(0.4262,-0.4767,-0.2321), vec3(-0.6704,0,0.742), vec2(0.7285,0.5096), vec2(0.7004,0.5096), vec2(0.7004,0.4996), 0.0207, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4557,-0.1805), vec3(0.4262,-0.4767,-0.2321), vec3(0.4833,-0.4767,-0.1805), vec3(-0.6704,0,0.742), vec2(0.7285,0.5096), vec2(0.7004,0.4996), vec2(0.7285,0.4996), 0.2987, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4262,-0.4557,-0.2321), vec3(0.4285,-0.4557,-0.2836), vec3(0.4285,-0.4767,-0.2836), vec3(-0.999,0,-0.0446), vec2(0.7004,0.5096), vec2(0.7015,0.5096), vec2(0.7015,0.4996), 0.1775, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4262,-0.4557,-0.2321), vec3(0.4285,-0.4767,-0.2836), vec3(0.4262,-0.4767,-0.2321), vec3(-0.999,0,-0.0446), vec2(0.7004,0.5096), vec2(0.7015,0.4996), vec2(0.7004,0.4996), 0.9825, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4285,-0.4557,-0.2836), vec3(0.4897,-0.4557,-0.3206), vec3(0.4897,-0.4767,-0.3206), vec3(-0.5178,0,-0.8555), vec2(0.7015,0.5096), vec2(0.7317,0.5096), vec2(0.7317,0.4996), 0.8819, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4285,-0.4557,-0.2836), vec3(0.4897,-0.4767,-0.3206), vec3(0.4285,-0.4767,-0.2836), vec3(-0.5178,0,-0.8555), vec2(0.7015,0.5096), vec2(0.7317,0.4996), vec2(0.7015,0.4996), 0.6745, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4557,-0.1921), vec3(0.4833,-0.4557,-0.1805), vec3(0.528,-0.4646,-0.1606), vec3(0.103,0.9741,0.2012), vec2(0.759,0.5096), vec2(0.7285,0.5096), vec2(0.7285,0.5096), 0.8399, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4557,-0.1921), vec3(0.528,-0.4646,-0.1606), vec3(0.5358,-0.4646,-0.1639), vec3(0.089,0.9735,0.2108), vec2(0.759,0.5096), vec2(0.7285,0.5096), vec2(0.759,0.5096), 0.2585, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4557,-0.1805), vec3(0.4833,-0.4767,-0.1805), vec3(0.528,-0.4788,-0.1606), vec3(-0.4056,0,0.9141), vec2(0.7285,0.5096), vec2(0.7285,0.4996), vec2(0.7285,0.4996), 0.9824, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4557,-0.1805), vec3(0.528,-0.4788,-0.1606), vec3(0.528,-0.4646,-0.1606), vec3(-0.4056,0,0.9141), vec2(0.7285,0.5096), vec2(0.7285,0.4996), vec2(0.7285,0.5096), 0.0661, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.1805), vec3(0.5061,-0.4767,-0.1921), vec3(0.5358,-0.4788,-0.1639), vec3(-0.0248,-0.9985,-0.0485), vec2(0.7285,0.4996), vec2(0.759,0.4996), vec2(0.759,0.4996), 0.9301, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,-0.4767,-0.1805), vec3(0.5358,-0.4788,-0.1639), vec3(0.528,-0.4788,-0.1606), vec3(-0.0229,-0.9983,-0.0543), vec2(0.7285,0.4996), vec2(0.759,0.4996), vec2(0.7285,0.4996), 0.0679, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4767,-0.1921), vec3(0.5061,-0.4557,-0.1921), vec3(0.5358,-0.4646,-0.1639), vec3(0.6887,0,-0.7251), vec2(0.759,0.4996), vec2(0.759,0.5096), vec2(0.759,0.5096), 0.1737, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4767,-0.1921), vec3(0.5358,-0.4646,-0.1639), vec3(0.5358,-0.4788,-0.1639), vec3(0.6887,0,-0.7251), vec2(0.759,0.4996), vec2(0.759,0.5096), vec2(0.759,0.4996), 0.7303, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4557,-0.252), vec3(0.5061,-0.4557,-0.1921), vec3(0.5897,-0.4646,-0.2175), vec3(0.1197,0.9916,0.0496), vec2(0.7852,0.5096), vec2(0.759,0.5096), vec2(0.759,0.5096), 0.3473, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4557,-0.252), vec3(0.5897,-0.4646,-0.2175), vec3(0.5982,-0.4646,-0.2344), vec3(0.1149,0.9917,0.0577), vec2(0.7852,0.5096), vec2(0.759,0.5096), vec2(0.7852,0.5096), 0.3894, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4557,-0.1921), vec3(0.5061,-0.4767,-0.1921), vec3(0.5897,-0.4788,-0.2175), vec3(0.2907,0,0.9568), vec2(0.759,0.5096), vec2(0.759,0.4996), vec2(0.759,0.4996), 0.8144, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4557,-0.1921), vec3(0.5897,-0.4788,-0.2175), vec3(0.5897,-0.4646,-0.2175), vec3(0.2907,0,0.9568), vec2(0.759,0.5096), vec2(0.759,0.4996), vec2(0.759,0.5096), 0.2211, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4767,-0.1921), vec3(0.5309,-0.4767,-0.252), vec3(0.5982,-0.4788,-0.2344), vec3(-0.0282,-0.9995,-0.0117), vec2(0.759,0.4996), vec2(0.7852,0.4996), vec2(0.7852,0.4996), 0.5273, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5061,-0.4767,-0.1921), vec3(0.5982,-0.4788,-0.2344), vec3(0.5897,-0.4788,-0.2175), vec3(-0.0297,-0.9994,-0.0149), vec2(0.759,0.4996), vec2(0.7852,0.4996), vec2(0.759,0.4996), 0.2079, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.252), vec3(0.5309,-0.4557,-0.252), vec3(0.5982,-0.4646,-0.2344), vec3(0.2533,0,-0.9674), vec2(0.7852,0.4996), vec2(0.7852,0.5096), vec2(0.7852,0.5096), 0.0032, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.252), vec3(0.5982,-0.4646,-0.2344), vec3(0.5982,-0.4788,-0.2344), vec3(0.2533,0,-0.9674), vec2(0.7852,0.4996), vec2(0.7852,0.5096), vec2(0.7852,0.4996), 0.5369, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5091,-0.4557,-0.3246), vec3(0.5329,-0.4557,-0.2903), vec3(0.5921,-0.4646,-0.3557), vec3(0.0839,0.9948,-0.0583), vec2(0.7621,0.5096), vec2(0.7873,0.5096), vec2(0.7873,0.5096), 0.8499, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5091,-0.4557,-0.3246), vec3(0.5921,-0.4646,-0.3557), vec3(0.584,-0.4646,-0.3654), vec3(0.0803,0.9945,-0.0676), vec2(0.7621,0.5096), vec2(0.7873,0.5096), vec2(0.7621,0.5096), 0.0859, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4557,-0.2903), vec3(0.5329,-0.4767,-0.2903), vec3(0.5921,-0.4788,-0.3557), vec3(0.7413,0,0.6712), vec2(0.7873,0.5096), vec2(0.7873,0.4996), vec2(0.7873,0.4996), 0.9991, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4557,-0.2903), vec3(0.5921,-0.4788,-0.3557), vec3(0.5921,-0.4646,-0.3557), vec3(0.7413,0,0.6712), vec2(0.7873,0.5096), vec2(0.7873,0.4996), vec2(0.7873,0.5096), 0.2863, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4767,-0.2903), vec3(0.5091,-0.4767,-0.3246), vec3(0.584,-0.4788,-0.3654), vec3(-0.0204,-0.9997,0.0142), vec2(0.7873,0.4996), vec2(0.7621,0.4996), vec2(0.7621,0.4996), 0.5064, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4767,-0.2903), vec3(0.584,-0.4788,-0.3654), vec3(0.5921,-0.4788,-0.3557), vec3(-0.0184,-0.9997,0.0155), vec2(0.7873,0.4996), vec2(0.7621,0.4996), vec2(0.7873,0.4996), 0.1617, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5091,-0.4767,-0.3246), vec3(0.5091,-0.4557,-0.3246), vec3(0.584,-0.4646,-0.3654), vec3(-0.4783,0,-0.8782), vec2(0.7621,0.4996), vec2(0.7621,0.5096), vec2(0.7621,0.5096), 0.8763, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5091,-0.4767,-0.3246), vec3(0.584,-0.4646,-0.3654), vec3(0.584,-0.4788,-0.3654), vec3(-0.4783,0,-0.8782), vec2(0.7621,0.4996), vec2(0.7621,0.5096), vec2(0.7621,0.4996), 0.0414, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4557,-0.2903), vec3(0.5309,-0.4557,-0.252), vec3(0.6131,-0.4646,-0.2833), vec3(0.1088,0.994,0.0056), vec2(0.7873,0.5096), vec2(0.7852,0.5096), vec2(0.7852,0.5096), 0.6507, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4557,-0.2903), vec3(0.6131,-0.4646,-0.2833), vec3(0.6138,-0.4646,-0.2941), vec3(0.1087,0.994,0.0068), vec2(0.7873,0.5096), vec2(0.7852,0.5096), vec2(0.7873,0.5096), 0.7989, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4557,-0.252), vec3(0.5309,-0.4767,-0.252), vec3(0.6131,-0.4788,-0.2833), vec3(0.3561,0,0.9344), vec2(0.7852,0.5096), vec2(0.7852,0.4996), vec2(0.7852,0.4996), 0.4905, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4557,-0.252), vec3(0.6131,-0.4788,-0.2833), vec3(0.6131,-0.4646,-0.2833), vec3(0.3561,0,0.9344), vec2(0.7852,0.5096), vec2(0.7852,0.4996), vec2(0.7852,0.5096), 0.1594, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.252), vec3(0.5329,-0.4767,-0.2903), vec3(0.6138,-0.4788,-0.2941), vec3(-0.0261,-0.9997,-0.0013), vec2(0.7852,0.4996), vec2(0.7873,0.4996), vec2(0.7873,0.4996), 0.8503, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5309,-0.4767,-0.252), vec3(0.6138,-0.4788,-0.2941), vec3(0.6131,-0.4788,-0.2833), vec3(-0.0262,-0.9997,-0.0016), vec2(0.7852,0.4996), vec2(0.7873,0.4996), vec2(0.7852,0.4996), 0.0962, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4767,-0.2903), vec3(0.5329,-0.4557,-0.2903), vec3(0.6138,-0.4646,-0.2941), vec3(-0.0471,0,-0.9989), vec2(0.7873,0.4996), vec2(0.7873,0.5096), vec2(0.7873,0.5096), 0.3628, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5329,-0.4767,-0.2903), vec3(0.6138,-0.4646,-0.2941), vec3(0.6138,-0.4788,-0.2941), vec3(-0.0471,0,-0.9989), vec2(0.7873,0.4996), vec2(0.7873,0.5096), vec2(0.7873,0.4996), 0.9772, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 13 (18 tris)
    if (raySphereNear(ro, rd, vec3(-0.3634,0.3728,-0.3675), 0.4618)) {
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.1563), vec3(-0.0802,0.4256,-0.3036), vec3(-0.3396,0.4483,-0.2871), vec3(0.1017,0.5629,0.8203), vec2(0.4097,0.8361), vec2(0.4506,0.9222), vec2(0.3227,0.9331), 0.0566, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.1563), vec3(-0.3396,0.4483,-0.2871), vec3(-0.3285,0.3017,-0.1119), vec3(0.466,0.693,0.5501), vec2(0.4097,0.8361), vec2(0.3227,0.9331), vec2(0.3282,0.8724), 0.2408, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3285,0.3017,-0.1119), vec3(-0.3396,0.4483,-0.2871), vec3(-0.5281,0.3591,-0.3065), vec3(-0.3906,0.6937,0.6051), vec2(0.3282,0.8724), vec2(0.3227,0.9331), vec2(0.2184,0.9004), 0.1939, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3285,0.3017,-0.1119), vec3(-0.5281,0.3591,-0.3065), vec3(-0.4964,0.1935,-0.1337), vec3(-0.4677,0.5937,0.6548), vec2(0.3282,0.8724), vec2(0.2184,0.9004), vec2(0.2184,0.8327), 0.908, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.1563), vec3(-0.3285,0.3017,-0.1119), vec3(-0.3526,0.2757,-0.0228), vec3(0.4676,0.8061,0.3627), vec2(0.4097,0.8361), vec2(0.3282,0.8724), vec2(0.3163,0.8424), 0.0252, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5281,0.3591,-0.3065), vec3(-0.5423,0.382,-0.4113), vec3(-0.7774,0.1928,-0.3342), vec3(-0.5564,0.7928,0.2489), vec2(0.2184,0.9004), vec2(0.2184,0.9206), vec2(0.1091,0.8583), 0.9627, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3396,0.4483,-0.2871), vec3(-0.3396,0.4705,-0.3911), vec3(-0.5423,0.382,-0.4113), vec3(-0.4084,0.8928,0.1901), vec2(0.3227,0.9331), vec2(0.3227,0.9532), vec2(0.2184,0.9206), 0.0448, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3396,0.4483,-0.2871), vec3(-0.5423,0.382,-0.4113), vec3(-0.5281,0.3591,-0.3065), vec3(-0.4351,0.8655,0.2483), vec2(0.3227,0.9331), vec2(0.2184,0.9206), vec2(0.2184,0.9004), 0.1688, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0802,0.4256,-0.3036), vec3(-0.0802,0.4477,-0.3911), vec3(-0.3396,0.4705,-0.3911), vec3(0.0847,0.9659,0.2445), vec2(0.4506,0.9222), vec2(0.4506,0.9423), vec2(0.3227,0.9532), 0.5648, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0802,0.4256,-0.3036), vec3(-0.3396,0.4705,-0.3911), vec3(-0.3396,0.4483,-0.2871), vec3(0.0986,0.9733,0.2072), vec2(0.4506,0.9222), vec2(0.3227,0.9532), vec2(0.3227,0.9331), 0.4851, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1632,0.2259,-0.626), vec3(-0.3396,0.4483,-0.4952), vec3(-0.0802,0.4256,-0.4787), vec3(0.1017,0.5629,-0.8203), vec2(0.4097,0.8361), vec2(0.3227,0.9331), vec2(0.4506,0.9222), 0.8296, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3285,0.3017,-0.6704), vec3(-0.5876,0.1935,-0.6976), vec3(-0.5564,0.3591,-0.5175), vec3(-0.2405,0.7349,-0.6341), vec2(0.3282,0.8724), vec2(0.2184,0.8327), vec2(0.2184,0.9004), 0.4571, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3285,0.3017,-0.6704), vec3(-0.5564,0.3591,-0.5175), vec3(-0.3396,0.4483,-0.4952), vec3(-0.2385,0.7374,-0.632), vec2(0.3282,0.8724), vec2(0.2184,0.9004), vec2(0.3227,0.9331), 0.3035, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5564,0.3591,-0.5175), vec3(-0.7774,0.1928,-0.3342), vec3(-0.5423,0.382,-0.4113), vec3(-0.6408,0.7636,-0.08), vec2(0.2184,0.9004), vec2(0.1091,0.8583), vec2(0.2184,0.9206), 0.7805, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3396,0.4483,-0.4952), vec3(-0.5564,0.3591,-0.5175), vec3(-0.5423,0.382,-0.4113), vec3(-0.3629,0.9196,-0.1505), vec2(0.3227,0.9331), vec2(0.2184,0.9004), vec2(0.2184,0.9206), 0.6073, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3396,0.4483,-0.4952), vec3(-0.5423,0.382,-0.4113), vec3(-0.3396,0.4705,-0.3911), vec3(-0.3761,0.9063,-0.1929), vec2(0.3227,0.9331), vec2(0.2184,0.9206), vec2(0.3227,0.9532), 0.3142, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0802,0.4256,-0.4787), vec3(-0.3396,0.4483,-0.4952), vec3(-0.3396,0.4705,-0.3911), vec3(0.0986,0.9733,-0.2072), vec2(0.4506,0.9222), vec2(0.3227,0.9331), vec2(0.3227,0.9532), 0.826, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0802,0.4256,-0.4787), vec3(-0.3396,0.4705,-0.3911), vec3(-0.0802,0.4477,-0.3911), vec3(0.0847,0.9659,-0.2445), vec2(0.4506,0.9222), vec2(0.3227,0.9532), vec2(0.4506,0.9423), 0.4735, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 14 (77 tris)
    if (raySphereNear(ro, rd, vec3(-0.1325,-0.41,-0.5296), 0.6578)) {
        if (triHit(ro, rd, vec3(-0.213,-0.3295,-0.583), vec3(-0.5956,-0.4411,-0.5774), vec3(-0.6697,-0.1266,-0.7465), vec3(0.118,-0.4484,-0.886), vec2(0.3851,0.5701), vec2(0.2141,0.5366), vec2(0.1985,0.6864), 0.0271, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0805,-0.2963,-0.5908), vec3(-0.213,-0.3295,-0.583), vec3(-0.3736,-0.0274,-0.7689), vec3(0.0729,-0.4942,-0.8663), vec2(0.4179,0.6003), vec2(0.3851,0.5701), vec2(0.3085,0.7162), 0.73, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5561,-0.4245,-0.5256), vec3(-0.5956,-0.4411,-0.5774), vec3(-0.213,-0.3295,-0.583), vec3(0.2802,-0.9554,0.093), vec2(0.2263,0.5731), vec2(0.2141,0.5366), vec2(0.3851,0.5701), 0.8762, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5561,-0.4245,-0.5256), vec3(-0.213,-0.3295,-0.583), vec3(-0.1871,-0.3009,-0.486), vec3(0.2923,-0.9358,0.1973), vec2(0.2263,0.5731), vec2(0.3851,0.5701), vec2(0.3979,0.6122), 0.7125, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.4709), vec3(-0.0805,-0.2963,-0.5908), vec3(-0.1076,-0.0227,-0.7607), vec3(0.9821,-0.0193,-0.1875), vec2(0.4621,0.6317), vec2(0.4179,0.6003), vec2(0.4237,0.6995), 0.5847, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.192,-0.455,-0.5007), vec3(-0.2094,-0.4552,-0.5659), vec3(-0.1688,-0.4609,-0.5711), vec3(-0.1352,-0.9901,0.0382), vec2(0.3955,0.51), vec2(0.3869,0.5099), vec2(0.407,0.5072), 0.5126, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.192,-0.455,-0.5007), vec3(-0.1688,-0.4609,-0.5711), vec3(-0.1529,-0.4609,-0.4906), vec3(-0.1566,-0.9872,0.0308), vec2(0.3955,0.51), vec2(0.407,0.5072), vec2(0.4148,0.5072), 0.7644, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1871,-0.3009,-0.486), vec3(-0.1952,-0.3732,-0.4971), vec3(-0.1416,-0.3586,-0.4858), vec3(-0.1707,-0.1318,0.9765), vec2(0.3979,0.6122), vec2(0.394,0.5492), vec2(0.4204,0.5562), 0.688, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1871,-0.3009,-0.486), vec3(-0.1416,-0.3586,-0.4858), vec3(-0.0569,-0.2602,-0.4709), vec3(-0.093,-0.0704,0.9932), vec2(0.3979,0.6122), vec2(0.4204,0.5562), vec2(0.4621,0.6317), 0.1547, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.4709), vec3(-0.1416,-0.3586,-0.4858), vec3(-0.1545,-0.3748,-0.5759), vec3(0.7571,-0.6532,0.0093), vec2(0.4621,0.6317), vec2(0.4204,0.5562), vec2(0.4005,0.5484), 0.8254, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0569,-0.2602,-0.4709), vec3(-0.1545,-0.3748,-0.5759), vec3(-0.0805,-0.2963,-0.5908), vec3(0.732,-0.6786,0.0604), vec2(0.4621,0.6317), vec2(0.4005,0.5484), vec2(0.4179,0.6003), 0.5017, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0805,-0.2963,-0.5908), vec3(-0.1545,-0.3748,-0.5759), vec3(-0.2132,-0.3944,-0.5701), vec3(-0.0517,-0.1392,-0.9889), vec2(0.4179,0.6003), vec2(0.4005,0.5484), vec2(0.3851,0.539), 0.3104, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0805,-0.2963,-0.5908), vec3(-0.2132,-0.3944,-0.5701), vec3(-0.213,-0.3295,-0.583), vec3(-0.0084,-0.1961,-0.9805), vec2(0.4179,0.6003), vec2(0.3851,0.539), vec2(0.3851,0.5701), 0.1295, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.213,-0.3295,-0.583), vec3(-0.2132,-0.3944,-0.5701), vec3(-0.1952,-0.3732,-0.4971), vec3(-0.973,0.0471,0.2262), vec2(0.3851,0.5701), vec2(0.3851,0.539), vec2(0.394,0.5492), 0.7381, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.213,-0.3295,-0.583), vec3(-0.1952,-0.3732,-0.4971), vec3(-0.1871,-0.3009,-0.486), vec3(-0.9687,0.0713,0.2376), vec2(0.3851,0.5701), vec2(0.394,0.5492), vec2(0.3979,0.6122), 0.8238, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1904,-0.4083,-0.5007), vec3(-0.192,-0.455,-0.5007), vec3(-0.1529,-0.4609,-0.4906), vec3(-0.2496,0.0086,0.9683), vec2(0.3963,0.5324), vec2(0.3955,0.51), vec2(0.4148,0.5072), 0.2716, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1904,-0.4083,-0.5007), vec3(-0.1529,-0.4609,-0.4906), vec3(-0.1439,-0.4021,-0.4906), vec3(-0.2171,0.0331,0.9756), vec2(0.3963,0.5324), vec2(0.4148,0.5072), vec2(0.4192,0.5353), 0.5545, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0226,-0.4521,-0.5558), vec3(-0.023,-0.4635,-0.5578), vec3(-0.0264,-0.4635,-0.5753), vec3(0.9812,0,-0.1931), vec2(0.4766,0.5238), vec2(0.4763,0.5119), vec2(0.4734,0.5119), 0.4207, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0226,-0.4521,-0.5558), vec3(-0.0264,-0.4635,-0.5753), vec3(-0.0264,-0.4537,-0.5753), vec3(0.9812,0,-0.1931), vec2(0.4766,0.5238), vec2(0.4734,0.5119), vec2(0.4734,0.522), 0.9353, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1583,-0.4118,-0.5711), vec3(-0.1688,-0.4609,-0.5711), vec3(-0.2094,-0.4552,-0.5659), vec3(-0.1235,0.0262,-0.992), vec2(0.3986,0.5307), vec2(0.407,0.5072), vec2(0.3869,0.5099), 0.776, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1583,-0.4118,-0.5711), vec3(-0.2094,-0.4552,-0.5659), vec3(-0.2136,-0.4271,-0.5659), vec3(-0.0902,-0.0135,-0.9958), vec2(0.3986,0.5307), vec2(0.3869,0.5099), vec2(0.3849,0.5234), 0.1155, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2136,-0.4271,-0.5659), vec3(-0.2094,-0.4552,-0.5659), vec3(-0.192,-0.455,-0.5007), vec3(-0.9562,-0.143,0.2555), vec2(0.3849,0.5234), vec2(0.3869,0.5099), vec2(0.3955,0.51), 0.9602, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2136,-0.4271,-0.5659), vec3(-0.192,-0.455,-0.5007), vec3(-0.1904,-0.4083,-0.5007), vec3(-0.9445,0.0324,0.3268), vec2(0.3849,0.5234), vec2(0.3955,0.51), vec2(0.3963,0.5324), 0.1195, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1439,-0.4021,-0.4906), vec3(-0.1101,-0.4309,-0.4906), vec3(-0.1136,-0.4329,-0.5082), vec3(0.6349,0.7443,-0.2069), vec2(0.4192,0.5353), vec2(0.4812,0.5263), vec2(0.4795,0.5253), 0.6034, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1583,-0.4118,-0.5711), vec3(-0.126,-0.4398,-0.5711), vec3(-0.126,-0.461,-0.5711), vec3(0,0,-1), vec2(0.3986,0.5307), vec2(0.4734,0.522), vec2(0.4734,0.5119), 0.7769, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1583,-0.4118,-0.5711), vec3(-0.126,-0.461,-0.5711), vec3(-0.1688,-0.4609,-0.5711), vec3(0,0,-1), vec2(0.3986,0.5307), vec2(0.4734,0.5119), vec2(0.407,0.5072), 0.5485, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1688,-0.4609,-0.5711), vec3(-0.126,-0.461,-0.5711), vec3(-0.1201,-0.461,-0.5413), vec3(-0.0025,-1,0.0005), vec2(0.407,0.5072), vec2(0.4734,0.5119), vec2(0.4763,0.5119), 0.308, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1529,-0.4609,-0.4906), vec3(-0.1101,-0.461,-0.4906), vec3(-0.1101,-0.4309,-0.4906), vec3(0,0,1), vec2(0.4148,0.5072), vec2(0.4812,0.5119), vec2(0.4812,0.5263), 0.6506, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1529,-0.4609,-0.4906), vec3(-0.1101,-0.4309,-0.4906), vec3(-0.1439,-0.4021,-0.4906), vec3(0,0,1), vec2(0.4148,0.5072), vec2(0.4812,0.5263), vec2(0.4192,0.5353), 0.9088, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3242,-0.3377,-0.4085), vec3(-0.1871,-0.3009,-0.486), vec3(-0.0569,-0.2602,-0.4709), vec3(0.2914,-0.9546,0.0627), vec2(0.3282,0.5695), vec2(0.3979,0.6122), vec2(0.4621,0.6317), 0.7956, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3242,-0.3377,-0.4085), vec3(-0.0569,-0.2602,-0.4709), vec3(-0.1291,-0.2924,-0.3911), vec3(0.2372,-0.9562,-0.1714), vec2(0.3282,0.5695), vec2(0.4621,0.6317), vec2(0.4265,0.5879), 0.6542, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5297,-0.4523,-0.4306), vec3(-0.5561,-0.4245,-0.5256), vec3(-0.1871,-0.3009,-0.486), vec3(0.3312,-0.877,-0.3481), vec2(0.2263,0.5304), vec2(0.2263,0.5731), vec2(0.3979,0.6122), 0.0282, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5297,-0.4523,-0.4306), vec3(-0.1871,-0.3009,-0.486), vec3(-0.3242,-0.3377,-0.4085), vec3(0.4252,-0.8313,0.358), vec2(0.2263,0.5304), vec2(0.3979,0.6122), vec2(0.3282,0.5695), 0.2525, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1291,-0.2924,-0.3911), vec3(-0.0569,-0.2602,-0.4709), vec3(0.1027,-0.1962,-0.4666), vec3(0.3725,-0.9273,-0.0373), vec2(0.4265,0.5879), vec2(0.4621,0.6317), vec2(0.5409,0.6624), 0.0846, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1291,-0.2924,-0.3911), vec3(0.1027,-0.1962,-0.4666), vec3(0.1027,-0.226,-0.3911), vec3(0.2576,-0.899,-0.3543), vec2(0.4265,0.5879), vec2(0.5409,0.6624), vec2(0.5409,0.6197), 0.8204, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1416,-0.3586,-0.4858), vec3(-0.1439,-0.4021,-0.4906), vec3(-0.1583,-0.4118,-0.5711), vec3(0.9845,-0.0335,-0.1721), vec2(0.4204,0.5562), vec2(0.4192,0.5353), vec2(0.3986,0.5307), 0.9076, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1416,-0.3586,-0.4858), vec3(-0.1583,-0.4118,-0.5711), vec3(-0.1545,-0.3748,-0.5759), vec3(0.9858,-0.1183,-0.1193), vec2(0.4204,0.5562), vec2(0.3986,0.5307), vec2(0.4005,0.5484), 0.7919, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1952,-0.3732,-0.4971), vec3(-0.1904,-0.4083,-0.5007), vec3(-0.1439,-0.4021,-0.4906), vec3(-0.1953,-0.1257,0.9727), vec2(0.394,0.5492), vec2(0.3963,0.5324), vec2(0.4192,0.5353), 0.7851, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1952,-0.3732,-0.4971), vec3(-0.1439,-0.4021,-0.4906), vec3(-0.1416,-0.3586,-0.4858), vec3(-0.1804,-0.098,0.9787), vec2(0.394,0.5492), vec2(0.4192,0.5353), vec2(0.4204,0.5562), 0.055, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2132,-0.3944,-0.5701), vec3(-0.2136,-0.4271,-0.5659), vec3(-0.1904,-0.4083,-0.5007), vec3(-0.9456,0.0537,0.321), vec2(0.3851,0.539), vec2(0.3849,0.5234), vec2(0.3963,0.5324), 0.2524, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2132,-0.3944,-0.5701), vec3(-0.1904,-0.4083,-0.5007), vec3(-0.1952,-0.3732,-0.4971), vec3(-0.9472,-0.1574,0.2793), vec2(0.3851,0.539), vec2(0.3963,0.5324), vec2(0.394,0.5492), 0.3143, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1545,-0.3748,-0.5759), vec3(-0.1583,-0.4118,-0.5711), vec3(-0.2136,-0.4271,-0.5659), vec3(-0.0599,-0.1215,-0.9908), vec2(0.4005,0.5484), vec2(0.3986,0.5307), vec2(0.3849,0.5234), 0.519, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1545,-0.3748,-0.5759), vec3(-0.2136,-0.4271,-0.5659), vec3(-0.2132,-0.3944,-0.5701), vec3(-0.0566,-0.1251,-0.9905), vec2(0.4005,0.5484), vec2(0.3849,0.5234), vec2(0.3851,0.539), 0.9261, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0127,-0.4487,-0.5056), vec3(-0.0127,-0.4625,-0.5056), vec3(-0.0154,-0.4625,-0.5191), vec3(0.9812,0,-0.1931), vec2(0.4812,0.5263), vec2(0.4812,0.5119), vec2(0.479,0.5119), 0.2141, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0127,-0.4487,-0.5056), vec3(-0.0154,-0.4625,-0.5191), vec3(-0.0148,-0.4496,-0.516), vec3(0.9812,0.0001,-0.1932), vec2(0.4812,0.5263), vec2(0.479,0.5119), vec2(0.4795,0.5253), 0.7612, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0167,-0.4497,-0.5259), vec3(-0.0173,-0.4626,-0.529), vec3(-0.0205,-0.4626,-0.5454), vec3(0.9812,0,-0.1931), vec2(0.4795,0.5253), vec2(0.479,0.5119), vec2(0.4763,0.5119), 0.7411, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0167,-0.4497,-0.5259), vec3(-0.0205,-0.4626,-0.5454), vec3(-0.0202,-0.4512,-0.5434), vec3(0.9812,0,-0.1932), vec2(0.4795,0.5253), vec2(0.4763,0.5119), vec2(0.4766,0.5238), 0.8683, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1583,-0.4118,-0.5711), vec3(-0.1194,-0.4361,-0.5379), vec3(-0.126,-0.4398,-0.5711), vec3(0.6392,0.7406,-0.2073), vec2(0.3986,0.5307), vec2(0.4766,0.5238), vec2(0.4734,0.522), 0.8173, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1439,-0.4021,-0.4906), vec3(-0.1136,-0.4329,-0.5082), vec3(-0.1194,-0.4361,-0.5379), vec3(0.6349,0.7443,-0.2069), vec2(0.4192,0.5353), vec2(0.4795,0.5253), vec2(0.4766,0.5238), 0.9594, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1439,-0.4021,-0.4906), vec3(-0.1194,-0.4361,-0.5379), vec3(-0.1583,-0.4118,-0.5711), vec3(0.6378,0.7426,-0.2042), vec2(0.4192,0.5353), vec2(0.4766,0.5238), vec2(0.3986,0.5307), 0.963, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1529,-0.4609,-0.4906), vec3(-0.1146,-0.461,-0.5135), vec3(-0.1101,-0.461,-0.4906), vec3(-0.0025,-1,0.0005), vec2(0.4148,0.5072), vec2(0.479,0.5119), vec2(0.4812,0.5119), 0.4765, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1688,-0.4609,-0.5711), vec3(-0.1201,-0.461,-0.5413), vec3(-0.1146,-0.461,-0.5135), vec3(-0.0025,-1,0.0005), vec2(0.407,0.5072), vec2(0.4763,0.5119), vec2(0.479,0.5119), 0.0862, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1688,-0.4609,-0.5711), vec3(-0.1146,-0.461,-0.5135), vec3(-0.1529,-0.4609,-0.4906), vec3(-0.0025,-1,0.0005), vec2(0.407,0.5072), vec2(0.479,0.5119), vec2(0.4148,0.5072), 0.6642, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1194,-0.4361,-0.5379), vec3(-0.1201,-0.461,-0.5413), vec3(-0.023,-0.4635,-0.5578), vec3(0.1621,-0.1388,0.977), vec2(0.4766,0.5238), vec2(0.4763,0.5119), vec2(0.4763,0.5119), 0.4119, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1194,-0.4361,-0.5379), vec3(-0.023,-0.4635,-0.5578), vec3(-0.0226,-0.4521,-0.5558), vec3(0.1504,-0.177,0.9727), vec2(0.4766,0.5238), vec2(0.4763,0.5119), vec2(0.4766,0.5238), 0.3905, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1201,-0.461,-0.5413), vec3(-0.126,-0.461,-0.5711), vec3(-0.0264,-0.4635,-0.5753), vec3(-0.0245,-0.9997,0.0048), vec2(0.4763,0.5119), vec2(0.4734,0.5119), vec2(0.4734,0.5119), 0.6221, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1201,-0.461,-0.5413), vec3(-0.0264,-0.4635,-0.5753), vec3(-0.023,-0.4635,-0.5578), vec3(-0.0245,-0.9997,0.0048), vec2(0.4763,0.5119), vec2(0.4734,0.5119), vec2(0.4763,0.5119), 0.6018, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.126,-0.461,-0.5711), vec3(-0.126,-0.4398,-0.5711), vec3(-0.0264,-0.4537,-0.5753), vec3(-0.0424,0,-0.9991), vec2(0.4734,0.5119), vec2(0.4734,0.522), vec2(0.4734,0.522), 0.9228, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.126,-0.461,-0.5711), vec3(-0.0264,-0.4537,-0.5753), vec3(-0.0264,-0.4635,-0.5753), vec3(-0.0424,0,-0.9991), vec2(0.4734,0.5119), vec2(0.4734,0.522), vec2(0.4734,0.5119), 0.4654, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.126,-0.4398,-0.5711), vec3(-0.1194,-0.4361,-0.5379), vec3(-0.0226,-0.4521,-0.5558), vec3(0.1365,0.9814,-0.1349), vec2(0.4734,0.522), vec2(0.4766,0.5238), vec2(0.4766,0.5238), 0.8796, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.126,-0.4398,-0.5711), vec3(-0.0226,-0.4521,-0.5558), vec3(-0.0264,-0.4537,-0.5753), vec3(0.1334,0.9849,-0.1107), vec2(0.4734,0.522), vec2(0.4766,0.5238), vec2(0.4734,0.522), 0.5982, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1101,-0.4309,-0.4906), vec3(-0.1101,-0.461,-0.4906), vec3(-0.0127,-0.4625,-0.5056), vec3(0.1529,0,0.9882), vec2(0.4812,0.5263), vec2(0.4812,0.5119), vec2(0.4812,0.5119), 0.9163, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1101,-0.4309,-0.4906), vec3(-0.0127,-0.4625,-0.5056), vec3(-0.0127,-0.4487,-0.5056), vec3(0.1529,0,0.9882), vec2(0.4812,0.5263), vec2(0.4812,0.5119), vec2(0.4812,0.5263), 0.287, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1101,-0.461,-0.4906), vec3(-0.1146,-0.461,-0.5135), vec3(-0.0154,-0.4625,-0.5191), vec3(-0.0144,-0.9999,0.0028), vec2(0.4812,0.5119), vec2(0.479,0.5119), vec2(0.479,0.5119), 0.7357, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1101,-0.461,-0.4906), vec3(-0.0154,-0.4625,-0.5191), vec3(-0.0127,-0.4625,-0.5056), vec3(-0.0144,-0.9999,0.0028), vec2(0.4812,0.5119), vec2(0.479,0.5119), vec2(0.4812,0.5119), 0.5863, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1146,-0.461,-0.5135), vec3(-0.1136,-0.4329,-0.5082), vec3(-0.0148,-0.4496,-0.516), vec3(-0.0466,0.1837,-0.9819), vec2(0.479,0.5119), vec2(0.4795,0.5253), vec2(0.4795,0.5253), 0.461, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1146,-0.461,-0.5135), vec3(-0.0148,-0.4496,-0.516), vec3(-0.0154,-0.4625,-0.5191), vec3(-0.052,0.2337,-0.9709), vec2(0.479,0.5119), vec2(0.4795,0.5253), vec2(0.479,0.5119), 0.8017, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1136,-0.4329,-0.5082), vec3(-0.1101,-0.4309,-0.4906), vec3(-0.0127,-0.4487,-0.5056), vec3(0.1567,0.9779,-0.1385), vec2(0.4795,0.5253), vec2(0.4812,0.5263), vec2(0.4812,0.5263), 0.1024, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1136,-0.4329,-0.5082), vec3(-0.0127,-0.4487,-0.5056), vec3(-0.0148,-0.4496,-0.516), vec3(0.1566,0.981,-0.1149), vec2(0.4795,0.5253), vec2(0.4812,0.5263), vec2(0.4795,0.5253), 0.2882, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1136,-0.4329,-0.5082), vec3(-0.1146,-0.461,-0.5135), vec3(-0.0173,-0.4626,-0.529), vec3(0.1523,-0.1855,0.9708), vec2(0.4795,0.5253), vec2(0.479,0.5119), vec2(0.479,0.5119), 0.4384, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1136,-0.4329,-0.5082), vec3(-0.0173,-0.4626,-0.529), vec3(-0.0167,-0.4497,-0.5259), vec3(0.135,-0.2355,0.9624), vec2(0.4795,0.5253), vec2(0.479,0.5119), vec2(0.4795,0.5253), 0.7813, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1146,-0.461,-0.5135), vec3(-0.1201,-0.461,-0.5413), vec3(-0.0205,-0.4626,-0.5454), vec3(-0.016,-0.9999,0.0031), vec2(0.479,0.5119), vec2(0.4763,0.5119), vec2(0.4763,0.5119), 0.993, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1146,-0.461,-0.5135), vec3(-0.0205,-0.4626,-0.5454), vec3(-0.0173,-0.4626,-0.529), vec3(-0.016,-0.9999,0.0031), vec2(0.479,0.5119), vec2(0.4763,0.5119), vec2(0.479,0.5119), 0.5406, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1201,-0.461,-0.5413), vec3(-0.1194,-0.4361,-0.5379), vec3(-0.0202,-0.4512,-0.5434), vec3(-0.0343,0.1371,-0.99), vec2(0.4763,0.5119), vec2(0.4766,0.5238), vec2(0.4766,0.5238), 0.3966, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1201,-0.461,-0.5413), vec3(-0.0202,-0.4512,-0.5434), vec3(-0.0205,-0.4626,-0.5454), vec3(-0.038,0.1751,-0.9838), vec2(0.4763,0.5119), vec2(0.4766,0.5238), vec2(0.4763,0.5119), 0.0593, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1194,-0.4361,-0.5379), vec3(-0.1136,-0.4329,-0.5082), vec3(-0.0167,-0.4497,-0.5259), vec3(0.1454,0.9799,-0.1365), vec2(0.4766,0.5238), vec2(0.4795,0.5253), vec2(0.4795,0.5253), 0.7348, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1194,-0.4361,-0.5379), vec3(-0.0167,-0.4497,-0.5259), vec3(-0.0202,-0.4512,-0.5434), vec3(0.1431,0.9833,-0.1125), vec2(0.4766,0.5238), vec2(0.4795,0.5253), vec2(0.4766,0.5238), 0.073, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    // cluster 15 (35 tris)
    if (raySphereNear(ro, rd, vec3(0.5633,0.1865,-0.3973), 0.4153)) {
        if (triHit(ro, rd, vec3(0.4455,0.3023,-0.2258), vec3(0.3542,0.3014,-0.1789), vec3(0.3554,0.1196,-0.1789), vec3(0.4568,0.0031,0.8896), vec2(0.7099,0.8727), vec2(0.6743,0.8766), vec2(0.6654,0.7852), 0.4989, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4455,0.3023,-0.2258), vec3(0.3554,0.1196,-0.1789), vec3(0.4537,0.1677,-0.2258), vec3(0.4203,0.0256,0.907), vec2(0.7099,0.8727), vec2(0.6654,0.7852), vec2(0.7024,0.8082), 0.9195, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.3366,-0.2702), vec3(0.4455,0.3023,-0.2258), vec3(0.4537,0.1677,-0.2258), vec3(0.3836,0.0234,0.9232), vec2(0.7616,0.8891), vec2(0.7099,0.8727), vec2(0.7024,0.8082), 0.1863, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.3366,-0.2702), vec3(0.4537,0.1677,-0.2258), vec3(0.5585,0.2624,-0.2702), vec3(0.3593,0.0397,0.9324), vec2(0.7616,0.8891), vec2(0.7024,0.8082), vec2(0.7656,0.8536), 0.5526, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.661,0.3957,-0.2685), vec3(0.5503,0.3366,-0.2702), vec3(0.5585,0.2624,-0.2702), vec3(-0.0149,-0.0016,0.9999), vec2(0.8088,0.9078), vec2(0.7616,0.8891), vec2(0.7656,0.8536), 0.0566, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.661,0.3957,-0.2685), vec3(0.5585,0.2624,-0.2702), vec3(0.6595,0.2615,-0.2597), vec3(-0.1029,0.0661,0.9925), vec2(0.8088,0.9078), vec2(0.7656,0.8536), vec2(0.8154,0.8532), 0.8602, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5585,0.2624,-0.2702), vec3(0.4537,0.1677,-0.2258), vec3(0.4471,-0.033,-0.335), vec3(0.633,-0.3859,0.6711), vec2(0.7656,0.8536), vec2(0.7024,0.8082), vec2(0.7107,0.7406), 0.072, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5585,0.2624,-0.2702), vec3(0.4471,-0.033,-0.335), vec3(0.5678,0.1505,-0.3512), vec3(0.6799,-0.3923,0.6195), vec2(0.7656,0.8536), vec2(0.7107,0.7406), vec2(0.7702,0.8285), 0.8161, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6595,0.2615,-0.2597), vec3(0.5585,0.2624,-0.2702), vec3(0.5678,0.1505,-0.3512), vec3(-0.0888,-0.5889,0.8033), vec2(0.8154,0.8532), vec2(0.7656,0.8536), vec2(0.7702,0.8285), 0.6424, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6595,0.2615,-0.2597), vec3(0.5678,0.1505,-0.3512), vec3(0.6724,0.1524,-0.3479), vec3(-0.0131,-0.6296,0.7768), vec2(0.8154,0.8532), vec2(0.7702,0.8285), vec2(0.8218,0.8294), 0.9428, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8028,0.2525,-0.2857), vec3(0.6595,0.2615,-0.2597), vec3(0.6724,0.1524,-0.3479), vec3(0.1022,-0.6181,0.7794), vec2(0.8861,0.8488), vec2(0.8154,0.8532), vec2(0.8218,0.8294), 0.6216, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6724,0.1524,-0.3479), vec3(0.6724,0.125,-0.3911), vec3(0.7984,0.136,-0.3911), vec3(0.0733,-0.8428,0.5332), vec2(0.8218,0.8294), vec2(0.8218,0.7878), vec2(0.8839,0.7931), 0.6462, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6724,0.1524,-0.3479), vec3(0.7984,0.136,-0.3911), vec3(0.7984,0.1634,-0.3475), vec3(0.0718,-0.8451,0.5297), vec2(0.8218,0.8294), vec2(0.8839,0.7931), vec2(0.8785,0.8242), 0.9161, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5678,0.1505,-0.3512), vec3(0.5678,0.1232,-0.3911), vec3(0.6724,0.125,-0.3911), vec3(0.0148,-0.825,0.5649), vec2(0.7702,0.8285), vec2(0.7702,0.7869), vec2(0.8218,0.7878), 0.0455, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5678,0.1505,-0.3512), vec3(0.6724,0.125,-0.3911), vec3(0.6724,0.1524,-0.3479), vec3(-0.0016,-0.8451,0.5346), vec2(0.7702,0.8285), vec2(0.8218,0.7878), vec2(0.8218,0.8294), 0.2343, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4471,-0.033,-0.335), vec3(0.4471,-0.0627,-0.3911), vec3(0.5678,0.1232,-0.3911), vec3(0.806,-0.5231,0.277), vec2(0.7107,0.7406), vec2(0.7107,0.6979), vec2(0.7702,0.7869), 0.8954, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4471,-0.033,-0.335), vec3(0.5678,0.1232,-0.3911), vec3(0.5678,0.1505,-0.3512), vec3(0.7995,-0.4956,0.3394), vec2(0.7107,0.7406), vec2(0.7702,0.7869), vec2(0.7702,0.8285), 0.3025, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2328,0.2806,-0.6158), vec3(0.3542,0.3014,-0.6034), vec3(0.3554,0.1196,-0.6034), vec3(0.101,0.0007,-0.9949), vec2(0.605,0.8623), vec2(0.6743,0.8766), vec2(0.6654,0.7852), 0.3507, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4455,0.3023,-0.5565), vec3(0.4537,0.1677,-0.5565), vec3(0.3554,0.1196,-0.6034), vec3(0.4203,0.0256,-0.907), vec2(0.7099,0.8727), vec2(0.7024,0.8082), vec2(0.6654,0.7852), 0.5015, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4455,0.3023,-0.5565), vec3(0.3554,0.1196,-0.6034), vec3(0.3542,0.3014,-0.6034), vec3(0.4568,0.0031,-0.8896), vec2(0.7099,0.8727), vec2(0.6654,0.7852), vec2(0.6743,0.8766), 0.1611, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.3366,-0.5121), vec3(0.5585,0.2624,-0.5121), vec3(0.4537,0.1677,-0.5565), vec3(0.3593,0.0397,-0.9324), vec2(0.7616,0.8891), vec2(0.7656,0.8536), vec2(0.7024,0.8082), 0.1658, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5503,0.3366,-0.5121), vec3(0.4537,0.1677,-0.5565), vec3(0.4455,0.3023,-0.5565), vec3(0.3836,0.0234,-0.9232), vec2(0.7616,0.8891), vec2(0.7024,0.8082), vec2(0.7099,0.8727), 0.9889, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.661,0.3957,-0.5138), vec3(0.6595,0.2615,-0.5226), vec3(0.5585,0.2624,-0.5121), vec3(-0.1029,0.0661,-0.9925), vec2(0.8088,0.9078), vec2(0.8154,0.8532), vec2(0.7656,0.8536), 0.1795, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.661,0.3957,-0.5138), vec3(0.5585,0.2624,-0.5121), vec3(0.5503,0.3366,-0.5121), vec3(-0.0149,-0.0016,-0.9999), vec2(0.8088,0.9078), vec2(0.7656,0.8536), vec2(0.7616,0.8891), 0.6487, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5585,0.2624,-0.5121), vec3(0.5678,0.1505,-0.4311), vec3(0.4471,-0.033,-0.4473), vec3(0.6799,-0.3923,-0.6195), vec2(0.7656,0.8536), vec2(0.7702,0.8285), vec2(0.7107,0.7406), 0.5464, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5585,0.2624,-0.5121), vec3(0.4471,-0.033,-0.4473), vec3(0.4537,0.1677,-0.5565), vec3(0.633,-0.3859,-0.6711), vec2(0.7656,0.8536), vec2(0.7107,0.7406), vec2(0.7024,0.8082), 0.9559, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6595,0.2615,-0.5226), vec3(0.6724,0.1524,-0.4344), vec3(0.5678,0.1505,-0.4311), vec3(-0.0131,-0.6296,-0.7768), vec2(0.8154,0.8532), vec2(0.8218,0.8294), vec2(0.7702,0.8285), 0.7363, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6595,0.2615,-0.5226), vec3(0.5678,0.1505,-0.4311), vec3(0.5585,0.2624,-0.5121), vec3(-0.0888,-0.5889,-0.8033), vec2(0.8154,0.8532), vec2(0.7702,0.8285), vec2(0.7656,0.8536), 0.7287, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8028,0.2525,-0.4966), vec3(0.6724,0.1524,-0.4344), vec3(0.6595,0.2615,-0.5226), vec3(0.1022,-0.6181,-0.7794), vec2(0.8861,0.8488), vec2(0.8218,0.8294), vec2(0.8154,0.8532), 0.7502, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6724,0.1524,-0.4344), vec3(0.7984,0.1634,-0.4348), vec3(0.7984,0.136,-0.3911), vec3(0.0718,-0.8451,-0.5297), vec2(0.8218,0.8294), vec2(0.8785,0.8242), vec2(0.8839,0.7931), 0.2259, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6724,0.1524,-0.4344), vec3(0.7984,0.136,-0.3911), vec3(0.6724,0.125,-0.3911), vec3(0.0733,-0.8428,-0.5332), vec2(0.8218,0.8294), vec2(0.8839,0.7931), vec2(0.8218,0.7878), 0.4665, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5678,0.1505,-0.4311), vec3(0.6724,0.1524,-0.4344), vec3(0.6724,0.125,-0.3911), vec3(-0.0016,-0.8451,-0.5346), vec2(0.7702,0.8285), vec2(0.8218,0.8294), vec2(0.8218,0.7878), 0.9207, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5678,0.1505,-0.4311), vec3(0.6724,0.125,-0.3911), vec3(0.5678,0.1232,-0.3911), vec3(0.0148,-0.825,-0.5649), vec2(0.7702,0.8285), vec2(0.8218,0.7878), vec2(0.7702,0.7869), 0.7425, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4471,-0.033,-0.4473), vec3(0.5678,0.1505,-0.4311), vec3(0.5678,0.1232,-0.3911), vec3(0.7995,-0.4956,-0.3394), vec2(0.7107,0.7406), vec2(0.7702,0.8285), vec2(0.7702,0.7869), 0.1272, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4471,-0.033,-0.4473), vec3(0.5678,0.1232,-0.3911), vec3(0.4471,-0.0627,-0.3911), vec3(0.806,-0.5231,-0.277), vec2(0.7107,0.7406), vec2(0.7702,0.7869), vec2(0.7107,0.6979), 0.6528, 0, vec3(0.5,0.5,0.5), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    }
    return hit;
}

// ===== PIZZA (easter egg prop, real mesh) =====
// v1.9: Sam sent a real low-poly pizza slice model (`REDVOX MODELS\pizza\LOWPOLY PIZZA.obj/.mtl`,
// 210 verts / 221 faces -- 171 quads + 50 tris, no UVs, 3 flat materials) after the hand-authored
// primitive wedge from v1.7/v1.8 didn't read as a real pizza slice. Converted offline (PowerShell,
// not by hand) the same way this file's own rat mesh was baked: literal triHit() calls with real
// vertex/normal data and each triangle's real .mtl Kd color carried through as useFlat/flatColor,
// quads fan-triangulated into 2 triangles each, degenerate (near-zero-area) triangles dropped.
// AXIS REMAP: the source OBJ has Z as its tip-to-crust length axis (verified by real cross-section
// analysis -- binning vertices along each candidate axis and checking which one shows a clean
// monotonic taper in the other two axes' spread, the same kind of check that finally settled Pigeon
// Hole Mesh's long axis-guessing saga, done up front here instead of guessing and iterating), X as
// width, Y as thickness (top = cheese/pepperoni side, larger Y in the source). Remapped at bake time
// to: length -> -Y (tip at local origin, crust hangs below, matching Sam's "hanging down" request),
// width -> X (unchanged), thickness -> Z with the cheese side facing -Z (the default camera's
// direction, see renderMain). Baked at a fixed real-world scale (tip-to-crust = 1.6 local units) so
// pizzaScale=1 lands close to "about the same size as the rat" as already promised in scene.json.
// Sized/positioned/oriented via pizzaScale/pizzaPosition/pizzaDepth/pizzaOrientation (new) rather
// than baking a single fixed placement -- there's no real mouth/landmark data for this rat model
// (unlike Pigeon Hole Mesh's eventual hand-placed landmarks), so live-adjustable controls are the
// honest way to get it positioned right instead of another round of coordinate guessing.
// Uses the SAME inverse-ray-transform trick as the whole rat model (see renderChannel): rather than
// re-scaling/re-positioning 392 baked triangles at runtime, the incoming ray is transformed once
// into the pizza's own local frame and tested against the raw, untouched baked data -- bestT solved
// in that local frame is exactly the real-world t (same algebra as the rat's own scale-invariance,
// see renderChannel's comment on this). Only bestN needs correcting back afterward (rotating the
// pizza-local normal up into the rat's local space), since triHit writes it directly and there's no
// other hook to intercept it mid-flight -- done by snapshotting bestT before the pizza test and
// checking whether it actually improved, to know whether the pizza (not the rat mesh) really won
// that particular ray before touching bestN.
// Inherits the rat's own idle-spin/bob/SPEEN/wobble/mirror transform for free (tested against the
// same already-transformed ray the mesh uses). meshWarp/meshDistort/meshFold also apply to it, since
// those run inside triHit() itself, same as before.

bool pizzaMeshHit(vec3 ro, vec3 rd, inout float bestT, inout vec3 bestN, inout vec2 bestUV,
                   inout float bestFacet, inout float bestUseFlat, inout vec3 bestFlatColor) {
    bool hit = false;
    // cull sphere centered at the tip (local origin, where all baked triangles are anchored),
    // radius padded slightly above the real measured farthest-vertex distance (1.8145)
    if (!raySphereNear(ro, rd, vec3(0.0, 0.0, 0.0), 1.9)) return false;
        if (triHit(ro, rd, vec3(0.1247,-0.3681,0.4564), vec3(0.0018,-0.3689,0.4496), vec3(0,-0.0038,0.5086), vec3(0.0539,0.1596,-0.9857), vec2(0.0), vec2(0.0), vec2(0.0), 0, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1247,-0.3681,0.4564), vec3(0,-0.0038,0.5086), vec3(0.0284,-0.0379,0.5099), vec3(0.3359,0.2452,-0.9094), vec2(0.0), vec2(0.0), vec2(0.0), 0.3814, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5052,-1.344,-0.5227), vec3(-0.5436,-1.2633,-0.5304), vec3(0,-1.1457,-0.5986), vec3(-0.0937,-0.1387,-0.9859), vec2(0.0), vec2(0.0), vec2(0.0), 0.7629, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5052,-1.344,-0.5227), vec3(0,-1.1457,-0.5986), vec3(0,-1.2354,-0.5947), vec3(-0.1319,-0.0431,-0.9903), vec2(0.0), vec2(0.0), vec2(0.0), 0.1443, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8451,-1.5171,-0.1717), vec3(-0.9092,-1.4574,-0.1911), vec3(-0.9187,-1.4985,-0.3012), vec3(-0.6965,-0.6506,0.3026), vec2(0.0), vec2(0.0), vec2(0.0), 0.5258, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8451,-1.5171,-0.1717), vec3(-0.9187,-1.4985,-0.3012), vec3(-0.8539,-1.5589,-0.2868), vec3(-0.6855,-0.666,0.2941), vec2(0.0), vec2(0.0), vec2(0.0), 0.9072, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2148,-0.3635,0.528), vec3(0.3734,-0.647,0.4497), vec3(0.2205,-0.3493,0.4757), vec3(0.8767,0.4315,0.2128), vec2(0.0), vec2(0.0), vec2(0.0), 0.2887, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2148,-0.3635,0.528), vec3(0.2205,-0.3493,0.4757), vec3(0.0568,-0.0764,0.5108), vec3(0.8484,0.4802,0.2228), vec2(0.0), vec2(0.0), vec2(0.0), 0.6701, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0568,-0.0764,0.5108), vec3(0.0284,-0.0379,0.5099), vec3(0.055,-0.0771,0.5493), vec3(0.8033,0.5936,0.0493), vec2(0.0), vec2(0.0), vec2(0.0), 0.0515, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0568,-0.0764,0.5108), vec3(0.055,-0.0771,0.5493), vec3(0.2148,-0.3635,0.528), vec3(0.8737,0.4838,0.0505), vec2(0.0), vec2(0.0), vec2(0.0), 0.433, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2057,-0.3758,0.5749), vec3(0.3549,-0.6734,0.4984), vec3(0.2148,-0.3635,0.528), vec3(0.8868,0.3751,0.2701), vec2(0.0), vec2(0.0), vec2(0.0), 0.8144, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2057,-0.3758,0.5749), vec3(0.2148,-0.3635,0.528), vec3(0.055,-0.0771,0.5493), vec3(0.8465,0.4514,0.2824), vec2(0.0), vec2(0.0), vec2(0.0), 0.1959, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.055,-0.0771,0.5493), vec3(0.0275,-0.0373,0.5485), vec3(0.0527,-0.0781,0.5986), vec3(0.8212,0.5685,0.0497), vec2(0.0), vec2(0.0), vec2(0.0), 0.5773, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.055,-0.0771,0.5493), vec3(0.0527,-0.0781,0.5986), vec3(0.2057,-0.3758,0.5749), vec3(0.8899,0.4534,0.0507), vec2(0.0), vec2(0.0), vec2(0.0), 0.9588, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9092,-1.4574,-0.1911), vec3(-0.8527,-1.3841,-0.1459), vec3(-0.8788,-1.3729,-0.2008), vec3(-0.8176,0.3468,0.4596), vec2(0.0), vec2(0.0), vec2(0.0), 0.3402, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9092,-1.4574,-0.1911), vec3(-0.8788,-1.3729,-0.2008), vec3(-0.8913,-1.396,-0.2353), vec3(-0.932,0.3472,0.1042), vec2(0.0), vec2(0.0), vec2(0.0), 0.7216, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4791,-1.3991,-0.5174), vec3(-0.5052,-1.344,-0.5227), vec3(0,-1.2354,-0.5947), vec3(-0.1088,-0.1457,-0.9833), vec2(0.0), vec2(0.0), vec2(0.0), 0.1031, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4791,-1.3991,-0.5174), vec3(0,-1.2354,-0.5947), vec3(0,-1.2965,-0.5921), vec3(-0.1447,-0.043,-0.9885), vec2(0.0), vec2(0.0), vec2(0.0), 0.4845, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4715,-1.3811,-0.4117), vec3(0.453,-1.354,-0.324), vec3(0,-1.2892,-0.501), vec3(-0.2298,-0.9424,0.2431), vec2(0.0), vec2(0.0), vec2(0.0), 0.866, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4715,-1.3811,-0.4117), vec3(0,-1.2892,-0.501), vec3(0,-1.2965,-0.5921), vec3(-0.2051,-0.9756,0.0784), vec2(0.0), vec2(0.0), vec2(0.0), 0.2474, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.2965,-0.5921), vec3(0.4898,-1.4026,-0.5016), vec3(0.4715,-1.3811,-0.4117), vec3(-0.2399,-0.9541,0.1794), vec2(0.0), vec2(0.0), vec2(0.0), 0.6289, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1118,-0.3712,0.5623), vec3(0,-0.3512,0.5616), vec3(0,0,0.5964), vec3(0.0238,-0.0988,0.9948), vec2(0.0), vec2(0.0), vec2(0.0), 0.0103, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1118,-0.3712,0.5623), vec3(0,0,0.5964), vec3(-0.0264,-0.0367,0.5978), vec3(0.2909,-0.1742,0.9408), vec2(0.0), vec2(0.0), vec2(0.0), 0.3918, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5165,-1.3479,-0.5075), vec3(0.5557,-1.2677,-0.5161), vec3(0.9187,-1.4985,-0.3012), vec3(0.3573,-0.2703,-0.894), vec2(0.0), vec2(0.0), vec2(0.0), 0.7732, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5165,-1.3479,-0.5075), vec3(0.9187,-1.4985,-0.3012), vec3(0.8539,-1.5589,-0.2868), vec3(0.2545,-0.4745,-0.8427), vec2(0.0), vec2(0.0), vec2(0.0), 0.1546, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4898,-1.4026,-0.5016), vec3(0.5165,-1.3479,-0.5075), vec3(0.8539,-1.5589,-0.2868), vec3(0.3931,-0.2856,-0.874), vec2(0.0), vec2(0.0), vec2(0.0), 0.5361, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4898,-1.4026,-0.5016), vec3(0.8539,-1.5589,-0.2868), vec3(0.8097,-1.6,-0.277), vec3(0.2754,-0.4929,-0.8254), vec2(0.0), vec2(0.0), vec2(0.0), 0.9175, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0275,-0.0373,0.5485), vec3(0.055,-0.0771,0.5493), vec3(0.0284,-0.0379,0.5099), vec3(0.8225,0.5686,0.0114), vec2(0.0), vec2(0.0), vec2(0.0), 0.299, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0275,-0.0373,0.5485), vec3(0.0284,-0.0379,0.5099), vec3(0,-0.0038,0.5086), vec3(0.7677,0.6408,0.0091), vec2(0.0), vec2(0.0), vec2(0.0), 0.6804, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-0.0038,0.5086), vec3(0,-0.0021,0.5471), vec3(0.0264,-0.0367,0.5978), vec3(0.8121,0.5829,-0.0253), vec2(0.0), vec2(0.0), vec2(0.0), 0.0619, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-0.0038,0.5086), vec3(0.0264,-0.0367,0.5978), vec3(0.0275,-0.0373,0.5485), vec3(0.7677,0.6408,0.0091), vec2(0.0), vec2(0.0), vec2(0.0), 0.4433, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-0.0021,0.5471), vec3(0,0,0.5964), vec3(0.0264,-0.0367,0.5978), vec3(0.8121,0.5829,-0.0253), vec2(0.0), vec2(0.0), vec2(0.0), 0.8247, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8014,-1.5578,-0.1585), vec3(-0.8451,-1.5171,-0.1717), vec3(-0.8539,-1.5589,-0.2868), vec3(-0.6973,-0.6551,0.291), vec2(0.0), vec2(0.0), vec2(0.0), 0.2062, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8014,-1.5578,-0.1585), vec3(-0.8539,-1.5589,-0.2868), vec3(-0.8097,-1.6,-0.277), vec3(-0.6862,-0.6686,0.2866), vec2(0.0), vec2(0.0), vec2(0.0), 0.5876, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0275,-0.0373,0.5485), vec3(0,-0.0021,0.5471), vec3(-0.0284,-0.0379,0.5099), vec3(-0.7877,0.616,0.0099), vec2(0.0), vec2(0.0), vec2(0.0), 0.9691, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0275,-0.0373,0.5485), vec3(-0.0284,-0.0379,0.5099), vec3(-0.0568,-0.0764,0.5108), vec3(-0.8046,0.5937,0.0106), vec2(0.0), vec2(0.0), vec2(0.0), 0.3505, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0568,-0.0764,0.5108), vec3(-0.2215,-0.3497,0.4758), vec3(-0.055,-0.0771,0.5493), vec3(-0.8582,0.5108,0.0503), vec2(0.0), vec2(0.0), vec2(0.0), 0.732, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0568,-0.0764,0.5108), vec3(-0.055,-0.0771,0.5493), vec3(-0.0275,-0.0373,0.5485), vec3(-0.8212,0.5685,0.0496), vec2(0.0), vec2(0.0), vec2(0.0), 0.1134, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0264,-0.0367,0.5978), vec3(0,0,0.5964), vec3(-0.0275,-0.0373,0.5485), vec3(-0.8117,0.584,0.011), vec2(0.0), vec2(0.0), vec2(0.0), 0.4948, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0264,-0.0367,0.5978), vec3(-0.0275,-0.0373,0.5485), vec3(-0.055,-0.0771,0.5493), vec3(-0.8225,0.5686,0.0114), vec2(0.0), vec2(0.0), vec2(0.0), 0.8763, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.055,-0.0771,0.5493), vec3(-0.2148,-0.3635,0.528), vec3(-0.0527,-0.0781,0.5986), vec3(-0.8737,0.4838,0.0506), vec2(0.0), vec2(0.0), vec2(0.0), 0.2577, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.055,-0.0771,0.5493), vec3(-0.0527,-0.0781,0.5986), vec3(-0.0264,-0.0367,0.5978), vec3(-0.8425,0.5364,0.0501), vec2(0.0), vec2(0.0), vec2(0.0), 0.6392, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6304,-1.2422,0.1634), vec3(-0.4973,-0.9654,0.3634), vec3(-0.6616,-1.2042,0.1376), vec3(-0.7257,-0.1381,0.674), vec2(0.0), vec2(0.0), vec2(0.0), 0.0206, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6304,-1.2422,0.1634), vec3(-0.6616,-1.2042,0.1376), vec3(-0.7926,-1.4464,-0.1225), vec3(-0.7692,-0.226,0.5977), vec2(0.0), vec2(0.0), vec2(0.0), 0.4021, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7926,-1.4464,-0.1225), vec3(-0.7515,-1.4888,-0.1065), vec3(-0.6304,-1.2422,0.1634), vec3(-0.6547,-0.3882,0.6486), vec2(0.0), vec2(0.0), vec2(0.0), 0.7835, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4607,-1.3788,-0.4276), vec3(-0.4791,-1.3991,-0.5174), vec3(0,-1.2892,-0.501), vec3(0.2146,-0.9613,0.1728), vec2(0.0), vec2(0.0), vec2(0.0), 0.1649, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4607,-1.3788,-0.4276), vec3(0,-1.2892,-0.501), vec3(0,-1.2752,-0.4107), vec3(0.2118,-0.9658,0.1496), vec2(0.0), vec2(0.0), vec2(0.0), 0.5464, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.2752,-0.4107), vec3(0,-1.1599,-0.0771), vec3(-0.4421,-1.3529,-0.3399), vec3(0.2135,-0.9233,0.3191), vec2(0.0), vec2(0.0), vec2(0.0), 0.9278, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.2752,-0.4107), vec3(-0.4421,-1.3529,-0.3399), vec3(-0.4607,-1.3788,-0.4276), vec3(0.2049,-0.9497,0.2368), vec2(0.0), vec2(0.0), vec2(0.0), 0.3093, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3712,-1.1938,-0.0067), vec3(0,-1.1599,-0.0771), vec3(0,-1.2752,-0.4107), vec3(-0.1468,-0.9349,0.3231), vec2(0.0), vec2(0.0), vec2(0.0), 0.6907, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3712,-1.1938,-0.0067), vec3(0,-1.2752,-0.4107), vec3(0.453,-1.354,-0.324), vec3(-0.2298,-0.8914,0.3907), vec2(0.0), vec2(0.0), vec2(0.0), 0.0722, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4101,-1.069,-0.0772), vec3(0,-1.0369,-0.1663), vec3(0,-1.127,-0.4392), vec3(-0.141,0.9401,-0.3104), vec2(0.0), vec2(0.0), vec2(0.0), 0.4536, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4101,-1.069,-0.0772), vec3(0,-1.127,-0.4392), vec3(-0.5017,-1.218,-0.3717), vec3(-0.2147,0.8967,-0.387), vec2(0.0), vec2(0.0), vec2(0.0), 0.8351, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7986,-1.5536,-0.1545), vec3(0.8422,-1.5128,-0.1679), vec3(0.8527,-1.3841,-0.1459), vec3(0.4431,-0.1861,0.8769), vec2(0.0), vec2(0.0), vec2(0.0), 0.2165, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7986,-1.5536,-0.1545), vec3(0.8527,-1.3841,-0.1459), vec3(0.7926,-1.4464,-0.1225), vec3(0.5385,-0.2134,0.8151), vec2(0.0), vec2(0.0), vec2(0.0), 0.5979, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7926,-1.4464,-0.1225), vec3(0.7515,-1.4888,-0.1065), vec3(0.7986,-1.5536,-0.1545), vec3(0.5385,-0.2134,0.8151), vec2(0.0), vec2(0.0), vec2(0.0), 0.9794, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8422,-1.5128,-0.1679), vec3(0.9062,-1.4529,-0.1875), vec3(0.8527,-1.3841,-0.1459), vec3(0.4432,-0.1861,0.8769), vec2(0.0), vec2(0.0), vec2(0.0), 0.3608, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6616,-1.2042,0.1376), vec3(-0.5195,-0.9355,0.3303), vec3(-0.7121,-1.1512,0.0835), vec3(-0.7594,-0.0626,0.6476), vec2(0.0), vec2(0.0), vec2(0.0), 0.7423, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.6616,-1.2042,0.1376), vec3(-0.7121,-1.1512,0.0835), vec3(-0.8527,-1.3841,-0.1459), vec3(-0.7837,-0.1259,0.6082), vec2(0.0), vec2(0.0), vec2(0.0), 0.1237, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8527,-1.3841,-0.1459), vec3(-0.7926,-1.4464,-0.1225), vec3(-0.6616,-1.2042,0.1376), vec3(-0.6442,-0.3704,0.6692), vec2(0.0), vec2(0.0), vec2(0.0), 0.5052, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5436,-1.2633,-0.5304), vec3(-0.9187,-1.4985,-0.3012), vec3(-0.9036,-1.4184,-0.2708), vec3(-0.6431,0.3748,-0.6678), vec2(0.0), vec2(0.0), vec2(0.0), 0.8866, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5436,-1.2633,-0.5304), vec3(-0.9036,-1.4184,-0.2708), vec3(-0.5325,-1.2111,-0.4955), vec3(-0.6358,0.5181,-0.5721), vec2(0.0), vec2(0.0), vec2(0.0), 0.268, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5248,-1.2019,-0.4568), vec3(-0.517,-1.1916,-0.4185), vec3(0,-1.1006,-0.5231), vec3(-0.2114,0.9532,-0.2161), vec2(0.0), vec2(0.0), vec2(0.0), 0.6495, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5248,-1.2019,-0.4568), vec3(0,-1.1006,-0.5231), vec3(0,-1.1046,-0.5644), vec3(-0.2003,0.9751,-0.0951), vec2(0.0), vec2(0.0), vec2(0.0), 0.0309, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.1046,-0.5644), vec3(-0.5325,-1.2111,-0.4955), vec3(-0.5248,-1.2019,-0.4568), vec3(-0.2155,0.959,-0.1838), vec2(0.0), vec2(0.0), vec2(0.0), 0.4124, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5375,-1.2052,-0.4428), vec3(0.5452,-1.2149,-0.4815), vec3(0,-1.1006,-0.5231), vec3(0.2156,0.9565,-0.1965), vec2(0.0), vec2(0.0), vec2(0.0), 0.7938, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5375,-1.2052,-0.4428), vec3(0,-1.1006,-0.5231), vec3(0,-1.095,-0.482), vec3(0.2086,0.9689,-0.1332), vec2(0.0), vec2(0.0), vec2(0.0), 0.1753, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.095,-0.482), vec3(0.5297,-1.1943,-0.4045), vec3(0.5375,-1.2052,-0.4428), vec3(0.2117,0.9502,-0.2289), vec2(0.0), vec2(0.0), vec2(0.0), 0.5567, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.514,-1.22,-0.3572), vec3(0.8527,-1.3841,-0.1459), vec3(0.8788,-1.3729,-0.2008), vec3(0.2532,0.9176,0.3065), vec2(0.0), vec2(0.0), vec2(0.0), 0.9381, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.514,-1.22,-0.3572), vec3(0.8788,-1.3729,-0.2008), vec3(0.5297,-1.1943,-0.4045), vec3(0.1385,0.8501,0.5081), vec2(0.0), vec2(0.0), vec2(0.0), 0.3196, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5017,-1.218,-0.3717), vec3(0,-1.127,-0.4392), vec3(0.5297,-1.1943,-0.4045), vec3(-0.0142,-0.5447,-0.8385), vec2(0.0), vec2(0.0), vec2(0.0), 0.701, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5017,-1.218,-0.3717), vec3(0.5297,-1.1943,-0.4045), vec3(0,-1.095,-0.482), vec3(0.0094,0.6459,0.7633), vec2(0.0), vec2(0.0), vec2(0.0), 0.0825, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.095,-0.482), vec3(-0.517,-1.1916,-0.4185), vec3(-0.8527,-1.3841,-0.1459), vec3(-0.1024,0.8677,0.4865), vec2(0.0), vec2(0.0), vec2(0.0), 0.4639, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.095,-0.482), vec3(-0.8527,-1.3841,-0.1459), vec3(-0.5017,-1.218,-0.3717), vec3(0.1111,-0.8752,-0.4709), vec2(0.0), vec2(0.0), vec2(0.0), 0.8454, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9062,-1.4529,-0.1875), vec3(0.9187,-1.4985,-0.3012), vec3(0.9036,-1.4184,-0.2708), vec3(0.9847,0.1696,0.0407), vec2(0.0), vec2(0.0), vec2(0.0), 0.2268, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9062,-1.4529,-0.1875), vec3(0.9036,-1.4184,-0.2708), vec3(0.8913,-1.396,-0.2353), vec3(0.9346,0.3377,0.112), vec2(0.0), vec2(0.0), vec2(0.0), 0.6082, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5557,-1.2677,-0.5161), vec3(0,-1.1457,-0.5986), vec3(0,-1.1046,-0.5644), vec3(0.2466,0.6195,-0.7453), vec2(0.0), vec2(0.0), vec2(0.0), 0.9897, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5557,-1.2677,-0.5161), vec3(0,-1.1046,-0.5644), vec3(0.5452,-1.2149,-0.4815), vec3(0.2346,0.5652,-0.7909), vec2(0.0), vec2(0.0), vec2(0.0), 0.3711, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.517,-1.1916,-0.4185), vec3(-0.8788,-1.3729,-0.2008), vec3(-0.8527,-1.3841,-0.1459), vec3(-0.2686,0.9111,0.3126), vec2(0.0), vec2(0.0), vec2(0.0), 0.7526, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8913,-1.396,-0.2353), vec3(-0.5248,-1.2019,-0.4568), vec3(-0.5325,-1.2111,-0.4955), vec3(-0.512,0.8532,-0.0995), vec2(0.0), vec2(0.0), vec2(0.0), 0.134, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8913,-1.396,-0.2353), vec3(-0.5325,-1.2111,-0.4955), vec3(-0.9036,-1.4184,-0.2708), vec3(-0.59,0.7596,-0.2737), vec2(0.0), vec2(0.0), vec2(0.0), 0.5155, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.1457,-0.5986), vec3(-0.5436,-1.2633,-0.5304), vec3(-0.5325,-1.2111,-0.4955), vec3(-0.223,0.5747,-0.7874), vec2(0.0), vec2(0.0), vec2(0.0), 0.8969, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.1457,-0.5986), vec3(-0.5325,-1.2111,-0.4955), vec3(0,-1.1046,-0.5644), vec3(-0.2217,0.6233,-0.7499), vec2(0.0), vec2(0.0), vec2(0.0), 0.2784, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7121,-1.1512,0.0835), vec3(-0.4101,-1.069,-0.0772), vec3(-0.5017,-1.218,-0.3717), vec3(-0.4003,0.8618,-0.3116), vec2(0.0), vec2(0.0), vec2(0.0), 0.6598, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7121,-1.1512,0.0835), vec3(-0.5017,-1.218,-0.3717), vec3(-0.8527,-1.3841,-0.1459), vec3(-0.5824,0.7212,-0.3751), vec2(0.0), vec2(0.0), vec2(0.0), 0.0412, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8014,-1.5578,-0.1585), vec3(-0.8097,-1.6,-0.277), vec3(-0.4607,-1.3788,-0.4276), vec3(0.5905,-0.7725,0.2338), vec2(0.0), vec2(0.0), vec2(0.0), 0.4227, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8014,-1.5578,-0.1585), vec3(-0.4607,-1.3788,-0.4276), vec3(-0.4421,-1.3529,-0.3399), vec3(0.5401,-0.8313,0.131), vec2(0.0), vec2(0.0), vec2(0.0), 0.8041, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4421,-1.3529,-0.3399), vec3(-0.3622,-1.1969,-0.0185), vec3(-0.7515,-1.4888,-0.1065), vec3(0.543,-0.8005,0.2538), vec2(0.0), vec2(0.0), vec2(0.0), 0.1856, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4421,-1.3529,-0.3399), vec3(-0.7515,-1.4888,-0.1065), vec3(-0.8014,-1.5578,-0.1585), vec3(0.5946,-0.7119,0.3737), vec2(0.0), vec2(0.0), vec2(0.0), 0.567, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,0,0.5964), vec3(0,-0.0021,0.5471), vec3(-0.0275,-0.0373,0.5485), vec3(-0.7881,0.615,-0.0267), vec2(0.0), vec2(0.0), vec2(0.0), 0.9485, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-0.0021,0.5471), vec3(0,-0.0038,0.5086), vec3(-0.0284,-0.0379,0.5099), vec3(-0.7681,0.6397,-0.0278), vec2(0.0), vec2(0.0), vec2(0.0), 0.3299, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2057,-0.3758,0.5749), vec3(-0.1118,-0.3712,0.5623), vec3(-0.0264,-0.0367,0.5978), vec3(0.1394,-0.1397,0.9803), vec2(0.0), vec2(0.0), vec2(0.0), 0.7113, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2057,-0.3758,0.5749), vec3(-0.0264,-0.0367,0.5978), vec3(-0.0527,-0.0781,0.5986), vec3(0.5901,-0.3608,0.7222), vec2(0.0), vec2(0.0), vec2(0.0), 0.0928, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8097,-1.6,-0.277), vec3(-0.8539,-1.5589,-0.2868), vec3(-0.5052,-1.344,-0.5227), vec3(-0.2656,-0.4843,-0.8336), vec2(0.0), vec2(0.0), vec2(0.0), 0.4742, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8097,-1.6,-0.277), vec3(-0.5052,-1.344,-0.5227), vec3(-0.4791,-1.3991,-0.5174), vec3(-0.441,-0.2906,-0.8492), vec2(0.0), vec2(0.0), vec2(0.0), 0.8557, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8539,-1.5589,-0.2868), vec3(-0.9187,-1.4985,-0.3012), vec3(-0.5436,-1.2633,-0.5304), vec3(-0.2362,-0.4583,-0.8569), vec2(0.0), vec2(0.0), vec2(0.0), 0.2371, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8539,-1.5589,-0.2868), vec3(-0.5436,-1.2633,-0.5304), vec3(-0.5052,-1.344,-0.5227), vec3(-0.414,-0.2795,-0.8663), vec2(0.0), vec2(0.0), vec2(0.0), 0.6186, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9187,-1.4985,-0.3012), vec3(0.5557,-1.2677,-0.5161), vec3(0.5452,-1.2149,-0.4815), vec3(0.6541,0.5019,-0.5659), vec2(0.0), vec2(0.0), vec2(0.0), 0, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9187,-1.4985,-0.3012), vec3(0.5452,-1.2149,-0.4815), vec3(0.9036,-1.4184,-0.2708), vec3(0.6192,0.378,-0.6883), vec2(0.0), vec2(0.0), vec2(0.0), 0.3814, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.127,-0.4392), vec3(0.514,-1.22,-0.3572), vec3(0.5297,-1.1943,-0.4045), vec3(0.0773,0.865,0.4958), vec2(0.0), vec2(0.0), vec2(0.0), 0.7629, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8913,-1.396,-0.2353), vec3(0.9036,-1.4184,-0.2708), vec3(0.5375,-1.2052,-0.4428), vec3(0.5781,0.7658,-0.2818), vec2(0.0), vec2(0.0), vec2(0.0), 0.1443, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8913,-1.396,-0.2353), vec3(0.5375,-1.2052,-0.4428), vec3(0.5297,-1.1943,-0.4045), vec3(0.5295,0.8378,-0.1327), vec2(0.0), vec2(0.0), vec2(0.0), 0.5258, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5297,-1.1943,-0.4045), vec3(0.8788,-1.3729,-0.2008), vec3(0.8913,-1.396,-0.2353), vec3(0.5689,0.7636,-0.3054), vec2(0.0), vec2(0.0), vec2(0.0), 0.9072, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6304,-1.2422,0.1634), vec3(0.3712,-1.1938,-0.0067), vec3(0.453,-1.354,-0.324), vec3(-0.3814,-0.8611,0.3363), vec2(0.0), vec2(0.0), vec2(0.0), 0.2887, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6304,-1.2422,0.1634), vec3(0.453,-1.354,-0.324), vec3(0.7515,-1.4888,-0.1065), vec3(-0.596,-0.7078,0.3792), vec2(0.0), vec2(0.0), vec2(0.0), 0.6701, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0275,-0.0373,0.5485), vec3(0.0264,-0.0367,0.5978), vec3(0.0527,-0.0781,0.5986), vec3(0.8438,0.5365,0.0124), vec2(0.0), vec2(0.0), vec2(0.0), 0.0515, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.2965,-0.5921), vec3(0,-1.2354,-0.5947), vec3(0.5557,-1.2677,-0.5161), vec3(0.1375,-0.043,-0.9896), vec2(0.0), vec2(0.0), vec2(0.0), 0.433, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.2965,-0.5921), vec3(0.5557,-1.2677,-0.5161), vec3(0.5165,-1.3479,-0.5075), vec3(0.1422,-0.1739,-0.9744), vec2(0.0), vec2(0.0), vec2(0.0), 0.8144, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5165,-1.3479,-0.5075), vec3(0.4898,-1.4026,-0.5016), vec3(0,-1.2965,-0.5921), vec3(0.1422,-0.1738,-0.9744), vec2(0.0), vec2(0.0), vec2(0.0), 0.1959, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.2354,-0.5947), vec3(0,-1.1457,-0.5986), vec3(0.5557,-1.2677,-0.5161), vec3(0.1375,-0.043,-0.9896), vec2(0.0), vec2(0.0), vec2(0.0), 0.5773, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7986,-1.5536,-0.1545), vec3(0.4715,-1.3811,-0.4117), vec3(0.4898,-1.4026,-0.5016), vec3(-0.5223,-0.8473,0.0963), vec2(0.0), vec2(0.0), vec2(0.0), 0.9588, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7986,-1.5536,-0.1545), vec3(0.4898,-1.4026,-0.5016), vec3(0.8097,-1.6,-0.277), vec3(-0.6221,-0.749,0.2279), vec2(0.0), vec2(0.0), vec2(0.0), 0.3402, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2205,-0.3493,0.4757), vec3(0.3926,-0.6196,0.399), vec3(0.1247,-0.3681,0.4564), vec3(0.1209,0.3415,-0.9321), vec2(0.0), vec2(0.0), vec2(0.0), 0.7216, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2205,-0.3493,0.4757), vec3(0.1247,-0.3681,0.4564), vec3(0.0284,-0.0379,0.5099), vec3(0.1553,0.2019,-0.967), vec2(0.0), vec2(0.0), vec2(0.0), 0.1031, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0284,-0.0379,0.5099), vec3(0.0568,-0.0764,0.5108), vec3(0.2205,-0.3493,0.4757), vec3(0.6542,0.4686,-0.5937), vec2(0.0), vec2(0.0), vec2(0.0), 0.4845, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7515,-1.4888,-0.1065), vec3(0.453,-1.354,-0.324), vec3(0.4715,-1.3811,-0.4117), vec3(-0.4999,-0.8515,0.1581), vec2(0.0), vec2(0.0), vec2(0.0), 0.866, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7515,-1.4888,-0.1065), vec3(0.4715,-1.3811,-0.4117), vec3(0.7986,-1.5536,-0.1545), vec3(-0.6299,-0.7032,0.3298), vec2(0.0), vec2(0.0), vec2(0.0), 0.2474, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.9036,-1.4184,-0.2708), vec3(0.5452,-1.2149,-0.4815), vec3(0.5375,-1.2052,-0.4428), vec3(0.5361,0.8378,-0.1031), vec2(0.0), vec2(0.0), vec2(0.0), 0.6289, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8097,-1.6,-0.277), vec3(-0.4791,-1.3991,-0.5174), vec3(-0.4607,-1.3788,-0.4276), vec3(0.5561,-0.8279,0.0727), vec2(0.0), vec2(0.0), vec2(0.0), 0.0103, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8788,-1.3729,-0.2008), vec3(-0.517,-1.1916,-0.4185), vec3(-0.5248,-1.2019,-0.4568), vec3(-0.5055,0.8531,-0.1292), vec2(0.0), vec2(0.0), vec2(0.0), 0.3918, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8788,-1.3729,-0.2008), vec3(-0.5248,-1.2019,-0.4568), vec3(-0.8913,-1.396,-0.2353), vec3(-0.5809,0.7578,-0.2972), vec2(0.0), vec2(0.0), vec2(0.0), 0.7732, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8527,-1.3841,-0.1459), vec3(0.9062,-1.4529,-0.1875), vec3(0.8913,-1.396,-0.2353), vec3(0.8331,0.4667,0.297), vec2(0.0), vec2(0.0), vec2(0.0), 0.1546, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8527,-1.3841,-0.1459), vec3(0.8913,-1.396,-0.2353), vec3(0.8788,-1.3729,-0.2008), vec3(0.9056,-0.1196,0.407), vec2(0.0), vec2(0.0), vec2(0.0), 0.5361, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5452,-1.2149,-0.4815), vec3(0,-1.1046,-0.5644), vec3(0,-1.1006,-0.5231), vec3(0.2113,0.9728,-0.0949), vec2(0.0), vec2(0.0), vec2(0.0), 0.9175, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.517,-1.1916,-0.4185), vec3(0,-1.095,-0.482), vec3(0,-1.1006,-0.5231), vec3(-0.1978,0.9711,-0.1335), vec2(0.0), vec2(0.0), vec2(0.0), 0.299, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8539,-1.5589,-0.2868), vec3(0.9187,-1.4985,-0.3012), vec3(0.9062,-1.4529,-0.1875), vec3(0.6807,-0.6509,0.336), vec2(0.0), vec2(0.0), vec2(0.0), 0.6804, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8539,-1.5589,-0.2868), vec3(0.9062,-1.4529,-0.1875), vec3(0.8422,-1.5128,-0.1679), vec3(0.6981,-0.6419,0.3173), vec2(0.0), vec2(0.0), vec2(0.0), 0.0619, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8097,-1.6,-0.277), vec3(0.8539,-1.5589,-0.2868), vec3(0.8422,-1.5128,-0.1679), vec3(0.6826,-0.6564,0.3214), vec2(0.0), vec2(0.0), vec2(0.0), 0.4433, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8097,-1.6,-0.277), vec3(0.8422,-1.5128,-0.1679), vec3(0.7986,-1.5536,-0.1545), vec3(0.6987,-0.6457,0.308), vec2(0.0), vec2(0.0), vec2(0.0), 0.8247, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4791,-1.3991,-0.5174), vec3(0,-1.2965,-0.5921), vec3(0,-1.2892,-0.501), vec3(0.2204,-0.9723,0.0781), vec2(0.0), vec2(0.0), vec2(0.0), 0.2062, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7515,-1.4888,-0.1065), vec3(-0.7926,-1.4464,-0.1225), vec3(-0.9092,-1.4574,-0.1911), vec3(-0.4905,-0.1508,0.8583), vec2(0.0), vec2(0.0), vec2(0.0), 0.5876, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7515,-1.4888,-0.1065), vec3(-0.9092,-1.4574,-0.1911), vec3(-0.8451,-1.5171,-0.1717), vec3(-0.4963,-0.2655,0.8265), vec2(0.0), vec2(0.0), vec2(0.0), 0.9691, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.8451,-1.5171,-0.1717), vec3(-0.8014,-1.5578,-0.1585), vec3(-0.7515,-1.4888,-0.1065), vec3(-0.4963,-0.2655,0.8265), vec2(0.0), vec2(0.0), vec2(0.0), 0.3505, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.453,-1.354,-0.324), vec3(0,-1.2752,-0.4107), vec3(0,-1.2892,-0.501), vec3(-0.1972,-0.9688,0.1501), vec2(0.0), vec2(0.0), vec2(0.0), 0.732, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9187,-1.4985,-0.3012), vec3(-0.9092,-1.4574,-0.1911), vec3(-0.8913,-1.396,-0.2353), vec3(-0.9631,0.2686,-0.0175), vec2(0.0), vec2(0.0), vec2(0.0), 0.1134, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.9187,-1.4985,-0.3012), vec3(-0.8913,-1.396,-0.2353), vec3(-0.9036,-1.4184,-0.2708), vec3(-0.9551,0.0701,0.2878), vec2(0.0), vec2(0.0), vec2(0.0), 0.4948, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.7926,-1.4464,-0.1225), vec3(-0.8527,-1.3841,-0.1459), vec3(-0.9092,-1.4574,-0.1911), vec3(-0.4905,-0.1508,0.8583), vec2(0.0), vec2(0.0), vec2(0.0), 0.8763, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8527,-1.3841,-0.1459), vec3(0.514,-1.22,-0.3572), vec3(0.4193,-1.0743,-0.0737), vec3(0.5388,0.8088,-0.2358), vec2(0.0), vec2(0.0), vec2(0.0), 0.2577, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8527,-1.3841,-0.1459), vec3(0.4193,-1.0743,-0.0737), vec3(0.7022,-1.1477,0.0933), vec3(0.466,0.7582,-0.456), vec2(0.0), vec2(0.0), vec2(0.0), 0.6392, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7022,-1.1477,0.0933), vec3(0.4193,-1.0743,-0.0737), vec3(0.3177,-0.883,0.1734), vec3(0.4529,0.7855,-0.4218), vec2(0.0), vec2(0.0), vec2(0.0), 0.0206, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7022,-1.1477,0.0933), vec3(0.3177,-0.883,0.1734), vec3(0.5383,-0.8895,0.2793), vec3(0.333,0.681,-0.6522), vec2(0.0), vec2(0.0), vec2(0.0), 0.4021, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5383,-0.8895,0.2793), vec3(0.3177,-0.883,0.1734), vec3(0.2228,-0.6252,0.3452), vec3(0.3587,0.6055,-0.7104), vec2(0.0), vec2(0.0), vec2(0.0), 0.7835, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5383,-0.8895,0.2793), vec3(0.2228,-0.6252,0.3452), vec3(0.3926,-0.6196,0.399), vec3(0.2464,0.5011,-0.8296), vec2(0.0), vec2(0.0), vec2(0.0), 0.1649, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3926,-0.6196,0.399), vec3(0.2228,-0.6252,0.3452), vec3(0.1247,-0.3681,0.4564), vec3(0.2537,0.464,-0.8487), vec2(0.0), vec2(0.0), vec2(0.0), 0.5464, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0527,-0.0781,0.5986), vec3(0.0264,-0.0367,0.5978), vec3(0.1142,-0.3685,0.5632), vec3(-0.3119,-0.1798,0.933), vec2(0.0), vec2(0.0), vec2(0.0), 0.9278, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0527,-0.0781,0.5986), vec3(0.1142,-0.3685,0.5632), vec3(0.2057,-0.3758,0.5749), vec3(-0.1375,-0.1485,0.9793), vec2(0.0), vec2(0.0), vec2(0.0), 0.3093, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2057,-0.3758,0.5749), vec3(0.1142,-0.3685,0.5632), vec3(0,-0.6785,0.4294), vec3(-0.1465,-0.3459,0.9267), vec2(0.0), vec2(0.0), vec2(0.0), 0.6907, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2057,-0.3758,0.5749), vec3(0,-0.6785,0.4294), vec3(0.2012,-0.6841,0.4473), vec3(-0.092,-0.3799,0.9204), vec2(0.0), vec2(0.0), vec2(0.0), 0.0722, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2012,-0.6841,0.4473), vec3(0.3549,-0.6734,0.4984), vec3(0.2057,-0.3758,0.5749), vec3(-0.2712,-0.365,0.8906), vec2(0.0), vec2(0.0), vec2(0.0), 0.4536, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3549,-0.6734,0.4984), vec3(0.2012,-0.6841,0.4473), vec3(0,-0.9555,0.2107), vec3(-0.2332,-0.5349,0.8121), vec2(0.0), vec2(0.0), vec2(0.0), 0.8351, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3549,-0.6734,0.4984), vec3(0,-0.9555,0.2107), vec3(0.2871,-0.9651,0.2545), vec3(-0.139,-0.616,0.7754), vec2(0.0), vec2(0.0), vec2(0.0), 0.2165, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2871,-0.9651,0.2545), vec3(0.4973,-0.9654,0.3634), vec3(0.3549,-0.6734,0.4984), vec3(-0.3889,-0.5361,0.7492), vec2(0.0), vec2(0.0), vec2(0.0), 0.5979, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4973,-0.9654,0.3634), vec3(0.2871,-0.9651,0.2545), vec3(0,-1.1599,-0.0771), vec3(-0.3545,-0.6392,0.6824), vec2(0.0), vec2(0.0), vec2(0.0), 0.9794, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4973,-0.9654,0.3634), vec3(0,-1.1599,-0.0771), vec3(0.3712,-1.1938,-0.0067), vec3(-0.1802,-0.8084,0.5604), vec2(0.0), vec2(0.0), vec2(0.0), 0.3608, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3712,-1.1938,-0.0067), vec3(0.6304,-1.2422,0.1634), vec3(0.4973,-0.9654,0.3634), vec3(-0.4972,-0.6523,0.5721), vec2(0.0), vec2(0.0), vec2(0.0), 0.7423, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3622,-1.1969,-0.0185), vec3(-0.2802,-0.9699,0.247), vec3(-0.6304,-1.2422,0.1634), vec3(0.4585,-0.7405,0.4913), vec2(0.0), vec2(0.0), vec2(0.0), 0.1237, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3622,-1.1969,-0.0185), vec3(-0.6304,-1.2422,0.1634), vec3(-0.7515,-1.4888,-0.1065), vec3(0.4536,-0.7499,0.4816), vec2(0.0), vec2(0.0), vec2(0.0), 0.5052, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2802,-0.9699,0.247), vec3(-0.1966,-0.6886,0.4437), vec3(-0.4973,-0.9654,0.3634), vec3(0.3669,-0.6038,0.7077), vec2(0.0), vec2(0.0), vec2(0.0), 0.8866, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2802,-0.9699,0.247), vec3(-0.4973,-0.9654,0.3634), vec3(-0.6304,-1.2422,0.1634), vec3(0.3472,-0.6531,0.6729), vec2(0.0), vec2(0.0), vec2(0.0), 0.268, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1966,-0.6886,0.4437), vec3(-0.1118,-0.3712,0.5623), vec3(-0.3549,-0.6734,0.4984), vec3(0.2653,-0.3988,0.8778), vec2(0.0), vec2(0.0), vec2(0.0), 0.6495, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1966,-0.6886,0.4437), vec3(-0.3549,-0.6734,0.4984), vec3(-0.4973,-0.9654,0.3634), vec3(0.2394,-0.5012,0.8315), vec2(0.0), vec2(0.0), vec2(0.0), 0.0309, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1118,-0.3712,0.5623), vec3(-0.2057,-0.3758,0.5749), vec3(-0.3549,-0.6734,0.4984), vec3(0.1423,-0.3129,0.9391), vec2(0.0), vec2(0.0), vec2(0.0), 0.4124, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0568,-0.0764,0.5108), vec3(-0.0284,-0.0379,0.5099), vec3(-0.1221,-0.345,0.4625), vec3(-0.368,0.2505,-0.8954), vec2(0.0), vec2(0.0), vec2(0.0), 0.7938, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0568,-0.0764,0.5108), vec3(-0.1221,-0.345,0.4625), vec3(-0.2215,-0.3497,0.4758), vec3(-0.1398,0.2081,-0.9681), vec2(0.0), vec2(0.0), vec2(0.0), 0.1753, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2215,-0.3497,0.4758), vec3(-0.1221,-0.345,0.4625), vec3(0,-0.6219,0.3319), vec3(-0.1408,0.3709,-0.9179), vec2(0.0), vec2(0.0), vec2(0.0), 0.5567, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2215,-0.3497,0.4758), vec3(0,-0.6219,0.3319), vec3(-0.2162,-0.6332,0.3485), vec3(-0.091,0.4067,-0.909), vec2(0.0), vec2(0.0), vec2(0.0), 0.9381, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2162,-0.6332,0.3485), vec3(-0.3928,-0.6077,0.4047), vec3(-0.2215,-0.3497,0.4758), vec3(-0.226,0.3957,-0.8902), vec2(0.0), vec2(0.0), vec2(0.0), 0.3196, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3928,-0.6077,0.4047), vec3(-0.2162,-0.6332,0.3485), vec3(-0.0039,-0.8386,0.1514), vec3(-0.1672,0.5871,-0.792), vec2(0.0), vec2(0.0), vec2(0.0), 0.701, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3928,-0.6077,0.4047), vec3(-0.0039,-0.8386,0.1514), vec3(-0.3105,-0.8666,0.1849), vec3(-0.1409,0.6143,-0.7764), vec2(0.0), vec2(0.0), vec2(0.0), 0.0825, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3105,-0.8666,0.1849), vec3(-0.55,-0.8942,0.2845), vec3(-0.3928,-0.6077,0.4047), vec3(-0.3777,0.5265,-0.7617), vec2(0.0), vec2(0.0), vec2(0.0), 0.4639, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.55,-0.8942,0.2845), vec3(-0.3105,-0.8666,0.1849), vec3(0,-1.0369,-0.1663), vec3(-0.3451,0.6878,-0.6386), vec2(0.0), vec2(0.0), vec2(0.0), 0.8454, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.55,-0.8942,0.2845), vec3(0,-1.0369,-0.1663), vec3(-0.4101,-1.069,-0.0772), vec3(-0.172,0.8593,-0.4817), vec2(0.0), vec2(0.0), vec2(0.0), 0.2268, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4101,-1.069,-0.0772), vec3(-0.7121,-1.1512,0.0835), vec3(-0.55,-0.8942,0.2845), vec3(-0.472,0.7084,-0.5248), vec2(0.0), vec2(0.0), vec2(0.0), 0.6082, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2215,-0.3497,0.4758), vec3(-0.3928,-0.6077,0.4047), vec3(-0.2148,-0.3635,0.528), vec3(-0.8382,0.4909,0.2377), vec2(0.0), vec2(0.0), vec2(0.0), 0.9897, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2215,-0.3497,0.4758), vec3(-0.2148,-0.3635,0.528), vec3(-0.055,-0.0771,0.5493), vec3(-0.8566,0.4608,0.2321), vec2(0.0), vec2(0.0), vec2(0.0), 0.3711, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3928,-0.6077,0.4047), vec3(-0.55,-0.8942,0.2845), vec3(-0.3778,-0.6407,0.4381), vec3(-0.8016,0.204,0.5621), vec2(0.0), vec2(0.0), vec2(0.0), 0.7526, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3928,-0.6077,0.4047), vec3(-0.3778,-0.6407,0.4381), vec3(-0.2148,-0.3635,0.528), vec3(-0.7623,0.2551,0.5949), vec2(0.0), vec2(0.0), vec2(0.0), 0.134, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.55,-0.8942,0.2845), vec3(-0.7121,-1.1512,0.0835), vec3(-0.5195,-0.9355,0.3303), vec3(-0.8086,0.0517,0.5861), vec2(0.0), vec2(0.0), vec2(0.0), 0.5155, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.55,-0.8942,0.2845), vec3(-0.5195,-0.9355,0.3303), vec3(-0.3778,-0.6407,0.4381), vec3(-0.7632,0.1358,0.6317), vec2(0.0), vec2(0.0), vec2(0.0), 0.8969, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0284,-0.0379,0.5099), vec3(0,-0.0038,0.5086), vec3(0.0018,-0.3689,0.4496), vec3(-0.2292,0.1542,-0.9611), vec2(0.0), vec2(0.0), vec2(0.0), 0.2784, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0284,-0.0379,0.5099), vec3(0.0018,-0.3689,0.4496), vec3(-0.1221,-0.345,0.4625), vec3(-0.069,0.1727,-0.9825), vec2(0.0), vec2(0.0), vec2(0.0), 0.6598, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1221,-0.345,0.4625), vec3(0.0018,-0.3689,0.4496), vec3(0.2228,-0.6252,0.3452), vec3(-0.0286,0.3559,-0.9341), vec2(0.0), vec2(0.0), vec2(0.0), 0.0412, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.1221,-0.345,0.4625), vec3(0.2228,-0.6252,0.3452), vec3(0,-0.6219,0.3319), vec3(0.0599,0.4473,-0.8924), vec2(0.0), vec2(0.0), vec2(0.0), 0.4227, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2162,-0.6332,0.3485), vec3(0,-0.6219,0.3319), vec3(-0.0039,-0.8386,0.1514), vec3(-0.092,0.6383,-0.7643), vec2(0.0), vec2(0.0), vec2(0.0), 0.8041, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3105,-0.8666,0.1849), vec3(-0.0039,-0.8386,0.1514), vec3(0,-1.0369,-0.1663), vec3(-0.1342,0.8399,-0.5259), vec2(0.0), vec2(0.0), vec2(0.0), 0.1856, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0264,-0.0367,0.5978), vec3(0,0,0.5964), vec3(0,-0.3512,0.5616), vec3(-0.1855,-0.0971,0.9778), vec2(0.0), vec2(0.0), vec2(0.0), 0.567, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0264,-0.0367,0.5978), vec3(0,-0.3512,0.5616), vec3(0.1142,-0.3685,0.5632), vec3(-0.0312,-0.1118,0.9932), vec2(0.0), vec2(0.0), vec2(0.0), 0.9485, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1142,-0.3685,0.5632), vec3(0,-0.3512,0.5616), vec3(-0.1966,-0.6886,0.4437), vec3(-0.0589,-0.2986,0.9526), vec2(0.0), vec2(0.0), vec2(0.0), 0.3299, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1142,-0.3685,0.5632), vec3(-0.1966,-0.6886,0.4437), vec3(0,-0.6785,0.4294), vec3(0.087,-0.4215,0.9026), vec2(0.0), vec2(0.0), vec2(0.0), 0.7113, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2012,-0.6841,0.4473), vec3(0,-0.6785,0.4294), vec3(0,-0.9555,0.2107), vec3(-0.0863,-0.6175,0.7818), vec2(0.0), vec2(0.0), vec2(0.0), 0.0928, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2871,-0.9651,0.2545), vec3(0,-0.9555,0.2107), vec3(0,-1.1599,-0.0771), vec3(-0.1149,-0.8099,0.5752), vec2(0.0), vec2(0.0), vec2(0.0), 0.4742, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2148,-0.3635,0.528), vec3(-0.3778,-0.6407,0.4381), vec3(-0.2057,-0.3758,0.5749), vec3(-0.8649,0.4185,0.2773), vec2(0.0), vec2(0.0), vec2(0.0), 0.8557, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2148,-0.3635,0.528), vec3(-0.2057,-0.3758,0.5749), vec3(-0.0527,-0.0781,0.5986), vec3(-0.8632,0.4217,0.2778), vec2(0.0), vec2(0.0), vec2(0.0), 0.2371, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3778,-0.6407,0.4381), vec3(-0.5195,-0.9355,0.3303), vec3(-0.3549,-0.6734,0.4984), vec3(-0.8555,0.2441,0.4568), vec2(0.0), vec2(0.0), vec2(0.0), 0.6186, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3778,-0.6407,0.4381), vec3(-0.3549,-0.6734,0.4984), vec3(-0.2057,-0.3758,0.5749), vec3(-0.8299,0.2941,0.4741), vec2(0.0), vec2(0.0), vec2(0.0), 0, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5195,-0.9355,0.3303), vec3(-0.6616,-1.2042,0.1376), vec3(-0.4973,-0.9654,0.3634), vec3(-0.8209,0.0253,0.5705), vec2(0.0), vec2(0.0), vec2(0.0), 0.3814, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5195,-0.9355,0.3303), vec3(-0.4973,-0.9654,0.3634), vec3(-0.3549,-0.6734,0.4984), vec3(-0.7841,0.0992,0.6127), vec2(0.0), vec2(0.0), vec2(0.0), 0.7629, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-1.1599,-0.0771), vec3(-0.3622,-1.1969,-0.0185), vec3(-0.4421,-1.3529,-0.3399), vec3(0.1568,-0.9031,0.3997), vec2(0.0), vec2(0.0), vec2(0.0), 0.1443, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3622,-1.1969,-0.0185), vec3(0,-1.1599,-0.0771), vec3(0,-0.9555,0.2107), vec3(0.1741,-0.8028,0.5702), vec2(0.0), vec2(0.0), vec2(0.0), 0.5258, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3622,-1.1969,-0.0185), vec3(0,-0.9555,0.2107), vec3(-0.2802,-0.9699,0.247), vec3(0.1206,-0.7727,0.6232), vec2(0.0), vec2(0.0), vec2(0.0), 0.9072, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2802,-0.9699,0.247), vec3(0,-0.9555,0.2107), vec3(0,-0.6785,0.4294), vec3(0.1325,-0.6143,0.7778), vec2(0.0), vec2(0.0), vec2(0.0), 0.2887, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2802,-0.9699,0.247), vec3(0,-0.6785,0.4294), vec3(-0.1966,-0.6886,0.4437), vec3(0.0884,-0.5882,0.8039), vec2(0.0), vec2(0.0), vec2(0.0), 0.6701, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0,-0.3512,0.5616), vec3(-0.1118,-0.3712,0.5623), vec3(-0.1966,-0.6886,0.4437), vec3(0.071,-0.3657,0.928), vec2(0.0), vec2(0.0), vec2(0.0), 0.0515, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7515,-1.4888,-0.1065), vec3(0.7926,-1.4464,-0.1225), vec3(0.6618,-1.2041,0.1375), vec3(0.6442,-0.3703,0.6693), vec2(0.0), vec2(0.0), vec2(0.0), 0.433, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7515,-1.4888,-0.1065), vec3(0.6618,-1.2041,0.1375), vec3(0.6304,-1.2422,0.1634), vec3(0.7786,-0.2483,0.5763), vec2(0.0), vec2(0.0), vec2(0.0), 0.8144, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6304,-1.2422,0.1634), vec3(0.6618,-1.2041,0.1375), vec3(0.5181,-0.9373,0.3323), vec3(0.7146,-0.1186,0.6894), vec2(0.0), vec2(0.0), vec2(0.0), 0.1959, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6304,-1.2422,0.1634), vec3(0.5181,-0.9373,0.3323), vec3(0.4973,-0.9654,0.3634), vec3(0.8321,-0.0006,0.5546), vec2(0.0), vec2(0.0), vec2(0.0), 0.5773, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4973,-0.9654,0.3634), vec3(0.5181,-0.9373,0.3323), vec3(0.3734,-0.647,0.4497), vec3(0.7675,0.1286,0.6281), vec2(0.0), vec2(0.0), vec2(0.0), 0.9588, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4973,-0.9654,0.3634), vec3(0.3734,-0.647,0.4497), vec3(0.3549,-0.6734,0.4984), vec3(0.868,0.2168,0.4468), vec2(0.0), vec2(0.0), vec2(0.0), 0.3402, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3549,-0.6734,0.4984), vec3(0.3734,-0.647,0.4497), vec3(0.2148,-0.3635,0.528), vec3(0.8142,0.3219,0.4832), vec2(0.0), vec2(0.0), vec2(0.0), 0.7216, 1.0, vec3(0.366,0.2588,0.1367), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7926,-1.4464,-0.1225), vec3(0.8527,-1.3841,-0.1459), vec3(0.7022,-1.1477,0.0933), vec3(0.6184,-0.3286,0.7139), vec2(0.0), vec2(0.0), vec2(0.0), 0.1031, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.7926,-1.4464,-0.1225), vec3(0.7022,-1.1477,0.0933), vec3(0.6618,-1.2041,0.1375), vec3(0.8185,-0.1525,0.554), vec2(0.0), vec2(0.0), vec2(0.0), 0.4845, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6618,-1.2041,0.1375), vec3(0.7022,-1.1477,0.0933), vec3(0.5383,-0.8895,0.2793), vec3(0.7437,-0.0094,0.6684), vec2(0.0), vec2(0.0), vec2(0.0), 0.866, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6618,-1.2041,0.1375), vec3(0.5383,-0.8895,0.2793), vec3(0.5181,-0.9373,0.3323), vec3(0.8778,0.1377,0.4587), vec2(0.0), vec2(0.0), vec2(0.0), 0.2474, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5181,-0.9373,0.3323), vec3(0.5383,-0.8895,0.2793), vec3(0.3926,-0.6196,0.399), vec3(0.8292,0.2195,0.5141), vec2(0.0), vec2(0.0), vec2(0.0), 0.6289, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5181,-0.9373,0.3323), vec3(0.3926,-0.6196,0.399), vec3(0.3734,-0.647,0.4497), vec3(0.8563,0.2424,0.4561), vec2(0.0), vec2(0.0), vec2(0.0), 0.0103, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3734,-0.647,0.4497), vec3(0.3926,-0.6196,0.399), vec3(0.2205,-0.3493,0.4757), vec3(0.7895,0.362,0.4956), vec2(0.0), vec2(0.0), vec2(0.0), 0.3918, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.514,-1.22,-0.3572), vec3(0,-1.127,-0.4392), vec3(0,-1.0369,-0.1663), vec3(0.2166,0.927,-0.3061), vec2(0.0), vec2(0.0), vec2(0.0), 0.7732, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.514,-1.22,-0.3572), vec3(0,-1.0369,-0.1663), vec3(0.4193,-1.0743,-0.0737), vec3(0.1696,0.8984,-0.4051), vec2(0.0), vec2(0.0), vec2(0.0), 0.1546, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4193,-1.0743,-0.0737), vec3(0,-1.0369,-0.1663), vec3(-0.0039,-0.8386,0.1514), vec3(0.1889,0.8341,-0.5183), vec2(0.0), vec2(0.0), vec2(0.0), 0.5361, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4193,-1.0743,-0.0737), vec3(-0.0039,-0.8386,0.1514), vec3(0.3177,-0.883,0.1734), vec3(0.1507,0.8108,-0.5656), vec2(0.0), vec2(0.0), vec2(0.0), 0.9175, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3177,-0.883,0.1734), vec3(-0.0039,-0.8386,0.1514), vec3(0,-0.6219,0.3319), vec3(0.1395,0.6323,-0.7621), vec2(0.0), vec2(0.0), vec2(0.0), 0.299, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3177,-0.883,0.1734), vec3(0,-0.6219,0.3319), vec3(0.2228,-0.6252,0.3452), vec3(0.0575,0.5682,-0.8209), vec2(0.0), vec2(0.0), vec2(0.0), 0.6804, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0018,-0.3689,0.4496), vec3(0.1247,-0.3681,0.4564), vec3(0.2228,-0.6252,0.3452), vec3(0.048,0.4121,-0.9099), vec2(0.0), vec2(0.0), vec2(0.0), 0.0619, 1.0, vec3(0.4222,0.2799,0.058), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.7594,0.2472), vec3(-0.4249,-0.8035,0.2463), vec3(-0.5189,-0.8092,0.2914), vec3(-0.3362,0.7168,-0.6109), vec2(0.0), vec2(0.0), vec2(0.0), 0.4433, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.7594,0.2472), vec3(-0.5189,-0.8092,0.2914), vec3(-0.3917,-0.5977,0.384), vec3(-0.3276,0.5375,-0.7771), vec2(0.0), vec2(0.0), vec2(0.0), 0.8247, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.7594,0.2472), vec3(-0.3917,-0.5977,0.384), vec3(-0.3107,-0.6294,0.3374), vec3(-0.2247,0.5802,-0.7829), vec2(0.0), vec2(0.0), vec2(0.0), 0.2062, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.7594,0.2472), vec3(-0.3107,-0.6294,0.3374), vec3(-0.2868,-0.6935,0.2857), vec3(-0.1662,0.5804,-0.7972), vec2(0.0), vec2(0.0), vec2(0.0), 0.5876, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5169,-0.8471,0.3104), vec3(-0.3739,-0.596,0.4228), vec3(-0.3917,-0.5977,0.384), vec3(-0.866,0.3219,0.3825), vec2(0.0), vec2(0.0), vec2(0.0), 0.9691, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5169,-0.8471,0.3104), vec3(-0.3917,-0.5977,0.384), vec3(-0.5189,-0.8092,0.2914), vec3(-0.7982,0.2372,0.5537), vec2(0.0), vec2(0.0), vec2(0.0), 0.3505, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3917,-0.5977,0.384), vec3(-0.3739,-0.596,0.4228), vec3(-0.2826,-0.6356,0.37), vec3(0.3015,0.9361,-0.1814), vec2(0.0), vec2(0.0), vec2(0.0), 0.732, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3917,-0.5977,0.384), vec3(-0.2826,-0.6356,0.37), vec3(-0.3107,-0.6294,0.3374), vec3(0.3159,0.9443,-0.0922), vec2(0.0), vec2(0.0), vec2(0.0), 0.1134, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2077,-0.7407,0.2378), vec3(0.1934,-0.7478,0.2771), vec3(0.3086,-0.7622,0.2971), vec3(0.0857,0.9745,0.2075), vec2(0.0), vec2(0.0), vec2(0.0), 0.4948, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2077,-0.7407,0.2378), vec3(0.3086,-0.7622,0.2971), vec3(0.3101,-0.7538,0.2554), vec3(0.0905,0.9756,0.1998), vec2(0.0), vec2(0.0), vec2(0.0), 0.8763, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2555,-0.7127,0.3096), vec3(-0.2868,-0.6935,0.2857), vec3(-0.3107,-0.6294,0.3374), vec3(0.6855,0.5945,-0.4203), vec2(0.0), vec2(0.0), vec2(0.0), 0.2577, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2555,-0.7127,0.3096), vec3(-0.3107,-0.6294,0.3374), vec3(-0.2826,-0.6356,0.37), vec3(0.6627,0.5921,-0.4586), vec2(0.0), vec2(0.0), vec2(0.0), 0.6392, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,-0.5427,0.3986), vec3(0.1462,-0.5154,0.3728), vec3(0.193,-0.4572,0.4073), vec3(0.7662,-0.2697,-0.5833), vec2(0.0), vec2(0.0), vec2(0.0), 0.0206, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,-0.5427,0.3986), vec3(0.193,-0.4572,0.4073), vec3(0.2088,-0.4735,0.4406), vec3(0.8009,-0.2906,-0.5236), vec2(0.0), vec2(0.0), vec2(0.0), 0.4021, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0828,-0.4534,0.3943), vec3(-0.1019,-0.4693,0.4259), vec3(-0.0834,-0.3847,0.4574), vec3(-0.8723,0.3259,-0.3646), vec2(0.0), vec2(0.0), vec2(0.0), 0.7835, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0828,-0.4534,0.3943), vec3(-0.0834,-0.3847,0.4574), vec3(-0.0664,-0.3828,0.4211), vec3(-0.857,0.3437,-0.3839), vec2(0.0), vec2(0.0), vec2(0.0), 0.1649, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.307,-0.7899,0.2621), vec3(-0.3324,-0.7594,0.2472), vec3(-0.2868,-0.6935,0.2857), vec3(0.5726,0.0799,-0.8159), vec2(0.0), vec2(0.0), vec2(0.0), 0.5464, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.307,-0.7899,0.2621), vec3(-0.2868,-0.6935,0.2857), vec3(-0.2555,-0.7127,0.3096), vec3(0.6282,0.0585,-0.7758), vec2(0.0), vec2(0.0), vec2(0.0), 0.9278, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3584,-0.9111,0.1139), vec3(0.2628,-0.9107,0.075), vec3(0.1647,-0.8805,0.0856), vec3(0.2061,0.8428,-0.4971), vec2(0.0), vec2(0.0), vec2(0.0), 0.3093, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3584,-0.9111,0.1139), vec3(0.1647,-0.8805,0.0856), vec3(0.1115,-0.8297,0.135), vec3(0.2095,0.7858,-0.582), vec2(0.0), vec2(0.0), vec2(0.0), 0.6907, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3584,-0.9111,0.1139), vec3(0.1115,-0.8297,0.135), vec3(0.1287,-0.7738,0.1937), vec3(0.1669,0.6886,-0.7057), vec2(0.0), vec2(0.0), vec2(0.0), 0.0722, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3584,-0.9111,0.1139), vec3(0.1287,-0.7738,0.1937), vec3(0.2077,-0.7407,0.2378), vec3(0.1371,0.6586,-0.7399), vec2(0.0), vec2(0.0), vec2(0.0), 0.4536, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3584,-0.9111,0.1139), vec3(0.2077,-0.7407,0.2378), vec3(0.3101,-0.7538,0.2554), vec3(0.2076,0.6884,-0.695), vec2(0.0), vec2(0.0), vec2(0.0), 0.8351, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3584,-0.9111,0.1139), vec3(0.3101,-0.7538,0.2554), vec3(0.3882,-0.8091,0.2367), vec3(0.3302,0.685,-0.6494), vec2(0.0), vec2(0.0), vec2(0.0), 0.2165, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3584,-0.9111,0.1139), vec3(0.3882,-0.8091,0.2367), vec3(0.4071,-0.8736,0.1811), vec3(0.374,0.6666,-0.6448), vec2(0.0), vec2(0.0), vec2(0.0), 0.5979, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1115,-0.8297,0.135), vec3(0.0849,-0.8566,0.1569), vec3(0.1044,-0.7892,0.2263), vec3(-0.7892,0.5366,-0.2986), vec2(0.0), vec2(0.0), vec2(0.0), 0.9794, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1115,-0.8297,0.135), vec3(0.1044,-0.7892,0.2263), vec3(0.1287,-0.7738,0.1937), vec3(-0.769,0.5603,-0.3076), vec2(0.0), vec2(0.0), vec2(0.0), 0.3608, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4249,-0.8035,0.2463), vec3(-0.4114,-0.8408,0.2582), vec3(-0.5169,-0.8471,0.3104), vec3(-0.3854,-0.4049,-0.8291), vec2(0.0), vec2(0.0), vec2(0.0), 0.7423, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4249,-0.8035,0.2463), vec3(-0.5169,-0.8471,0.3104), vec3(-0.5189,-0.8092,0.2914), vec3(-0.369,-0.4311,-0.8234), vec2(0.0), vec2(0.0), vec2(0.0), 0.1237, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.7594,0.2472), vec3(-0.307,-0.7899,0.2621), vec3(-0.4114,-0.8408,0.2582), vec3(0.1827,-0.3032,-0.9353), vec2(0.0), vec2(0.0), vec2(0.0), 0.5052, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.7594,0.2472), vec3(-0.4114,-0.8408,0.2582), vec3(-0.4249,-0.8035,0.2463), vec3(0.1327,-0.2577,-0.9571), vec2(0.0), vec2(0.0), vec2(0.0), 0.8866, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1462,-0.5154,0.3728), vec3(0.0563,-0.5357,0.3536), vec3(-0.0344,-0.5124,0.3644), vec3(0.0475,0.5665,-0.8227), vec2(0.0), vec2(0.0), vec2(0.0), 0.268, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1462,-0.5154,0.3728), vec3(-0.0344,-0.5124,0.3644), vec3(-0.0828,-0.4534,0.3943), vec3(0.0486,0.4835,-0.874), vec2(0.0), vec2(0.0), vec2(0.0), 0.6495, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1462,-0.5154,0.3728), vec3(-0.0828,-0.4534,0.3943), vec3(-0.0664,-0.3828,0.4211), vec3(0.0076,0.3534,-0.9354), vec2(0.0), vec2(0.0), vec2(0.0), 0.0309, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1462,-0.5154,0.3728), vec3(-0.0664,-0.3828,0.4211), vec3(0.0066,-0.3352,0.4353), vec3(-0.0202,0.3139,-0.9492), vec2(0.0), vec2(0.0), vec2(0.0), 0.4124, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1462,-0.5154,0.3728), vec3(0.0066,-0.3352,0.4353), vec3(0.1021,-0.336,0.4399), vec3(0.0472,0.3601,-0.9317), vec2(0.0), vec2(0.0), vec2(0.0), 0.7938, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1462,-0.5154,0.3728), vec3(0.1021,-0.336,0.4399), vec3(0.1755,-0.3852,0.4326), vec3(0.1659,0.381,-0.9096), vec2(0.0), vec2(0.0), vec2(0.0), 0.1753, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1462,-0.5154,0.3728), vec3(0.1755,-0.3852,0.4326), vec3(0.193,-0.4572,0.4073), vec3(0.2081,0.3696,-0.9056), vec2(0.0), vec2(0.0), vec2(0.0), 0.5567, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0066,-0.3352,0.4353), vec3(-0.0011,-0.3274,0.4729), vec3(0.1065,-0.3281,0.4781), vec3(0.0164,0.9795,-0.2009), vec2(0.0), vec2(0.0), vec2(0.0), 0.9381, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0066,-0.3352,0.4353), vec3(0.1065,-0.3281,0.4781), vec3(0.1021,-0.336,0.4399), vec3(0.0175,0.979,-0.2032), vec2(0.0), vec2(0.0), vec2(0.0), 0.3196, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,-0.5427,0.3986), vec3(0.2088,-0.4735,0.4406), vec3(0.1891,-0.3872,0.4704), vec3(-0.237,-0.3659,0.9), vec2(0.0), vec2(0.0), vec2(0.0), 0.701, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,-0.5427,0.3986), vec3(0.1891,-0.3872,0.4704), vec3(0.1065,-0.3281,0.4781), vec3(-0.1876,-0.3791,0.9061), vec2(0.0), vec2(0.0), vec2(0.0), 0.0825, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,-0.5427,0.3986), vec3(0.1065,-0.3281,0.4781), vec3(-0.0011,-0.3274,0.4729), vec3(-0.0471,-0.3566,0.9331), vec2(0.0), vec2(0.0), vec2(0.0), 0.4639, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,-0.5427,0.3986), vec3(-0.0011,-0.3274,0.4729), vec3(-0.0834,-0.3847,0.4574), vec3(0.033,-0.3046,0.9519), vec2(0.0), vec2(0.0), vec2(0.0), 0.8454, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,-0.5427,0.3986), vec3(-0.0834,-0.3847,0.4574), vec3(-0.1019,-0.4693,0.4259), vec3(-0.0001,-0.3491,0.9371), vec2(0.0), vec2(0.0), vec2(0.0), 0.2268, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,-0.5427,0.3986), vec3(-0.1019,-0.4693,0.4259), vec3(-0.0474,-0.5393,0.3891), vec3(-0.0487,-0.4944,0.8679), vec2(0.0), vec2(0.0), vec2(0.0), 0.6082, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,-0.5427,0.3986), vec3(-0.0474,-0.5393,0.3891), vec3(0.0549,-0.5666,0.3753), vec3(-0.0475,-0.5866,0.8085), vec2(0.0), vec2(0.0), vec2(0.0), 0.9897, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2088,-0.4735,0.4406), vec3(0.193,-0.4572,0.4073), vec3(0.1755,-0.3852,0.4326), vec3(0.9071,0.3175,-0.2764), vec2(0.0), vec2(0.0), vec2(0.0), 0.3711, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2088,-0.4735,0.4406), vec3(0.1755,-0.3852,0.4326), vec3(0.1891,-0.3872,0.4704), vec3(0.8992,0.3117,-0.3071), vec2(0.0), vec2(0.0), vec2(0.0), 0.7526, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1021,-0.336,0.4399), vec3(0.1065,-0.3281,0.4781), vec3(0.1891,-0.3872,0.4704), vec3(0.5525,0.8017,-0.228), vec2(0.0), vec2(0.0), vec2(0.0), 0.134, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1021,-0.336,0.4399), vec3(0.1891,-0.3872,0.4704), vec3(0.1755,-0.3852,0.4326), vec3(0.5406,0.8276,-0.1508), vec2(0.0), vec2(0.0), vec2(0.0), 0.5155, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3629,-0.9508,0.128), vec3(0.3584,-0.9111,0.1139), vec3(0.4071,-0.8736,0.1811), vec3(0.8307,-0.0991,-0.5479), vec2(0.0), vec2(0.0), vec2(0.0), 0.8969, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3629,-0.9508,0.128), vec3(0.4071,-0.8736,0.1811), vec3(0.4174,-0.9061,0.2086), vec3(0.8555,-0.1491,-0.4959), vec2(0.0), vec2(0.0), vec2(0.0), 0.2784, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0344,-0.5124,0.3644), vec3(-0.0474,-0.5393,0.3891), vec3(-0.1019,-0.4693,0.4259), vec3(-0.7322,-0.2339,-0.6396), vec2(0.0), vec2(0.0), vec2(0.0), 0.6598, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0344,-0.5124,0.3644), vec3(-0.1019,-0.4693,0.4259), vec3(-0.0828,-0.4534,0.3943), vec3(-0.7403,-0.3029,-0.6001), vec2(0.0), vec2(0.0), vec2(0.0), 0.0412, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0563,-0.5357,0.3536), vec3(0.0549,-0.5666,0.3753), vec3(-0.0474,-0.5393,0.3891), vec3(-0.2544,-0.5478,-0.797), vec2(0.0), vec2(0.0), vec2(0.0), 0.4227, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0563,-0.5357,0.3536), vec3(-0.0474,-0.5393,0.3891), vec3(-0.0344,-0.5124,0.3644), vec3(-0.2435,-0.5906,-0.7693), vec2(0.0), vec2(0.0), vec2(0.0), 0.8041, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1462,-0.5154,0.3728), vec3(0.1563,-0.5427,0.3986), vec3(0.0549,-0.5666,0.3753), vec3(0.3109,-0.5901,-0.7451), vec2(0.0), vec2(0.0), vec2(0.0), 0.1856, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1462,-0.5154,0.3728), vec3(0.0549,-0.5666,0.3753), vec3(0.0563,-0.5357,0.3536), vec3(0.2922,-0.5583,-0.7764), vec2(0.0), vec2(0.0), vec2(0.0), 0.567, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0011,-0.3274,0.4729), vec3(0.0066,-0.3352,0.4353), vec3(-0.0664,-0.3828,0.4211), vec3(-0.4872,0.8295,-0.2731), vec2(0.0), vec2(0.0), vec2(0.0), 0.9485, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.0011,-0.3274,0.4729), vec3(-0.0664,-0.3828,0.4211), vec3(-0.0834,-0.3847,0.4574), vec3(-0.5321,0.8209,-0.2073), vec2(0.0), vec2(0.0), vec2(0.0), 0.3299, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3629,-0.9508,0.128), vec3(0.4174,-0.9061,0.2086), vec3(0.3962,-0.8285,0.2751), vec3(-0.403,-0.657,0.6372), vec2(0.0), vec2(0.0), vec2(0.0), 0.7113, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3629,-0.9508,0.128), vec3(0.3962,-0.8285,0.2751), vec3(0.3086,-0.7622,0.2971), vec3(-0.352,-0.6791,0.6441), vec2(0.0), vec2(0.0), vec2(0.0), 0.0928, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3629,-0.9508,0.128), vec3(0.3086,-0.7622,0.2971), vec3(0.1934,-0.7478,0.2771), vec3(-0.2072,-0.6856,0.6978), vec2(0.0), vec2(0.0), vec2(0.0), 0.4742, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3629,-0.9508,0.128), vec3(0.1934,-0.7478,0.2771), vec3(0.1044,-0.7892,0.2263), vec3(-0.1231,-0.6522,0.748), vec2(0.0), vec2(0.0), vec2(0.0), 0.8557, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3629,-0.9508,0.128), vec3(0.1044,-0.7892,0.2263), vec3(0.0849,-0.8566,0.1569), vec3(-0.1586,-0.686,0.7101), vec2(0.0), vec2(0.0), vec2(0.0), 0.2371, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3629,-0.9508,0.128), vec3(0.0849,-0.8566,0.1569), vec3(0.1449,-0.9158,0.0965), vec3(-0.2096,-0.7938,0.5709), vec2(0.0), vec2(0.0), vec2(0.0), 0.6186, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3629,-0.9508,0.128), vec3(0.1449,-0.9158,0.0965), vec3(0.2555,-0.9505,0.0821), vec3(-0.2057,-0.8557,0.4748), vec2(0.0), vec2(0.0), vec2(0.0), 0, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.307,-0.7899,0.2621), vec3(-0.2555,-0.7127,0.3096), vec3(-0.2826,-0.6356,0.37), vec3(0.1322,-0.5821,0.8023), vec2(0.0), vec2(0.0), vec2(0.0), 0.3814, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.307,-0.7899,0.2621), vec3(-0.2826,-0.6356,0.37), vec3(-0.3739,-0.596,0.4228), vec3(0.2024,-0.5826,0.7871), vec2(0.0), vec2(0.0), vec2(0.0), 0.7629, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.307,-0.7899,0.2621), vec3(-0.3739,-0.596,0.4228), vec3(-0.5169,-0.8471,0.3104), vec3(0.3249,-0.5346,0.7802), vec2(0.0), vec2(0.0), vec2(0.0), 0.1443, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.307,-0.7899,0.2621), vec3(-0.5169,-0.8471,0.3104), vec3(-0.4114,-0.8408,0.2582), vec3(0.3357,-0.733,0.5916), vec2(0.0), vec2(0.0), vec2(0.0), 0.5258, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4174,-0.9061,0.2086), vec3(0.4071,-0.8736,0.1811), vec3(0.3882,-0.8091,0.2367), vec3(0.9564,0.2918,-0.0126), vec2(0.0), vec2(0.0), vec2(0.0), 0.9072, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.4174,-0.9061,0.2086), vec3(0.3882,-0.8091,0.2367), vec3(0.3962,-0.8285,0.2751), vec3(0.9528,0.3002,-0.0455), vec2(0.0), vec2(0.0), vec2(0.0), 0.2887, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3101,-0.7538,0.2554), vec3(0.3086,-0.7622,0.2971), vec3(0.3962,-0.8285,0.2751), vec3(0.6219,0.7629,0.1766), vec2(0.0), vec2(0.0), vec2(0.0), 0.6701, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3101,-0.7538,0.2554), vec3(0.3962,-0.8285,0.2751), vec3(0.3882,-0.8091,0.2367), vec3(0.599,0.7581,0.258), vec2(0.0), vec2(0.0), vec2(0.0), 0.0515, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1647,-0.8805,0.0856), vec3(0.1449,-0.9158,0.0965), vec3(0.0849,-0.8566,0.1569), vec3(-0.6396,0.1252,-0.7584), vec2(0.0), vec2(0.0), vec2(0.0), 0.433, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1647,-0.8805,0.0856), vec3(0.0849,-0.8566,0.1569), vec3(0.1115,-0.8297,0.135), vec3(-0.6587,0.0404,-0.7514), vec2(0.0), vec2(0.0), vec2(0.0), 0.8144, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2628,-0.9107,0.075), vec3(0.2555,-0.9505,0.0821), vec3(0.1449,-0.9158,0.0965), vec3(-0.1718,-0.142,-0.9748), vec2(0.0), vec2(0.0), vec2(0.0), 0.1959, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2628,-0.9107,0.075), vec3(0.1449,-0.9158,0.0965), vec3(0.1647,-0.8805,0.0856), vec3(-0.1673,-0.2026,-0.9649), vec2(0.0), vec2(0.0), vec2(0.0), 0.5773, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3584,-0.9111,0.1139), vec3(0.3629,-0.9508,0.128), vec3(0.2555,-0.9505,0.0821), vec3(0.3776,-0.2702,-0.8857), vec2(0.0), vec2(0.0), vec2(0.0), 0.9588, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3584,-0.9111,0.1139), vec3(0.2555,-0.9505,0.0821), vec3(0.2628,-0.9107,0.075), vec3(0.3667,-0.2283,-0.9019), vec2(0.0), vec2(0.0), vec2(0.0), 0.3402, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1934,-0.7478,0.2771), vec3(0.2077,-0.7407,0.2378), vec3(0.1287,-0.7738,0.1937), vec3(-0.3968,0.9176,0.0218), vec2(0.0), vec2(0.0), vec2(0.0), 0.7216, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1934,-0.7478,0.2771), vec3(0.1287,-0.7738,0.1937), vec3(0.1044,-0.7892,0.2263), vec3(-0.4569,0.8861,0.0783), vec2(0.0), vec2(0.0), vec2(0.0), 0.1031, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4849,-1.0238,0.0398), vec3(-0.4783,-1.0432,0.0775), vec3(-0.3665,-1.0104,0.0543), vec3(-0.1557,0.8675,0.4724), vec2(0.0), vec2(0.0), vec2(0.0), 0.4845, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4849,-1.0238,0.0398), vec3(-0.3665,-1.0104,0.0543), vec3(-0.3855,-0.9944,0.0195), vec3(-0.1564,0.8611,0.4837), vec2(0.0), vec2(0.0), vec2(0.0), 0.866, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3418,-1.081,-0.1742), vec3(-0.4374,-1.1193,-0.1895), vec3(-0.5299,-1.1426,-0.1469), vec3(-0.3323,0.917,-0.2208), vec2(0.0), vec2(0.0), vec2(0.0), 0.2474, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3418,-1.081,-0.1742), vec3(-0.5299,-1.1426,-0.1469), vec3(-0.577,-1.131,-0.0659), vec3(-0.3365,0.8846,-0.3228), vec2(0.0), vec2(0.0), vec2(0.0), 0.6289, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3418,-1.081,-0.1742), vec3(-0.577,-1.131,-0.0659), vec3(-0.5595,-1.0816,0.0089), vec3(-0.3781,0.8106,-0.4472), vec2(0.0), vec2(0.0), vec2(0.0), 0.0103, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3418,-1.081,-0.1742), vec3(-0.5595,-1.0816,0.0089), vec3(-0.4849,-1.0238,0.0398), vec3(-0.4046,0.7792,-0.4788), vec2(0.0), vec2(0.0), vec2(0.0), 0.3918, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3418,-1.081,-0.1742), vec3(-0.4849,-1.0238,0.0398), vec3(-0.3855,-0.9944,0.0195), vec3(-0.3365,0.829,-0.4466), vec2(0.0), vec2(0.0), vec2(0.0), 0.7732, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3418,-1.081,-0.1742), vec3(-0.3855,-0.9944,0.0195), vec3(-0.3077,-1.0047,-0.0388), vec3(-0.2128,0.8732,-0.4385), vec2(0.0), vec2(0.0), vec2(0.0), 0.1546, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3418,-1.081,-0.1742), vec3(-0.3077,-1.0047,-0.0388), vec3(-0.29,-1.0398,-0.1136), vec3(-0.1701,0.8762,-0.451), vec2(0.0), vec2(0.0), vec2(0.0), 0.5361, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.577,-1.131,-0.0659), vec3(-0.5816,-1.1711,-0.049), vec3(-0.5619,-1.1117,0.0406), vec3(-0.9812,0.1578,0.1111), vec2(0.0), vec2(0.0), vec2(0.0), 0.9175, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.577,-1.131,-0.0659), vec3(-0.5619,-1.1117,0.0406), vec3(-0.5595,-1.0816,0.0089), vec3(-0.9766,0.1878,0.1051), vec2(0.0), vec2(0.0), vec2(0.0), 0.299, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,-1.1154,-0.1755), vec3(-0.3418,-1.081,-0.1742), vec3(-0.29,-1.0398,-0.1136), vec3(0.5358,0.4113,-0.7374), vec2(0.0), vec2(0.0), vec2(0.0), 0.6804, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,-1.1154,-0.1755), vec3(-0.29,-1.0398,-0.1136), vec3(-0.2587,-1.0683,-0.1022), vec3(0.5964,0.3693,-0.7127), vec2(0.0), vec2(0.0), vec2(0.0), 0.0619, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,-1.1154,-0.1755), vec3(-0.2587,-1.0683,-0.1022), vec3(-0.2787,-1.0257,-0.0136), vec3(0.1376,-0.8799,0.4547), vec2(0.0), vec2(0.0), vec2(0.0), 0.4433, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,-1.1154,-0.1755), vec3(-0.2787,-1.0257,-0.0136), vec3(-0.3665,-1.0104,0.0543), vec3(0.1886,-0.8774,0.4412), vec2(0.0), vec2(0.0), vec2(0.0), 0.8247, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,-1.1154,-0.1755), vec3(-0.3665,-1.0104,0.0543), vec3(-0.4783,-1.0432,0.0775), vec3(0.3361,-0.8274,0.45), vec2(0.0), vec2(0.0), vec2(0.0), 0.2062, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,-1.1154,-0.1755), vec3(-0.4783,-1.0432,0.0775), vec3(-0.5619,-1.1117,0.0406), vec3(0.4165,-0.7693,0.4846), vec2(0.0), vec2(0.0), vec2(0.0), 0.5876, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,-1.1154,-0.1755), vec3(-0.5619,-1.1117,0.0406), vec3(-0.5816,-1.1711,-0.049), vec3(0.3852,-0.8058,0.4498), vec2(0.0), vec2(0.0), vec2(0.0), 0.9691, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,-1.1154,-0.1755), vec3(-0.5816,-1.1711,-0.049), vec3(-0.5289,-1.1851,-0.1457), vec3(0.3364,-0.8888,0.3112), vec2(0.0), vec2(0.0), vec2(0.0), 0.3505, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,-1.1154,-0.1755), vec3(-0.5289,-1.1851,-0.1457), vec3(-0.425,-1.1583,-0.1954), vec3(0.3314,-0.9229,0.1962), vec2(0.0), vec2(0.0), vec2(0.0), 0.732, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2587,-1.0683,-0.1022), vec3(-0.29,-1.0398,-0.1136), vec3(-0.3077,-1.0047,-0.0388), vec3(0.6968,0.6985,-0.163), vec2(0.0), vec2(0.0), vec2(0.0), 0.1134, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.2587,-1.0683,-0.1022), vec3(-0.3077,-1.0047,-0.0388), vec3(-0.2787,-1.0257,-0.0136), vec3(0.6785,0.7099,-0.1886), vec2(0.0), vec2(0.0), vec2(0.0), 0.4948, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3855,-0.9944,0.0195), vec3(-0.3665,-1.0104,0.0543), vec3(-0.2787,-1.0257,-0.0136), vec3(0.3403,0.9104,0.2352), vec2(0.0), vec2(0.0), vec2(0.0), 0.8763, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3855,-0.9944,0.0195), vec3(-0.2787,-1.0257,-0.0136), vec3(-0.3077,-1.0047,-0.0388), vec3(0.3572,0.8772,0.3209), vec2(0.0), vec2(0.0), vec2(0.0), 0.2577, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5299,-1.1426,-0.1469), vec3(-0.5289,-1.1851,-0.1457), vec3(-0.5816,-1.1711,-0.049), vec3(-0.88,-0.0316,-0.4739), vec2(0.0), vec2(0.0), vec2(0.0), 0.6392, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.5299,-1.1426,-0.1469), vec3(-0.5816,-1.1711,-0.049), vec3(-0.577,-1.131,-0.0659), vec3(-0.8658,-0.108,-0.4886), vec2(0.0), vec2(0.0), vec2(0.0), 0.0206, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4374,-1.1193,-0.1895), vec3(-0.425,-1.1583,-0.1954), vec3(-0.5289,-1.1851,-0.1457), vec3(-0.4317,0.0009,-0.902), vec2(0.0), vec2(0.0), vec2(0.0), 0.4021, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4374,-1.1193,-0.1895), vec3(-0.5289,-1.1851,-0.1457), vec3(-0.5299,-1.1426,-0.1469), vec3(-0.4112,-0.0335,-0.9109), vec2(0.0), vec2(0.0), vec2(0.0), 0.7835, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3418,-1.081,-0.1742), vec3(-0.3172,-1.1154,-0.1755), vec3(-0.425,-1.1583,-0.1954), vec3(0.1302,0.13,-0.9829), vec2(0.0), vec2(0.0), vec2(0.0), 0.1649, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.3418,-1.081,-0.1742), vec3(-0.425,-1.1583,-0.1954), vec3(-0.4374,-1.1193,-0.1895), vec3(0.0864,0.1765,-0.9805), vec2(0.0), vec2(0.0), vec2(0.0), 0.5464, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4783,-1.0432,0.0775), vec3(-0.4849,-1.0238,0.0398), vec3(-0.5595,-1.0816,0.0089), vec3(-0.6571,0.618,0.4316), vec2(0.0), vec2(0.0), vec2(0.0), 0.9278, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(-0.4783,-1.0432,0.0775), vec3(-0.5595,-1.0816,0.0089), vec3(-0.5619,-1.1117,0.0406), vec3(-0.6729,0.5609,0.4822), vec2(0.0), vec2(0.0), vec2(0.0), 0.3093, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1511,-1.0046,-0.1122), vec3(0.1394,-1.0264,-0.0781), vec3(0.2579,-1.043,-0.0701), vec3(0.0777,0.8267,0.5572), vec2(0.0), vec2(0.0), vec2(0.0), 0.6907, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1511,-1.0046,-0.1122), vec3(0.2579,-1.043,-0.0701), vec3(0.2564,-1.0193,-0.1053), vec3(0.0796,0.8286,0.5542), vec2(0.0), vec2(0.0), vec2(0.0), 0.0722, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2993,-1.1084,-0.2912), vec3(0.2002,-1.0983,-0.3228), vec3(0.1009,-1.0793,-0.2987), vec3(0.1494,0.9766,-0.1545), vec2(0.0), vec2(0.0), vec2(0.0), 0.4536, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2993,-1.1084,-0.2912), vec3(0.1009,-1.0793,-0.2987), vec3(0.0489,-1.053,-0.2335), vec3(0.1501,0.9529,-0.2636), vec2(0.0), vec2(0.0), vec2(0.0), 0.8351, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2993,-1.1084,-0.2912), vec3(0.0489,-1.053,-0.2335), vec3(0.0689,-1.022,-0.1607), vec3(0.1047,0.9042,-0.4141), vec2(0.0), vec2(0.0), vec2(0.0), 0.2165, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2993,-1.1084,-0.2912), vec3(0.0689,-1.022,-0.1607), vec3(0.1511,-1.0046,-0.1122), vec3(0.0777,0.8889,-0.4515), vec2(0.0), vec2(0.0), vec2(0.0), 0.5979, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2993,-1.1084,-0.2912), vec3(0.1511,-1.0046,-0.1122), vec3(0.2564,-1.0193,-0.1053), vec3(0.153,0.9044,-0.3983), vec2(0.0), vec2(0.0), vec2(0.0), 0.9794, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2993,-1.1084,-0.2912), vec3(0.2564,-1.0193,-0.1053), vec3(0.3353,-1.06,-0.1451), vec3(0.2756,0.8901,-0.3631), vec2(0.0), vec2(0.0), vec2(0.0), 0.3608, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2993,-1.1084,-0.2912), vec3(0.3353,-1.06,-0.1451), vec3(0.352,-1.0971,-0.219), vec3(0.3144,0.8752,-0.3678), vec2(0.0), vec2(0.0), vec2(0.0), 0.7423, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0489,-1.053,-0.2335), vec3(0.0242,-1.0873,-0.222), vec3(0.0467,-1.0494,-0.1353), vec3(-0.8171,0.5751,-0.0394), vec2(0.0), vec2(0.0), vec2(0.0), 0.1237, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.0489,-1.053,-0.2335), vec3(0.0467,-1.0494,-0.1353), vec3(0.0689,-1.022,-0.1607), vec3(-0.7951,0.6052,-0.04), vec2(0.0), vec2(0.0), vec2(0.0), 0.5052, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-1.1501,-0.2927), vec3(0.2993,-1.1084,-0.2912), vec3(0.352,-1.0971,-0.219), vec3(0.7863,0.1511,-0.5991), vec2(0.0), vec2(0.0), vec2(0.0), 0.8866, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-1.1501,-0.2927), vec3(0.352,-1.0971,-0.219), vec3(0.3652,-1.137,-0.2061), vec3(0.817,0.0847,-0.5705), vec2(0.0), vec2(0.0), vec2(0.0), 0.268, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-1.1501,-0.2927), vec3(0.3652,-1.137,-0.2061), vec3(0.3464,-1.0921,-0.1174), vec3(-0.3437,-0.8652,0.3651), vec2(0.0), vec2(0.0), vec2(0.0), 0.6495, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-1.1501,-0.2927), vec3(0.3464,-1.0921,-0.1174), vec3(0.2579,-1.043,-0.0701), vec3(-0.2983,-0.8837,0.3608), vec2(0.0), vec2(0.0), vec2(0.0), 0.0309, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-1.1501,-0.2927), vec3(0.2579,-1.043,-0.0701), vec3(0.1394,-1.0264,-0.0781), vec3(-0.1534,-0.903,0.4014), vec2(0.0), vec2(0.0), vec2(0.0), 0.4124, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-1.1501,-0.2927), vec3(0.1394,-1.0264,-0.0781), vec3(0.0467,-1.0494,-0.1353), vec3(-0.0639,-0.8852,0.4607), vec2(0.0), vec2(0.0), vec2(0.0), 0.7938, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-1.1501,-0.2927), vec3(0.0467,-1.0494,-0.1353), vec3(0.0242,-1.0873,-0.222), vec3(-0.0959,-0.9028,0.4192), vec2(0.0), vec2(0.0), vec2(0.0), 0.1753, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-1.1501,-0.2927), vec3(0.0242,-1.0873,-0.222), vec3(0.0828,-1.1171,-0.3007), vec3(-0.1501,-0.9563,0.2508), vec2(0.0), vec2(0.0), vec2(0.0), 0.5567, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-1.1501,-0.2927), vec3(0.0828,-1.1171,-0.3007), vec3(0.1947,-1.1381,-0.3302), vec3(-0.1493,-0.9804,0.1285), vec2(0.0), vec2(0.0), vec2(0.0), 0.9381, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3652,-1.137,-0.2061), vec3(0.352,-1.0971,-0.219), vec3(0.3353,-1.06,-0.1451), vec3(0.9436,0.3273,0.0498), vec2(0.0), vec2(0.0), vec2(0.0), 0.3196, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.3652,-1.137,-0.2061), vec3(0.3353,-1.06,-0.1451), vec3(0.3464,-1.0921,-0.1174), vec3(0.9381,0.3454,0.0242), vec2(0.0), vec2(0.0), vec2(0.0), 0.701, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2564,-1.0193,-0.1053), vec3(0.2579,-1.043,-0.0701), vec3(0.3464,-1.0921,-0.1174), vec3(0.6029,0.6733,0.428), vec2(0.0), vec2(0.0), vec2(0.0), 0.0825, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2564,-1.0193,-0.1053), vec3(0.3464,-1.0921,-0.1174), vec3(0.3353,-1.06,-0.1451), vec3(0.5833,0.6363,0.5048), vec2(0.0), vec2(0.0), vec2(0.0), 0.4639, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1009,-1.0793,-0.2987), vec3(0.0828,-1.1171,-0.3007), vec3(0.0242,-1.0873,-0.222), vec3(-0.6787,0.3579,-0.6414), vec2(0.0), vec2(0.0), vec2(0.0), 0.8454, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1009,-1.0793,-0.2987), vec3(0.0242,-1.0873,-0.222), vec3(0.0489,-1.053,-0.2335), vec3(-0.6937,0.2769,-0.6649), vec2(0.0), vec2(0.0), vec2(0.0), 0.2268, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2002,-1.0983,-0.3228), vec3(0.1947,-1.1381,-0.3302), vec3(0.0828,-1.1171,-0.3007), vec3(-0.2134,0.2088,-0.9544), vec2(0.0), vec2(0.0), vec2(0.0), 0.6082, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2002,-1.0983,-0.3228), vec3(0.0828,-1.1171,-0.3007), vec3(0.1009,-1.0793,-0.2987), vec3(-0.2061,0.1488,-0.9671), vec2(0.0), vec2(0.0), vec2(0.0), 0.9897, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2993,-1.1084,-0.2912), vec3(0.3061,-1.1501,-0.2927), vec3(0.1947,-1.1381,-0.3302), vec3(0.3264,0.0891,-0.941), vec2(0.0), vec2(0.0), vec2(0.0), 0.3711, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.2993,-1.1084,-0.2912), vec3(0.1947,-1.1381,-0.3302), vec3(0.2002,-1.0983,-0.3228), vec3(0.3138,0.1328,-0.9402), vec2(0.0), vec2(0.0), vec2(0.0), 0.7526, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1394,-1.0264,-0.0781), vec3(0.1511,-1.0046,-0.1122), vec3(0.0689,-1.022,-0.1607), vec3(-0.4058,0.8264,0.3903), vec2(0.0), vec2(0.0), vec2(0.0), 0.134, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.1394,-1.0264,-0.0781), vec3(0.0689,-1.022,-0.1607), vec3(0.0467,-1.0494,-0.1353), vec3(-0.4598,0.7749,0.4336), vec2(0.0), vec2(0.0), vec2(0.0), 0.5155, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5983,-1.1422,-0.0589), vec3(0.6135,-1.1067,0.0257), vec3(0.6823,-1.1095,0.1), vec3(0.4753,0.7778,-0.4112), vec2(0.0), vec2(0.0), vec2(0.0), 0.8969, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5983,-1.1422,-0.0589), vec3(0.6823,-1.1095,0.1), vec3(0.8091,-1.3031,-0.0746), vec3(0.5276,0.7329,-0.4295), vec2(0.0), vec2(0.0), vec2(0.0), 0.2784, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5983,-1.1422,-0.0589), vec3(0.8091,-1.3031,-0.0746), vec3(0.73,-1.2604,-0.1301), vec3(0.5806,0.7824,-0.2254), vec2(0.0), vec2(0.0), vec2(0.0), 0.6598, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5983,-1.1422,-0.0589), vec3(0.73,-1.2604,-0.1301), vec3(0.6455,-1.1986,-0.1209), vec3(0.5407,0.7847,-0.3031), vec2(0.0), vec2(0.0), vec2(0.0), 0.0412, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6562,-1.1209,0.1316), vec3(0.7987,-1.3465,-0.0781), vec3(0.8091,-1.3031,-0.0746), vec3(0.6819,-0.2182,0.6981), vec2(0.0), vec2(0.0), vec2(0.0), 0.4227, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6562,-1.1209,0.1316), vec3(0.8091,-1.3031,-0.0746), vec3(0.6823,-1.1095,0.1), vec3(0.7799,-0.0518,0.6238), vec2(0.0), vec2(0.0), vec2(0.0), 0.8041, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8091,-1.3031,-0.0746), vec3(0.7987,-1.3465,-0.0781), vec3(0.7102,-1.2976,-0.1419), vec3(0.5585,-0.0667,-0.8268), vec2(0.0), vec2(0.0), vec2(0.0), 0.1856, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.8091,-1.3031,-0.0746), vec3(0.7102,-1.2976,-0.1419), vec3(0.73,-1.2604,-0.1301), vec3(0.5606,-0.036,-0.8273), vec2(0.0), vec2(0.0), vec2(0.0), 0.567, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6147,-1.228,-0.1284), vec3(0.6455,-1.1986,-0.1209), vec3(0.73,-1.2604,-0.1301), vec3(0.0434,0.2046,-0.9779), vec2(0.0), vec2(0.0), vec2(0.0), 0.9485, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6147,-1.228,-0.1284), vec3(0.73,-1.2604,-0.1301), vec3(0.7102,-1.2976,-0.1419), vec3(0.0625,0.2717,-0.9604), vec2(0.0), vec2(0.0), vec2(0.0), 0.3299, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5611,-1.164,-0.0536), vec3(0.5983,-1.1422,-0.0589), vec3(0.6455,-1.1986,-0.1209), vec3(-0.4023,0.5036,-0.7645), vec2(0.0), vec2(0.0), vec2(0.0), 0.7113, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5611,-1.164,-0.0536), vec3(0.6455,-1.1986,-0.1209), vec3(0.6147,-1.228,-0.1284), vec3(-0.3584,0.5666,-0.7419), vec2(0.0), vec2(0.0), vec2(0.0), 0.0928, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6135,-1.1067,0.0257), vec3(0.5784,-1.1213,0.0456), vec3(0.6562,-1.1209,0.1316), vec3(-0.259,0.9381,0.2298), vec2(0.0), vec2(0.0), vec2(0.0), 0.4742, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.6135,-1.1067,0.0257), vec3(0.6562,-1.1209,0.1316), vec3(0.6823,-1.1095,0.1), vec3(-0.1789,0.9631,0.2009), vec2(0.0), vec2(0.0), vec2(0.0), 0.8557, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5983,-1.1422,-0.0589), vec3(0.5611,-1.164,-0.0536), vec3(0.5784,-1.1213,0.0456), vec3(-0.515,0.8164,-0.2613), vec2(0.0), vec2(0.0), vec2(0.0), 0.2371, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5983,-1.1422,-0.0589), vec3(0.5784,-1.1213,0.0456), vec3(0.6135,-1.1067,0.0257), vec3(-0.4922,0.8308,-0.2599), vec2(0.0), vec2(0.0), vec2(0.0), 0.6186, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5611,-1.164,-0.0536), vec3(0.6147,-1.228,-0.1284), vec3(0.7102,-1.2976,-0.1419), vec3(-0.5354,-0.7917,0.2942), vec2(0.0), vec2(0.0), vec2(0.0), 0, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5611,-1.164,-0.0536), vec3(0.7102,-1.2976,-0.1419), vec3(0.7987,-1.3465,-0.0781), vec3(-0.5827,-0.7862,0.2058), vec2(0.0), vec2(0.0), vec2(0.0), 0.3814, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5611,-1.164,-0.0536), vec3(0.7987,-1.3465,-0.0781), vec3(0.6562,-1.1209,0.1316), vec3(-0.5192,-0.7344,0.4371), vec2(0.0), vec2(0.0), vec2(0.0), 0.7629, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
        if (triHit(ro, rd, vec3(0.5611,-1.164,-0.0536), vec3(0.6562,-1.1209,0.1316), vec3(0.5784,-1.1213,0.0456), vec3(-0.4567,-0.7858,0.417), vec2(0.0), vec2(0.0), vec2(0.0), 0.1443, 1.0, vec3(0.366,0.0677,0.0436), bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    return hit;
}

// Placement locked in by Sam live in Synesthesia (v2.0) -- was previously driven by
// pizzaScale/pizzaPosition/pizzaDepth/pizzaOrientation controls; baked here as constants and those
// controls removed from scene.json now that the right spot's been found, so the panel doesn't carry
// four sliders nobody needs to touch again. Regenerate from a screenshot of that panel if the rat
// mesh itself ever changes and the pizza needs to be re-seated.
const float PIZZA_SCALE = 0.82;
const vec2 PIZZA_ORIENTATION = vec2(90.0, 82.80); // degrees: X=yaw, Y=pitch
const vec2 PIZZA_POSITION = vec2(2.00, -0.16);
const float PIZZA_DEPTH = 0.30;

bool pizzaHit(vec3 ro, vec3 rd, inout float bestT, inout vec3 bestN, inout vec2 bestUV,
              inout float bestFacet, inout float bestUseFlat, inout vec3 bestFlatColor) {
    if (showPizza < 0.5) return false;

    float pzScale = PIZZA_SCALE;
    float pzYaw = radians(PIZZA_ORIENTATION.x);
    float pzPitch = radians(PIZZA_ORIENTATION.y);
    mat3 pzYawM = mat3(cos(pzYaw), 0.0, -sin(pzYaw),  0.0, 1.0, 0.0,  sin(pzYaw), 0.0, cos(pzYaw));
    mat3 pzPitchM = mat3(1.0, 0.0, 0.0,  0.0, cos(pzPitch), sin(pzPitch),  0.0, -sin(pzPitch), cos(pzPitch));
    mat3 pzRot = pzYawM * pzPitchM;
    mat3 pzInvRot = transpose(pzRot);
    // -PIZZA_DEPTH: the default camera sits on -Z looking toward +Z (see renderMain), so more
    // negative Z is closer to the camera -- negating here means a more POSITIVE depth value reads as
    // "bring it toward the camera," matching how the removed pizzaDepth control was described.
    vec3 pzPivot = vec3(PIZZA_POSITION.x, PIZZA_POSITION.y, -PIZZA_DEPTH);

    vec3 pro = (pzInvRot * (ro - pzPivot)) / pzScale;
    vec3 prd = (pzInvRot * rd) / pzScale;

    float bestT_before = bestT;
    vec3 localN = bestN;
    bool hit = pizzaMeshHit(pro, prd, bestT, localN, bestUV, bestFacet, bestUseFlat, bestFlatColor);
    if (bestT < bestT_before) {
        // the pizza (specifically) won this ray -- localN is still in the pizza's own pre-pzRot
        // local space, rotate it up into the rat's local space to match how mesh-hit normals are
        // already handled (uniform scale doesn't change normal direction, same as everywhere else)
        bestN = normalize(pzRot * localN);
        return true;
    }
    return hit;
}

// ===== BACKGROUND =====

// Ported from Pigeon Hole Mesh's pigeonBackground -- style-aware instead of this template's old
// single flat 2-tone gradient: Neon Blue/Red gets a cold horizon + red laser-grid-style glow (the
// grid lines themselves are drawn in renderMain, same as Pigeon Hole Mesh), Textured/Flat Lit get a
// warm drifting bokeh-haze (originally that scene's "Iridescent Realism" background).
vec3 ratBackground(vec3 rd, float style, float sat, float bright, float intensity, float mediaAmt) {
    vec3 col;
    if (style >= 1.5) {
        float horizon = smoothstep(-0.3, 0.4, rd.y);
        vec3 low = vec3(0.05, 0.02, 0.03);
        vec3 high = vec3(0.01, 0.02, 0.05);
        col = mix(low, high, horizon);
        float glow = pow(max(1.0 - abs(rd.y - 0.05) * 2.0, 0.0), 3.0);
        col += vec3(0.05, 0.15, 0.4) * glow * intensity;
    } else {
        float n = 0.0;
        n += sin(rd.x * 6.0 + TIME * 0.15) * 0.5;
        n += sin(rd.y * 5.0 + TIME * 0.11) * 0.3;
        n += sin((rd.x + rd.y) * 4.0 + TIME * 0.08) * 0.2;
        n = fract(n * 0.5 + 0.5);
        vec3 dark = vec3(0.03, 0.03, 0.05);
        vec3 warm = vec3(0.18, 0.12, 0.10);
        col = mix(dark, warm, smoothstep(0.6, 1.0, n) * intensity);
        col += vec3(0.06, 0.05, 0.08) * smoothstep(0.3, -0.4, rd.y);
    }
    col = enhanceColor(col, bright, sat);
    if (mediaAmt > 0.001 && _isMediaActive()) {
        col = mix(col, _textureMedia(_uv).rgb, mediaAmt);
    }
    return col;
}

// ===== SHADING =====

vec3 shadeMeshHit(vec3 p, vec3 n, vec2 uv, float facetSeed, float useFlat, vec3 flatColor, vec3 viewDir, float style, float sat, float bright, float facetAmt) {
    vec3 base;
    if (style < 0.5) {
        // useFlat triangles came from a source material with no texture of its own (see triHit's
        // comment) -- they never had a meaningful UV into the shared atlas, so use their real
        // baked material color instead of sampling it regardless of the Textured/Flat Lit style.
        base = useFlat > 0.5 ? flatColor : texture2D(diffuseTex, uv).rgb;
    } else if (style < 1.5) {
        base = vec3(0.62, 0.63, 0.66);
    } else {
        // Neon Blue/Red, ported from Pigeon Hole Mesh -- deliberately near-black base; all the
        // real color comes from the rim light added below, after enhanceColor.
        base = vec3(0.03, 0.035, 0.05);
    }

    // deliberate low-poly facet variation: a stable per-triangle tint jitter, since this template
    // has no smoothed vertex normals -- flat shading alone can look a little dead on large facets,
    // this gives it some of the "real low-poly asset" character back without adding any real cost.
    vec3 facetTint = vec3(facetSeed, fract(facetSeed * 7.13), fract(facetSeed * 13.7)) - 0.5;
    base += facetTint * facetAmt * 0.15;

    vec3 lightDir = normalize(vec3(0.5, 1.0, -0.4));
    float diff = max(dot(n, lightDir), 0.0);
    vec3 shaded = base * (0.38 + diff * 0.78);

    if (style >= 1.5) {
        // Neon's base is near-black, so a plain brightness multiply barely moves it -- lift the
        // body directly too, and add the rim light AFTER enhanceColor so saturation/brightness
        // scaling can't wash the glow back out. Ported from Pigeon Hole Mesh.
        shaded = mix(shaded, shaded + vec3(0.07, 0.09, 0.15), clamp((bright - 1.0) / 2.0, 0.0, 1.0));
        shaded = enhanceColor(shaded, bright, sat);
        float fresNeon = pow(1.0 - max(dot(n, -viewDir), 0.0), 2.5);
        shaded += vec3(0.20, 0.50, 1.0) * fresNeon * (1.1 + syn_BassLevel * 0.9) * bright;
        return shaded;
    }

    float fres = pow(1.0 - max(dot(n, -viewDir), 0.0), 2.5);
    shaded += vec3(0.5, 0.6, 0.7) * fres * 0.25;

    return enhanceColor(shaded, bright, sat);
}

// ===== SCENE ASSEMBLY =====

// Lightweight hit-test-only probe for edgeDetectAmount, ported from Pigeon Hole Mesh -- applies the
// same orientation/SPEEN/wobble/mirror transform as renderChannel below so the probe ray lines up
// with the actual rendered model, but skips mesh corruption and all shading (edge detection only
// needs hit/miss + depth). Some duplication of renderChannel's transform block is accepted here
// rather than restructuring that function to share it, same tradeoff Pigeon Hole Mesh made.
float silhouetteProbe(vec2 cuv, vec3 ro, vec3 forward, vec3 right, vec3 up, out float tOut) {
    vec3 rd = normalize(forward + cuv.x * right + cuv.y * up);

    float yaw = radians(clamp(modelOrientation.x, -180.0, 180.0)) + TIME * clamp(idleSpin, 0.0, 2.0) * 0.3;
    float pitch = radians(clamp(modelOrientation.y, -90.0, 90.0));
    mat3 yawM = mat3(cos(yaw), 0.0, -sin(yaw),  0.0, 1.0, 0.0,  sin(yaw), 0.0, cos(yaw));
    mat3 pitchM = mat3(1.0, 0.0, 0.0,  0.0, cos(pitch), sin(pitch),  0.0, -sin(pitch), cos(pitch));
    mat3 objRot = yawM * pitchM;
    vec3 pivot = vec3(0.0, sin(TIME * 0.8) * clamp(bobAmount, 0.0, 1.0) * 0.1, 0.0);

    mat3 invRot = transpose(objRot);
    float safeScale = max(clamp(modelScale, 0.1, 5.0), 0.001);
    vec3 lro = (invRot * (ro - pivot)) / safeScale;
    vec3 lrd = (invRot * rd) / safeScale;

    float speenEnvC = clamp(speenEnv, 0.0, 1.0);
    float posNeg = (flipSpeen > 0.5) ? -1.0 : 1.0;
    float sx = pendulum(TIME, clamp(speenX, 0.0, 2.0)) * speenEnvC * posNeg;
    float sy = pendulum(TIME * 1.1, clamp(speenY, 0.0, 2.0)) * speenEnvC * posNeg;
    float sz = pendulum(TIME * 0.9, clamp(speenZ, 0.0, 2.0)) * speenEnvC * posNeg;
    float wobbleAmt = clamp(wobbleAmount, 0.0, 1.0);
    float wobbleYaw = sin(TIME * 0.7) * wobbleAmt * 0.22;
    float wobblePitch = sin(TIME * 0.55 + 1.7) * wobbleAmt * 0.16;

    vec3 sro = lro; vec3 srd = lrd;
    sro.xz = rot(-wobbleYaw) * sro.xz; srd.xz = rot(-wobbleYaw) * srd.xz;
    sro.xy = rot(-sz) * sro.xy;        srd.xy = rot(-sz) * srd.xy;
    sro.xz = rot(-sy) * sro.xz;        srd.xz = rot(-sy) * srd.xz;
    sro.yz = rot(-(sx + wobblePitch)) * sro.yz; srd.yz = rot(-(sx + wobblePitch)) * srd.yz;

    vec3 mirrorAxis = vec3(mirrorModel > 0.5 ? -1.0 : 1.0, 1.0, 1.0);
    vec3 mro = sro * mirrorAxis;
    vec3 mrd = srd * mirrorAxis;

    float bestT = 1e6;
    vec3 bestN = vec3(0.0);
    vec2 bestUV = vec2(0.0);
    float bestFacet = 0.0;
    float bestUseFlat = 0.0;
    vec3 bestFlatColor = vec3(0.0);
    bool hit = meshRayTest_RAT(mro, mrd, bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor);
    if (pizzaHit(mro, mrd, bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;
    tOut = bestT;
    return hit ? 1.0 : 0.0;
}

vec3 renderChannel(vec2 cuv, vec3 ro, vec3 forward, vec3 right, vec3 up,
                    float scale, vec2 orientation, float spinSpeed, float bobAmt, float mirrorAmt,
                    float style, float sat, float bright, float facetAmt,
                    float bgSat, float bgBright, float bgIntensity, float mediaAmt,
                    float meshGlitchAmt, float meshGlitchRes, float meshTwistAmt, float meshWarpAmt,
                    float meshDistortAmt, float meshFoldAmt, float lowPolyAmt, out float hitOut) {
    // meshWarp/meshDistort/meshFold are real per-vertex distortions (see warpVertex(), applied
    // inside triHit() for every triangle test) rather than a ray-origin offset -- set once here as
    // plain globals since triHit() is called from many hundred deeply nested unrolled call sites
    // that were never going to be threaded extra parameters each. lowPolyAmt is set here too so its
    // vertex-snap half (see snapVertex) runs in the same pass. Ported from Pigeon Hole Mesh.
    gMeshWarpAmt = meshWarpAmt;
    gMeshDistortAmt = meshDistortAmt;
    gMeshFoldAmt = meshFoldAmt;
    gLowPolyAmt = lowPolyAmt;

    vec3 rd = normalize(forward + cuv.x * right + cuv.y * up);

    float yaw = radians(clamp(orientation.x, -180.0, 180.0)) + TIME * clamp(spinSpeed, 0.0, 2.0) * 0.3;
    float pitch = radians(clamp(orientation.y, -90.0, 90.0));
    mat3 yawM = mat3(cos(yaw), 0.0, -sin(yaw),  0.0, 1.0, 0.0,  sin(yaw), 0.0, cos(yaw));
    mat3 pitchM = mat3(1.0, 0.0, 0.0,  0.0, cos(pitch), sin(pitch),  0.0, -sin(pitch), cos(pitch));
    mat3 objRot = yawM * pitchM;
    vec3 pivot = vec3(0.0, sin(TIME * 0.8) * clamp(bobAmt, 0.0, 1.0) * 0.1, 0.0);

    // Inverse-ray transform (Pigeon Hole Mesh's technique): rather than transforming every baked
    // vertex by objRot/scale/pivot on every triHit call, transform the RAY once into the model's
    // fixed local frame and test it against the literal, untouched triangle data. For a rotation +
    // UNIFORM scale, this is exact: the intersection parameter t solved in local space is identical
    // to the real-world t (rescaling origin, direction, and the solved t by the same factor cancels
    // out algebraically), so bestT can be used directly in world space afterward with no correction.
    mat3 invRot = transpose(objRot); // exact inverse for an orthonormal rotation matrix
    float safeScale = max(scale, 0.001);
    vec3 lro = (invRot * (ro - pivot)) / safeScale;
    vec3 lrd = (invRot * rd) / safeScale;

    // SPEEN + wobble, ported from Pigeon Hole Mesh: bounded pendulum tumble on each axis plus a
    // small idle turn/tilt, applied as sequential local-space rotations on top of this template's
    // own yaw/pitch orientation matrix above (rather than folded into one combined matrix) -- keeps
    // modelOrientation/idleSpin's existing math untouched, and composes cleanly since these are all
    // just rotations applied to the same already-scaled local ray.
    float speenEnvC = clamp(speenEnv, 0.0, 1.0);
    float speenXVal = clamp(speenX, 0.0, 2.0);
    float speenYVal = clamp(speenY, 0.0, 2.0);
    float speenZVal = clamp(speenZ, 0.0, 2.0);
    float posNeg = (flipSpeen > 0.5) ? -1.0 : 1.0;
    float sx = pendulum(TIME, speenXVal) * speenEnvC * posNeg;
    float sy = pendulum(TIME * 1.1, speenYVal) * speenEnvC * posNeg;
    float sz = pendulum(TIME * 0.9, speenZVal) * speenEnvC * posNeg;
    float wobbleAmt = clamp(wobbleAmount, 0.0, 1.0);
    float wobbleYaw = sin(TIME * 0.7) * wobbleAmt * 0.22;
    float wobblePitch = sin(TIME * 0.55 + 1.7) * wobbleAmt * 0.16;

    vec3 sro = lro; vec3 srd = lrd;
    sro.xz = rot(-wobbleYaw) * sro.xz; srd.xz = rot(-wobbleYaw) * srd.xz;
    sro.xy = rot(-sz) * sro.xy;        srd.xy = rot(-sz) * srd.xy;
    sro.xz = rot(-sy) * sro.xz;        srd.xz = rot(-sy) * srd.xz;
    sro.yz = rot(-(sx + wobblePitch)) * sro.yz; srd.yz = rot(-(sx + wobblePitch)) * srd.yz;

    // mesh corruption: coarse screen-space cells jitter/rotate the local ray before it ever reaches
    // the mesh test, ported from Pigeon Hole Mesh -- corrupts the actual 3D geometry rather than
    // just shuffling the final 2D pixels the way the 2D CORRUPTION bank below does. Jitter is scaled
    // by 1/safeScale since this ray already lives in the model's inverse-scaled local space, where a
    // fixed local offset would read as a bigger jump the smaller modelScale is set.
    if (meshGlitchAmt > 0.001) {
        vec2 gCell = floor(cuv * meshGlitchRes);
        float gHash = hash(gCell.x * 13.1 + gCell.y * 7.3 + floor(TIME * 12.0));
        if (gHash > 1.0 - meshGlitchAmt) {
            vec3 jitter = vec3(hash(gHash + 1.0) - 0.5, hash(gHash + 2.0) - 0.5, hash(gHash + 3.0) - 0.5);
            sro += jitter * 0.18 / safeScale;
        }
    }
    if (meshTwistAmt > 0.001) {
        vec2 twCell = floor(cuv * meshGlitchRes);
        float twHash = hash(twCell.x * 19.3 + twCell.y * 5.9 + floor(TIME * 9.0));
        if (twHash > 1.0 - meshTwistAmt) {
            float twistAngle = (twHash - 0.5) * 6.283;
            sro.xy = rot(twistAngle) * sro.xy; srd.xy = rot(twistAngle) * srd.xy;
        }
    }

    // mirrorModel: some source .obj exports come in left/right-swapped from the reference art
    // (a true mirror -- e.g. a raised hand on the wrong side -- which no amount of yaw/pitch
    // rotation can ever fix, since a rotation preserves handedness and a mirror doesn't). Reflect
    // the local-space ray's X axis instead of touching the baked triangle data: testing the
    // ORIGINAL triangles against a reflected ray is mathematically equivalent to testing the
    // UNREFLECTED ray against mirrored geometry (reflections are linear, so this holds exactly,
    // same reasoning as the uniform-scale-ray trick above). Applied last, after SPEEN/wobble/mesh
    // corruption, matching this template's original ordering.
    vec3 mirrorAxis = vec3(mirrorAmt > 0.5 ? -1.0 : 1.0, 1.0, 1.0);
    vec3 mro = sro * mirrorAxis;
    vec3 mrd = srd * mirrorAxis;

    float bestT = 1e6;
    vec3 bestN = vec3(0.0);
    vec2 bestUV = vec2(0.0);
    float bestFacet = 0.0;
    float bestUseFlat = 0.0;
    vec3 bestFlatColor = vec3(0.0);

    bool hit = meshRayTest_RAT(mro, mrd, bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor);
    if (pizzaHit(mro, mrd, bestT, bestN, bestUV, bestFacet, bestUseFlat, bestFlatColor)) hit = true;

    vec3 bg = ratBackground(rd, style, bgSat, bgBright, bgIntensity, mediaAmt);
    // hitOut: lets renderMain mask screen-space effects (bgEcho) to background-only pixels, so they
    // can't paint over the model itself. Ported from Pigeon Hole Mesh.
    hitOut = hit ? 1.0 : 0.0;
    if (!hit) return bg;

    // Low-poly: blend toward the faceted normal rather than snapping, so the control sweeps
    // smoothly from the real mesh's shading into a flat-shaded one instead of popping between them.
    if (lowPolyAmt > 0.001) {
        bestN = normalize(mix(bestN, facetNormal(bestN), lowPolyAmt));
    }

    vec3 p = ro + rd * bestT;
    // Reverse the SPEEN/wobble rotations (same axes, opposite order, positive angles) then the
    // mirror, then the base orientation, to bring the locally-tested normal back into world space --
    // the exact inverse of the forward chain lro -> sro (SPEEN/wobble) -> mro (mirror) built above.
    vec3 nMirrored = bestN * mirrorAxis;
    nMirrored.yz = rot(sx + wobblePitch) * nMirrored.yz;
    nMirrored.xz = rot(sy) * nMirrored.xz;
    nMirrored.xy = rot(sz) * nMirrored.xy;
    nMirrored.xz = rot(wobbleYaw) * nMirrored.xz;
    vec3 worldN = normalize(objRot * nMirrored); // uniform scale doesn't change normal direction

    // No distance-fog blend toward the background here (an earlier version mixed a little bg into
    // every hit via `mix(shaded, bg, 1.0-exp(-bestT*0.05))`) -- at this scene's normal camera
    // distance that was already a real, visible ~15% background bleed on every pixel of the model,
    // which read as outright transparency once the background was a playing media clip instead of
    // the static gradient (reported directly: "slightly transparent when I play media behind").
    // This is a single nearby hero object, not an atmosphere shot that needs depth fog, so the fix
    // is to just not blend at all rather than tune the coefficient down.
    return shadeMeshHit(p, worldN, bestUV, bestFacet, bestUseFlat, bestFlatColor, rd, style, sat, bright, facetAmt);
}

vec4 renderMain() {
    vec2 uv = _uvc;

    float scale = clamp(modelScale, 0.1, 5.0);
    float mirrorAmt = mirrorModel;
    float style = shadeStyle;
    float sat = clamp(meshColors.x, 0.5, 3.0);
    float bright = clamp(meshColors.y, 0.5, 3.0);
    float facetAmt = clamp(facetShading, 0.0, 1.0);
    float bgSat = clamp(backgroundColors.x, 0.3, 3.0);
    float bgBright = clamp(backgroundColors.y, 0.1, 2.0);
    float bgIntensity = clamp(backgroundIntensity, 0.0, 2.0);
    float mediaAmt = clamp(backgroundMediaAmount, 0.0, 1.0);

    // resetModel: an obvious "panic button" pad -- snaps every 3D corruption amount to 0 instantly
    // (fast-attack envelope in script.js) and eases them back over about a second, regardless of
    // where their sliders are sitting. Ported from Pigeon Hole Mesh.
    float resetSuppress = 1.0 - clamp(resetModelEnv, 0.0, 1.0);
    float meshGlitchAmt = clamp(meshGlitch, 0.0, 1.0) * (0.3 + syn_BassHits * 1.7) * resetSuppress;
    float meshGlitchRes = clamp(meshGlitchResolution, 2.0, 24.0);
    float meshTwistAmt = clamp(meshTwist, 0.0, 1.0) * (0.3 + syn_BassHits * 1.7) * resetSuppress;
    float meshWarpAmt = clamp(meshWarp, 0.0, 1.0) * (0.3 + syn_BassHits * 1.7) * resetSuppress;
    // meshDistort is a continuous, full-mesh twist (not a probabilistic per-cell trigger like
    // meshGlitch/meshTwist), so the same 0.3-2.0x audio swing those use reads as way too violent
    // here -- toned down to a much gentler hit boost.
    float meshDistortAmt = clamp(meshDistort, 0.0, 1.0) * (0.85 + syn_BassHits * 0.3) * resetSuppress;
    float meshFoldAmt = clamp(meshFold, 0.0, 1.0) * (0.3 + syn_BassHits * 1.7) * resetSuppress;
    // Single low-poly control -- facet coarseness AND vertex-snap grid are both fixed constants
    // (LOW_POLY_FACETS, snapVertex) pushed toward N64/PS1-era chunkiness rather than tunable
    // sliders. lowPolyReactivity adds bass hits on top of the base slider.
    float lowPolyAmt = clamp(lowPolyAmount + clamp(lowPolyReactivity, 0.0, 1.0) * syn_BassHits, 0.0, 1.0);

    // CORRUPTION envelopes (smoothed in script.js from bang pads)
    float shatterAmt = clamp(shatterEnv, 0.0, 1.0);
    float blockGlitchAmt = clamp(blockGlitchEnv, 0.0, 1.0);
    float shiftAmt = clamp(shiftEnv, 0.0, 1.0);
    float rgbSplitAmt = clamp(rgbShiftEnv, 0.0, 1.0);
    float pixelSortAmt = clamp(pixelSort, 0.0, 0.2);
    float scanlineAmt = clamp(scanlines, 0.0, 2.0);
    float blockGlitchSlider = clamp(blockGlitchAmount, 0.0, 1.0);
    float screenShakeSlider = clamp(screenShake, 0.0, 1.0);
    float rgbSplitSlider = clamp(rgbSplitAmount, 0.0, 1.0);
    float audioBassCorrupt = syn_BassHits;
    float audioMidCorrupt = syn_MidHighHits;

    vec2 workingUV = uv;

    // Kaleidoscope, ported from Metal Shader (via Pigeon Hole Mesh): wraps the angle around the
    // frame center into `kaleidoSegments` repeating wedges.
    if (kaleidoscope > 0.5) {
        float kSeg = clamp(kaleidoSegments, 2.0, 16.0);
        float kAngle = atan(workingUV.y, workingUV.x);
        float kSegAngle = 6.28318530718 / kSeg;
        kAngle = mod(kAngle, kSegAngle);
        float kRadius = length(workingUV);
        workingUV = vec2(cos(kAngle), sin(kAngle)) * kRadius;
    }

    // zoomPunch: a quick impact zoom-in pulse (envelope smoothed in script.js, no hard cut).
    float zoomPunchAmt = clamp(zoomPunchEnv, 0.0, 1.0);
    if (zoomPunchAmt > 0.001) {
        workingUV *= 1.0 - zoomPunchAmt * 0.35;
    }

    if (shatterAmt > 0.01) {
        vec2 shardCoord = floor(workingUV * 8.0);
        float shardHash = hash(shardCoord.x * 10.0 + shardCoord.y + floor(TIME * 0.5));
        float shardAngle = shardHash * 6.28 * shatterAmt;
        float shardDist = (shardHash - 0.5) * 0.4 * shatterAmt;
        vec2 shardCenter = (shardCoord + 0.5) / 8.0;
        vec2 toCenter = workingUV - shardCenter;
        toCenter = rot(shardAngle) * toCenter;
        toCenter += vec2(cos(shardHash * 6.28), sin(shardHash * 6.28)) * shardDist;
        workingUV = shardCenter + toCenter;
        vec2 shardEdge = fract(workingUV * 8.0);
        float edgeDist = min(min(shardEdge.x, 1.0 - shardEdge.x), min(shardEdge.y, 1.0 - shardEdge.y));
        if (edgeDist < 0.05 * shatterAmt) {
            workingUV += vec2(hash(shardHash + 10.0) - 0.5, hash(shardHash + 20.0) - 0.5) * 0.1;
        }
    }

    float totalShake = shiftAmt + screenShakeSlider * audioBassCorrupt;
    if (totalShake > 0.01) {
        float shakeX = (hash(floor(TIME * 10.0)) - 0.5) * totalShake * 0.3;
        float shakeY = (hash(floor(TIME * 10.0) + 1.0) - 0.5) * totalShake * 0.2;
        workingUV += vec2(shakeX, shakeY);
    }

    float totalPixelSort = pixelSortAmt + pixelSortAmt * audioMidCorrupt * 2.0;
    if (totalPixelSort > 0.001) {
        float sortCols = clamp(pixelSortWidth, 2.0, 60.0);
        float sortLine = floor(workingUV.x * sortCols);
        float sortShift = hash(sortLine + floor(TIME * 5.0)) * totalPixelSort * 2.0;
        workingUV.y += sortShift;
    }

    float totalBlockGlitch = max(blockGlitchAmt, blockGlitchSlider * audioBassCorrupt);
    if (totalBlockGlitch > 0.01) {
        vec2 blockCoord = floor(workingUV * 12.0);
        float blockHash = hash(blockCoord.x + blockCoord.y * 10.0 + floor(TIME * 3.0));
        if (blockHash > (0.85 - totalBlockGlitch * 0.3)) {
            vec2 offset = vec2(hash(blockHash) - 0.5, hash(blockHash + 1.0) - 0.5) * 0.4 * totalBlockGlitch;
            workingUV += offset;
        }
    }

    // ----- camera -----
    // Click-drag orbit camera, ported from Synesthesia's own "3D Orbit Camera" example scene
    // (3d_orbit_camera_dup.synScene) -- camOrbit.xy/camDistance are computed in script.js from
    // mouse drag (with momentum decay), the view-preset bangs, or an idle auto-rotate; this file
    // just consumes the result the same way that example scene's main.glsl consumes cam_xy/cam_zoom.
    float camYaw = camOrbit.x;
    float camPitch = clamp(camOrbit.y, -1.5, 1.5);
    float camDist = clamp(camDistance, 0.5, 12.0);

    vec3 ro = vec3(0.0, 0.0, -camDist);
    ro.yz = rot(camPitch) * ro.yz;
    ro.xz = rot(camYaw) * ro.xz;

    vec3 lookAt = vec3(0.0, 0.0, 0.0);
    vec3 forward = normalize(lookAt - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);

    float totalRGBSplit = rgbSplitAmt + rgbSplitSlider * audioBassCorrupt;
    vec3 col;
    // hitMask: 1 where the model was actually hit, 0 on background -- lets bgEcho below mask itself
    // to background-only pixels instead of painting over the model. Captured from the G channel (no
    // split offset) as the representative mask, same simplification Pigeon Hole Mesh makes.
    float hitMask;

    if (totalRGBSplit > 0.01) {
        float splitOffset = totalRGBSplit * 0.015;
        float hitR, hitB;
        float colR = renderChannel(workingUV + vec2(splitOffset, 0.0), ro, forward, right, up, scale, modelOrientation, idleSpin, bobAmount, mirrorAmt, style, sat, bright, facetAmt, bgSat, bgBright, bgIntensity, mediaAmt, meshGlitchAmt, meshGlitchRes, meshTwistAmt, meshWarpAmt, meshDistortAmt, meshFoldAmt, lowPolyAmt, hitR).r;
        float colG = renderChannel(workingUV, ro, forward, right, up, scale, modelOrientation, idleSpin, bobAmount, mirrorAmt, style, sat, bright, facetAmt, bgSat, bgBright, bgIntensity, mediaAmt, meshGlitchAmt, meshGlitchRes, meshTwistAmt, meshWarpAmt, meshDistortAmt, meshFoldAmt, lowPolyAmt, hitMask).g;
        float colB = renderChannel(workingUV - vec2(splitOffset, 0.0), ro, forward, right, up, scale, modelOrientation, idleSpin, bobAmount, mirrorAmt, style, sat, bright, facetAmt, bgSat, bgBright, bgIntensity, mediaAmt, meshGlitchAmt, meshGlitchRes, meshTwistAmt, meshWarpAmt, meshDistortAmt, meshFoldAmt, lowPolyAmt, hitB).b;
        col = vec3(colR, colG, colB);
    } else {
        col = renderChannel(workingUV, ro, forward, right, up, scale, modelOrientation, idleSpin, bobAmount, mirrorAmt, style, sat, bright, facetAmt, bgSat, bgBright, bgIntensity, mediaAmt, meshGlitchAmt, meshGlitchRes, meshTwistAmt, meshWarpAmt, meshDistortAmt, meshFoldAmt, lowPolyAmt, hitMask);
    }

    if (scanlineAmt > 0.01) {
        float scanline = sin(uv.y * RENDERSIZE.y * 2.0) * 0.5 + 0.5;
        col *= 1.0 - (scanline * scanlineAmt * 0.4);
    }

    if (shatterAmt > 0.01) {
        vec2 shardEdge = fract(uv * 8.0);
        float edgeDist = min(min(shardEdge.x, 1.0 - shardEdge.x), min(shardEdge.y, 1.0 - shardEdge.y));
        if (edgeDist < 0.03) col *= 1.0 - shatterAmt * 0.5;
    }

    // Neon Blue/Red's red laser-grid overlay, ported from Pigeon Hole Mesh -- screen-space grid
    // lines drawn over the final image, gated to the Neon style only.
    if (style >= 1.5) {
        vec2 guv = uv;
        float lineX = min(abs(fract(guv.x * 1.5) - 0.5), abs(fract(guv.x * 1.5 + 0.5) - 0.5));
        float lineY = min(abs(fract(guv.y * 1.5) - 0.5), abs(fract(guv.y * 1.5 + 0.5) - 0.5));
        float grid = 1.0 - smoothstep(0.0, 0.0025, min(lineX, lineY));
        vec3 gridCol = vec3(1.0, 0.08, 0.08) * grid * 0.35 * bgIntensity;
        col += gridCol * (0.5 + 0.5 * syn_BassLevel);
    }

    // invert: quick color-inversion pulse (envelope smoothed in script.js -- a color-space flip,
    // not a brightness flash, so it doesn't run into the seizure-flashing concern a strobe would).
    float invertAmt = clamp(invertEnv, 0.0, 1.0);
    if (invertAmt > 0.001) {
        col = mix(col, 1.0 - col, invertAmt);
    }

    // afterimage/feedback trail -- off by default. Classic phosphor-persistence mix (a convex
    // combination structurally can't exceed the brighter input, stable at any setting), not
    // screenBlend, which still creeps toward white over many frames of sustained feedback even
    // though it's bounded per-call. Ported from Pigeon Hole Mesh.
    float trailAmt = clamp(feedbackAmount, 0.0, 0.97) * (1.0 + syn_BassHits * 0.15);
    trailAmt = min(trailAmt, 0.985);
    if (trailAmt > 0.001) {
        vec3 prevCol = texture2D(syn_FinalPass, _uv).rgb;
        col = mix(col, prevCol, trailAmt);
    }

    // Repeating echo trail -- one small zoom + rotation + kaleido-fold applied to syn_FinalPass each
    // frame, left to compound over many frames into nested receding copies (rather than trying to
    // fake multiple copies out of one frame, which just reads as blur). Ported from Pigeon Hole Mesh.
    float echoAmt = clamp(bgEchoAmount, 0.0, 2.0);
    if (echoAmt > 0.001) {
        vec2 base = _uv - 0.5;
        float zoom = mix(1.0, 0.965, clamp(echoAmt * 0.5, 0.0, 1.0));
        vec2 sp = base * zoom;
        sp = rot(TIME * 0.06) * sp;
        float ang = atan(sp.y, sp.x);
        float r = length(sp);
        float segAngle = 6.28318 / 5.0;
        ang = mod(ang, segAngle);
        if (ang > segAngle * 0.5) ang = segAngle - ang;
        sp = vec2(cos(ang), sin(ang)) * r;
        vec2 sampleUV = clamp(sp + 0.5, 0.0, 1.0);
        vec3 echoSample = texture2D(syn_FinalPass, sampleUV).rgb;
        // Masked to background-only pixels (hitMask==0) so it can't blend over the model itself.
        float echoBlend = clamp(echoAmt * (0.5 + syn_BassHits * 0.2), 0.0, 1.0) * (1.0 - hitMask);
        col = mix(col, echoSample, echoBlend);
    }

    // edgeDetect/Highlight: real silhouette + depth signal from silhouetteProbe() (hit/miss flips
    // and depth jumps between real hits), not a Sobel filter on final-pixel luminance -- luminance
    // can't tell a true silhouette from two neighboring flat-shaded facets with different normals.
    // Ported from Pigeon Hole Mesh.
    float edgeAmt = clamp(edgeDetectAmount, 0.0, 1.0);
    if (edgeAmt > 0.001) {
        float pixelStep = 1.3 / RENDERSIZE.y;
        float tC, tL, tR, tU, tD;
        float hC = silhouetteProbe(workingUV, ro, forward, right, up, tC);
        float hL = silhouetteProbe(workingUV + vec2(-pixelStep, 0.0), ro, forward, right, up, tL);
        float hR = silhouetteProbe(workingUV + vec2(pixelStep, 0.0), ro, forward, right, up, tR);
        float hU = silhouetteProbe(workingUV + vec2(0.0, pixelStep), ro, forward, right, up, tU);
        float hD = silhouetteProbe(workingUV + vec2(0.0, -pixelStep), ro, forward, right, up, tD);

        float hitEdge = abs(hC - hL) + abs(hC - hR) + abs(hC - hU) + abs(hC - hD);

        float depthEdge = 0.0;
        if (hC > 0.5 && hL > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tL));
        if (hC > 0.5 && hR > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tR));
        if (hC > 0.5 && hU > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tU));
        if (hC > 0.5 && hD > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tD));

        float edge = clamp(hitEdge + depthEdge * 0.5, 0.0, 1.0);
        vec3 edgeColor = vec3(0.3, 1.0, 0.9);
        col = mix(col, col + edgeColor * edge, edgeAmt);
    }

    // streak: a directional light-trail/comet smear, distinct from bgEcho's radial kaleidoscope
    // spiral -- a linear smear along a slowly-rotating direction instead. Whole-frame (not masked
    // to background) since dragging the model's own motion/color is the point. Ported from Pigeon
    // Hole Mesh.
    float streakAmt = clamp(streakAmount, 0.0, 1.0);
    if (streakAmt > 0.001) {
        float streakAngle = TIME * 0.15;
        vec2 streakDir = vec2(cos(streakAngle), sin(streakAngle));
        vec2 streakUV = clamp(_uv - streakDir * streakAmt * 0.02, 0.0, 1.0);
        vec3 streakSample = texture2D(syn_FinalPass, streakUV).rgb;
        col = mix(col, streakSample, streakAmt * (0.5 + syn_BassHits * 0.2));
    }

    return vec4(col, 1.0);
}
