// RedVox Rat -- Script v2
// Click-drag orbit camera, ported from Synesthesia's own "3D Orbit Camera" example scene
// (3d_orbit_camera_dup.synScene) -- same LastClick/Smooth3 pattern (smoothed drag with momentum
// decay on release), adapted from that scene's cam_xy/cam_zoom to this template's
// camOrbit/camDistance, plus an idle auto-rotate that immediately yields to manual dragging.
// v2 adds controls ported from Pigeon Hole Mesh: SPEEN/CORRUPTION bang pads get a script.js
// attack/decay envelope (per synesthesia-prefs: bang pads always get an envelope, not native
// "bang smooth"), and the 7 camera view-preset bangs drive this scene's own camOrbit/camDistance
// goal directly rather than the separate viewYaw/viewPitch pair Pigeon Hole Mesh uses, since this
// template's camera was already a single self-contained orbit (cam.x/cam.y/cam.z below).

function LastClick() {
    this.x = -100
    this.y = -100
}
LastClick.prototype.click = function() {
    this.x = _muvc.x
    this.y = _muvc.y
}
LastClick.prototype.release = function() {
    this.x = -100
    this.y = -100
}
var last_clickL = new LastClick()
var last_clickR = new LastClick()

// generic smoothed x/y/z, same interface as the reference scene's Smooth3
function Smooth3() {
    this.x = 0; this.y = 0; this.z = 0
    this.goal_x = 0; this.goal_y = 0; this.goal_z = 0
}
Smooth3.prototype.instant = function(x, y, z) {
    this.x = x; this.y = y; this.z = z
    this.goal_x = x; this.goal_y = y; this.goal_z = z
}
// Sets the goal only (current value eases toward it via tick() below) -- unlike instant(), which
// also snaps the current value. Fixes a real bug found while porting the view bangs in: the
// previous version of this file called cam.smooth(...) every frame but never defined this method,
// so every frame the camera wasn't actively being dragged or auto-rotated threw a silent JS error
// and skipped the "track manual panel edits" branch entirely.
Smooth3.prototype.smooth = function(x, y, z) {
    this.goal_x = x; this.goal_y = y; this.goal_z = z
}
Smooth3.prototype.tick = function() {
    this.x += (this.goal_x - this.x) * 0.5
    this.y += (this.goal_y - this.y) * 0.5
    this.z += (this.goal_z - this.z) * 0.5
}

var cam = new Smooth3()
uniforms.cam = cam

var deltaL = {x: 0, y: 0}
var deltaR = {x: 0, y: 0}
var drag_timeout = 0

// ---- CORRUPTION / SPEEN bang envelopes, ported from Pigeon Hole Mesh ----
var _speenEnv = 0.0
var _shatterEnv = 0.0
var _blockGlitchEnv = 0.0
var _shiftEnv = 0.0
var _rgbShiftEnv = 0.0
var _resetModelEnv = 0.0
var _invertEnv = 0.0
var _zoomPunchEnv = 0.0

var attackRate = 50.0
var decayRate = 0.8

function envelope(current, target, dt) {
    if (target > current) {
        current += attackRate * dt
        if (current > 1.0) current = 1.0
    } else {
        current -= decayRate * dt
        if (current < 0.0) current = 0.0
    }
    return current
}

// ---- camera view-preset bangs, ported from Pigeon Hole Mesh ----
// Redirect this scene's own orbit-camera goal toward a preset angle instead of the separate
// viewYaw/viewPitch pair that scene uses -- cam.tick()'s existing exponential ease (x += (goal-x)*
// 0.5 per frame) already gives a smooth, non-snapping transition, so no extra easing scheme is
// needed here.
var _prevViewFront = 0.0, _prevViewBack = 0.0, _prevViewLeft = 0.0, _prevViewRight = 0.0
var _prevViewTop = 0.0, _prevViewBottom = 0.0, _prevViewPerspective = 0.0
// Explicit "a view bang is actively easing" countdown, in frames -- NOT inferred from how far
// goal is from current. An earlier version used |goal-current| > 0.002 as that signal, which was
// a real bug: the "track manual panel edits" branch below recomputes goal every single frame as a
// blend weighted 95% toward cam.x itself, so goal and current are NEVER exactly equal -- typing a
// new number into camOrbit changes cam.smooth()'s input for one frame, leaves a real (if small)
// goal/current gap, and that gap alone was enough to trip the old heuristic and call setControl()
// right back over the typed value with the barely-moved internal cam.x -- reported directly as
// "camOrbit keeps homing when trying to adjust numbers." A plain countdown set only by an actual
// bang press can't be triggered by an ordinary panel edit.
var viewBangFrames = 0
var VIEW_BANG_SETTLE_FRAMES = 15

function risingEdge(val, prevVal) {
    return val > 0.5 && prevVal <= 0.5
}

// picks whichever of target, target+-2*PI lands closest to current, so the eased yaw takes the
// short way around the circle instead of potentially spinning the long way
function nearestYaw(current, target) {
    var twoPi = Math.PI * 2.0
    var diff = (target - current) % twoPi
    if (diff > Math.PI) diff -= twoPi
    if (diff < -Math.PI) diff += twoPi
    return current + diff
}

function setup() {
    // copy the panel's default camOrbit/camDistance so script and panel agree on the starting view
    cam.instant(camOrbit.x, camOrbit.y, camDistance)
    setUniform('speenEnv', 0.0)
    setUniform('shatterEnv', 0.0)
    setUniform('blockGlitchEnv', 0.0)
    setUniform('shiftEnv', 0.0)
    setUniform('rgbShiftEnv', 0.0)
    setUniform('resetModelEnv', 0.0)
    setUniform('invertEnv', 0.0)
    setUniform('zoomPunchEnv', 0.0)
}

function update(dt) {
    var clickL = _click.x > 0.5
    var clickR = _click.y > 0.5

    // LEFT CLICK drag -> orbit (yaw/pitch)
    if (clickL && last_clickL.x < -50) last_clickL.click()
    else if (!clickL && last_clickL.x > -50) last_clickL.release()
    if (clickL) {
        deltaL.x = _muvc.x - last_clickL.x
        deltaL.y = _muvc.y - last_clickL.y
    } else if (deltaL.x != 0 || deltaL.y != 0) {
        // momentum decay on release, same as the reference scene
        deltaL.x *= 0.95
        deltaL.y *= 0.95
        if (Math.abs(deltaL.x) < 0.01) deltaL.x = 0
        if (Math.abs(deltaL.y) < 0.01) deltaL.y = 0
    }
    cam.goal_x += deltaL.x * 0.08
    cam.goal_y += deltaL.y * 0.08

    // RIGHT CLICK drag (vertical) -> distance/zoom
    if (clickR && last_clickR.x < -50) last_clickR.click()
    else if (!clickR && last_clickR.x > -50) last_clickR.release()
    if (clickR) {
        deltaR.y = _muvc.y - last_clickR.y
    } else if (deltaR.y != 0) {
        deltaR.y *= 0.95
        if (Math.abs(deltaR.y) < 0.01) deltaR.y = 0
    }
    cam.goal_z += deltaR.y * 3.0

    // view bangs: on rising edge, redirect the orbit goal toward a preset angle. Top/Bottom only
    // change pitch, keeping whatever yaw was last active, since a level-to-overhead tilt shouldn't
    // also spin the camera around.
    if (risingEdge(viewFrontBang, _prevViewFront)) { cam.goal_x = nearestYaw(cam.x, 0.0); viewBangFrames = VIEW_BANG_SETTLE_FRAMES }
    if (risingEdge(viewBackBang, _prevViewBack)) { cam.goal_x = nearestYaw(cam.x, Math.PI); viewBangFrames = VIEW_BANG_SETTLE_FRAMES }
    if (risingEdge(viewLeftBang, _prevViewLeft)) { cam.goal_x = nearestYaw(cam.x, Math.PI * 0.5); viewBangFrames = VIEW_BANG_SETTLE_FRAMES }
    if (risingEdge(viewRightBang, _prevViewRight)) { cam.goal_x = nearestYaw(cam.x, -Math.PI * 0.5); viewBangFrames = VIEW_BANG_SETTLE_FRAMES }
    if (risingEdge(viewTopBang, _prevViewTop)) { cam.goal_y = 1.4; viewBangFrames = VIEW_BANG_SETTLE_FRAMES }
    if (risingEdge(viewBottomBang, _prevViewBottom)) { cam.goal_y = -1.4; viewBangFrames = VIEW_BANG_SETTLE_FRAMES }
    if (risingEdge(viewPerspectiveBang, _prevViewPerspective)) {
        cam.goal_x = nearestYaw(cam.x, Math.PI * 0.25)
        cam.goal_y = 0.45
        viewBangFrames = VIEW_BANG_SETTLE_FRAMES
    }
    _prevViewFront = viewFrontBang; _prevViewBack = viewBackBang
    _prevViewLeft = viewLeftBang; _prevViewRight = viewRightBang
    _prevViewTop = viewTopBang; _prevViewBottom = viewBottomBang
    _prevViewPerspective = viewPerspectiveBang

    // wrap yaw -PI..PI once the smoothed value actually crosses (keeps goal in sync so the
    // wrap doesn't visibly snap), clamp pitch short of the poles, clamp distance to a sane range
    if (cam.x < -Math.PI) { cam.x += 2 * Math.PI; cam.goal_x += 2 * Math.PI }
    if (cam.x > Math.PI) { cam.x -= 2 * Math.PI; cam.goal_x -= 2 * Math.PI }
    cam.goal_y = Math.min(Math.max(cam.goal_y, -1.5), 1.5)
    cam.goal_z = Math.min(Math.max(cam.goal_z, 0.5), 12.0)

    // Figure out whether the mouse, a view bang, or the control panel is currently driving the
    // camera. setControl() must NOT be called unconditionally every frame -- it fights Synesthesia's
    // own handling of that control outside an active drag/ease/auto-rotate (reported directly in an
    // earlier version of this file as "cam orbit and cam distance are broken"). A view bang counts
    // as "driving" for a fixed settle window after the press (viewBangFrames, an explicit countdown
    // -- see its declaration above for why a goal/current-distance heuristic doesn't work here),
    // same idea as the drag momentum tail.
    var dragging = deltaL.x != 0 || deltaL.y != 0 || deltaR.y != 0
    if (dragging) drag_timeout = 20
    if (drag_timeout > 0 || viewBangFrames > 0) {
        if (!dragging && drag_timeout > 0) drag_timeout--
        if (viewBangFrames > 0) viewBangFrames--
        setControl('camOrbit', [cam.x, cam.y])
        setControl('camDistance', cam.z)
    } else if (autoCamera > 0.5) {
        cam.goal_x += autoCameraSpeed * dt * 0.3
        setControl('camOrbit', [cam.x, cam.y])
        setControl('camDistance', cam.z)
    } else {
        cam.smooth(
            (inputs.camOrbit.x + cam.x * 19) / 20,
            (inputs.camOrbit.y + cam.y * 19) / 20,
            (inputs.camDistance + cam.z * 19) / 20
        )
    }
    cam.tick()

    _speenEnv = envelope(_speenEnv, speenBang, dt)
    _shatterEnv = envelope(_shatterEnv, shatterBang, dt)
    _blockGlitchEnv = envelope(_blockGlitchEnv, blockGlitchBang, dt)
    _shiftEnv = envelope(_shiftEnv, shiftBang, dt)
    _rgbShiftEnv = envelope(_rgbShiftEnv, rgbShiftBang, dt)
    // resetModel: an obvious "panic button" -- fast attack snaps this to 1 almost instantly on the
    // bang, main.glsl uses (1 - resetModelEnv) to suppress every 3D corruption amount to 0 right
    // then, and the same decay rate eases corruption back in over about a second afterward.
    _resetModelEnv = envelope(_resetModelEnv, resetModelBang, dt)
    _invertEnv = envelope(_invertEnv, invertBang, dt)
    _zoomPunchEnv = envelope(_zoomPunchEnv, zoomPunchBang, dt)

    setUniform('speenEnv', _speenEnv)
    setUniform('shatterEnv', _shatterEnv)
    setUniform('blockGlitchEnv', _blockGlitchEnv)
    setUniform('shiftEnv', _shiftEnv)
    setUniform('rgbShiftEnv', _rgbShiftEnv)
    setUniform('resetModelEnv', _resetModelEnv)
    setUniform('invertEnv', _invertEnv)
    setUniform('zoomPunchEnv', _zoomPunchEnv)
}
