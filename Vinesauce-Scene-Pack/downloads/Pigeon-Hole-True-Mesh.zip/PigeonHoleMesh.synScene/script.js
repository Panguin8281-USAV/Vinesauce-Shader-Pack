// Pigeon Hole — True Mesh — Script v1
// Smooths the CORRUPTION bang pads into attack/decay envelopes (bang + script.js envelope,
// not native "bang smooth", for full control over the attack/decay shape).

var _shatterEnv = 0.0;
var _blockGlitchEnv = 0.0;
var _shiftEnv = 0.0;
var _rgbShiftEnv = 0.0;
var _resetModelEnv = 0.0;
var _invertEnv = 0.0;
var _zoomPunchEnv = 0.0;

var attackRate = 50.0;
var decayRate = 0.8;

function envelope(current, target, dt) {
    if (target > current) {
        current += attackRate * dt;
        if (current > 1.0) current = 1.0;
    } else {
        current -= decayRate * dt;
        if (current < 0.0) current = 0.0;
    }
    return current;
}

// View bangs (Front/Back/Left/Right/Top/Bottom/Perspective) smoothly orbit the camera to a preset
// angle instead of snapping -- an ease-toward-target each frame (ease rate below), with yaw taking
// the shortest path around the circle rather than always spinning the same direction. Top/Bottom
// only change pitch, keeping whatever yaw (facing) was last active, since a level-to-overhead tilt
// shouldn't also spin the camera around.
var _prevViewFront = 0.0, _prevViewBack = 0.0, _prevViewLeft = 0.0, _prevViewRight = 0.0;
var _prevViewTop = 0.0, _prevViewBottom = 0.0, _prevViewPerspective = 0.0;
var _viewYaw = 0.0, _viewPitch = 0.0;
var _targetYaw = 0.0, _targetPitch = 0.0;
var viewEaseRate = 3.5;

// Left-click-drag orbit, ported from Synesthesia's own 3D Orbit Camera example scene (_click/_muvc
// are real Synesthesia globals confirmed directly from that scene's shipped script.js). Drag moves
// the camera 1:1 with the mouse in real time -- the slow ease above is right for a cinematic bang
// transition, but would just read as laggy for direct dragging, so while a drag is active this
// updates _viewYaw/_viewPitch immediately and keeps _targetYaw/_targetPitch in sync so releasing
// the mouse doesn't spring the view back to wherever a bang last pointed it.
var _dragging = false;
var _prevClickL = false;
var _lastMouseX = 0.0, _lastMouseY = 0.0;
var dragSensitivity = 2.4;

// Right-click-drag zoom -- same reference scene has this on its right-click, but that version
// drives zoom as an ongoing rate proportional to distance from the click point (a joystick feel:
// hold the mouse away from where you clicked and it keeps zooming even without moving further).
// Kept the left-drag orbit above 1:1 with mouse position instead (matches how virtually every 3D
// tool's orbit-drag behaves), so this zoom-drag matches that same feel for consistency rather than
// copying the joystick style: it's a direct position delta, with a short momentum decay after
// release as the one deliberate carryover from the reference (a nice touch worth keeping).
var _prevClickR = false;
var _lastMouseYR = 0.0;
var _zoomDrag = 0.0;
var _zoomVel = 0.0;
var zoomDragSensitivity = 4.0;
var zoomMomentumDecay = 0.9;

function risingEdge(val, prevVal) {
    return val > 0.5 && prevVal <= 0.5;
}

function angleLerp(current, target, rate, dt) {
    var twoPi = Math.PI * 2.0;
    var diff = (target - current) % twoPi;
    if (diff > Math.PI) diff -= twoPi;
    if (diff < -Math.PI) diff += twoPi;
    return current + diff * Math.min(1.0, rate * dt);
}

function setup() {
    setUniform('shatterEnv', 0.0);
    setUniform('blockGlitchEnv', 0.0);
    setUniform('shiftEnv', 0.0);
    setUniform('rgbShiftEnv', 0.0);
    setUniform('resetModelEnv', 0.0);
    setUniform('invertEnv', 0.0);
    setUniform('zoomPunchEnv', 0.0);
    setUniform('viewYaw', 0.0);
    setUniform('viewPitch', 0.0);
    setUniform('zoomDrag', 0.0);
    console.log('[Pigeon Hole True Mesh v1] Script loaded OK');
}

function update(dt) {
    _shatterEnv = envelope(_shatterEnv, shatterBang, dt);
    _blockGlitchEnv = envelope(_blockGlitchEnv, blockGlitchBang, dt);
    _shiftEnv = envelope(_shiftEnv, shiftBang, dt);
    _rgbShiftEnv = envelope(_rgbShiftEnv, rgbShiftBang, dt);
    // resetModel: an obvious "panic button" -- fast attack snaps this to 1 almost instantly on the
    // bang, main.glsl uses (1 - resetModelEnv) to suppress every 3D corruption amount to 0 right
    // then, and the same decay rate eases corruption back in over about a second afterward.
    _resetModelEnv = envelope(_resetModelEnv, resetModelBang, dt);
    _invertEnv = envelope(_invertEnv, invertBang, dt);
    _zoomPunchEnv = envelope(_zoomPunchEnv, zoomPunchBang, dt);

    if (risingEdge(viewFrontBang, _prevViewFront)) { _targetYaw = 0.0; _targetPitch = 0.0; }
    if (risingEdge(viewBackBang, _prevViewBack)) { _targetYaw = Math.PI; _targetPitch = 0.0; }
    if (risingEdge(viewLeftBang, _prevViewLeft)) { _targetYaw = Math.PI * 0.5; _targetPitch = 0.0; }
    if (risingEdge(viewRightBang, _prevViewRight)) { _targetYaw = -Math.PI * 0.5; _targetPitch = 0.0; }
    if (risingEdge(viewTopBang, _prevViewTop)) { _targetPitch = 1.4; }
    if (risingEdge(viewBottomBang, _prevViewBottom)) { _targetPitch = -1.4; }
    if (risingEdge(viewPerspectiveBang, _prevViewPerspective)) { _targetYaw = Math.PI * 0.25; _targetPitch = 0.45; }
    _prevViewFront = viewFrontBang; _prevViewBack = viewBackBang;
    _prevViewLeft = viewLeftBang; _prevViewRight = viewRightBang;
    _prevViewTop = viewTopBang; _prevViewBottom = viewBottomBang;
    _prevViewPerspective = viewPerspectiveBang;

    var clickL = _click.x > 0.5;
    if (clickL && !_prevClickL) {
        _lastMouseX = _muvc.x;
        _lastMouseY = _muvc.y;
    }
    if (clickL) {
        var dx = _muvc.x - _lastMouseX;
        var dy = _muvc.y - _lastMouseY;
        _lastMouseX = _muvc.x;
        _lastMouseY = _muvc.y;
        _viewYaw -= dx * dragSensitivity;
        _viewPitch = Math.max(-1.4, Math.min(1.4, _viewPitch + dy * dragSensitivity));
        _targetYaw = _viewYaw;
        _targetPitch = _viewPitch;
        _dragging = true;
    } else {
        _dragging = false;
    }
    _prevClickL = clickL;

    // bangs (and idle rest) still ease smoothly; an active drag already set the view directly above
    if (!_dragging) {
        _viewYaw = angleLerp(_viewYaw, _targetYaw, viewEaseRate, dt);
        _viewPitch += (_targetPitch - _viewPitch) * Math.min(1.0, viewEaseRate * dt);
    }

    var clickR = _click.y > 0.5;
    if (clickR && !_prevClickR) {
        _lastMouseYR = _muvc.y;
    }
    if (clickR) {
        var dyR = _muvc.y - _lastMouseYR;
        _lastMouseYR = _muvc.y;
        _zoomVel = dyR * zoomDragSensitivity;
        _zoomDrag += _zoomVel;
    } else if (_zoomVel !== 0.0) {
        _zoomDrag += _zoomVel;
        _zoomVel *= zoomMomentumDecay;
        if (Math.abs(_zoomVel) < 0.0008) _zoomVel = 0.0;
    }
    _prevClickR = clickR;
    _zoomDrag = Math.max(-3.0, Math.min(3.0, _zoomDrag));

    setUniform('shatterEnv', _shatterEnv);
    setUniform('blockGlitchEnv', _blockGlitchEnv);
    setUniform('shiftEnv', _shiftEnv);
    setUniform('rgbShiftEnv', _rgbShiftEnv);
    setUniform('resetModelEnv', _resetModelEnv);
    setUniform('invertEnv', _invertEnv);
    setUniform('zoomPunchEnv', _zoomPunchEnv);
    setUniform('viewYaw', _viewYaw);
    setUniform('viewPitch', _viewPitch);
    setUniform('zoomDrag', _zoomDrag);
}
