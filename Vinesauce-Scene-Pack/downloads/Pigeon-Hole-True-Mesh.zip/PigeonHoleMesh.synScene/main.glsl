// Pigeon Hole — True Mesh — for RedVox
// The actual reference model, not an SDF approximation. Synesthesia scenes are fragment shaders with
// no rasterizer/mesh-import path, so the only way to get real geometry in here is testing each ray
// against the real triangles directly.
// Single hero pigeon only -- brute-force triangle testing times a 12-bird flock isn't viable in a
// fragment shader. Static fly.obj pose (no per-vertex wing-flap animation).
// v1.1: fixed default camera facing the wrong side (same root cause/fix as the SDF scene needed --
// beak points away from the -Z camera without a +PI offset on the yaw).
// v1.2: the v1.1 decimation (2066 tris -> 306 via crude vertex clustering) was producing genuinely
// distorted/sliver triangles in curved regions like the wing, not just "low resolution" -- vertex
// clustering is a weak decimation technique for organic shapes. Switched to the FULL undecimated
// mesh (all 2066 triangles, exactly what the WebGL reference viewer renders) and leaned entirely on
// clustering for performance instead: 24 bounding-sphere-guarded clusters (~18-200 tris each) so a
// ray only pays for the triangles in whichever cluster(s) it's actually near, regardless of total
// mesh size -- clustering caps *per-ray* cost, not total triangle count, so this should perform
// similarly to the smaller mesh for most of the screen (background rays reject at the cheap overall-
// bounds check; only the pixels actually covering the bird pay the higher per-cluster cost).
// v1.3: first confirmed-working render -- Sam had been looking at the wrong scene (PigeonHole, the
// SDF one) this whole time without realizing this was a separate file; once actually loaded, the
// full-mesh v1.2 read as a real pigeon in flight. Only fix needed: the neck iridescence distance
// radius (0.30-0.75) reached far enough to bleed onto the wing root, tightened to (0.15-0.38).
// v1.4: HEAD_APPROX was calibrated against the discarded decimated-mesh transform and sat ~0.29
// units too far forward (past the beak, into empty space) -- tightening the tint radius in v1.3 just
// made it latch onto whatever geometry was nearest that wrong point (read as landing on the wing/tail)
// instead of fixing anything. Recomputed directly from the shipped full-mesh transform.
// v1.5: re-verified the beak-vs-tail Z-direction call after the tint still read as wrong post-v1.4
// (a nearby-vertex-count test at each Z extreme, |x|<0.6 restricted, confirms +Z=beak: 6 vertices
// near the +Z tip vs 126 near the -Z tip). Refined HEAD_APPROX from that same tight restriction --
// landed within 0.17 units of v1.4's value, reinforcing the v1.3->v1.4 bug was the stale-transform
// offset, not a backwards axis. If still wrong, suspect a stale Synesthesia reload before the logic.
// v1.6: replaced position-based color classification for Iridescent Realism with the real thing --
// the OBJ's own UV coordinates, carried through the ray-triangle test via barycentric interpolation
// (triHit now returns bestUV alongside bestT/bestN), sampled directly against the reference model's
// actual texture (T_Pigeon_D.png, copied into images/, wired up as scene.json IMAGES "pigeonTex").
// No more guessing where the neck/wing/tail are from hit-point position -- exact real color, every
// pixel. Neon and Hooded Cult styles stay procedural (deliberately stylized, not photoreal).
// v1.7: texture was sampling (real detail visible) but scrambled into a patchwork -- the V-flip
// applied when sampling was a guess and it was wrong. This texture is a scattered-island UV atlas
// (each body part its own disconnected region on a shared gray background), so a wrong flip doesn't
// read as "upside down," it reads as "every island samples a different unrelated part of the atlas."
// Removed the flip.
// v1.8: added a second baked pose -- Pigeon walk.obj (wings folded, standing/walking, legs down) as a
// selectable alternate to the default fly.obj, via a new `pigeonPose` dropdown and a second geometry
// function (meshRayTestWalk). walk.obj bundles a ground/shadow plane in its raw geometry (found and
// characterized earlier this session); filtered out here by excluding any triangle touching a vertex
// below y=-3.6 in raw units before generating this pose's data -- may trim a sliver off the very
// bottom of the feet along with the plane, since the two vertex sets couldn't be cleanly separated by
// mesh connectivity (a handful of feet-touching-ground vertices weld them into one connected region).
// Both poses share the same texture atlas (same rig/UV layout, only vertex positions differ between
// animation frames). File is now ~765KB (two full baked meshes) -- the compile-time/editor-lag risk
// flagged since v1.2 is more relevant than ever at this size, still unverified.
// v1.9: Hooded Cult read as flat black -- it had no rim/accent light at all (only the Neon style got
// one) and its dark base color, run through ambient*diffuse and then the wing/tail darkening
// multipliers, crushed toward zero against an equally near-black background. Added a warm rim light
// (same lamp concept the background already implies) and brightened the base color.
// v2.0: Hooded Cult had no actual hood or cloak -- just mood coloring on the bare mesh, a limitation
// I'd only noted in the scene description rather than actually fixed. Added real hood + cloak geometry
// via analytic ray-ellipsoid intersection (exact closed-form, no marching -- stays consistent with
// this file's pure-raytrace approach): two ellipsoids layered on top of the mesh, whichever surface
// (mesh triangle or cloak) the ray actually hits first wins, so wings/tail can still poke out from
// under the cloak mid-flap. Hood positioned from HEAD_APPROX (the verified real head location) rather
// than guessed independently.
// v2.1: Sam reported the v2.0 cloak looked like the head/tail were flipped and that it was "just 2
// orbs." Real cause of the confusing look: those 2 pieces were sized so large (one radius alone was
// over half the bird's total height) that together they engulfed the head, neck, and most of the
// torso, leaving only a small sliver of the real mesh exposed at the far end -- easy to misread as
// "wrong part visible" when it's really "almost everything got swallowed by two giant balls." Rebuilt
// as 4 properly-proportioned pieces (hood, shoulder cape, main robe body, flared hem) so it reads as a
// draped cloak instead of spheres, and so enough of the actual bird stays visible to judge by.
// v2.2: Sam found the v2.1 cloak floating disconnected from the pigeon entirely -- root cause was
// simpler than another head/tail mixup: the cloak was positioned entirely against the fly pose's
// proportions, and Sam was viewing walk pose, which has a very different actual body shape even
// though both normalize to the same overall height (extended flight posture vs standing/folded).
// Added HEAD_APPROX_WALK (same vertex-density verification method as the fly-pose one: 14 vs 121
// vertices near each Z extreme, confirming +Z=beak carries over between poses) and branched all 4
// cloak piece positions on pigeonPose, since walk's torso mass and head both sit substantially lower
// than fly's equivalent points.
// v2.3: Sam reported the 4-piece ellipsoid cloak looked like "tumors" once it was actually attached
// to the body (previous version floated disconnected entirely) -- hand-placed primitives bolted onto
// a much more detailed real silhouette were never going to read as fabric. Sam's fix, implemented
// as testCloakShell(): scale the real mesh itself up 10% around the torso pivot and cut holes over
// the face/tail/wingtips so the real mesh pokes through there. Done via the uniform-scale-ray trick
// (test the existing meshRayTest/meshRayTestWalk with a rescaled ray) rather than baking a second,
// larger copy of the triangle data -- zero meaningful file-size cost, and pose-agnostic by
// construction since it's just "this pose's own mesh, bigger," no separate per-pose tuning needed
// the way the old hand-placed ellipsoids required.
// v3.0: batch of requested changes. (1) Removed Hooded Cult entirely -- three rebuilds (ellipsoids
// floating disconnected, then reading as tumors, then the inflate-and-mask mesh-shell technique) never
// stopped being a maintenance sink relative to its payoff; gone, along with testCloakShell and all
// style>=1.5 branches. (2) Real bug found and fixed in the Neon neck tint: it always referenced
// HEAD_APPROX (the fly-pose head) regardless of pigeonPose, in two separate places (shadeHit's tint
// and renderChannel's shimmer boost) -- viewing Walk pose in Neon, the tint was anchored to where
// fly's head would be, nowhere near walk's differently-shaped body, easily reading as "on the tail."
// Both now branch on pigeonPose like the geometry itself already did. (3) pigeonColors' Brightness did
// almost nothing in Neon style because it only ever multiplied an already-near-black base color --
// now it also scales the rim light directly and adds a lift to the body past its default value.
// (4) Background media: _isMediaActive()/_textureMedia(_uv), same pattern as Motion Amplification,
// blended under the pigeon via a new backgroundMediaAmount control. (5) Two new CORRUPTION entries:
// feedbackAmount (afterimage trail via texture2D(syn_FinalPass, _uv) + screenBlend, the same
// bounded-composite fix documented for MystifyFlurry's trail) and meshGlitch (corrupts the actual 3D
// geometry by displacing the ray in coarse screen-space blocks before the mesh test, distinct from
// the existing 2D-only corruption bank).
// v3.1: added flockCount (1-5). Previously said a true-mesh flock "isn't real-time feasible" --
// reconsidered: meshRayTest/meshRayTestWalk already reject cheaply via one overall-bounding-sphere
// check before doing any real work, so a ray that misses every bird only pays that cheap check N
// times, not a full intersection N times. Each instance gets a hashed scattered offset (not a rigid
// ring -- the SDF flock scene already learned that lesson) and its own idle bob/spin phase. Capped at
// 5, well under the SDF scene's 12, since each instance here is a full real-mesh ray-trace, much
// heavier per-bird than an SDF primitive. Rigid per-bird transform (rotation+translation, no scale)
// preserves the ray's real distance, so hit distances compare directly across birds' local frames --
// smallest wins, same principle as the single-bird case.
// v3.2: real bug in v3.1's per-bird ray transform, found chasing Sam's reports of overlapping
// birds and neck-tint landing on the tail -- it re-added `pivot` (this bird's world position)
// after de-spinning the ray instead of `basePivot` (the mesh's own fixed baked frame), so every
// bird except the centered flockCount==1 case tested the static triangle data through a ray still
// shifted by flockOffset away from where those triangles actually live. One fix explains both
// symptoms: a shifted ray samples the wrong region of the same mesh (mislanding any per-position
// effect like HEAD_APPROX's neck tint) and often just clips/misses the real mesh location,
// reading as birds piled up rather than spread out.
// v3.3: meshGlitch's screen-space grid cell size was a hardcoded 7.0 -- exposed as
// meshGlitchResolution. Also split the CORRUPTION control group into 3D CORRUPTION (meshGlitch +
// its new resolution control, the one effect that actually displaces the ray before the mesh
// test) and 2D CORRUPTION (everything else, which only ever touches the final rendered pixels).
// v3.4: real second bug found from the screenshot Sam sent showing the tail/wing-fan facing the
// camera instead of the head -- baseYaw's per-bird hash offset (h1 * 6.283, meant to keep a flock
// from spinning in lockstep) was unconditional, so even the solo hero bird (fCount==1, no flock to
// desync) got an arbitrary extra yaw baked in on top of the +PI "face the camera" fix, silently
// undoing it by however far that hash landed. Gated by the same flock-active smoothstep as
// flockOffset -- a solo bird now gets exactly +PI again. Also added: lowPolyAmount/
// lowPolyFacetCount (faceted flat-shading blend, same technique as GL Classics), pixelSortWidth
// (was hardcoded at 15 columns), meshTwist (rotates whole screen-space chunks of the bird before
// the mesh test, a rigid twist/shear rather than meshGlitch's translation), and meshFreeze
// (quantized the spin/bob/SPEEN clock for a stop-motion judder -- removed again in v3.5, see below).
// v3.5: removed meshFreeze per Sam's request (one corruption too many for the value it added).
// lowPolyFacetCount's range/default lowered (2-20, default 7 -> 2-12, default 4) so "low poly"
// reads as chunky by default rather than needing to dial down from a near-smooth starting point.
// Added two more 3D CORRUPTION effects that actually warp/deform the model rather than
// glitch/rotate chunks of it: meshWarp (continuous multi-frequency sine ripple through the ray --
// an organic melt/wave, always-on once dialed up rather than meshGlitch/meshTwist's discrete
// per-cell triggering) and meshDistort (uniform pulsing scale around the bird's own pivot -- a
// balloon-glitch; uniform scale specifically because it keeps the ray's hit distance exact with no
// renormalization needed, unlike a non-uniform/per-direction scale would, so cross-bird nearest-hit
// comparisons in the flock loop stay correct even while distorted). Also added an obvious
// `resetModelBang` pad -- since warp/distort/glitch/twist can make the bird unrecognizable when
// cranked up for a moment, hitting it snaps all 3D corruption amounts to 0 instantly (fast-attack
// script.js envelope) and eases them back over about a second, independent of slider positions.
// v3.6: Sam correctly called out that v3.5's meshWarp "just shakes it, not a sine wave" and
// meshDistort "is ASS" -- real bug, not a tuning issue: both perturbed `bro`, the ray's ORIGIN,
// which is the same camera point for every pixel on screen. Warping a single constant point by a
// function of its own position just translates the whole rigid bird by one TIME-varying vector per
// frame -- shaking, not a per-surface ripple. A ray-triangle test can't domain-warp along the ray
// the way an SDF raymarcher does (there's no "sample many points per ray" step to perturb), so the
// actual fix is to warp the triangle VERTICES themselves before intersecting: added
// gMeshWarpAmt/gMeshDistortAmt globals + warpVertex(), called once per triangle inside triHit()
// (triHit already takes each triangle's raw corners as parameters, so this needed touching one
// function, not its ~2000+ unrolled call sites). meshWarp is now a real per-vertex multi-frequency
// sine ripple (the standard raymarching-shader domain warp, `p += A*sin(freq*p+time)`, applied to
// real corners instead of a marched sample point); meshDistort is now a real per-vertex twist
// (`p.xz *= rot(p.y*k)`, the classic raymarching "twist" domain warp, spiraling the silhouette
// around its own vertical axis). Both recompute the hit normal from the warped triangle (sign-
// matched against the original to guard rare winding flips) so lighting responds to the actual
// deformed surface instead of shading a rippled shape with its flat undistorted normal.
// Also: removed lowPolyFacetCount as a separate control per Sam's request for one fixed, harsher
// setting -- facet coarseness is now a single hardcoded constant (LOW_POLY_FACETS = 2.2, well
// below the old 4-7 default range) pushed toward N64-era chunkiness, `lowPolyAmount` is the only
// remaining low-poly control.
// v3.7: large batch. (1) Low-poly pushed further per Sam's request ("N64 or PS1 level"):
// LOW_POLY_FACETS dropped 2.2 -> 1.3, and added real vertex-position snapping (snapVertex(),
// collapses positions onto a coarse lattice) alongside the existing normal faceting -- the actual
// PS1/N64 signature is blocky GEOMETRY, not just flat shading on an otherwise-smooth silhouette,
// and normal faceting alone couldn't produce that. (2) Renamed the "3D CORRUPTION" control group
// to "PIGEON CORRUPTION" per Sam's request. (3) Added meshFold, a fractal mirror-fold domain warp
// (the abs()-fold-and-rotate technique behind classic Kaleidoscopic-IFS raymarching fractals, the
// same idea as party_doodad_dup.synScene's `p4 = abs(p4)` folding, studied for this) applied to
// real vertices in warpVertex() alongside meshWarp/meshDistort -- a crystalline/splintered look,
// genuinely distinct from the smooth ripple and the single twist. (4) Added bgEchoAmount, a
// repeating kaleidoscope echo trail: samples syn_FinalPass at several progressively zoomed/
// rotated/kaleido-folded offsets, inspired by media_key_&_cloner_fx_dup's clone-loop (studied for
// the offset-per-iteration structure) and chroma_cascade/Metal Shader's angle-segment kaleidoscope
// fold (studied for the fold math) -- condensed into one pass over the existing feedback texture
// rather than a real multi-buffer cloner chain, since this file is single-pass.
// Version 3.7 (pigeonholemesh_syn_main_v3_7)
// v3.8: two real bugs from Sam's first test pass. (1) meshDistort's audio swing (0.3-2.0x, the same
// range meshGlitch/meshTwist use) was way too strong for a *continuous* full-mesh effect -- those
// two are probabilistic per-cell triggers where a big swing just changes the odds a few chunks
// glitch, but meshDistort applies its twist angle to the entire bird every frame, so doubling it on
// every hit reads as violent. Toned down to 0.85-1.15x. (2) bgEchoAmount's v3.7 implementation
// composited with screenBlend, same as the feedback trail -- but screenBlend only ever pushes
// brighter (no floor to decay toward), and a persistent source fed through it every frame
// mathematically converges to white given enough frames; the first echo layer also had no
// per-layer falloff, so even one frame at a high setting could inject a full-strength copy.
// Confirmed exactly by Sam: "ends up making the screen white" and didn't read as a kaleidoscope
// trail at all. Rewritten as a genuine weighted average of the mirrored samples, composited with
// mix() instead of screenBlend -- mix settles toward a steady state rather than ratcheting upward,
// so it can't run away regardless of how it's combined with feedbackAmount.
// Version 3.8 (pigeonholemesh_syn_main_v3_8)
// v3.9: Sam reported the neck-tint bug persisted with "did nothing" energy after v3.8 -- checked
// for a systemic compile break first (a full line-by-line brace-depth trace over the whole file,
// not just a global open/close count, which can't catch a swapped-order break that still
// balances) and confirmed the file structure is sound. Static analysis of the position math was
// already exhausted last round, so switched from reasoning to direct instrumentation: temporarily
// forced the neckT-masked region in shadeHit to solid magenta instead of the real hue cycle, as an
// unambiguous render-vs-math tiebreaker.
// v3.10: two more real bugs found after Sam's magenta test (still on the same region they call the
// tail) and continued reports that meshDistort/feedback/bgEcho still weren't right. (1) meshDistort
// actual root cause, not just needing more audio tuning: its twist angle had a raw `TIME * amt *
// 0.7` term -- unbounded, so for ANY nonzero setting the twist keeps winding tighter for as long
// as the scene has run, independent of the audio range already fixed in v3.8. Replaced with
// `sin(TIME*0.5) * amt * 0.6` (oscillating, bounded) and dropped the static coefficient
// (3.2 -> 1.8 rad). (2) bgEcho's per-layer geometric offset was scaled BY echoAmt itself, so at any
// moderate slider setting the 5 "echo" samples were nearly identical to the base frame, and the
// weighted average favors the least-offset layer -- read as a faint blur, not repeating copies.
// Decoupled: the per-layer zoom/rotation step is now a fixed, always-substantial amount regardless
// of amt, and echoAmt only controls how strongly the (now genuinely multi-copy) result blends in.
// Also published a standalone visual verification tool (side + top orthographic projections of the
// real baked Fly-pose mesh data with HEAD_APPROX marked) since screenshot-based back-and-forth on
// the neck-tint question had stopped converging after several rounds.
// v3.11: the tool from v3.10 worked -- Sam hand-placed 15 real landmarks on the actual mesh
// (Beak, Eyes, Top/Bottom of skull, neck at chest/spine/both shoulders, tail start/end left/
// center/right, both wingtips) and settled the axis question for good: **the beak is at -Z, not
// +Z.** Every vertex-density heuristic tried across this entire saga (multiple sessions, plus two
// independent rechecks this session) concluded the opposite and was wrong every time -- the real
// signal (wingtips also cluster near -Z, right next to the actual head) kept getting misread as
// "the tail needs lots of vertices." Two real fixes from this: (1) HEAD_APPROX replaced with the
// centroid of the 8 real head/neck/shoulder landmarks (was pointing at the tail this entire time);
// neckT radius widened (0.12-0.32 -> 0.18-0.42) to actually span beak-to-shoulder instead of just
// the beak tip. Reverted the v3.9 magenta debug back to the real color cycle. (2) Removed the
// per-bird "+PI" yaw offset, which was reasoned from the same backwards axis assumption -- traced
// the ray transform through it and confirmed it was rotating the ray to enter the mesh from the
// wrong side, hitting the tail first by default. HEAD_APPROX_WALK is UNVERIFIED -- it was derived
// with the same flawed vertex-density method and almost certainly has the same bug, but Sam has
// only placed Fly-pose landmarks so far.
// v3.12: extended the beak-locator artifact with a Fly/Walk pose toggle (separate triangle data,
// separate saved-marker collection per pose) and Sam placed 11 real Walk-pose landmarks (beak
// tip/base, top of head, base of skull, neck at spine/chest, breast, top of back, feet, tail
// start/tip). Confirms the same axis convention as Fly (beak at -Z) and the same failure mode:
// the old HEAD_APPROX_WALK (Y=-0.13, Z=+1.05) was low to the ground AND in the tail's +Z region --
// nowhere near a walking bird's head. Replaced with the centroid of the 6 real head/neck landmarks.
// The +PI removal from v3.11 already applies to both poses (baseYaw doesn't branch on pigeonPose),
// so no separate orientation fix was needed here.
// v3.13: Sam's verdict on bgEcho + feedbackAmount was "all of the above" (washes out, doesn't look
// like copies, too subtle) -- both had the same underlying problem, just at different layers.
// feedbackAmount: screenBlend fixes raw addition's total lack of an upper bound, but it's still a
// one-way brightening operator with no independent decay term, so a persistent source fed through
// it every frame still creeps toward white over time at high trailAmt -- just slower than raw
// addition. Switched to a classic phosphor-persistence mix() (convex combination, structurally
// cannot exceed the brighter input). bgEcho: the real design mistake was trying to fake "multiple
// copies" by averaging 5 samples of ONE frame -- averaging samples together is a blur operation by
// definition, no matter how far apart the samples are, which explains both "washes out" and
// "doesn't look like copies" as the same root cause. Rebuilt on the actual principle behind the
// reference cloner and real analog video feedback: a single small zoom+rotate+kaleido-fold
// transform applied once per frame, left to COMPOUND over many frames through the syn_FinalPass
// feedback loop itself -- nested copies build up and become clearly visible within a second or two
// rather than needing to be complete from one frame's math, and composite with mix() for the same
// stability reason as feedbackAmount.
// Version 3.13 (pigeonholemesh_syn_main_v3_13)
// v3.14: batch request. (1) Removed flockCount entirely -- single hero bird again, no per-bird
// loop/hash-offset/pivot bookkeeping. (2) SPEEN ported from Vineshroom SPEEN Circle's actual
// architecture (already proven in the SDF Pigeon Hole scene): independent speenX/Y/Z amount knobs
// and flipSpeen, using a bounded pendulum() sin-oscillation instead of the old single uniform
// TIME*fixed-ratio*speenEnvC tumble -- same runaway-avoidance shape as the meshDistort fix, applied
// proactively here since the old code had the same TIME*amt structure. (3) bobAmount's amplitude
// increased 0.08 -> 0.2 (2.5x). (4) Added a kaleidoscope control ported from Metal Shader (angle
// wrapped into N repeating wedges around center) -- kept faithful to Metal Shader's actual shipped
// behavior including an apparent quirk in the source (the mirror-alternation branch there is dead
// code since angle is already reduced into one segment's range before it runs), rather than fixing
// behavior Sam hasn't asked to change. (5) Removed the per-hit distance fog -- at this scene's
// normal camera range it was blending 10-25% background into the bird by default, reading as
// semi-transparent rather than atmospheric haze. Sam: "should be opaque." Bird is now a solid hit
// regardless of camera distance/zoom.
// Version 3.14 (pigeonholemesh_syn_main_v3_14)
// v3.15: added 7 view bangs -- Front/Back/Left/Right/Top/Bottom/Perspective -- that smoothly orbit
// the static camera to a preset angle around the bird (script.js eases viewYaw/viewPitch toward a
// bang-set target each frame, yaw taking the shortest path around the circle; Top/Bottom only
// change pitch so they don't also spin the current facing). The camera is now a proper spherical
// orbit around `lookAt` (was a single fixed offset vector) -- yaw=0/pitch=0 reproduces the original
// static view exactly, so nothing changes until a bang is pressed. Pitch clamped to +-1.4 rad
// (short of +-PI/2) to stay clear of the gimbal-lock singularity directly overhead/underneath,
// where forward becomes parallel to the world-up reference and the right/up cross product
// degenerates to zero.
// Version 3.15 (pigeonholemesh_syn_main_v3_15)
// v3.16: (1) bgEcho was blending over the bird itself, reading as if it were in front of it --
// added an `out float hitOut` to renderChannel (background=0/bird=1, captured from the RGB-split's
// G channel as the representative mask) and masked bgEcho's compositing by (1-hitMask) so it can
// only ever show through where the bird isn't. feedbackAmount left covering the whole frame since
// only bgEcho was named. (2) Added meshDisplace, a new Pigeon Corruption ported from iquilezles.org/
// articles/distfunctions' "Displacement" technique -- a much higher-frequency sine perturbation
// (24 vs meshWarp's 3-4) pushed outward along the radial direction from the body center (no cheap
// per-vertex normal available here, so this stands in for IQ's along-the-normal push), giving a
// spiky/corroded texture distinct from the smooth ripple/twist/fold already in the bank.
// (3) Camera controls, studied directly from Synesthesia's own "3D Orbit Camera" example scene
// (confirmed the real `_click`/`_muvc` globals and the drag-updates-goal-then-eases pattern from
// its actual shipped script.js): added left-click-drag orbit on top of the existing view-preset
// bangs -- dragging updates viewYaw/viewPitch immediately (1:1, no lag) and keeps the bang-driven
// ease target in sync so releasing the mouse doesn't spring back to a stale preset.
// Version 3.16 (pigeonholemesh_syn_main_v3_16)
// v3.17: (1) bgEchoAmount's ceiling raised 1.0 -> 2.0; the mix() blend factor is now separately
// clamped to [0,1] since mix() extrapolates past its inputs for t>1 -- without that clamp, values
// above ~1.4 would have overshot color values instead of just blending in more echo. (2) Added
// right-click-drag zoom, studied from the same 3D Orbit Camera example scene as the orbit drag --
// kept it a direct 1:1 position delta (with a short momentum decay after release) rather than that
// reference's own hold-and-it-keeps-zooming joystick style, for the same feel as the existing
// left-drag orbit. (3) Controls reorganized: feedbackAmount + bgEchoAmount split out of 2D
// CORRUPTION into a new TRAILS group (they're persistence effects, not glitch/corruption); added an
// emoji to Sam's new ORIENTATION group (matching every other group's convention).
// Version 3.17 (pigeonholemesh_syn_main_v3_17)
// v3.18: added wobbleAmount -- a small idle turn-left/right (yaw) + tilt-up/down (pitch/nod),
// bob's rotational counterpart for a bit of alive-feeling idle motion. Bounded sin oscillations on
// both axes (never a raw TIME*amt accumulation -- same family of fix as the meshDistort runaway-
// twist bug), phase-offset from each other so the two axes don't move in lockstep. Yaw folds into
// the existing baseYaw rotation; pitch combines into the same X-axis rotation SPEEN's sx already
// uses (both affect the Y-Z plane, so the angles just add) rather than a separate rot() call.
// Version 3.18 (pigeonholemesh_syn_main_v3_18)
// v3.19: large batch. (1) Removed meshDisplace per Sam's request (redundant with meshWarp) --
// control, global, warpVertex block, and all threading through renderChannel/renderMain fully
// removed. (2) ORIENTATION: added viewIsometricBang (45deg yaw / 35.264deg pitch, the classic
// game-art isometric angle) -- note this camera is perspective, not orthographic, so it's the
// isometric VIEWING angle, not a true parallel-projection isometric render. (3) TRAILS: added
// edgeDetectAmount (Sobel-style luminance-gradient outline glow, sampling syn_FinalPass for
// neighboring pixels) and streakAmount (a directional light-trail/comet smear, slowly rotating --
// same one-small-step-per-frame compounding principle as bgEcho, but linear instead of radial for
// a genuinely different trail character; left whole-frame/unmasked since dragging the bird's own
// motion is the point of this one). (4) PIGEON: three physical-impulse bangs (peckBang/hopBang/
// lookBang, each just an attack/decay envelope like the corruption bangs, used directly as the
// motion shape -- no oscillation needed for a non-bouncy impulse) plus two knobs for idle-motion
// categories bob/wobble didn't cover: breatheAmount (uniform scale pulse, using the same exact-
// scale-ray trick proven for meshDistort) and swayAmount (horizontal drift, bob's X-axis
// counterpart). (5) LOW POLY: added lowPolyReactivity so the chunky look can pulse in on bass hits.
// (6) 2D CORRUPTION: mirrorScreen (bilateral mirror, distinct from kaleidoscope's radial repeat),
// invertBang + zoomPunchBang (both envelope-smoothed pulses -- deliberately NOT a brightness-flash
// strobe, given the established flashing-safety preference), vignetteAmount (edge darkening, a
// staple this scene didn't have yet).
// Version 3.19 (pigeonholemesh_syn_main_v3_19)
// v3.20: removed 8 of v3.19's additions per Sam's request -- lookBang, peckBang, hopBang,
// viewIsometricBang, mirrorScreen, breatheAmount, swayAmount, vignetteAmount. Fully cleaned out
// (control, uniform, GLSL logic, script.js state), not just hidden. wobbleAmount, the rest of the
// PIGEON corruption bank, the other view bangs, and everything else from v3.19 (edgeDetectAmount,
// streakAmount, lowPolyReactivity, invertBang, zoomPunchBang, mouse drag orbit/zoom) untouched.
// Sam also flagged edgeDetectAmount as not working correctly -- not yet investigated/fixed.
// Version 3.20 (pigeonholemesh_syn_main_v3_20)
// v3.21: edgeDetectAmount fix. Sam's symptom was "looks wrong/glitchy," which pointed at the real
// bug: the Sobel filter had no noise floor, so tiny per-pixel quantization/dithering variation in
// syn_FinalPass (especially across the near-black Neon background) got amplified into visible
// speckle everywhere, indistinguishable from a real edge. Replaced the linear clamp with a
// smoothstep threshold (0.04-0.25) so only genuinely significant gradients (the bird's silhouette,
// the red grid lines, real texture boundaries) pass through; anything below the noise floor is
// fully suppressed instead of partially lighting up.
// Version 3.21 (pigeonholemesh_syn_main_v3_21)
// v3.22: edgeDetectAmount's real fix. Sam's v3.21 report was still wrong, and precisely diagnosed
// why: "detecting every single edge between 2 vertexes... instead of the outline from the camera's
// perspective." The v3.21 noise-floor fix didn't address the actual bug -- a Sobel filter on
// syn_FinalPass's LUMINANCE fundamentally cannot distinguish a real silhouette (background meets
// bird) from two neighboring flat-shaded facets that just have different normals; both are real,
// non-noise luminance jumps in the 2D image. Rebuilt on the correct signal instead: HIT/MISS and
// DEPTH. Added silhouetteProbe(), a cheap hit-test-only re-trace (same object transform as the real
// render, no shading/corruption) called at 4 neighboring screen directions -- a true edge is where
// the ray stops hitting the mesh (silhouette) or where depth jumps sharply between two real hits
// (e.g. a wing crossing in front of the body), never at an ordinary facet seam where both sides are
// the same continuous surface at nearly the same depth. Genuinely more expensive (up to 5 extra
// mesh tests per pixel) but only when the control is actually on, and it's the only way to get a
// real outline instead of facet noise.
// Version 3.22 (pigeonholemesh_syn_main_v3_22)
// v3.23: performance pass, prompted by "anything you can do to optimize." Found a real, safe
// (behavior-preserving) win: renderChannel (up to 3x/pixel for RGB split) and silhouetteProbe (up
// to 5x/pixel for edge detect) each independently recomputed the identical idle spin/bob/wobble/
// SPEEN transform angles from scratch on every call -- ~15 scalar ops including 6 sin() calls,
// repeated up to 8x per pixel when both effects are active, for values that only depend on TIME and
// the controls, never on which call is asking. Hoisted to compute once in renderMain and pass the 5
// results in as parameters instead. No visual change -- same math, just not redone redundantly.
// Verified every call site's argument count against both signatures programmatically after the
// refactor (27 args x4 renderChannel calls, 11 args x5 silhouetteProbe calls, all matching).
// v3.24: added Dove as a third pigeonStyle. No dove texture asset exists, so it's procedural like
// Neon rather than a texture sample like Iridescent Realism: soft pale white/cream plumage
// (shadeHit, checked before the Iridescent texture branch since Dove is also style >= 0.5) over a
// gentle pale gradient sky with a warm horizon glow (pigeonBackground) -- left tunable through the
// existing pigeonColors/backgroundColors/backgroundIntensity controls, same as the other two
// styles, rather than a fixed look, per Sam's request to dial it in from within Synesthesia.
// v3.25: performance pass #2 (see v3.23 for the first). meshRayTest/meshRayTestWalk's ~20 clusters
// each were guarded only by raySphereNear -- "does the ray pass near this cluster at all" -- with
// no awareness of how close a hit had already been found elsewhere, so every cluster the ray passed
// near got its triangles fully tested even after a much closer hit was already in hand. Added
// clusterHit (same near-test, plus the cluster's own nearest-possible-surface distance along the
// ray computed from the sphere's entry point) and swapped all 40 per-cluster guards over to it,
// passing the function's live bestT through. Once any cluster resolves a close hit, farther
// clusters whose nearest possible point can't beat it are skipped outright -- on a solid mesh like
// this bird, roughly half of any ray's clusters sit on the far/occluded side once the near side has
// already been hit, so this should cut a meaningful chunk of triangle tests per ray with zero visual
// change (order-independent: it only skips clusters already proven unable to produce a closer hit
// than the real winner, never changes which triangle that winner is). Biggest multiplier: this
// benefit applies per mesh test, and mesh tests already run up to 3x/pixel (RGB split) and up to
// 5x/pixel more via silhouetteProbe (edge detect), so the saving compounds under those controls.
// Version 3.25 (pigeonholemesh_syn_main_v3_25)
// v3.26: removed SPEEN entirely per Sam's request ("seems quite pointless now") -- the whole tumble-
// chaos bank (speenBang, flipSpeen, speenX/Y/Z, and the pendulum() helper that drove them) is gone:
// scene.json's 5 SPEEN controls, script.js's _speenEnv envelope + both setUniform calls, and every
// GLSL reference (renderMain's speenEnvC/speenXVal/speenYVal/speenZVal/posNeg/speenSx/speenSy/
// speenSz block, and the sy/sz parameters they fed into renderChannel and silhouetteProbe, dropped
// from both signatures and all 9 call sites). objPitchTotal is now just wobblePitch (previously
// speenSx + wobblePitch) -- wobbleAmount's existing idle tilt is untouched and still works exactly
// as before. Scene-level DESCRIPTION also updated (was still advertising SPEEN, and separately was
// still calling out only Iridescent Realism as a style despite Dove already existing as of v3.24).
// Version 3.26 (pigeonholemesh_syn_main_v3_26)
// v3.27: batch of 3 requests. (1) Dove background recolored -- Sam reported it read as "blinding
// white." Real cause: the old palette's high tone + horizon glow summed past 1.0 near the horizon
// (clipping to flat white), and both base tones sat too close to gray to read as colorful even
// before that. Replaced with an actual dusk gradient (dusty rose horizon -> indigo sky, amber glow
// kept under 1.0) -- see pigeonBackground's comment. (2) Iridescent Realism now has its own neck/
// head color sheen, finally matching what neckIridescence's own control description already
// claimed ("Neon and Iridescent styles") but the code had only ever wired to Neon. Two new color
// pickers, iridescentColorA/B, default to Neon's own hardcoded blue/red so the initial look doesn't
// change; factored the shared turbulence math out of neonAccentColor into neckSheenT() so both
// styles' sheens move in sync rather than risk drifting out of sync from a duplicated formula.
// Blended at half strength (not neckT's full range) so the real photo texture still reads through
// the sheen instead of getting painted over. (3) edgeDetectColor: the edge-outline glow's color
// (previously hardcoded cyan/teal) is now a color picker, defaulting to that same cyan/teal.
// Verification pass caught a residual headroom gap in (1): the initial glow coefficient
// (0.45,0.24,0.14) still let backgroundIntensity's R channel clip past 1.0 on its own once pushed
// above ~1.67 out of its 0-2 slider range, before backgroundColors was even touched. Lowered to
// (0.35,0.20,0.12) so the glow stays under 1.0 across the slider's full range, not just at default.
// Version 3.27 (pigeonholemesh_syn_main_v3_27)
// v3.28: Sam corrected v3.27 item (2) -- the two iridescentColorA/B pickers were meant for
// Iridescent Realism's BACKGROUND, not the neck. Reverted shadeHit's Iridescent branch back to a
// plain texture sample (no neck sheen -- neckSheenT/neonAccentColor's factor-out from v3.27 is kept
// since Neon still uses it) and rewired iridescentColorA/B onto pigeonBackground's Iridescent
// (bokeh-haze) branch instead, replacing what were previously hardcoded dark/warm tones. Defaults
// changed to match: A=(0.03,0.03,0.05) (was the neon-blue default), B=(0.18,0.12,0.10) (was the
// neon-red default) -- these are the actual old hardcoded background values, so the look is
// unchanged until the pickers are touched. Moved both controls' UI_GROUP from COLOR to BACKGROUND
// to sit alongside backgroundColors/backgroundIntensity, which already describe this same haze.
// Version 3.28 (pigeonholemesh_syn_main_v3_28)
// v3.29: performance pass #3 (see v3.23 and v3.25 for the first two) -- a second level of
// clustering inside meshRayTest/meshRayTestWalk's existing ~40 top-level clusters, prompted by a
// dev's question about whether tracing the mesh is the real cost (it is: this is ray-TRIANGLE
// intersection against the real baked geometry, not raymarching, and the ~40 clusters' own
// triangles were previously tested as one flat unrolled list per cluster once that cluster's
// bounding sphere was entered -- up to 203 triHit calls in a single cluster with zero further
// culling). Any cluster over 30 triangles is now split into 2-4 sub-clusters (bounding-sphere
// radius sized to just enclose its member triangles' actual vertices, +0.0008 float-safety margin)
// along whichever axis has the most spread, each guarded by the same clusterHit() pruning from
// v3.25 -- so a ray that enters a cluster's outer sphere but only actually needs one corner of it
// no longer pays for every triangle in the whole cluster, just the sub-cluster(s) it's actually
// near. Generated and verified programmatically rather than by hand (given ~3077 triangles across
// 35 affected clusters): confirmed the exact same multiset of triHit() calls exists before and
// after (zero triangles added, dropped, or edited -- only regrouped), confirmed every generated
// sub-cluster sphere actually contains all its member triangles' vertices, and confirmed the file's
// brace/paren balance. Zero visual change, same triangle data, same winner-takes-bestT logic --
// purely fewer wasted triHit calls per ray.
// Version 3.29 (pigeonholemesh_syn_main_v3_29)
// v3.30: reverted v3.29. Sam reloaded the scene and got "Render Engine Reset due to a graphics
// error: Program linking failed for sceneB" -- a real GLSL compile/link failure, not a logic bug.
// v3.29's every check (triangle data unchanged, every sub-cluster sphere geometrically valid,
// brace/paren balance) was a TEXT-level/structural check, not an actual shader compile -- none of
// them could have caught a compiler resource limit. v3.29 roughly tripled the mesh-test functions'
// branch count (40 cluster guards -> 132, nesting a second clusterHit guard inside most of the
// first), and that's the prime suspect: most likely an instruction-count/shader-complexity ceiling
// in Synesthesia's underlying GLSL compiler, not anything wrong with the sub-clustering math
// itself. Reverted by flattening every sub-cluster back into its parent cluster's single flat
// triHit list (mechanical, scripted, and re-verified against the exact original per-cluster
// triangle counts recorded before v3.29 ever ran -- all 40 clusters matched exactly, 3077 triangles
// total, same triHit call text, brace count back to the pre-v3.29 101/101). Back to v3.25's
// single-level clusterHit pruning only. If more mesh-test performance is wanted later, a real
// sub-clustering pass would need to actually compile-test in Synesthesia incrementally (a handful
// of clusters at a time) rather than applying it file-wide in one shot the way this attempt did.
// Version 3.30 (pigeonholemesh_syn_main_v3_30)

// ===== HELPERS =====

mat2 rot(float a) {
    float c = cos(a);
    float s = sin(a);
    return mat2(c, -s, s, c);
}

float hash(float n) {
    return fract(sin(n) * 43758.5453);
}

// Low-poly look, take 2: normal-faceting alone read as flat-shaded but still smooth-SILHOUETTE --
// real N64/PS1 chunkiness needs the actual GEOMETRY collapsed onto a coarse lattice too, not just
// the shading. LOW_POLY_FACETS dropped hard (2.2 -> 1.3, close to the floor where facetNormal still
// returns a well-defined direction) and vertex snapping was added alongside it in warpVertex()
// below -- both driven by the same lowPolyAmount control.
const float LOW_POLY_FACETS = 1.3;
vec3 facetNormal(vec3 n) {
    vec3 q = floor(n * LOW_POLY_FACETS + 0.5) / LOW_POLY_FACETS;
    return (dot(q, q) > 1e-8) ? normalize(q) : n;
}

// PS1-style vertex snapping: collapses vertex positions onto a coarse lattice, the other half of
// the "real geometry, not just shading" low-poly look -- this is what actually gives PS1/N64
// models their wobbly, faceted silhouette (a consequence of their lack of subpixel vertex
// precision), not just flat normals on an otherwise smooth shape.
vec3 snapVertex(vec3 p, float amt) {
    if (amt < 0.001) return p;
    float grid = mix(400.0, 7.0, amt);
    return mix(p, floor(p * grid + 0.5) / grid, amt);
}

vec3 enhanceColor(vec3 col, float bright, float sat) {
    col *= bright;
    float gray = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(gray), col, sat);
    return col;
}

// composites new content over a faded feedback trail with a screen blend instead of raw addition --
// bounded to [0,1] regardless of how many times/how brightly it's applied, unlike raw addition, which
// creeps toward white in any region revisited faster than the fade removes it. Same fix documented for
// MystifyFlurry's trail; carrying it straight over since it's the proven pattern for this exact need.
vec3 screenBlend(vec3 base, vec3 add) {
    return 1.0 - (1.0 - base) * (1.0 - clamp(add, 0.0, 1.0));
}

// ===== RAY / MESH INTERSECTION =====

// cheap reject: does the ray's line pass within `radius` of `center`? (line test, not segment --
// fine here since the camera always sits in front of the object at a sane working distance)
bool raySphereNear(vec3 ro, vec3 rd, vec3 center, float radius) {
    vec3 oc = center - ro;
    float tca = dot(oc, rd);
    float d2 = dot(oc, oc) - tca * tca;
    return d2 <= radius * radius;
}

// Per-cluster guard used by meshRayTest/meshRayTestWalk's ~20-cluster lists below. Same near-test
// as raySphereNear, but also rejects a cluster outright once its nearest possible surface point
// along the ray is already farther than the closest real triangle hit found so far (bestT) --
// once one cluster lands a close hit, no farther cluster can beat it, so its triangles never need
// testing. Order-independent and visually identical to testing every cluster unconditionally: this
// only ever skips clusters already proven unable to win, never changes which triangle ends up as
// the final hit. Real savings on a solid mesh like this bird, where roughly half of any given ray's
// clusters sit on the far/occluded side once a near-side hit is already in hand.
bool clusterHit(vec3 ro, vec3 rd, vec3 center, float radius, float bestT) {
    vec3 oc = center - ro;
    float tca = dot(oc, rd);
    float d2 = dot(oc, oc) - tca * tca;
    float r2 = radius * radius;
    if (d2 > r2) return false;
    float entryT = tca - sqrt(r2 - d2);
    return entryT < bestT;
}

// Pigeon Corruption state (meshWarp/meshDistort/meshFold) plus lowPolyAmount's vertex-snap half,
// read directly by triHit() below (see renderChannel, which sets these once per render call).
// Plain globals rather than threading four more parameters through triHit() and its ~2000+
// unrolled call sites -- same idiom this file already uses for the k-means cluster culling state.
float gMeshWarpAmt = 0.0;
float gMeshDistortAmt = 0.0;
float gMeshFoldAmt = 0.0;
float gLowPolyAmt = 0.0;

const vec3 MESH_PIVOT = vec3(0.0, 0.55, 0.0);

// Real per-vertex distortion, applied to a triangle's actual corners before intersecting -- the
// only way to get a genuine surface-varying warp out of a ray-TRIANGLE test (as opposed to
// raymarching an SDF, where you can warp the sample point at every step along the ray). An earlier
// version instead offset the ray's origin, which is the same camera point for every pixel on
// screen -- warping a single constant point just translates the whole rigid bird by one
// TIME-varying vector per frame, which reads as shaking, not rippling. Warping the vertices
// themselves means each triangle deforms according to its own position, the same way a vertex
// shader displacement or an SDF domain-warp would.
vec3 warpVertex(vec3 p) {
    vec3 wp = p;
    if (gMeshWarpAmt > 0.001) {
        // organic multi-frequency ripple/melt -- classic raymarching-shader domain warp
        // (p += A*sin(freq*p + time)), just applied to real triangle corners instead of a
        // raymarch sample point.
        wp += vec3(
            sin(p.y * 4.5 + TIME * 2.0) * sin(p.z * 3.3 + TIME * 1.3),
            sin(p.z * 3.8 + TIME * 1.7) * sin(p.x * 4.7 + TIME * 2.1),
            sin(p.x * 3.4 + TIME * 1.1) * sin(p.y * 4.1 + TIME * 1.9)
        ) * gMeshWarpAmt * 0.16;
    }
    if (gMeshDistortAmt > 0.001) {
        // classic raymarching "twist" domain warp (p.xz *= rot(p.y * k)) -- spirals the whole
        // silhouette around its own vertical axis like a barber pole, angle growing with height.
        // basePivot's x/z is (0,0) so no pivot subtraction needed for the twist axis itself.
        // Real bug, the actual reason this stayed "too intense" after the audio-range tuning:
        // the second term was `TIME * amt * 0.7` -- unbounded. For ANY nonzero meshDistort, the
        // twist keeps winding tighter for as long as the scene has been running, completely
        // independent of the audio multiplier -- a session left running for a few minutes would
        // wind through many full rotations no matter how gentle the slider or the audio swing.
        // Same family of mistake as the TIME*speedMultiplier jitter lesson, different symptom:
        // that one was frame-to-frame jitter, this is runaway-with-session-length. Fixed by
        // oscillating (bounded) instead of accumulating, and the static coefficient dropped too
        // (3.2 rad ~ 183 degrees at full height offset and amt=1 was extreme on its own, before
        // the runaway term ever stacked on top).
        float twistAngle = (wp.y - 0.55) * gMeshDistortAmt * 1.8 + sin(TIME * 0.5) * gMeshDistortAmt * 0.6;
        wp.xz = rot(twistAngle) * wp.xz;
    }
    if (gMeshFoldAmt > 0.001) {
        // Fractal mirror-fold: the abs()-fold-and-rotate technique behind classic Kaleidoscopic-IFS
        // raymarching fractals (party_doodad_dup's `p4 = abs(p4)` folding is the same idea) --
        // folds the mesh back through its own pivot a couple of times for a crystalline, splintered
        // look, distinct from the smooth ripple above and the single twist below it. Blended rather
        // than switched at the threshold since abs() has a kink -- a hard cut would pop visibly.
        vec3 fp = wp - MESH_PIVOT;
        for (int i = 0; i < 2; i++) {
            fp = abs(fp);
            fp -= 0.28 * gMeshFoldAmt;
            fp.xz = rot(0.9 + float(i) * 0.6) * fp.xz;
        }
        wp = mix(wp, fp + MESH_PIVOT, gMeshFoldAmt);
    }
    if (gLowPolyAmt > 0.001) {
        wp = snapVertex(wp, gLowPolyAmt);
    }
    return wp;
}

// Moller-Trumbore ray-triangle intersection, exact and standard -- no array/initializer-list syntax
// used anywhere in this file since I can't confirm Synesthesia's GLSL dialect supports it; every
// triangle is a separate explicit call instead, matching this codebase's existing unrolled-loop idiom.
// Now also carries the triangle's real UV coordinates (from the OBJ's own vt data) and returns the
// barycentric-interpolated UV at the hit point, for real texture sampling instead of position-based
// color guessing.
bool triHit(vec3 ro, vec3 rd, vec3 p0, vec3 p1, vec3 p2, vec3 n, vec2 uv0, vec2 uv1, vec2 uv2,
            inout float bestT, inout vec3 bestN, inout vec2 bestUV) {
    bool warping = gMeshWarpAmt > 0.001 || gMeshDistortAmt > 0.001 || gMeshFoldAmt > 0.001 || gLowPolyAmt > 0.001;
    if (warping) {
        p0 = warpVertex(p0);
        p1 = warpVertex(p1);
        p2 = warpVertex(p2);
    }
    vec3 e1 = p1 - p0;
    vec3 e2 = p2 - p0;
    vec3 h = cross(rd, e2);
    float a = dot(e1, h);
    if (abs(a) < 1e-7) return false;
    float f = 1.0 / a;
    vec3 s = ro - p0;
    float u = f * dot(s, h);
    if (u < 0.0 || u > 1.0) return false;
    vec3 q = cross(s, e1);
    float v = f * dot(rd, q);
    if (v < 0.0 || u + v > 1.0) return false;
    float t = f * dot(e2, q);
    if (t > 0.001 && t < bestT) {
        bestT = t;
        // Recompute the normal from the warped triangle itself so lighting responds to the actual
        // deformed surface, rather than shading a rippled/twisted shape with its flat, undistorted
        // normal. Sign-matched against the original baked normal so a rare winding flip under
        // extreme distortion can't invert the lighting.
        if (warping) {
            vec3 nWarp = normalize(cross(e1, e2));
            bestN = (dot(nWarp, n) < 0.0) ? -nWarp : nWarp;
        } else {
            bestN = n;
        }
        bestUV = uv0 * (1.0 - u - v) + uv1 * u + uv2 * v;
        return true;
    }
    return false;
}

float meshRayTest(vec3 ro, vec3 rd, inout float bestT, inout vec3 bestN, inout vec2 bestUV) {
    bool hit = false;
    if (!raySphereNear(ro, rd, vec3(0.0,0.55,0.0), 2.1678)) return 0.0;
    if (clusterHit(ro, rd, vec3(-1.2909,0.1698,-0.9951), 0.6546, bestT)) {
        if (triHit(ro, rd, vec3(-1.0909,0.3121,-0.9723), vec3(-1.0745,0.3008,-0.9736), vec3(-1.4623,0.107,-1.2889), vec3(0.3313,0.5658,-0.755), vec2(0.0164,0.5957), vec2(0.4602,0.0317), vec2(0,0), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.4667,0.1179,-1.287), vec3(-1.0909,0.3121,-0.9723), vec3(-1.4623,0.107,-1.2889), vec3(0.4957,0.3377,-0.8001), vec2(0.0083,0.4624), vec2(0.0164,0.5957), vec2(0,0), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.554,0.0446,-1.2521), vec3(-1.5761,0.0279,-1.1594), vec3(-1.5173,0.0753,-1.2809), vec3(-0.6485,0.761,-0.0172), vec2(0.0308,0.4351), vec2(0.0548,0.4341), vec2(0.0182,0.4458), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.4667,0.1179,-1.287), vec3(-1.5173,0.0753,-1.2809), vec3(-1.5761,0.0279,-1.1594), vec3(-0.6451,0.7639,-0.0145), vec2(0.0083,0.4624), vec2(0.0182,0.4458), vec2(0.0548,0.4341), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.5925,-0.0152,-0.9779), vec3(-1.4667,0.1179,-1.287), vec3(-1.5761,0.0279,-1.1594), vec3(-0.5146,0.8436,0.1537), vec2(0.1003,0.436), vec2(0.0083,0.4624), vec2(0.0548,0.4341), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.5925,-0.0152,-0.9779), vec3(-1.0909,0.3121,-0.9723), vec3(-1.4667,0.1179,-1.287), vec3(-0.5425,0.829,0.136), vec2(0.1003,0.436), vec2(0.0164,0.5957), vec2(0.0083,0.4624), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0909,0.3121,-0.9723), vec3(-0.9584,0.3789,-0.9268), vec3(-1.0745,0.3008,-0.9736), vec3(0.1542,0.3284,-0.9319), vec2(0.0164,0.5957), vec2(0.014,0.6331), vec2(0.0116,0.5989), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0909,0.3121,-0.9723), vec3(-1.5925,-0.0152,-0.9779), vec3(-1.0694,0.3338,-0.8269), vec3(-0.5456,0.8369,-0.0441), vec2(0.0164,0.5957), vec2(0.1003,0.436), vec2(0.0489,0.6072), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.5925,-0.0152,-0.9779), vec3(-1.4019,-0.0962,-0.4666), vec3(-1.0694,0.3338,-0.8269), vec3(-0.5879,0.736,0.3358), vec2(0.1003,0.436), vec2(0.1998,0.4692), vec2(0.0489,0.6072), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0909,0.3121,-0.9723), vec3(-0.9822,0.4055,-0.8857), vec3(-0.9584,0.3789,-0.9268), vec3(-0.1822,0.7742,-0.6061), vec2(0.0164,0.5957), vec2(0.0258,0.6326), vec2(0.014,0.6331), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0909,0.3121,-0.9723), vec3(-1.0694,0.3338,-0.8269), vec3(-0.9822,0.4055,-0.8857), vec3(-0.6426,0.766,-0.0191), vec2(0.0164,0.5957), vec2(0.0489,0.6072), vec2(0.0258,0.6326), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0694,0.3338,-0.8269), vec3(-1.4019,-0.0962,-0.4666), vec3(-1.0134,0.339,-0.6198), vec3(-0.7038,0.6891,0.1728), vec2(0.0489,0.6072), vec2(0.1998,0.4692), vec2(0.0934,0.6282), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.5493,0.0331,-1.2541), vec3(-1.5128,0.0643,-1.2827), vec3(-1.5691,0.0039,-1.1663), vec3(0.5816,-0.8022,-0.1348), vec2(0.3462,0.0425), vec2(0.3486,0.0327), vec2(0.354,0.061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.5128,0.0643,-1.2827), vec3(-1.4623,0.107,-1.2889), vec3(-1.5691,0.0039,-1.1663), vec3(0.6366,-0.766,-0.0895), vec2(0.3486,0.0327), vec2(0.3569,0.0249), vec2(0.354,0.061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.5691,0.0039,-1.1663), vec3(-1.4623,0.107,-1.2889), vec3(-1.5843,-0.0363,-0.9851), vec3(0.6134,-0.7803,-0.1217), vec2(0.354,0.061), vec2(0.3569,0.0249), vec2(0.375,0.0962), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0745,0.3008,-0.9736), vec3(-1.5843,-0.0363,-0.9851), vec3(-1.4623,0.107,-1.2889), vec3(0.5463,-0.8207,-0.1677), vec2(0.4602,0.0317), vec2(0.375,0.0962), vec2(0.3569,0.0249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0441,0.3099,-0.8294), vec3(-1.5843,-0.0363,-0.9851), vec3(-1.0745,0.3008,-0.9736), vec3(0.5513,-0.8319,-0.0632), vec2(0.4824,0.0566), vec2(0.375,0.0962), vec2(0.4602,0.0317), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.5843,-0.0363,-0.9851), vec3(-1.0441,0.3099,-0.8294), vec3(-1.3878,-0.1197,-0.4732), vec3(0.5749,-0.7434,-0.3419), vec2(0.375,0.0962), vec2(0.4824,0.0566), vec2(0.4397,0.1743), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0745,0.3008,-0.9736), vec3(-0.9455,0.366,-0.8457), vec3(-1.0441,0.3099,-0.8294), vec3(0.4879,-0.8716,-0.0473), vec2(0.4602,0.0317), vec2(0.4978,0.0459), vec2(0.4824,0.0566), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.9584,0.3789,-0.9268), vec3(-0.9455,0.366,-0.8457), vec3(-1.0745,0.3008,-0.9736), vec3(0.6038,-0.7669,-0.2176), vec2(0.4871,0.0322), vec2(0.4978,0.0459), vec2(0.4602,0.0317), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.9791,0.2901,-0.6211), vec3(-1.3878,-0.1197,-0.4732), vec3(-1.0441,0.3099,-0.8294), vec3(0.6326,-0.7271,-0.2667), vec2(0.5166,0.0957), vec2(0.4397,0.1743), vec2(0.4824,0.0566), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.8525,0.427,-0.5519), 0.8191, bestT)) {
        if (triHit(ro, rd, vec3(-0.9584,0.3789,-0.9268), vec3(-0.9822,0.4055,-0.8857), vec3(-0.8171,0.5139,-0.8054), vec3(-0.2041,0.764,-0.6121), vec2(0.014,0.6331), vec2(0.0258,0.6326), vec2(0.0172,0.6948), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.9584,0.3789,-0.9268), vec3(-0.8171,0.5139,-0.8054), vec3(-0.9455,0.366,-0.8457), vec3(0.7655,-0.6055,-0.2178), vec2(0.4871,0.0322), vec2(0.5356,0.0342), vec2(0.4978,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.9613,0.4165,-0.8138), vec3(-0.9822,0.4055,-0.8857), vec3(-1.0694,0.3338,-0.8269), vec3(-0.6113,0.7894,0.056), vec2(0.0381,0.6428), vec2(0.0258,0.6326), vec2(0.0489,0.6072), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.9822,0.4055,-0.8857), vec3(-0.9613,0.4165,-0.8138), vec3(-0.8507,0.5337,-0.7667), vec3(-0.7447,0.6574,0.115), vec2(0.0258,0.6326), vec2(0.0381,0.6428), vec2(0.0331,0.6912), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8507,0.5337,-0.7667), vec3(-0.8171,0.5139,-0.8054), vec3(-0.9822,0.4055,-0.8857), vec3(-0.2229,0.7761,-0.5899), vec2(0.0331,0.6912), vec2(0.0172,0.6948), vec2(0.0258,0.6326), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.9302,0.3682,-0.77), vec3(-1.0441,0.3099,-0.8294), vec3(-0.9455,0.366,-0.8457), vec3(0.484,-0.872,-0.0725), vec2(0.5098,0.0581), vec2(0.4824,0.0566), vec2(0.4978,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8149,0.4936,-0.7584), vec3(-0.9455,0.366,-0.8457), vec3(-0.8171,0.5139,-0.8054), vec3(0.7606,-0.5825,-0.2866), vec2(0.54,0.0469), vec2(0.4978,0.0459), vec2(0.5356,0.0342), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.9455,0.366,-0.8457), vec3(-0.8149,0.4936,-0.7584), vec3(-0.9302,0.3682,-0.77), vec3(0.7358,-0.6648,-0.1292), vec2(0.4978,0.0459), vec2(0.54,0.0469), vec2(0.5098,0.0581), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8171,0.5139,-0.8054), vec3(-0.8507,0.5337,-0.7667), vec3(-0.6658,0.6363,-0.7412), vec3(-0.3081,0.7119,-0.6311), vec2(0.0172,0.6948), vec2(0.0331,0.6912), vec2(0.0175,0.7574), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8681,0.5331,-0.7004), vec3(-0.8507,0.5337,-0.7667), vec3(-0.9613,0.4165,-0.8138), vec3(-0.6806,0.7122,-0.1722), vec2(0.0525,0.6885), vec2(0.0331,0.6912), vec2(0.0381,0.6428), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0694,0.3338,-0.8269), vec3(-1.0134,0.339,-0.6198), vec3(-0.9613,0.4165,-0.8138), vec3(-0.6126,0.7768,0.146), vec2(0.0489,0.6072), vec2(0.0934,0.6282), vec2(0.0381,0.6428), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8149,0.4936,-0.7584), vec3(-0.8171,0.5139,-0.8054), vec3(-0.6485,0.613,-0.6855), vec3(0.6413,-0.6932,-0.329), vec2(0.54,0.0469), vec2(0.5356,0.0342), vec2(0.5928,0.0532), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6658,0.6363,-0.7412), vec3(-0.6485,0.613,-0.6855), vec3(-0.8171,0.5139,-0.8054), vec3(0.6689,-0.5882,-0.4546), vec2(0.585,0.0381), vec2(0.5928,0.0532), vec2(0.5356,0.0342), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0441,0.3099,-0.8294), vec3(-0.9302,0.3682,-0.77), vec3(-0.9791,0.2901,-0.6211), vec3(0.54,-0.8051,-0.2453), vec2(0.4824,0.0566), vec2(0.5098,0.0581), vec2(0.5166,0.0957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8128,0.4694,-0.6829), vec3(-0.9302,0.3682,-0.77), vec3(-0.8149,0.4936,-0.7584), vec3(0.7271,-0.6477,-0.2278), vec2(0.5469,0.0659), vec2(0.5098,0.0581), vec2(0.54,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6961,0.6659,-0.6858), vec3(-0.6658,0.6363,-0.7412), vec3(-0.8507,0.5337,-0.7667), vec3(-0.333,0.744,-0.5793), vec2(0.0387,0.755), vec2(0.0175,0.7574), vec2(0.0331,0.6912), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8681,0.5331,-0.7004), vec3(-0.9613,0.4165,-0.8138), vec3(-0.9278,0.4662,-0.6751), vec3(-0.7545,0.6543,-0.0518), vec2(0.0525,0.6885), vec2(0.0381,0.6428), vec2(0.0659,0.6641), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8507,0.5337,-0.7667), vec3(-0.8681,0.5331,-0.7004), vec3(-0.6961,0.6659,-0.6858), vec3(-0.5963,0.7887,-0.1494), vec2(0.0331,0.6912), vec2(0.0525,0.6885), vec2(0.0387,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8128,0.4694,-0.6829), vec3(-0.8149,0.4936,-0.7584), vec3(-0.6485,0.613,-0.6855), vec3(0.6345,-0.7308,-0.2519), vec2(0.5469,0.0659), vec2(0.54,0.0469), vec2(0.5928,0.0532), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8732,0.4,-0.6602), vec3(-0.9302,0.3682,-0.77), vec3(-0.8128,0.4694,-0.6829), vec3(0.7138,-0.6782,-0.1745), vec2(0.5337,0.0767), vec2(0.5098,0.0581), vec2(0.5469,0.0659), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.9278,0.4662,-0.6751), vec3(-0.9613,0.4165,-0.8138), vec3(-1.0134,0.339,-0.6198), vec3(-0.8294,0.5587,0.0005), vec2(0.0659,0.6641), vec2(0.0381,0.6428), vec2(0.0934,0.6282), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8732,0.4,-0.6602), vec3(-0.9791,0.2901,-0.6211), vec3(-0.9302,0.3682,-0.77), vec3(0.6849,-0.7131,-0.1493), vec2(0.5337,0.0767), vec2(0.5166,0.0957), vec2(0.5098,0.0581), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6658,0.6363,-0.7412), vec3(-0.6961,0.6659,-0.6858), vec3(-0.4573,0.813,-0.6081), vec3(-0.289,0.7699,-0.569), vec2(0.0175,0.7574), vec2(0.0387,0.755), vec2(0.0175,0.8508), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6658,0.6363,-0.7412), vec3(-0.4573,0.813,-0.6081), vec3(-0.6485,0.613,-0.6855), vec3(0.7271,-0.5226,-0.4453), vec2(0.585,0.0381), vec2(0.6582,0.0444), vec2(0.5928,0.0532), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7097,0.6698,-0.5931), vec3(-0.6961,0.6659,-0.6858), vec3(-0.8681,0.5331,-0.7004), vec3(-0.6001,0.7906,-0.1219), vec2(0.0676,0.7512), vec2(0.0387,0.755), vec2(0.0525,0.6885), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8852,0.4863,-0.5724), vec3(-0.8681,0.5331,-0.7004), vec3(-0.9278,0.4662,-0.6751), vec3(-0.7059,0.6904,0.1581), vec2(0.0903,0.6775), vec2(0.0525,0.6885), vec2(0.0659,0.6641), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8128,0.4694,-0.6829), vec3(-0.6485,0.613,-0.6855), vec3(-0.6452,0.587,-0.5472), vec3(0.6486,-0.7451,-0.1554), vec2(0.5469,0.0659), vec2(0.5928,0.0532), vec2(0.6055,0.0903), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8732,0.4,-0.6602), vec3(-0.8128,0.4694,-0.6829), vec3(-0.8165,0.4164,-0.5583), vec3(0.6813,-0.6808,-0.269), vec2(0.5337,0.0767), vec2(0.5469,0.0659), vec2(0.5562,0.0977), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0134,0.339,-0.6198), vec3(-0.8852,0.4863,-0.5724), vec3(-0.9278,0.4662,-0.6751), vec3(-0.7698,0.6057,0.2012), vec2(0.0934,0.6282), vec2(0.0903,0.6775), vec2(0.0659,0.6641), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8681,0.5331,-0.7004), vec3(-0.8852,0.4863,-0.5724), vec3(-0.7097,0.6698,-0.5931), vec3(-0.7047,0.6916,0.1587), vec2(0.0525,0.6885), vec2(0.0903,0.6775), vec2(0.0676,0.7512), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6961,0.6659,-0.6858), vec3(-0.7097,0.6698,-0.5931), vec3(-0.5132,0.8254,-0.5758), vec3(-0.6094,0.7833,-0.123), vec2(0.0387,0.755), vec2(0.0676,0.7512), vec2(0.041,0.8383), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8732,0.4,-0.6602), vec3(-0.8165,0.4164,-0.5583), vec3(-0.9791,0.2901,-0.6211), vec3(0.6523,-0.7165,-0.2472), vec2(0.5337,0.0767), vec2(0.5562,0.0977), vec2(0.5166,0.0957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6485,0.613,-0.6855), vec3(-0.4271,0.7659,-0.556), vec3(-0.6452,0.587,-0.5472), vec3(0.6223,-0.7665,-0.1588), vec2(0.5928,0.0532), vec2(0.6665,0.0669), vec2(0.6055,0.0903), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8128,0.4694,-0.6829), vec3(-0.6452,0.587,-0.5472), vec3(-0.8165,0.4164,-0.5583), vec3(0.6886,-0.6745,-0.2661), vec2(0.5469,0.0659), vec2(0.6055,0.0903), vec2(0.5562,0.0977), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0134,0.339,-0.6198), vec3(-0.9234,0.3395,-0.4336), vec3(-0.8852,0.4863,-0.5724), vec3(-0.7571,0.5421,0.3646), vec2(0.0934,0.6282), vec2(0.1436,0.6477), vec2(0.0903,0.6775), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8165,0.4164,-0.5583), vec3(-0.8837,0.291,-0.4327), vec3(-0.9791,0.2901,-0.6211), vec3(0.6555,-0.6799,-0.3289), vec2(0.5562,0.0977), vec2(0.5532,0.1372), vec2(0.5166,0.0957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7823,0.5185,-0.4423), vec3(-0.7097,0.6698,-0.5931), vec3(-0.8852,0.4863,-0.5724), vec3(-0.656,0.667,0.3533), vec2(0.1287,0.7048), vec2(0.0676,0.7512), vec2(0.0903,0.6775), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7109,0.4505,-0.4305), vec3(-0.8165,0.4164,-0.5583), vec3(-0.6452,0.587,-0.5472), vec3(0.6652,-0.6437,-0.3784), vec2(0.5942,0.1309), vec2(0.5562,0.0977), vec2(0.6055,0.0903), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7823,0.5185,-0.4423), vec3(-0.8852,0.4863,-0.5724), vec3(-0.9234,0.3395,-0.4336), vec3(-0.7048,0.5757,0.4145), vec2(0.1287,0.7048), vec2(0.0903,0.6775), vec2(0.1436,0.6477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8837,0.291,-0.4327), vec3(-0.8165,0.4164,-0.5583), vec3(-0.7109,0.4505,-0.4305), vec3(0.6391,-0.6874,-0.3451), vec2(0.5532,0.1372), vec2(0.5562,0.0977), vec2(0.5942,0.1309), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7222,0.5337,-0.3307), vec3(-0.7097,0.6698,-0.5931), vec3(-0.7823,0.5185,-0.4423), vec3(-0.7114,0.6371,0.2966), vec2(0.1591,0.7239), vec2(0.0676,0.7512), vec2(0.1287,0.7048), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.3878,-0.1197,-0.4732), vec3(-0.9791,0.2901,-0.6211), vec3(-1.2583,-0.0633,-0.244), vec3(0.6589,-0.7269,-0.1934), vec2(0.4397,0.1743), vec2(0.5166,0.0957), vec2(0.4917,0.2139), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.2764,-0.0455,-0.2434), vec3(-1.0134,0.339,-0.6198), vec3(-1.4019,-0.0962,-0.4666), vec3(-0.6851,0.6918,0.228), vec2(0.2474,0.5112), vec2(0.0934,0.6282), vec2(0.1998,0.4692), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8837,0.291,-0.4327), vec3(-1.2583,-0.0633,-0.244), vec3(-0.9791,0.2901,-0.6211), vec3(0.577,-0.764,-0.2887), vec2(0.5532,0.1372), vec2(0.4917,0.2139), vec2(0.5166,0.0957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0134,0.339,-0.6198), vec3(-1.2764,-0.0455,-0.2434), vec3(-0.9234,0.3395,-0.4336), vec3(-0.6246,0.721,0.3001), vec2(0.0934,0.6282), vec2(0.2474,0.5112), vec2(0.1436,0.6477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7109,0.4505,-0.4305), vec3(-0.6452,0.587,-0.5472), vec3(-0.6522,0.475,-0.3119), vec3(0.7662,-0.5888,-0.2574), vec2(0.5942,0.1309), vec2(0.6055,0.0903), vec2(0.6216,0.1567), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5398,0.8028,-0.3826), vec3(-0.7097,0.6698,-0.5931), vec3(-0.6502,0.5963,-0.2365), vec3(-0.7695,0.5878,0.2496), vec2(0.113,0.8263), vec2(0.0676,0.7512), vec2(0.177,0.7528), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8192,0.3716,-0.2887), vec3(-0.7823,0.5185,-0.4423), vec3(-0.9234,0.3395,-0.4336), vec3(-0.7155,0.5827,0.3854), vec2(0.1854,0.6741), vec2(0.1287,0.7048), vec2(0.1436,0.6477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7097,0.6698,-0.5931), vec3(-0.7222,0.5337,-0.3307), vec3(-0.6502,0.5963,-0.2365), vec3(-0.7991,0.5483,0.2464), vec2(0.0676,0.7512), vec2(0.1591,0.7239), vec2(0.177,0.7528), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8837,0.291,-0.4327), vec3(-0.7109,0.4505,-0.4305), vec3(-0.7905,0.3386,-0.2854), vec3(0.6674,-0.7202,-0.1894), vec2(0.5532,0.1372), vec2(0.5942,0.1309), vec2(0.5903,0.1714), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8192,0.3716,-0.2887), vec3(-0.7222,0.5337,-0.3307), vec3(-0.7823,0.5185,-0.4423), vec3(-0.7661,0.5464,0.3385), vec2(0.1854,0.6741), vec2(0.1591,0.7239), vec2(0.1287,0.7048), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5739,0.58,-0.1872), vec3(-0.6522,0.475,-0.3119), vec3(-0.6452,0.587,-0.5472), vec3(0.8797,-0.439,-0.1827), vec2(0.6597,0.1782), vec2(0.6216,0.1567), vec2(0.6055,0.0903), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7905,0.3386,-0.2854), vec3(-0.7109,0.4505,-0.4305), vec3(-0.6522,0.475,-0.3119), vec3(0.6721,-0.7171,-0.1844), vec2(0.5903,0.1714), vec2(0.5942,0.1309), vec2(0.6216,0.1567), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.9234,0.3395,-0.4336), vec3(-1.1563,0.0227,-0.0783), vec3(-0.8192,0.3716,-0.2887), vec3(-0.6061,0.7482,0.2699), vec2(0.1436,0.6477), vec2(0.2808,0.553), vec2(0.1854,0.6741), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8837,0.291,-0.4327), vec3(-0.7905,0.3386,-0.2854), vec3(-1.1451,0.0092,-0.0769), vec3(0.625,-0.7665,-0.1477), vec2(0.5532,0.1372), vec2(0.5903,0.1714), vec2(0.5356,0.2417), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8192,0.3716,-0.2887), vec3(-0.7287,0.4342,-0.1501), vec3(-0.7222,0.5337,-0.3307), vec3(-0.7931,0.5452,0.2714), vec2(0.1854,0.6741), vec2(0.2158,0.7061), vec2(0.1591,0.7239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.1563,0.0227,-0.0783), vec3(-0.9234,0.3395,-0.4336), vec3(-1.2764,-0.0455,-0.2434), vec3(-0.673,0.7135,0.195), vec2(0.2808,0.553), vec2(0.1436,0.6477), vec2(0.2474,0.5112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.2583,-0.0633,-0.244), vec3(-0.8837,0.291,-0.4327), vec3(-1.1451,0.0092,-0.0769), vec3(0.6511,-0.7501,-0.1156), vec2(0.4917,0.2139), vec2(0.5532,0.1372), vec2(0.5356,0.2417), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7905,0.3386,-0.2854), vec3(-0.6522,0.475,-0.3119), vec3(-0.707,0.41,-0.1454), vec3(0.6965,-0.7158,-0.0503), vec2(0.5903,0.1714), vec2(0.6216,0.1567), vec2(0.6265,0.1968), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8192,0.3716,-0.2887), vec3(-1.0356,0.1474,0.0736), vec3(-0.7287,0.4342,-0.1501), vec3(-0.6484,0.757,0.0813), vec2(0.1854,0.6741), vec2(0.3049,0.6011), vec2(0.2158,0.7061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7905,0.3386,-0.2854), vec3(-0.707,0.41,-0.1454), vec3(-1.0292,0.1387,0.0741), vec3(0.6458,-0.7635,0.0043), vec2(0.5903,0.1714), vec2(0.6265,0.1968), vec2(0.5811,0.2627), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0356,0.1474,0.0736), vec3(-0.8192,0.3716,-0.2887), vec3(-1.1563,0.0227,-0.0783), vec3(-0.719,0.6951,0.0008), vec2(0.3049,0.6011), vec2(0.1854,0.6741), vec2(0.2808,0.553), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-1.0292,0.1387,0.0741), vec3(-1.1451,0.0092,-0.0769), vec3(-0.7905,0.3386,-0.2854), vec3(0.7008,-0.7098,0.0707), vec2(0.5811,0.2627), vec2(0.5356,0.2417), vec2(0.5903,0.1714), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.2476,0.8402,-0.4439), 0.6195, bestT)) {
        if (triHit(ro, rd, vec3(-0.5411,0.8112,-0.5006), vec3(-0.7097,0.6698,-0.5931), vec3(-0.5398,0.8028,-0.3826), vec3(-0.6605,0.7484,0.0602), vec2(0.0714,0.8306), vec2(0.0676,0.7512), vec2(0.113,0.8263), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5411,0.8112,-0.5006), vec3(-0.5132,0.8254,-0.5758), vec3(-0.7097,0.6698,-0.5931), vec3(-0.6145,0.7849,-0.0794), vec2(0.0714,0.8306), vec2(0.041,0.8383), vec2(0.0676,0.7512), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5132,0.8254,-0.5758), vec3(-0.4573,0.813,-0.6081), vec3(-0.6961,0.6659,-0.6858), vec3(-0.2239,0.714,-0.6634), vec2(0.041,0.8383), vec2(0.0175,0.8508), vec2(0.0387,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4271,0.7659,-0.556), vec3(-0.6485,0.613,-0.6855), vec3(-0.4573,0.813,-0.6081), vec3(0.6405,-0.3468,-0.6852), vec2(0.6665,0.0669), vec2(0.5928,0.0532), vec2(0.6582,0.0444), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4043,0.6999,-0.4812), vec3(-0.6452,0.587,-0.5472), vec3(-0.4271,0.7659,-0.556), vec3(0.4589,-0.592,-0.6625), vec2(0.6753,0.0967), vec2(0.6055,0.0903), vec2(0.6665,0.0669), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.415,0.6746,-0.417), vec3(-0.6452,0.587,-0.5472), vec3(-0.4043,0.6999,-0.4812), vec3(0.4667,-0.8466,-0.2557), vec2(0.6772,0.1162), vec2(0.6055,0.0903), vec2(0.6753,0.0967), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5411,0.8112,-0.5006), vec3(-0.5398,0.8028,-0.3826), vec3(-0.3622,1.0353,-0.402), vec3(-0.7915,0.609,0.0517), vec2(0.0714,0.8306), vec2(0.113,0.8263), vec2(0.0729,0.9232), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5132,0.8254,-0.5758), vec3(-0.5411,0.8112,-0.5006), vec3(-0.3622,1.0353,-0.402), vec3(-0.7395,0.6562,-0.15), vec2(0.041,0.8383), vec2(0.0714,0.8306), vec2(0.0729,0.9232), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4084,1.0733,-0.2135), vec3(-0.3622,1.0353,-0.402), vec3(-0.5398,0.8028,-0.3826), vec3(-0.7695,0.5627,-0.3021), vec2(0.1307,0.9007), vec2(0.0729,0.9232), vec2(0.113,0.8263), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4573,0.813,-0.6081), vec3(-0.5132,0.8254,-0.5758), vec3(-0.3053,1.048,-0.5052), vec3(-0.3235,0.5472,-0.7719), vec2(0.0175,0.8508), vec2(0.041,0.8383), vec2(0.0388,0.9443), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3608,0.7702,-0.2462), vec3(-0.4433,0.8552,-0.0938), vec3(-0.415,0.6746,-0.417), vec3(0.0028,-0.8729,0.488), vec2(0.7378,0.1396), vec2(0.7397,0.1714), vec2(0.6772,0.1162), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3622,1.0353,-0.402), vec3(-0.3053,1.048,-0.5052), vec3(-0.5132,0.8254,-0.5758), vec3(-0.6571,0.7014,-0.2762), vec2(0.0729,0.9232), vec2(0.0388,0.9443), vec2(0.041,0.8383), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4271,0.7659,-0.556), vec3(-0.4573,0.813,-0.6081), vec3(-0.2216,0.9231,-0.5136), vec3(0.5089,-0.4705,-0.7208), vec2(0.6665,0.0669), vec2(0.6582,0.0444), vec2(0.7339,0.0747), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4043,0.6999,-0.4812), vec3(-0.2746,0.7941,-0.3544), vec3(-0.415,0.6746,-0.417), vec3(0.6813,-0.7127,-0.167), vec2(0.6753,0.0967), vec2(0.7344,0.1177), vec2(0.6772,0.1162), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3598,1.0755,-0.1564), vec3(-0.3049,0.9793,-0.3356), vec3(-0.4054,0.959,-0.1428), vec3(-0.8612,0.288,-0.4188), vec2(0.5923,0.6455), vec2(0.6465,0.6724), vec2(0.6128,0.6121), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4271,0.7659,-0.556), vec3(-0.2238,0.8632,-0.447), vec3(-0.4043,0.6999,-0.4812), vec3(0.5834,-0.5124,-0.6301), vec2(0.6665,0.0669), vec2(0.7319,0.0942), vec2(0.6753,0.0967), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3608,0.7702,-0.2462), vec3(-0.415,0.6746,-0.417), vec3(-0.2746,0.7941,-0.3544), vec3(0.5533,-0.7892,0.2665), vec2(0.7378,0.1396), vec2(0.6772,0.1162), vec2(0.7344,0.1177), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2689,0.8473,-0.3647), vec3(-0.3608,0.7702,-0.2462), vec3(-0.4054,0.959,-0.1428), vec3(-0.8195,0.1141,-0.5616), vec2(0.6782,0.6387), vec2(0.6768,0.592), vec2(0.6128,0.6121), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3053,1.048,-0.5052), vec3(-0.2526,0.9919,-0.5493), vec3(-0.4573,0.813,-0.6081), vec3(-0.1873,0.4931,-0.8496), vec2(0.0388,0.9443), vec2(0.0115,0.9512), vec2(0.0175,0.8508), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3608,0.7702,-0.2462), vec3(-0.2746,0.7941,-0.3544), vec3(-0.377,0.6763,-0.2198), vec3(-0.7768,-0.0431,-0.6283), vec2(0.9258,0.3682), vec2(0.9224,0.3472), vec2(0.8945,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4084,1.0733,-0.2135), vec3(-0.2181,1.209,-0.2888), vec3(-0.3622,1.0353,-0.402), vec3(-0.6295,0.7171,-0.299), vec2(0.1307,0.9007), vec2(0.0942,0.9587), vec2(0.0729,0.9232), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2689,0.8473,-0.3647), vec3(-0.4054,0.959,-0.1428), vec3(-0.3049,0.9793,-0.3356), vec3(-0.8728,-0.1345,-0.4692), vec2(0.6782,0.6387), vec2(0.6128,0.6121), vec2(0.6465,0.6724), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2978,1.1071,-0.3083), vec3(-0.3049,0.9793,-0.3356), vec3(-0.3598,1.0755,-0.1564), vec3(-0.9272,0.1266,-0.3524), vec2(0.6216,0.6965), vec2(0.6465,0.6724), vec2(0.5923,0.6455), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3598,1.0755,-0.1564), vec3(-0.304,1.1638,-0.1397), vec3(-0.2978,1.1071,-0.3083), vec3(-0.8065,0.5508,-0.215), vec2(0.5923,0.6455), vec2(0.5713,0.667), vec2(0.6216,0.6965), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2935,0.5622,-0.2445), vec3(-0.377,0.6763,-0.2198), vec3(-0.2773,0.59,-0.338), vec3(-0.8007,-0.5223,-0.2936), vec2(0.8633,0.3774), vec2(0.8945,0.3745), vec2(0.8613,0.3623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2526,0.9919,-0.5493), vec3(-0.2216,0.9231,-0.5136), vec3(-0.4573,0.813,-0.6081), vec3(0.4559,-0.2402,-0.857), vec2(0.7368,0.0562), vec2(0.7339,0.0747), vec2(0.6582,0.0444), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2689,0.8473,-0.3647), vec3(-0.2746,0.7941,-0.3544), vec3(-0.3608,0.7702,-0.2462), vec3(-0.7776,-0.0372,-0.6276), vec2(0.6782,0.6387), vec2(0.6948,0.6187), vec2(0.6768,0.592), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2746,0.7941,-0.3544), vec3(-0.4043,0.6999,-0.4812), vec3(-0.2238,0.8632,-0.447), vec3(0.6789,-0.7161,-0.1619), vec2(0.7344,0.1177), vec2(0.6753,0.0967), vec2(0.7319,0.0942), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3622,1.0353,-0.402), vec3(-0.2236,1.1887,-0.3703), vec3(-0.3053,1.048,-0.5052), vec3(-0.6788,0.6739,-0.2916), vec2(0.0729,0.9232), vec2(0.0743,0.9632), vec2(0.0388,0.9443), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2978,1.1071,-0.3083), vec3(-0.2784,0.9895,-0.3963), vec3(-0.3049,0.9793,-0.3356), vec3(-0.9166,0.1314,-0.3777), vec2(0.6216,0.6965), vec2(0.6606,0.6909), vec2(0.6465,0.6724), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2216,0.9231,-0.5136), vec3(-0.2238,0.8632,-0.447), vec3(-0.4271,0.7659,-0.556), vec3(0.5807,-0.6147,-0.5338), vec2(0.7339,0.0747), vec2(0.7319,0.0942), vec2(0.6665,0.0669), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.377,0.6763,-0.2198), vec3(-0.2086,0.7514,-0.4775), vec3(-0.2773,0.59,-0.338), vec3(-0.8072,-0.1497,-0.571), vec2(0.8945,0.3745), vec2(0.8813,0.3306), vec2(0.8613,0.3623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2086,0.7514,-0.4775), vec3(-0.377,0.6763,-0.2198), vec3(-0.2746,0.7941,-0.3544), vec3(-0.8471,0.1552,-0.5082), vec2(0.8813,0.3306), vec2(0.8945,0.3745), vec2(0.9224,0.3472), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3049,0.9793,-0.3356), vec3(-0.2784,0.9895,-0.3963), vec3(-0.2689,0.8473,-0.3647), vec3(-0.8963,-0.1526,-0.4163), vec2(0.6465,0.6724), vec2(0.6606,0.6909), vec2(0.6782,0.6387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2784,0.9895,-0.3963), vec3(-0.2978,1.1071,-0.3083), vec3(-0.2669,1.0238,-0.422), vec3(-0.9456,0.0801,-0.3154), vec2(0.6606,0.6909), vec2(0.6216,0.6965), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2098,1.2248,-0.123), vec3(-0.2181,1.209,-0.2888), vec3(-0.4084,1.0733,-0.2135), vec3(-0.5922,0.8045,-0.047), vec2(0.1346,0.9552), vec2(0.0942,0.9587), vec2(0.1307,0.9007), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2978,1.1071,-0.3083), vec3(-0.304,1.1638,-0.1397), vec3(-0.2181,1.209,-0.2888), vec3(-0.7423,0.6263,-0.238), vec2(0.6216,0.6965), vec2(0.5713,0.667), vec2(0.5986,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2236,1.1887,-0.3703), vec3(-0.3622,1.0353,-0.402), vec3(-0.2181,1.209,-0.2888), vec3(-0.7238,0.6793,-0.1209), vec2(0.0743,0.9632), vec2(0.0729,0.9232), vec2(0.0942,0.9587), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2935,0.5622,-0.2445), vec3(-0.2773,0.59,-0.338), vec3(-0.219,0.473,-0.27), vec3(-0.7725,-0.5598,-0.2999), vec2(0.8633,0.3774), vec2(0.8613,0.3623), vec2(0.8379,0.3799), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2978,1.1071,-0.3083), vec3(-0.2181,1.209,-0.2888), vec3(-0.2669,1.0238,-0.422), vec3(-0.5862,0.5692,-0.5765), vec2(0.6216,0.6965), vec2(0.5986,0.7261), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2238,0.8632,-0.447), vec3(-0.2689,0.8473,-0.3647), vec3(-0.2784,0.9895,-0.3963), vec3(-0.8504,-0.1678,-0.4986), vec2(0.7051,0.6558), vec2(0.6782,0.6387), vec2(0.6606,0.6909), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2689,0.8473,-0.3647), vec3(-0.2238,0.8632,-0.447), vec3(-0.2746,0.7941,-0.3544), vec3(-0.8771,0.002,-0.4803), vec2(0.6782,0.6387), vec2(0.7051,0.6558), vec2(0.6948,0.6187), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2669,1.0238,-0.422), vec3(-0.2078,0.921,-0.5), vec3(-0.2784,0.9895,-0.3963), vec3(-0.8519,-0.0995,-0.5142), vec2(0.6636,0.7075), vec2(0.7139,0.6836), vec2(0.6606,0.6909), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2526,0.9919,-0.5493), vec3(-0.3053,1.048,-0.5052), vec3(-0.1928,1.0904,-0.616), vec3(-0.6854,-0.0736,-0.7244), vec2(0.0115,0.9512), vec2(0.0388,0.9443), vec2(0.0097,0.9876), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1965,1.1708,-0.4782), vec3(-0.3053,1.048,-0.5052), vec3(-0.2236,1.1887,-0.3703), vec3(-0.6862,0.6701,-0.2831), vec2(0.0479,0.9786), vec2(0.0388,0.9443), vec2(0.0743,0.9632), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2238,0.8632,-0.447), vec3(-0.2784,0.9895,-0.3963), vec3(-0.2078,0.921,-0.5), vec3(-0.8652,-0.1877,-0.465), vec2(0.7051,0.6558), vec2(0.6606,0.6909), vec2(0.7139,0.6836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2181,1.209,-0.2888), vec3(-0.2236,1.1887,-0.3703), vec3(-0.2669,1.0238,-0.422), vec3(-0.9672,0.2541,0.0015), vec2(0.5986,0.7261), vec2(0.625,0.74), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2669,1.0238,-0.422), vec3(-0.2216,1.0497,-0.5036), vec3(-0.2078,0.921,-0.5), vec3(-0.8548,-0.1059,-0.508), vec2(0.6636,0.7075), vec2(0.6914,0.731), vec2(0.7139,0.6836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3053,1.048,-0.5052), vec3(-0.1965,1.1708,-0.4782), vec3(-0.1928,1.0904,-0.616), vec3(-0.6407,0.6555,-0.3998), vec2(0.0388,0.9443), vec2(0.0479,0.9786), vec2(0.0097,0.9876), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2077,0.6509,-0.4974), vec3(-0.2773,0.59,-0.338), vec3(-0.2086,0.7514,-0.4775), vec3(-0.9234,0.0664,-0.3781), vec2(0.8564,0.333), vec2(0.8613,0.3623), vec2(0.8813,0.3306), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2238,0.8632,-0.447), vec3(-0.1891,0.8679,-0.5436), vec3(-0.2746,0.7941,-0.3544), vec3(-0.9152,0.2485,-0.3171), vec2(0.9253,0.3237), vec2(0.8999,0.3076), vec2(0.9224,0.3472), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2236,1.1887,-0.3703), vec3(-0.1965,1.1708,-0.4782), vec3(-0.2669,1.0238,-0.422), vec3(-0.9029,0.3256,-0.2806), vec2(0.625,0.74), vec2(0.6626,0.7659), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2216,1.0497,-0.5036), vec3(-0.2669,1.0238,-0.422), vec3(-0.1965,1.1708,-0.4782), vec3(-0.8761,0.2663,-0.402), vec2(0.6914,0.731), vec2(0.6636,0.7075), vec2(0.6626,0.7659), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1887,0.5059,-0.4074), vec3(-0.219,0.473,-0.27), vec3(-0.2773,0.59,-0.338), vec3(-0.7702,-0.5609,-0.3036), vec2(0.8335,0.3569), vec2(0.8379,0.3799), vec2(0.8613,0.3623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2021,0.945,-0.5254), vec3(-0.2216,0.9231,-0.5136), vec3(-0.2526,0.9919,-0.5493), vec3(-0.0121,-0.4655,-0.885), vec2(0.7417,0.0767), vec2(0.7339,0.0747), vec2(0.7368,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2746,0.7941,-0.3544), vec3(-0.1891,0.8679,-0.5436), vec3(-0.2086,0.7514,-0.4775), vec3(-0.8909,-0.1013,-0.4427), vec2(0.9224,0.3472), vec2(0.8999,0.3076), vec2(0.8813,0.3306), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2216,0.9231,-0.5136), vec3(-0.2078,0.921,-0.5), vec3(-0.2238,0.8632,-0.447), vec3(0.4698,-0.664,-0.5817), vec2(0.7339,0.0747), vec2(0.7373,0.0801), vec2(0.7319,0.0942), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2077,0.6509,-0.4974), vec3(-0.1641,0.5523,-0.5125), vec3(-0.2773,0.59,-0.338), vec3(-0.8293,-0.2944,-0.4749), vec2(0.8564,0.333), vec2(0.8335,0.334), vec2(0.8613,0.3623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2021,0.945,-0.5254), vec3(-0.2526,0.9919,-0.5493), vec3(-0.1928,1.0904,-0.616), vec3(-0.0832,-0.5233,-0.8481), vec2(0.7417,0.0767), vec2(0.7368,0.0562), vec2(0.7651,0.0596), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2021,0.945,-0.5254), vec3(-0.2078,0.921,-0.5), vec3(-0.2216,1.0497,-0.5036), vec3(-0.9419,-0.1098,-0.3173), vec2(0.7202,0.6946), vec2(0.7139,0.6836), vec2(0.6914,0.731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2216,0.9231,-0.5136), vec3(-0.2021,0.945,-0.5254), vec3(-0.2078,0.921,-0.5), vec3(0.4441,-0.6985,-0.5611), vec2(0.7339,0.0747), vec2(0.7417,0.0767), vec2(0.7373,0.0801), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1887,0.5059,-0.4074), vec3(-0.2773,0.59,-0.338), vec3(-0.1641,0.5523,-0.5125), vec3(-0.7761,-0.4891,-0.3981), vec2(0.8335,0.3569), vec2(0.8613,0.3623), vec2(0.8335,0.334), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2078,0.921,-0.5), vec3(-0.1891,0.8679,-0.5436), vec3(-0.2238,0.8632,-0.447), vec3(-0.9388,-0.0528,-0.3403), vec2(0.9258,0.3066), vec2(0.8999,0.3076), vec2(0.9253,0.3237), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1917,0.9951,-0.6299), vec3(-0.2021,0.945,-0.5254), vec3(-0.2216,1.0497,-0.5036), vec3(-0.9749,-0.1472,-0.1672), vec2(0.7549,0.7261), vec2(0.7202,0.6946), vec2(0.6914,0.731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2021,0.945,-0.5254), vec3(-0.1891,0.8679,-0.5436), vec3(-0.2078,0.921,-0.5), vec3(-0.9497,-0.0897,-0.3), vec2(0.9243,0.2998), vec2(0.8999,0.3076), vec2(0.9258,0.3066), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1811,0.7795,-0.589), vec3(-0.2086,0.7514,-0.4775), vec3(-0.1891,0.8679,-0.5436), vec3(-0.9722,0.0318,-0.232), vec2(0.875,0.3071), vec2(0.8813,0.3306), vec2(0.8999,0.3076), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2021,0.945,-0.5254), vec3(-0.1917,0.9951,-0.6299), vec3(-0.1787,0.9141,-0.6864), vec3(-0.9892,-0.0674,-0.1304), vec2(0.9243,0.2998), vec2(0.915,0.2778), vec2(0.8931,0.2773), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1891,0.8679,-0.5436), vec3(-0.2021,0.945,-0.5254), vec3(-0.1787,0.9141,-0.6864), vec3(-0.9835,-0.139,-0.1158), vec2(0.8999,0.3076), vec2(0.9243,0.2998), vec2(0.8931,0.2773), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1437,0.6251,-0.6071), vec3(-0.2077,0.6509,-0.4974), vec3(-0.2086,0.7514,-0.4775), vec3(-0.8502,0.0947,-0.5179), vec2(0.8389,0.3125), vec2(0.8564,0.333), vec2(0.8813,0.3306), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2181,1.209,-0.2888), vec3(-0.1183,1.2581,-0.2881), vec3(-0.2236,1.1887,-0.3703), vec3(-0.4324,0.8813,-0.1908), vec2(0.5986,0.7261), vec2(0.5781,0.7605), vec2(0.625,0.74), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2181,1.209,-0.2888), vec3(-0.2098,1.2248,-0.123), vec3(-0.1183,1.2581,-0.2881), vec3(-0.4403,0.8956,-0.0633), vec2(0.5986,0.7261), vec2(0.5479,0.6924), vec2(0.5781,0.7605), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1965,1.1708,-0.4782), vec3(-0.2236,1.1887,-0.3703), vec3(-0.1165,1.2459,-0.4606), vec3(-0.6245,0.7301,-0.2775), vec2(0.6626,0.7659), vec2(0.625,0.74), vec2(0.6309,0.8002), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1811,0.7795,-0.589), vec3(-0.1891,0.8679,-0.5436), vec3(-0.1645,0.8068,-0.6892), vec3(-0.9864,-0.0042,-0.1645), vec2(0.875,0.3071), vec2(0.8999,0.3076), vec2(0.8716,0.2856), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1887,0.5059,-0.4074), vec3(-0.1263,0.4734,-0.4239), vec3(-0.219,0.473,-0.27), vec3(-0.5022,-0.8095,-0.3041), vec2(0.8125,0.5249), vec2(0.835,0.5125), vec2(0.7827,0.4976), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2086,0.7514,-0.4775), vec3(-0.1811,0.7795,-0.589), vec3(-0.1437,0.6251,-0.6071), vec3(-0.9398,-0.1944,-0.281), vec2(0.8813,0.3306), vec2(0.875,0.3071), vec2(0.8389,0.3125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1787,0.9141,-0.6864), vec3(-0.1645,0.8068,-0.6892), vec3(-0.1891,0.8679,-0.5436), vec3(-0.9854,-0.1279,-0.1124), vec2(0.8931,0.2773), vec2(0.8716,0.2856), vec2(0.8999,0.3076), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1641,0.5523,-0.5125), vec3(-0.2077,0.6509,-0.4974), vec3(-0.1437,0.6251,-0.6071), vec3(-0.8509,-0.312,-0.4226), vec2(0.8335,0.334), vec2(0.8564,0.333), vec2(0.8389,0.3125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1811,0.7795,-0.589), vec3(-0.1645,0.8068,-0.6892), vec3(-0.1552,0.6968,-0.6602), vec3(-0.971,-0.1346,-0.1976), vec2(0.875,0.3071), vec2(0.8716,0.2856), vec2(0.8511,0.2983), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1381,0.4368,-0.3007), vec3(-0.219,0.473,-0.27), vec3(-0.1263,0.4734,-0.4239), vec3(-0.4807,-0.8271,-0.2912), vec2(0.811,0.4814), vec2(0.7827,0.4976), vec2(0.835,0.5125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1552,0.6968,-0.6602), vec3(-0.1437,0.6251,-0.6071), vec3(-0.1811,0.7795,-0.589), vec3(-0.9702,-0.2237,-0.0935), vec2(0.8511,0.2983), vec2(0.8389,0.3125), vec2(0.875,0.3071), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1169,0.522,-0.518), vec3(-0.1887,0.5059,-0.4074), vec3(-0.1641,0.5523,-0.5125), vec3(-0.5202,-0.7295,-0.4441), vec2(0.854,0.5461), vec2(0.8125,0.5249), vec2(0.8364,0.5576), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1183,1.2581,-0.2881), vec3(-0.1165,1.2459,-0.4606), vec3(-0.2236,1.1887,-0.3703), vec3(-0.5131,0.8558,-0.0659), vec2(0.5781,0.7605), vec2(0.6309,0.8002), vec2(0.625,0.74), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1169,0.522,-0.518), vec3(-0.1263,0.4734,-0.4239), vec3(-0.1887,0.5059,-0.4074), vec3(-0.5038,-0.7458,-0.4359), vec2(0.854,0.5461), vec2(0.835,0.5125), vec2(0.8125,0.5249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1437,0.6251,-0.6071), vec3(-0.0775,0.6176,-0.6718), vec3(-0.1641,0.5523,-0.5125), vec3(-0.6108,-0.5589,-0.5609), vec2(0.8491,0.5974), vec2(0.8833,0.6074), vec2(0.8364,0.5576), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1552,0.6968,-0.6602), vec3(-0.0775,0.6176,-0.6718), vec3(-0.1437,0.6251,-0.6071), vec3(-0.6237,-0.5264,-0.5778), vec2(0.8418,0.6313), vec2(0.8833,0.6074), vec2(0.8491,0.5974), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1169,0.522,-0.518), vec3(-0.1641,0.5523,-0.5125), vec3(-0.0775,0.6176,-0.6718), vec3(-0.4968,-0.6744,-0.5463), vec2(0.854,0.5461), vec2(0.8364,0.5576), vec2(0.8833,0.6074), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0775,0.6176,-0.6718), vec3(-0.1552,0.6968,-0.6602), vec3(-0.0502,0.7035,-0.761), vec3(-0.59,-0.4833,-0.6467), vec2(0.8833,0.6074), vec2(0.8418,0.6313), vec2(0.897,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1263,0.4734,-0.4239), vec3(0.0263,0.4056,-0.3337), vec3(-0.1381,0.4368,-0.3007), vec3(-0.2353,-0.9255,-0.2968), vec2(0.835,0.5125), vec2(0.8599,0.4399), vec2(0.811,0.4814), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1263,0.4734,-0.4239), vec3(-0.1169,0.522,-0.518), vec3(0.0245,0.4777,-0.5095), vec3(-0.239,-0.8526,-0.4648), vec2(0.835,0.5125), vec2(0.854,0.5461), vec2(0.9023,0.511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0775,0.6176,-0.6718), vec3(0.0177,0.5812,-0.6647), vec3(-0.1169,0.522,-0.518), vec3(-0.2601,-0.7889,-0.5568), vec2(0.8833,0.6074), vec2(0.9282,0.5854), vec2(0.854,0.5461), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1183,1.2581,-0.2881), vec3(-0.1026,1.2524,-0.0956), vec3(0.0547,1.2888,-0.2749), vec3(-0.1777,0.9831,0.0437), vec2(0.5781,0.7605), vec2(0.5176,0.7183), vec2(0.541,0.8092), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0245,0.4777,-0.5095), vec3(0.0252,0.4398,-0.4273), vec3(-0.1263,0.4734,-0.4239), vec3(-0.2058,-0.8893,-0.4083), vec2(0.9023,0.511), vec2(0.8853,0.4771), vec2(0.835,0.5125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0252,0.4398,-0.4273), vec3(0.0263,0.4056,-0.3337), vec3(-0.1263,0.4734,-0.4239), vec3(-0.2107,-0.9189,-0.3335), vec2(0.8853,0.4771), vec2(0.8599,0.4399), vec2(0.835,0.5125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0245,0.4777,-0.5095), vec3(-0.1169,0.522,-0.518), vec3(0.0177,0.5812,-0.6647), vec3(-0.2232,-0.8156,-0.5338), vec2(0.9023,0.511), vec2(0.854,0.5461), vec2(0.9282,0.5854), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1183,1.2581,-0.2881), vec3(0.0547,1.2888,-0.2749), vec3(0.0774,1.258,-0.472), vec3(-0.1596,0.9724,-0.1701), vec2(0.5781,0.7605), vec2(0.541,0.8092), vec2(0.605,0.8419), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0245,0.4777,-0.5095), vec3(0.1834,0.468,-0.435), vec3(0.0252,0.4398,-0.4273), vec3(0.1399,-0.8987,-0.4156), vec2(0.9023,0.511), vec2(0.835,0.5125), vec2(0.8853,0.4771), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0263,0.4056,-0.3337), vec3(0.0252,0.4398,-0.4273), vec3(0.1834,0.468,-0.435), vec3(0.1488,-0.9282,-0.3409), vec2(0.8599,0.4399), vec2(0.8853,0.4771), vec2(0.835,0.5125), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.3414,0.108,0.1236), 0.2004, bestT)) {
        if (triHit(ro, rd, vec3(-0.3017,0.0039,0.1128), vec3(-0.3068,0.0049,0.1145), vec3(-0.3099,0.0131,0.0965), vec3(-0.2925,-0.8896,-0.3507), vec2(0.7651,0.0112), vec2(0.7632,0.0112), vec2(0.7632,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3017,0.0039,0.1128), vec3(-0.3068,0.0049,0.1145), vec3(-0.3099,0.0131,0.0965), vec3(-0.2925,-0.8896,-0.3507), vec2(0.7651,0.0112), vec2(0.7632,0.0112), vec2(0.7632,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3016,0.0116,0.093), vec3(-0.3017,0.0039,0.1128), vec3(-0.3099,0.0131,0.0965), vec3(-0.3003,-0.8887,-0.3464), vec2(0.7656,0.019), vec2(0.7651,0.0112), vec2(0.7632,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3016,0.0116,0.093), vec3(-0.3017,0.0039,0.1128), vec3(-0.3099,0.0131,0.0965), vec3(-0.3003,-0.8887,-0.3464), vec2(0.7656,0.019), vec2(0.7651,0.0112), vec2(0.7632,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3017,0.0039,0.1128), vec3(-0.2935,0.0253,0.0945), vec3(-0.3068,0.0049,0.1145), vec3(0.3646,0.5201,0.7724), vec2(0.7632,0.0112), vec2(0.7651,0.0112), vec2(0.7578,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3017,0.0039,0.1128), vec3(-0.2935,0.0253,0.0945), vec3(-0.3068,0.0049,0.1145), vec3(0.3646,0.5201,0.7724), vec2(0.7632,0.0112), vec2(0.7651,0.0112), vec2(0.7578,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3017,0.0039,0.1128), vec3(-0.3016,0.0116,0.093), vec3(-0.2935,0.0253,0.0945), vec3(0.8543,-0.4863,-0.1834), vec2(0.7651,0.0112), vec2(0.7656,0.019), vec2(0.771,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3017,0.0039,0.1128), vec3(-0.3016,0.0116,0.093), vec3(-0.2935,0.0253,0.0945), vec3(0.8543,-0.4863,-0.1834), vec2(0.7651,0.0112), vec2(0.7656,0.019), vec2(0.771,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3068,0.0049,0.1145), vec3(-0.3187,0.0267,0.0975), vec3(-0.3099,0.0131,0.0965), vec3(-0.8402,-0.5337,-0.0958), vec2(0.7632,0.0112), vec2(0.7578,0.0215), vec2(0.7632,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3068,0.0049,0.1145), vec3(-0.3187,0.0267,0.0975), vec3(-0.3099,0.0131,0.0965), vec3(-0.8402,-0.5337,-0.0958), vec2(0.7632,0.0112), vec2(0.7578,0.0215), vec2(0.7632,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3016,0.0116,0.093), vec3(-0.3099,0.0131,0.0965), vec3(-0.313,0.0246,0.0878), vec3(-0.3947,-0.6152,-0.6824), vec2(0.7656,0.019), vec2(0.7632,0.0186), vec2(0.7622,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3016,0.0116,0.093), vec3(-0.3099,0.0131,0.0965), vec3(-0.313,0.0246,0.0878), vec3(-0.3947,-0.6152,-0.6824), vec2(0.7656,0.019), vec2(0.7632,0.0186), vec2(0.7622,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3187,0.0267,0.0975), vec3(-0.3068,0.0049,0.1145), vec3(-0.2935,0.0253,0.0945), vec3(0.1247,0.6523,0.7477), vec2(0.7554,0.0327), vec2(0.7578,0.0215), vec2(0.7651,0.0112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3187,0.0267,0.0975), vec3(-0.3068,0.0049,0.1145), vec3(-0.2935,0.0253,0.0945), vec3(0.1247,0.6523,0.7477), vec2(0.7554,0.0327), vec2(0.7578,0.0215), vec2(0.7651,0.0112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3005,0.0265,0.0831), vec3(-0.3016,0.0116,0.093), vec3(-0.313,0.0246,0.0878), vec3(-0.2286,-0.5252,-0.8197), vec2(0.7666,0.0239), vec2(0.7656,0.019), vec2(0.7622,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3005,0.0265,0.0831), vec3(-0.3016,0.0116,0.093), vec3(-0.313,0.0246,0.0878), vec3(-0.2286,-0.5252,-0.8197), vec2(0.7666,0.0239), vec2(0.7656,0.019), vec2(0.7622,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3005,0.0265,0.0831), vec3(-0.2935,0.0253,0.0945), vec3(-0.3016,0.0116,0.093), vec3(0.7646,-0.3961,-0.5084), vec2(0.7666,0.0239), vec2(0.771,0.0215), vec2(0.7656,0.019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3005,0.0265,0.0831), vec3(-0.2935,0.0253,0.0945), vec3(-0.3016,0.0116,0.093), vec3(0.7646,-0.3961,-0.5084), vec2(0.7666,0.0239), vec2(0.771,0.0215), vec2(0.7656,0.019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.313,0.0246,0.0878), vec3(-0.3099,0.0131,0.0965), vec3(-0.3187,0.0267,0.0975), vec3(-0.7945,-0.4839,-0.3669), vec2(0.7622,0.0229), vec2(0.7632,0.0186), vec2(0.7578,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.313,0.0246,0.0878), vec3(-0.3099,0.0131,0.0965), vec3(-0.3187,0.0267,0.0975), vec3(-0.7945,-0.4839,-0.3669), vec2(0.7622,0.0229), vec2(0.7632,0.0186), vec2(0.7578,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3005,0.0265,0.0831), vec3(-0.2904,0.0513,0.0899), vec3(-0.2935,0.0253,0.0945), vec3(0.8279,-0.1927,-0.5267), vec2(0.7666,0.0239), vec2(0.7725,0.0327), vec2(0.771,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3005,0.0265,0.0831), vec3(-0.2904,0.0513,0.0899), vec3(-0.2935,0.0253,0.0945), vec3(0.8279,-0.1927,-0.5267), vec2(0.7666,0.0239), vec2(0.7725,0.0327), vec2(0.771,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.313,0.0246,0.0878), vec3(-0.3187,0.0267,0.0975), vec3(-0.319,0.053,0.0966), vec3(-0.8624,-0.0254,-0.5056), vec2(0.7622,0.0229), vec2(0.7578,0.0215), vec2(0.7554,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.313,0.0246,0.0878), vec3(-0.3187,0.0267,0.0975), vec3(-0.319,0.053,0.0966), vec3(-0.8624,-0.0254,-0.5056), vec2(0.7622,0.0229), vec2(0.7578,0.0215), vec2(0.7554,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3187,0.0267,0.0975), vec3(-0.2935,0.0253,0.0945), vec3(-0.319,0.053,0.0966), vec3(0.1189,0.0355,0.9923), vec2(0.7554,0.0327), vec2(0.7651,0.0112), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3187,0.0267,0.0975), vec3(-0.2935,0.0253,0.0945), vec3(-0.319,0.053,0.0966), vec3(0.1189,0.0355,0.9923), vec2(0.7554,0.0327), vec2(0.7651,0.0112), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.313,0.0246,0.0878), vec3(-0.3138,0.0662,0.0861), vec3(-0.3005,0.0265,0.0831), vec3(-0.3431,-0.0434,-0.9383), vec2(0.7622,0.0229), vec2(0.7598,0.0396), vec2(0.7666,0.0239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.313,0.0246,0.0878), vec3(-0.3138,0.0662,0.0861), vec3(-0.3005,0.0265,0.0831), vec3(-0.3431,-0.0434,-0.9383), vec2(0.7622,0.0229), vec2(0.7598,0.0396), vec2(0.7666,0.0239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2926,0.0402,0.106), vec3(-0.3035,0.041,0.1116), vec3(-0.2917,0.0364,0.0937), vec3(0.082,-0.9506,0.2992), vec2(0.6216,0.9368), vec2(0.6162,0.9355), vec2(0.6221,0.9387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2926,0.0402,0.106), vec3(-0.3035,0.041,0.1116), vec3(-0.2917,0.0364,0.0937), vec3(0.082,-0.9506,0.2992), vec2(0.6216,0.9368), vec2(0.6162,0.9355), vec2(0.6221,0.9387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3143,0.0407,0.1013), vec3(-0.2917,0.0364,0.0937), vec3(-0.3035,0.041,0.1116), vec3(-0.1321,-0.9774,0.1653), vec2(0.6167,0.9436), vec2(0.6221,0.9387), vec2(0.6162,0.9355), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3143,0.0407,0.1013), vec3(-0.2917,0.0364,0.0937), vec3(-0.3035,0.041,0.1116), vec3(-0.1321,-0.9774,0.1653), vec2(0.6167,0.9436), vec2(0.6221,0.9387), vec2(0.6162,0.9355), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2917,0.0364,0.0937), vec3(-0.3143,0.0407,0.1013), vec3(-0.3017,0.0421,0.0852), vec3(-0.2763,-0.9146,-0.2952), vec2(0.6221,0.9387), vec2(0.6167,0.9436), vec2(0.623,0.9405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2917,0.0364,0.0937), vec3(-0.3143,0.0407,0.1013), vec3(-0.3017,0.0421,0.0852), vec3(-0.2763,-0.9146,-0.2952), vec2(0.6221,0.9387), vec2(0.6167,0.9436), vec2(0.623,0.9405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3132,0.044,0.0907), vec3(-0.3017,0.0421,0.0852), vec3(-0.3143,0.0407,0.1013), vec3(-0.2949,-0.9042,-0.3089), vec2(0.6216,0.9431), vec2(0.623,0.9405), vec2(0.6167,0.9436), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3132,0.044,0.0907), vec3(-0.3017,0.0421,0.0852), vec3(-0.3143,0.0407,0.1013), vec3(-0.2949,-0.9042,-0.3089), vec2(0.6216,0.9431), vec2(0.623,0.9405), vec2(0.6167,0.9436), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2904,0.0513,0.0899), vec3(-0.319,0.053,0.0966), vec3(-0.2935,0.0253,0.0945), vec3(0.2335,0.143,0.9618), vec2(0.771,0.0215), vec2(0.7598,0.0396), vec2(0.7651,0.0112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2904,0.0513,0.0899), vec3(-0.319,0.053,0.0966), vec3(-0.2935,0.0253,0.0945), vec3(0.2335,0.143,0.9618), vec2(0.771,0.0215), vec2(0.7598,0.0396), vec2(0.7651,0.0112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2917,0.0364,0.0937), vec3(-0.2879,0.064,0.0919), vec3(-0.2926,0.0402,0.106), vec3(0.9854,-0.1306,0.1092), vec2(0.6221,0.9387), vec2(0.6265,0.9377), vec2(0.6216,0.9368), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3017,0.0421,0.0852), vec3(-0.2879,0.064,0.0919), vec3(-0.2917,0.0364,0.0937), vec3(0.595,-0.1339,-0.7925), vec2(0.623,0.9405), vec2(0.6265,0.9377), vec2(0.6221,0.9387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.0648,0.08), vec3(-0.2904,0.0513,0.0899), vec3(-0.3005,0.0265,0.0831), vec3(0.6855,-0.0814,-0.7235), vec2(0.7671,0.0396), vec2(0.7725,0.0327), vec2(0.7666,0.0239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.0648,0.08), vec3(-0.2904,0.0513,0.0899), vec3(-0.3005,0.0265,0.0831), vec3(0.6855,-0.0814,-0.7235), vec2(0.7671,0.0396), vec2(0.7725,0.0327), vec2(0.7666,0.0239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3138,0.0662,0.0861), vec3(-0.313,0.0246,0.0878), vec3(-0.319,0.053,0.0966), vec3(-0.8756,-0.0356,-0.4817), vec2(0.7598,0.0396), vec2(0.7622,0.0229), vec2(0.7554,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3138,0.0662,0.0861), vec3(-0.313,0.0246,0.0878), vec3(-0.319,0.053,0.0966), vec3(-0.8756,-0.0356,-0.4817), vec2(0.7598,0.0396), vec2(0.7622,0.0229), vec2(0.7554,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2926,0.0402,0.106), vec3(-0.2891,0.0695,0.1099), vec3(-0.3035,0.041,0.1116), vec3(0.4387,-0.1674,0.8829), vec2(0.6216,0.9368), vec2(0.627,0.9333), vec2(0.6162,0.9355), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3035,0.041,0.1116), vec3(-0.3206,0.0703,0.103), vec3(-0.3143,0.0407,0.1013), vec3(-0.6768,-0.1867,0.712), vec2(0.6138,0.9489), vec2(0.626,0.9495), vec2(0.6167,0.9436), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3035,0.041,0.1116), vec3(-0.3206,0.0703,0.103), vec3(-0.3143,0.0407,0.1013), vec3(-0.6768,-0.1867,0.712), vec2(0.6138,0.9489), vec2(0.626,0.9495), vec2(0.6167,0.9436), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3143,0.0407,0.1013), vec3(-0.3206,0.0703,0.103), vec3(-0.3132,0.044,0.0907), vec3(-0.9672,-0.1993,-0.1577), vec2(0.6167,0.9436), vec2(0.626,0.9495), vec2(0.6216,0.9431), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.0648,0.08), vec3(-0.3005,0.0265,0.0831), vec3(-0.3138,0.0662,0.0861), vec3(-0.3927,-0.0615,-0.9176), vec2(0.7671,0.0396), vec2(0.7666,0.0239), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.0648,0.08), vec3(-0.3005,0.0265,0.0831), vec3(-0.3138,0.0662,0.0861), vec3(-0.3927,-0.0615,-0.9176), vec2(0.7671,0.0396), vec2(0.7666,0.0239), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3132,0.044,0.0907), vec3(-0.2988,0.0717,0.0787), vec3(-0.3017,0.0421,0.0852), vec3(-0.4436,-0.1518,-0.8833), vec2(0.6216,0.9431), vec2(0.6279,0.9412), vec2(0.623,0.9405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.0648,0.08), vec3(-0.319,0.053,0.0966), vec3(-0.2904,0.0513,0.0899), vec3(0.2074,0.6624,0.7199), vec2(0.7725,0.0327), vec2(0.7598,0.0396), vec2(0.771,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.0648,0.08), vec3(-0.319,0.053,0.0966), vec3(-0.2904,0.0513,0.0899), vec3(0.2074,0.6624,0.7199), vec2(0.7725,0.0327), vec2(0.7598,0.0396), vec2(0.771,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2891,0.0695,0.1099), vec3(-0.2926,0.0402,0.106), vec3(-0.2879,0.064,0.0919), vec3(0.9854,-0.1309,0.1086), vec2(0.627,0.9333), vec2(0.6216,0.9368), vec2(0.6265,0.9377), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2879,0.064,0.0919), vec3(-0.3017,0.0421,0.0852), vec3(-0.2988,0.0717,0.0787), vec3(0.6851,-0.2206,-0.6942), vec2(0.6265,0.9377), vec2(0.623,0.9405), vec2(0.6279,0.9412), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.305,0.0707,0.118), vec3(-0.3035,0.041,0.1116), vec3(-0.2891,0.0695,0.1099), vec3(0.4388,-0.1674,0.8829), vec2(0.6255,0.9282), vec2(0.6162,0.9355), vec2(0.627,0.9333), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3035,0.041,0.1116), vec3(-0.305,0.0707,0.118), vec3(-0.3206,0.0703,0.103), vec3(-0.6767,-0.1866,0.7122), vec2(0.6138,0.9489), vec2(0.624,0.9559), vec2(0.626,0.9495), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3035,0.041,0.1116), vec3(-0.305,0.0707,0.118), vec3(-0.3206,0.0703,0.103), vec3(-0.6767,-0.1866,0.7122), vec2(0.6138,0.9489), vec2(0.624,0.9559), vec2(0.626,0.9495), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3138,0.0662,0.0861), vec3(-0.319,0.053,0.0966), vec3(-0.2992,0.0648,0.08), vec3(0.3784,0.4784,0.7925), vec2(0.7671,0.0396), vec2(0.7598,0.0396), vec2(0.7725,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3138,0.0662,0.0861), vec3(-0.319,0.053,0.0966), vec3(-0.2992,0.0648,0.08), vec3(0.3784,0.4784,0.7925), vec2(0.7671,0.0396), vec2(0.7598,0.0396), vec2(0.7725,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3155,0.0745,0.0867), vec3(-0.3132,0.044,0.0907), vec3(-0.3206,0.0703,0.103), vec3(-0.9394,-0.1139,-0.3232), vec2(0.6279,0.9452), vec2(0.6216,0.9431), vec2(0.626,0.9495), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3132,0.044,0.0907), vec3(-0.3155,0.0745,0.0867), vec3(-0.2988,0.0717,0.0787), vec3(-0.4448,-0.151,-0.8828), vec2(0.6216,0.9431), vec2(0.6279,0.9452), vec2(0.6279,0.9412), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2879,0.064,0.0919), vec3(-0.2798,0.1064,0.0928), vec3(-0.2891,0.0695,0.1099), vec3(0.9743,-0.1875,0.1252), vec2(0.6265,0.9377), vec2(0.6396,0.9373), vec2(0.627,0.9333), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2988,0.0717,0.0787), vec3(-0.2798,0.1064,0.0928), vec3(-0.2879,0.064,0.0919), vec3(0.7282,-0.1245,-0.6739), vec2(0.6279,0.9412), vec2(0.6396,0.9373), vec2(0.6265,0.9377), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.305,0.0707,0.118), vec3(-0.3186,0.116,0.1046), vec3(-0.3206,0.0703,0.103), vec3(-0.6915,0.0054,0.7224), vec2(0.624,0.9559), vec2(0.6411,0.9505), vec2(0.626,0.9495), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.305,0.0707,0.118), vec3(-0.3186,0.116,0.1046), vec3(-0.3206,0.0703,0.103), vec3(-0.6915,0.0054,0.7224), vec2(0.624,0.9559), vec2(0.6411,0.9505), vec2(0.626,0.9495), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2891,0.0695,0.1099), vec3(-0.2765,0.117,0.1056), vec3(-0.305,0.0707,0.118), vec3(0.4524,-0.0414,0.8909), vec2(0.627,0.9333), vec2(0.6416,0.933), vec2(0.6255,0.9282), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3155,0.0745,0.0867), vec3(-0.2941,0.1129,0.0792), vec3(-0.2988,0.0717,0.0787), vec3(-0.421,0.0578,-0.9052), vec2(0.6279,0.9452), vec2(0.6416,0.9413), vec2(0.6279,0.9412), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3206,0.0703,0.103), vec3(-0.3186,0.116,0.1046), vec3(-0.3155,0.0745,0.0867), vec3(-0.9567,0.0528,-0.2864), vec2(0.626,0.9495), vec2(0.6411,0.9505), vec2(0.6279,0.9452), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2798,0.1064,0.0928), vec3(-0.2988,0.0717,0.0787), vec3(-0.2941,0.1129,0.0792), vec3(0.6705,-0.0667,-0.7389), vec2(0.6396,0.9373), vec2(0.6279,0.9412), vec2(0.6416,0.9413), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2765,0.117,0.1056), vec3(-0.2891,0.0695,0.1099), vec3(-0.2798,0.1064,0.0928), vec3(0.9648,-0.2603,-0.0373), vec2(0.6416,0.933), vec2(0.627,0.9333), vec2(0.6396,0.9373), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3186,0.116,0.1046), vec3(-0.305,0.0707,0.118), vec3(-0.3028,0.1128,0.1281), vec3(-0.8314,-0.0878,0.5487), vec2(0.6411,0.9505), vec2(0.624,0.9559), vec2(0.6406,0.9556), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3186,0.116,0.1046), vec3(-0.305,0.0707,0.118), vec3(-0.3028,0.1128,0.1281), vec3(-0.8314,-0.0878,0.5487), vec2(0.6411,0.9505), vec2(0.624,0.9559), vec2(0.6406,0.9556), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3028,0.1128,0.1281), vec3(-0.305,0.0707,0.118), vec3(-0.2765,0.117,0.1056), vec3(0.6538,-0.2092,0.7271), vec2(0.6411,0.9287), vec2(0.6255,0.9282), vec2(0.6416,0.933), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3155,0.0745,0.0867), vec3(-0.3148,0.1163,0.089), vec3(-0.2941,0.1129,0.0792), vec3(-0.4218,0.0583,-0.9048), vec2(0.6279,0.9452), vec2(0.6421,0.946), vec2(0.6416,0.9413), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3148,0.1163,0.089), vec3(-0.3155,0.0745,0.0867), vec3(-0.3186,0.116,0.1046), vec3(-0.9709,0.0306,-0.2376), vec2(0.6421,0.946), vec2(0.6279,0.9452), vec2(0.6411,0.9505), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2941,0.1129,0.0792), vec3(-0.2855,0.1979,0.1176), vec3(-0.2798,0.1064,0.0928), vec3(0.7218,0.2225,-0.6553), vec2(0.6416,0.9413), vec2(0.6597,0.9368), vec2(0.6396,0.9373), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2798,0.1064,0.0928), vec3(-0.2855,0.1979,0.1176), vec3(-0.2765,0.117,0.1056), vec3(0.9166,0.1565,-0.3678), vec2(0.6396,0.9373), vec2(0.6597,0.9368), vec2(0.6416,0.933), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3148,0.1163,0.089), vec3(-0.2945,0.2033,0.1034), vec3(-0.2941,0.1129,0.0792), vec3(-0.3861,0.237,-0.8915), vec2(0.6421,0.946), vec2(0.6602,0.9415), vec2(0.6416,0.9413), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3028,0.1128,0.1281), vec3(-0.3179,0.2051,0.1303), vec3(-0.3186,0.116,0.1046), vec3(-0.829,-0.1492,0.5389), vec2(0.6406,0.9556), vec2(0.6621,0.9518), vec2(0.6411,0.9505), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3028,0.1128,0.1281), vec3(-0.3179,0.2051,0.1303), vec3(-0.3186,0.116,0.1046), vec3(-0.829,-0.1492,0.5389), vec2(0.6406,0.9556), vec2(0.6621,0.9518), vec2(0.6411,0.9505), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2765,0.117,0.1056), vec3(-0.2828,0.2046,0.1311), vec3(-0.3028,0.1128,0.1281), vec3(0.6553,-0.1669,0.7367), vec2(0.6416,0.933), vec2(0.6616,0.9326), vec2(0.6411,0.9287), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3186,0.116,0.1046), vec3(-0.3113,0.2061,0.1113), vec3(-0.3148,0.1163,0.089), vec3(-0.9671,0.0962,-0.2354), vec2(0.6411,0.9505), vec2(0.6611,0.947), vec2(0.6421,0.946), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4008,0.1498,0.1611), vec3(-0.3992,0.1475,0.1792), vec3(-0.4051,0.1553,0.1646), vec3(-0.7889,-0.6146,-0.0044), vec2(0.7817,0.0415), vec2(0.7812,0.0352), vec2(0.7793,0.041), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4008,0.1498,0.1611), vec3(-0.3992,0.1475,0.1792), vec3(-0.4051,0.1553,0.1646), vec3(-0.7889,-0.6146,-0.0044), vec2(0.7817,0.0415), vec2(0.7812,0.0352), vec2(0.7793,0.041), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3992,0.1475,0.1792), vec3(-0.4008,0.1498,0.1611), vec3(-0.3889,0.1557,0.1577), vec3(0.404,-0.9025,-0.1493), vec2(0.7812,0.0352), vec2(0.7817,0.0415), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3992,0.1475,0.1792), vec3(-0.4008,0.1498,0.1611), vec3(-0.3889,0.1557,0.1577), vec3(0.404,-0.9025,-0.1493), vec2(0.7812,0.0352), vec2(0.7817,0.0415), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4019,0.1509,0.181), vec3(-0.4051,0.1553,0.1646), vec3(-0.3992,0.1475,0.1792), vec3(-0.7813,-0.624,-0.0125), vec2(0.7793,0.0347), vec2(0.7793,0.041), vec2(0.7812,0.0352), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4019,0.1509,0.181), vec3(-0.4051,0.1553,0.1646), vec3(-0.3992,0.1475,0.1792), vec3(-0.7813,-0.624,-0.0125), vec2(0.7793,0.0347), vec2(0.7793,0.041), vec2(0.7812,0.0352), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4008,0.1498,0.1611), vec3(-0.4051,0.1553,0.1646), vec3(-0.3954,0.1584,0.1471), vec3(-0.8062,-0.3116,-0.503), vec2(0.7817,0.0415), vec2(0.7793,0.041), vec2(0.7827,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4008,0.1498,0.1611), vec3(-0.4051,0.1553,0.1646), vec3(-0.3954,0.1584,0.1471), vec3(-0.8062,-0.3116,-0.503), vec2(0.7817,0.0415), vec2(0.7793,0.041), vec2(0.7827,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3954,0.1584,0.1471), vec3(-0.3889,0.1557,0.1577), vec3(-0.4008,0.1498,0.1611), vec3(0.3098,-0.8603,-0.4048), vec2(0.7827,0.0469), vec2(0.7861,0.0435), vec2(0.7817,0.0415), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3954,0.1584,0.1471), vec3(-0.3889,0.1557,0.1577), vec3(-0.4008,0.1498,0.1611), vec3(0.3098,-0.8603,-0.4048), vec2(0.7827,0.0469), vec2(0.7861,0.0435), vec2(0.7817,0.0415), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4019,0.1509,0.181), vec3(-0.3992,0.1475,0.1792), vec3(-0.4053,0.1692,0.163), vec3(0.8119,0.4787,0.3341), vec2(0.7744,0.0439), vec2(0.7793,0.0347), vec2(0.7734,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4019,0.1509,0.181), vec3(-0.3992,0.1475,0.1792), vec3(-0.4053,0.1692,0.163), vec3(0.8119,0.4787,0.3341), vec2(0.7744,0.0439), vec2(0.7793,0.0347), vec2(0.7734,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3889,0.1557,0.1577), vec3(-0.4053,0.1692,0.163), vec3(-0.3992,0.1475,0.1792), vec3(0.6361,0.5693,0.5208), vec2(0.7812,0.0352), vec2(0.7734,0.0503), vec2(0.7793,0.0347), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3889,0.1557,0.1577), vec3(-0.4053,0.1692,0.163), vec3(-0.3992,0.1475,0.1792), vec3(0.6361,0.5693,0.5208), vec2(0.7812,0.0352), vec2(0.7734,0.0503), vec2(0.7793,0.0347), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4051,0.1553,0.1646), vec3(-0.4019,0.1509,0.181), vec3(-0.4053,0.1692,0.163), vec3(-0.9798,0.0153,0.1992), vec2(0.7793,0.041), vec2(0.7793,0.0347), vec2(0.7744,0.0439), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4051,0.1553,0.1646), vec3(-0.4019,0.1509,0.181), vec3(-0.4053,0.1692,0.163), vec3(-0.9798,0.0153,0.1992), vec2(0.7793,0.041), vec2(0.7793,0.0347), vec2(0.7744,0.0439), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4038,0.1638,0.1529), vec3(-0.3954,0.1584,0.1471), vec3(-0.4051,0.1553,0.1646), vec3(-0.6868,-0.548,-0.4776), vec2(0.7788,0.0459), vec2(0.7827,0.0469), vec2(0.7793,0.041), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4038,0.1638,0.1529), vec3(-0.3954,0.1584,0.1471), vec3(-0.4051,0.1553,0.1646), vec3(-0.6868,-0.548,-0.4776), vec2(0.7788,0.0459), vec2(0.7827,0.0469), vec2(0.7793,0.041), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3954,0.1584,0.1471), vec3(-0.3816,0.1641,0.1473), vec3(-0.3889,0.1557,0.1577), vec3(0.3532,-0.8335,-0.4248), vec2(0.7827,0.0469), vec2(0.7876,0.0503), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3954,0.1584,0.1471), vec3(-0.3816,0.1641,0.1473), vec3(-0.3889,0.1557,0.1577), vec3(0.3532,-0.8335,-0.4248), vec2(0.7827,0.0469), vec2(0.7876,0.0503), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3865,0.1587,0.1631), vec3(-0.4008,0.1711,0.1614), vec3(-0.3904,0.1548,0.1534), vec3(-0.6002,-0.6294,0.4935), vec2(0.6875,0.9914), vec2(0.6851,0.9881), vec2(0.6846,0.9939), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3865,0.1587,0.1631), vec3(-0.4008,0.1711,0.1614), vec3(-0.3904,0.1548,0.1534), vec3(-0.6002,-0.6294,0.4935), vec2(0.6875,0.9914), vec2(0.6851,0.9881), vec2(0.6846,0.9939), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3904,0.1548,0.1534), vec3(-0.3722,0.1723,0.1462), vec3(-0.3865,0.1587,0.1631), vec3(0.6974,-0.7165,0.0164), vec2(0.6846,0.9939), vec2(0.6772,0.9875), vec2(0.6807,0.9971), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4053,0.1692,0.163), vec3(-0.4038,0.1638,0.1529), vec3(-0.4051,0.1553,0.1646), vec3(-0.9907,-0.0244,-0.1337), vec2(0.7744,0.0439), vec2(0.7788,0.0459), vec2(0.7793,0.041), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4053,0.1692,0.163), vec3(-0.4038,0.1638,0.1529), vec3(-0.4051,0.1553,0.1646), vec3(-0.9907,-0.0244,-0.1337), vec2(0.7744,0.0439), vec2(0.7788,0.0459), vec2(0.7793,0.041), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3904,0.1548,0.1534), vec3(-0.4008,0.1711,0.1614), vec3(-0.3951,0.1638,0.1465), vec3(-0.856,-0.511,-0.0783), vec2(0.6846,0.9939), vec2(0.6851,0.9881), vec2(0.6826,0.9893), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3904,0.1548,0.1534), vec3(-0.4008,0.1711,0.1614), vec3(-0.3951,0.1638,0.1465), vec3(-0.856,-0.511,-0.0783), vec2(0.6846,0.9939), vec2(0.6851,0.9881), vec2(0.6826,0.9893), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3951,0.1638,0.1465), vec3(-0.3722,0.1723,0.1462), vec3(-0.3904,0.1548,0.1534), vec3(0.1843,-0.5297,-0.8279), vec2(0.6826,0.9893), vec2(0.6772,0.9875), vec2(0.6846,0.9939), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3918,0.1657,0.1688), vec3(-0.4008,0.1711,0.1614), vec3(-0.3865,0.1587,0.1631), vec3(-0.6474,-0.7136,0.2677), vec2(0.687,0.9889), vec2(0.6851,0.9881), vec2(0.6875,0.9914), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3918,0.1657,0.1688), vec3(-0.4008,0.1711,0.1614), vec3(-0.3865,0.1587,0.1631), vec3(-0.6474,-0.7136,0.2677), vec2(0.687,0.9889), vec2(0.6851,0.9881), vec2(0.6875,0.9914), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3954,0.1584,0.1471), vec3(-0.4038,0.1638,0.1529), vec3(-0.3845,0.1762,0.1369), vec3(-0.6058,-0.0841,-0.7911), vec2(0.7827,0.0469), vec2(0.7788,0.0459), vec2(0.7832,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3954,0.1584,0.1471), vec3(-0.4038,0.1638,0.1529), vec3(-0.3845,0.1762,0.1369), vec3(-0.6058,-0.0841,-0.7911), vec2(0.7827,0.0469), vec2(0.7788,0.0459), vec2(0.7832,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3845,0.1762,0.1369), vec3(-0.3816,0.1641,0.1473), vec3(-0.3954,0.1584,0.1471), vec3(0.2578,-0.5934,-0.7625), vec2(0.7832,0.0562), vec2(0.7876,0.0503), vec2(0.7827,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3845,0.1762,0.1369), vec3(-0.3816,0.1641,0.1473), vec3(-0.3954,0.1584,0.1471), vec3(0.2578,-0.5934,-0.7625), vec2(0.7832,0.0562), vec2(0.7876,0.0503), vec2(0.7827,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3816,0.1641,0.1473), vec3(-0.3993,0.18,0.1559), vec3(-0.3889,0.1557,0.1577), vec3(0.6325,0.3234,0.7038), vec2(0.7861,0.0435), vec2(0.7769,0.0562), vec2(0.7812,0.0352), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3816,0.1641,0.1473), vec3(-0.3993,0.18,0.1559), vec3(-0.3889,0.1557,0.1577), vec3(0.6325,0.3234,0.7038), vec2(0.7861,0.0435), vec2(0.7769,0.0562), vec2(0.7812,0.0352), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3865,0.1587,0.1631), vec3(-0.3658,0.1783,0.1606), vec3(-0.3918,0.1657,0.1688), vec3(0.4349,-0.3571,0.8267), vec2(0.6875,0.9914), vec2(0.6929,0.9872), vec2(0.687,0.9889), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4053,0.1692,0.163), vec3(-0.3889,0.1557,0.1577), vec3(-0.3993,0.18,0.1559), vec3(0.4899,0.2715,0.8284), vec2(0.7734,0.0503), vec2(0.7812,0.0352), vec2(0.7769,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4053,0.1692,0.163), vec3(-0.3889,0.1557,0.1577), vec3(-0.3993,0.18,0.1559), vec3(0.4899,0.2715,0.8284), vec2(0.7734,0.0503), vec2(0.7812,0.0352), vec2(0.7769,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4004,0.172,0.1521), vec3(-0.3951,0.1638,0.1465), vec3(-0.4008,0.1711,0.1614), vec3(-0.8648,-0.494,-0.09), vec2(0.6841,0.9877), vec2(0.6826,0.9893), vec2(0.6851,0.9881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4004,0.172,0.1521), vec3(-0.3951,0.1638,0.1465), vec3(-0.4008,0.1711,0.1614), vec3(-0.8648,-0.494,-0.09), vec2(0.6841,0.9877), vec2(0.6826,0.9893), vec2(0.6851,0.9881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3658,0.1783,0.1606), vec3(-0.3865,0.1587,0.1631), vec3(-0.3722,0.1723,0.1462), vec3(0.6865,-0.7271,-0.0014), vec2(0.6719,0.9874), vec2(0.6807,0.9971), vec2(0.6772,0.9875), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4038,0.1638,0.1529), vec3(-0.4053,0.1692,0.163), vec3(-0.3993,0.18,0.1559), vec3(-0.9035,0.3059,-0.3001), vec2(0.7788,0.0459), vec2(0.7744,0.0439), vec2(0.7734,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4038,0.1638,0.1529), vec3(-0.4053,0.1692,0.163), vec3(-0.3993,0.18,0.1559), vec3(-0.9035,0.3059,-0.3001), vec2(0.7788,0.0459), vec2(0.7744,0.0439), vec2(0.7734,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3951,0.1638,0.1465), vec3(-0.4004,0.172,0.1521), vec3(-0.377,0.1831,0.1345), vec3(-0.6338,0.1198,-0.7641), vec2(0.6826,0.9893), vec2(0.6841,0.9877), vec2(0.6797,0.9842), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3951,0.1638,0.1465), vec3(-0.377,0.1831,0.1345), vec3(-0.3722,0.1723,0.1462), vec3(0.2349,-0.6635,-0.7103), vec2(0.6826,0.9893), vec2(0.6797,0.9842), vec2(0.6772,0.9875), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3026,0.2046,0.1436), vec3(-0.3028,0.1128,0.1281), vec3(-0.2828,0.2046,0.1311), vec3(0.5293,-0.1428,0.8363), vec2(0.6616,0.9293), vec2(0.6411,0.9287), vec2(0.6616,0.9326), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3179,0.2051,0.1303), vec3(-0.3028,0.1128,0.1281), vec3(-0.3026,0.2046,0.1436), vec3(-0.6531,-0.1254,0.7468), vec2(0.6621,0.9518), vec2(0.6406,0.9556), vec2(0.6626,0.9553), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3179,0.2051,0.1303), vec3(-0.3028,0.1128,0.1281), vec3(-0.3026,0.2046,0.1436), vec3(-0.6531,-0.1254,0.7468), vec2(0.6621,0.9518), vec2(0.6406,0.9556), vec2(0.6626,0.9553), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3926,0.1851,0.1433), vec3(-0.3845,0.1762,0.1369), vec3(-0.4038,0.1638,0.1529), vec3(-0.6346,-0.0159,-0.7727), vec2(0.7769,0.0562), vec2(0.7832,0.0562), vec2(0.7788,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3926,0.1851,0.1433), vec3(-0.3845,0.1762,0.1369), vec3(-0.4038,0.1638,0.1529), vec3(-0.6346,-0.0159,-0.7727), vec2(0.7769,0.0562), vec2(0.7832,0.0562), vec2(0.7788,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3845,0.1762,0.1369), vec3(-0.3926,0.1851,0.1433), vec3(-0.3816,0.1641,0.1473), vec3(0.8041,0.487,0.341), vec2(0.7876,0.0503), vec2(0.7832,0.0562), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3845,0.1762,0.1369), vec3(-0.3926,0.1851,0.1433), vec3(-0.3816,0.1641,0.1473), vec3(0.8041,0.487,0.341), vec2(0.7876,0.0503), vec2(0.7832,0.0562), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3918,0.1657,0.1688), vec3(-0.3735,0.1887,0.169), vec3(-0.4008,0.1711,0.1614), vec3(-0.4539,0.3561,0.8168), vec2(0.687,0.9889), vec2(0.6895,0.9845), vec2(0.6851,0.9881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2945,0.2033,0.1034), vec3(-0.3148,0.1163,0.089), vec3(-0.3113,0.2061,0.1113), vec3(-0.3852,0.2369,-0.8919), vec2(0.6602,0.9415), vec2(0.6421,0.946), vec2(0.6611,0.947), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3113,0.2061,0.1113), vec3(-0.3186,0.116,0.1046), vec3(-0.3179,0.2051,0.1303), vec3(-0.9405,0.1007,-0.3245), vec2(0.6611,0.947), vec2(0.6411,0.9505), vec2(0.6621,0.9518), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3926,0.1851,0.1433), vec3(-0.4038,0.1638,0.1529), vec3(-0.3993,0.18,0.1559), vec3(-0.8864,0.3092,-0.3446), vec2(0.7769,0.0562), vec2(0.7788,0.0459), vec2(0.7734,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3926,0.1851,0.1433), vec3(-0.4038,0.1638,0.1529), vec3(-0.3993,0.18,0.1559), vec3(-0.8864,0.3092,-0.3446), vec2(0.7769,0.0562), vec2(0.7788,0.0459), vec2(0.7734,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3993,0.18,0.1559), vec3(-0.3816,0.1641,0.1473), vec3(-0.3926,0.1851,0.1433), vec3(0.6886,0.4667,0.555), vec2(0.7769,0.0562), vec2(0.7861,0.0435), vec2(0.7832,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3993,0.18,0.1559), vec3(-0.3816,0.1641,0.1473), vec3(-0.3926,0.1851,0.1433), vec3(0.6886,0.4667,0.555), vec2(0.7769,0.0562), vec2(0.7861,0.0435), vec2(0.7832,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3735,0.1887,0.169), vec3(-0.3918,0.1657,0.1688), vec3(-0.3658,0.1783,0.1606), vec3(0.4325,-0.3494,0.8311), vec2(0.6895,0.9845), vec2(0.687,0.9889), vec2(0.6929,0.9872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4008,0.1711,0.1614), vec3(-0.3871,0.1963,0.158), vec3(-0.4004,0.172,0.1521), vec3(-0.8775,0.4796,-0.0007), vec2(0.6851,0.9881), vec2(0.6855,0.9836), vec2(0.6841,0.9877), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3845,0.1951,0.1428), vec3(-0.377,0.1831,0.1345), vec3(-0.4004,0.172,0.1521), vec3(-0.6363,0.1313,-0.7602), vec2(0.6826,0.9829), vec2(0.6797,0.9842), vec2(0.6841,0.9877), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3871,0.1963,0.158), vec3(-0.4008,0.1711,0.1614), vec3(-0.3735,0.1887,0.169), vec3(-0.4556,0.3599,0.8142), vec2(0.6855,0.9836), vec2(0.6851,0.9881), vec2(0.6895,0.9845), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3845,0.1951,0.1428), vec3(-0.4004,0.172,0.1521), vec3(-0.3871,0.1963,0.158), vec3(-0.8435,0.5052,-0.1822), vec2(0.6826,0.9829), vec2(0.6841,0.9877), vec2(0.6855,0.9836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3722,0.1723,0.1462), vec3(-0.3198,0.2334,0.1448), vec3(-0.3658,0.1783,0.1606), vec3(0.7569,-0.6503,-0.0644), vec2(0.6772,0.9875), vec2(0.6714,0.9616), vec2(0.6719,0.9874), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.377,0.1831,0.1345), vec3(-0.3198,0.2334,0.1448), vec3(-0.3722,0.1723,0.1462), vec3(0.5503,-0.4874,-0.6779), vec2(0.6797,0.9842), vec2(0.6714,0.9616), vec2(0.6772,0.9875), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3658,0.1783,0.1606), vec3(-0.3138,0.2416,0.1646), vec3(-0.3735,0.1887,0.169), vec3(0.3978,-0.3787,0.8357), vec2(0.6929,0.9872), vec2(0.6978,0.9676), vec2(0.6895,0.9845), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.377,0.1831,0.1345), vec3(-0.3845,0.1951,0.1428), vec3(-0.3275,0.2454,0.1328), vec3(-0.4292,0.3183,-0.8452), vec2(0.6797,0.9842), vec2(0.6826,0.9829), vec2(0.6777,0.96), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3735,0.1887,0.169), vec3(-0.3224,0.2504,0.1681), vec3(-0.3871,0.1963,0.158), vec3(-0.4436,0.3788,0.8123), vec2(0.6895,0.9845), vec2(0.6948,0.9653), vec2(0.6855,0.9836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3871,0.1963,0.158), vec3(-0.3333,0.2559,0.1415), vec3(-0.3845,0.1951,0.1428), vec3(-0.7545,0.6321,-0.1763), vec2(0.6855,0.9836), vec2(0.6841,0.9601), vec2(0.6826,0.9829), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.2542,0.4061,0.1338), 0.5951, bestT)) {
        if (triHit(ro, rd, vec3(0.0263,0.4056,-0.3337), vec3(0.0277,0.3772,-0.1851), vec3(-0.1381,0.4368,-0.3007), vec3(-0.2184,-0.9589,-0.1811), vec2(0.8599,0.4399), vec2(0.8193,0.3926), vec2(0.811,0.4814), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.219,0.473,-0.27), vec3(-0.1381,0.4368,-0.3007), vec3(-0.1323,0.3765,-0.0247), vec3(-0.4581,-0.8703,-0.1807), vec2(0.7827,0.4976), vec2(0.811,0.4814), vec2(0.7788,0.4385), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.219,0.473,-0.27), vec3(-0.2389,0.4534,0.0039), vec3(-0.2935,0.5622,-0.2445), vec3(-0.7775,-0.6207,-0.1011), vec2(0.8379,0.3799), vec2(0.8457,0.4097), vec2(0.8633,0.3774), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1323,0.3765,-0.0247), vec3(-0.1381,0.4368,-0.3007), vec3(0.0277,0.3772,-0.1851), vec3(-0.2012,-0.9578,-0.2053), vec2(0.7788,0.4385), vec2(0.811,0.4814), vec2(0.8193,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2973,0.5236,-0.1371), vec3(-0.2935,0.5622,-0.2445), vec3(-0.2389,0.4534,0.0039), vec3(-0.2788,-0.9007,-0.3333), vec2(0.8584,0.4111), vec2(0.8633,0.3774), vec2(0.8457,0.4097), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1323,0.3765,-0.0247), vec3(-0.2389,0.4534,0.0039), vec3(-0.219,0.473,-0.27), vec3(-0.5997,-0.7939,-0.1006), vec2(0.7788,0.4385), vec2(0.7417,0.4658), vec2(0.7827,0.4976), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0277,0.3772,-0.1851), vec3(0.0322,0.3742,-0.0258), vec3(-0.1323,0.3765,-0.0247), vec3(-0.014,-0.9997,-0.0189), vec2(0.8193,0.3926), vec2(0.7695,0.3516), vec2(0.7788,0.4385), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2963,0.5009,0.0038), vec3(-0.355,0.5796,-0.0773), vec3(-0.2973,0.5236,-0.1371), vec3(-0.7444,-0.66,-0.1013), vec2(0.6963,0.4434), vec2(0.6948,0.4858), vec2(0.7241,0.478), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2963,0.5009,0.0038), vec3(-0.2973,0.5236,-0.1371), vec3(-0.245,0.4607,-0.0237), vec3(-0.6504,-0.7506,-0.1166), vec2(0.6963,0.4434), vec2(0.7241,0.478), vec2(0.7168,0.4312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2389,0.4534,0.0039), vec3(-0.245,0.4607,-0.0237), vec3(-0.2973,0.5236,-0.1371), vec3(0.77,0.638,-0.001), vec2(0.7417,0.4658), vec2(0.7168,0.4312), vec2(0.7241,0.478), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0322,0.3742,-0.0258), vec3(-0.1533,0.4178,-0.0205), vec3(-0.1323,0.3765,-0.0247), vec3(0.0058,-0.0963,0.9953), vec2(0.7695,0.3516), vec2(0.7344,0.4028), vec2(0.7788,0.4385), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2963,0.5009,0.0038), vec3(-0.3811,0.6045,0.0276), vec3(-0.355,0.5796,-0.0773), vec3(-0.778,-0.6266,-0.0446), vec2(0.6963,0.4434), vec2(0.6626,0.4756), vec2(0.6948,0.4858), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2389,0.4534,0.0039), vec3(-0.1323,0.3765,-0.0247), vec3(-0.1533,0.4178,-0.0205), vec3(0.2945,0.0544,0.9541), vec2(0.7417,0.4658), vec2(0.7788,0.4385), vec2(0.7344,0.4028), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1533,0.4178,-0.0205), vec3(-0.245,0.4607,-0.0237), vec3(-0.2389,0.4534,0.0039), vec3(0.4149,0.8979,0.147), vec2(0.7344,0.4028), vec2(0.7168,0.4312), vec2(0.7417,0.4658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.245,0.4607,-0.0237), vec3(-0.1533,0.4178,-0.0205), vec3(-0.246,0.4381,0.0363), vec3(-0.3907,-0.8595,-0.3297), vec2(0.7168,0.4312), vec2(0.7344,0.4028), vec2(0.707,0.4131), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0322,0.3742,-0.0258), vec3(-0.1075,0.4064,0.0656), vec3(-0.1533,0.4178,-0.0205), vec3(-0.2291,-0.9734,-0.0075), vec2(0.7695,0.3516), vec2(0.7188,0.3711), vec2(0.7344,0.4028), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2838,0.462,0.06), vec3(-0.2963,0.5009,0.0038), vec3(-0.245,0.4607,-0.0237), vec3(-0.6833,-0.6625,-0.3069), vec2(0.6943,0.4199), vec2(0.6963,0.4434), vec2(0.7168,0.4312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.246,0.4381,0.0363), vec3(-0.2838,0.462,0.06), vec3(-0.245,0.4607,-0.0237), vec3(-0.632,-0.7218,-0.2821), vec2(0.707,0.4131), vec2(0.6943,0.4199), vec2(0.7168,0.4312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2011,0.4222,0.0572), vec3(-0.246,0.4381,0.0363), vec3(-0.1533,0.4178,-0.0205), vec3(-0.2825,-0.9517,-0.1202), vec2(0.7144,0.3921), vec2(0.707,0.4131), vec2(0.7344,0.4028), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0322,0.3742,-0.0258), vec3(0.0275,0.3842,0.0553), vec3(-0.1075,0.4064,0.0656), vec3(-0.1527,-0.9819,0.1122), vec2(0.7695,0.3516), vec2(0.7422,0.335), vec2(0.7188,0.3711), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1075,0.4064,0.0656), vec3(-0.2011,0.4222,0.0572), vec3(-0.1533,0.4178,-0.0205), vec3(-0.1626,-0.9857,-0.0445), vec2(0.7188,0.3711), vec2(0.7144,0.3921), vec2(0.7344,0.4028), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2963,0.5009,0.0038), vec3(-0.3199,0.5329,0.0779), vec3(-0.3811,0.6045,0.0276), vec3(-0.77,-0.6373,0.0301), vec2(0.6963,0.4434), vec2(0.6709,0.4399), vec2(0.6626,0.4756), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2963,0.5009,0.0038), vec3(-0.2838,0.462,0.06), vec3(-0.3199,0.5329,0.0779), vec3(-0.8969,-0.4309,-0.0995), vec2(0.6963,0.4434), vec2(0.6943,0.4199), vec2(0.6709,0.4399), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.246,0.4381,0.0363), vec3(-0.2011,0.4222,0.0572), vec3(-0.2426,0.4186,0.1108), vec3(-0.2252,-0.9448,-0.2381), vec2(0.707,0.4131), vec2(0.7144,0.3921), vec2(0.6938,0.3955), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2838,0.462,0.06), vec3(-0.246,0.4381,0.0363), vec3(-0.2654,0.428,0.1181), vec3(-0.6208,-0.7465,-0.2395), vec2(0.6943,0.4199), vec2(0.707,0.4131), vec2(0.6885,0.4004), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2999,0.487,0.0995), vec3(-0.3199,0.5329,0.0779), vec3(-0.2838,0.462,0.06), vec3(-0.8968,-0.4328,-0.0915), vec2(0.6792,0.4209), vec2(0.6709,0.4399), vec2(0.6943,0.4199), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2426,0.4186,0.1108), vec3(-0.2654,0.428,0.1181), vec3(-0.246,0.4381,0.0363), vec3(-0.4313,-0.8772,-0.211), vec2(0.6938,0.3955), vec2(0.6885,0.4004), vec2(0.707,0.4131), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1075,0.4064,0.0656), vec3(0.0275,0.3842,0.0553), vec3(-0.0877,0.4253,0.1457), vec3(-0.137,-0.9557,0.2605), vec2(0.7188,0.3711), vec2(0.7422,0.335), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3811,0.6045,0.0276), vec3(-0.3199,0.5329,0.0779), vec3(-0.3619,0.6312,0.1621), vec3(-0.8127,-0.5383,0.223), vec2(0.6626,0.4756), vec2(0.6709,0.4399), vec2(0.626,0.4536), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2011,0.4222,0.0572), vec3(-0.1075,0.4064,0.0656), vec3(-0.1646,0.4319,0.1512), vec3(-0.179,-0.969,0.1702), vec2(0.7144,0.3921), vec2(0.7188,0.3711), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2654,0.428,0.1181), vec3(-0.2999,0.487,0.0995), vec3(-0.2838,0.462,0.06), vec3(-0.859,-0.5113,-0.0261), vec2(0.6885,0.4004), vec2(0.6792,0.4209), vec2(0.6943,0.4199), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0298,0.4113,0.1437), vec3(0.0275,0.3842,0.0553), vec3(0.2126,0.4259,0.0846), vec3(0.1677,-0.9438,0.2849), vec2(0.7104,0.3188), vec2(0.7422,0.335), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2426,0.4186,0.1108), vec3(-0.2011,0.4222,0.0572), vec3(-0.2247,0.4212,0.1335), vec3(0.115,-0.9931,0.0225), vec2(0.6938,0.3955), vec2(0.7144,0.3921), vec2(0.6895,0.3877), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3199,0.5329,0.0779), vec3(-0.2999,0.487,0.0995), vec3(-0.307,0.5452,0.1573), vec3(-0.9296,-0.3106,0.1985), vec2(0.6709,0.4399), vec2(0.6792,0.4209), vec2(0.6499,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2426,0.4186,0.1108), vec3(-0.2616,0.3709,0.1099), vec3(-0.2654,0.428,0.1181), vec3(-0.261,0.1213,-0.9577), vec2(0.016,0.3662), vec2(0.048,0.3647), vec2(0.0156,0.3486), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2247,0.4212,0.1335), vec3(-0.2011,0.4222,0.0572), vec3(-0.1646,0.4319,0.1512), vec3(0.165,-0.9856,0.0381), vec2(0.6895,0.3877), vec2(0.7144,0.3921), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0298,0.4113,0.1437), vec3(-0.0877,0.4253,0.1457), vec3(0.0275,0.3842,0.0553), vec3(-0.1089,-0.9497,0.2937), vec2(0.7104,0.3188), vec2(0.6943,0.3525), vec2(0.7422,0.335), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2844,0.3803,0.1173), vec3(-0.2654,0.428,0.1181), vec3(-0.2616,0.3709,0.1099), vec3(-0.2606,0.1213,-0.9578), vec2(0.0473,0.3496), vec2(0.0156,0.3486), vec2(0.048,0.3647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2616,0.3709,0.1099), vec3(-0.2675,0.3573,0.1164), vec3(-0.285,0.3646,0.1221), vec3(-0.3933,-0.256,-0.8831), vec2(0.048,0.3647), vec2(0.0582,0.3647), vec2(0.0585,0.3501), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2616,0.3709,0.1099), vec3(-0.285,0.3646,0.1221), vec3(-0.2844,0.3803,0.1173), vec3(-0.393,-0.2569,-0.8829), vec2(0.048,0.3647), vec2(0.0585,0.3501), vec2(0.0473,0.3496), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2616,0.3709,0.1099), vec3(-0.2426,0.4186,0.1108), vec3(-0.2441,0.3731,0.1319), vec3(0.7619,-0.293,-0.5776), vec2(0.048,0.3647), vec2(0.016,0.3662), vec2(0.0443,0.3823), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2675,0.3573,0.1164), vec3(-0.2918,0.2934,0.1192), vec3(-0.285,0.3646,0.1221), vec3(-0.2838,0.0669,-0.9565), vec2(0.0582,0.3647), vec2(0.0958,0.3643), vec2(0.0585,0.3501), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2654,0.428,0.1181), vec3(-0.2681,0.4406,0.1418), vec3(-0.2999,0.487,0.0995), vec3(-0.8731,-0.4648,0.147), vec2(0.6885,0.4004), vec2(0.6812,0.3989), vec2(0.6792,0.4209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2675,0.3573,0.1164), vec3(-0.2616,0.3709,0.1099), vec3(-0.2537,0.3593,0.1339), vec3(0.693,-0.5322,-0.4863), vec2(0.0582,0.3647), vec2(0.048,0.3647), vec2(0.0557,0.3804), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0877,0.4253,0.1457), vec3(-0.1646,0.4319,0.1512), vec3(-0.1075,0.4064,0.0656), vec3(-0.0652,-0.9672,0.2455), vec2(0.6943,0.3525), vec2(0.6885,0.3687), vec2(0.7188,0.3711), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2918,0.2934,0.1192), vec3(-0.2675,0.3573,0.1164), vec3(-0.278,0.3023,0.1288), vec3(0.6657,-0.2823,-0.6908), vec2(0.0958,0.3643), vec2(0.0582,0.3647), vec2(0.0944,0.377), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3076,0.2979,0.1233), vec3(-0.285,0.3646,0.1221), vec3(-0.2918,0.2934,0.1192), vec3(-0.2384,0.0631,-0.9691), vec2(0.096,0.353), vec2(0.0585,0.3501), vec2(0.0958,0.3643), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2844,0.3803,0.1173), vec3(-0.2883,0.3883,0.1364), vec3(-0.2654,0.428,0.1181), vec3(-0.8758,0.3554,-0.3265), vec2(0.0473,0.3496), vec2(0.0417,0.3345), vec2(0.0156,0.3486), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2441,0.3731,0.1319), vec3(-0.2537,0.3593,0.1339), vec3(-0.2616,0.3709,0.1099), vec3(0.6826,-0.5436,-0.4884), vec2(0.0443,0.3823), vec2(0.0557,0.3804), vec2(0.048,0.3647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2247,0.4212,0.1335), vec3(-0.2441,0.3731,0.1319), vec3(-0.2426,0.4186,0.1108), vec3(0.7671,-0.2906,-0.572), vec2(0.0108,0.3843), vec2(0.0443,0.3823), vec2(0.016,0.3662), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2537,0.3593,0.1339), vec3(-0.278,0.3023,0.1288), vec3(-0.2675,0.3573,0.1164), vec3(0.7695,-0.2764,-0.5757), vec2(0.0557,0.3804), vec2(0.0944,0.377), vec2(0.0582,0.3647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.285,0.3646,0.1221), vec3(-0.2871,0.3743,0.1404), vec3(-0.2844,0.3803,0.1173), vec3(-0.9934,0.0025,-0.1148), vec2(0.0585,0.3501), vec2(0.054,0.3354), vec2(0.0473,0.3496), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3076,0.2979,0.1233), vec3(-0.3111,0.302,0.1397), vec3(-0.285,0.3646,0.1221), vec3(-0.9134,0.3049,-0.2697), vec2(0.096,0.353), vec2(0.1024,0.3428), vec2(0.0585,0.3501), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2871,0.3743,0.1404), vec3(-0.2883,0.3883,0.1364), vec3(-0.2844,0.3803,0.1173), vec3(-0.9811,-0.126,-0.1468), vec2(0.054,0.3354), vec2(0.0417,0.3345), vec2(0.0473,0.3496), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2654,0.428,0.1181), vec3(-0.2883,0.3883,0.1364), vec3(-0.2681,0.4406,0.1418), vec3(-0.8797,0.371,-0.2974), vec2(0.0156,0.3486), vec2(0.0417,0.3345), vec2(0.0091,0.332), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.307,0.5452,0.1573), vec3(-0.3619,0.6312,0.1621), vec3(-0.3199,0.5329,0.0779), vec3(-0.8177,-0.5339,0.2153), vec2(0.6499,0.4253), vec2(0.626,0.4536), vec2(0.6709,0.4399), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.285,0.3646,0.1221), vec3(-0.3111,0.302,0.1397), vec3(-0.2871,0.3743,0.1404), vec3(-0.9139,0.3059,-0.2669), vec2(0.0585,0.3501), vec2(0.1024,0.3428), vec2(0.054,0.3354), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2819,0.4988,0.1685), vec3(-0.2999,0.487,0.0995), vec3(-0.2681,0.4406,0.1418), vec3(-0.8919,-0.3456,0.2918), vec2(0.6606,0.4077), vec2(0.6792,0.4209), vec2(0.6812,0.3989), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.278,0.3023,0.1288), vec3(-0.2537,0.3593,0.1339), vec3(-0.2751,0.3271,0.1502), vec3(0.8528,-0.3948,0.342), vec2(0.1046,0.3081), vec2(0.0678,0.2944), vec2(0.0872,0.3154), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2537,0.3593,0.1339), vec3(-0.2441,0.3731,0.1319), vec3(-0.2562,0.3661,0.1524), vec3(0.8057,-0.5111,0.2993), vec2(0.0678,0.2944), vec2(0.0584,0.2881), vec2(0.0586,0.3052), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2693,0.3041,0.1403), vec3(-0.278,0.3023,0.1288), vec3(-0.2705,0.3332,0.1514), vec3(0.7485,0.2631,-0.6087), vec2(0.6978,0.9262), vec2(0.6948,0.9307), vec2(0.7095,0.9249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2441,0.3731,0.1319), vec3(-0.2247,0.4212,0.1335), vec3(-0.2471,0.3823,0.1566), vec3(0.8966,-0.3701,0.2434), vec2(0.0584,0.2881), vec2(0.0285,0.272), vec2(0.0463,0.3003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2819,0.4988,0.1685), vec3(-0.307,0.5452,0.1573), vec3(-0.2999,0.487,0.0995), vec3(-0.8685,-0.3987,0.2947), vec2(0.6606,0.4077), vec2(0.6499,0.4253), vec2(0.6792,0.4209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2751,0.3271,0.1502), vec3(-0.2705,0.3332,0.1514), vec3(-0.278,0.3023,0.1288), vec3(-0.5959,0.5632,-0.5725), vec2(0.7031,0.933), vec2(0.7095,0.9249), vec2(0.6948,0.9307), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2883,0.3883,0.1364), vec3(-0.2871,0.3743,0.1404), vec3(-0.2742,0.3697,0.1541), vec3(-0.6999,0.1403,0.7003), vec2(0.0417,0.3345), vec2(0.054,0.3354), vec2(0.0552,0.3184), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2916,0.3317,0.1509), vec3(-0.2871,0.3743,0.1404), vec3(-0.3111,0.302,0.1397), vec3(-0.7306,0.236,0.6407), vec2(0.085,0.3262), vec2(0.054,0.3354), vec2(0.1024,0.3428), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2883,0.3883,0.1364), vec3(-0.2709,0.387,0.158), vec3(-0.2681,0.4406,0.1418), vec3(-0.7522,0.2259,0.6191), vec2(0.0417,0.3345), vec2(0.0417,0.3159), vec2(0.0091,0.332), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2562,0.3661,0.1524), vec3(-0.2751,0.3271,0.1502), vec3(-0.2537,0.3593,0.1339), vec3(0.8585,-0.4313,0.2773), vec2(0.0586,0.3052), vec2(0.0872,0.3154), vec2(0.0678,0.2944), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2471,0.3823,0.1566), vec3(-0.2562,0.3661,0.1524), vec3(-0.2441,0.3731,0.1319), vec3(0.7988,-0.5272,0.2898), vec2(0.0463,0.3003), vec2(0.0586,0.3052), vec2(0.0584,0.2881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2621,0.3059,0.1492), vec3(-0.2693,0.3041,0.1403), vec3(-0.2705,0.3332,0.1514), vec3(0.7186,0.2735,-0.6393), vec2(0.6987,0.9209), vec2(0.6978,0.9262), vec2(0.7095,0.9249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2742,0.3697,0.1541), vec3(-0.2871,0.3743,0.1404), vec3(-0.2916,0.3317,0.1509), vec3(-0.6667,0.2448,0.704), vec2(0.0552,0.3184), vec2(0.054,0.3354), vec2(0.085,0.3262), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3111,0.302,0.1397), vec3(-0.2992,0.3196,0.1557), vec3(-0.2916,0.3317,0.1509), vec3(-0.8417,0.5391,0.0301), vec2(0.6978,0.946), vec2(0.7085,0.9448), vec2(0.7051,0.937), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2883,0.3883,0.1364), vec3(-0.2742,0.3697,0.1541), vec3(-0.2709,0.387,0.158), vec3(-0.7786,0.0113,0.6275), vec2(0.0417,0.3345), vec2(0.0552,0.3184), vec2(0.0417,0.3159), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2751,0.3271,0.1502), vec3(-0.2916,0.3317,0.1509), vec3(-0.2759,0.3355,0.1502), vec3(-0.0423,-0.0011,-0.9991), vec2(0.7031,0.933), vec2(0.7051,0.937), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2751,0.3271,0.1502), vec3(-0.2916,0.3317,0.1509), vec3(-0.2759,0.3355,0.1502), vec3(-0.0423,-0.0011,-0.9991), vec2(0.7031,0.933), vec2(0.7051,0.937), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2759,0.3355,0.1502), vec3(-0.2705,0.3332,0.1514), vec3(-0.2751,0.3271,0.1502), vec3(0.2265,0.0242,-0.9737), vec2(0.7104,0.9305), vec2(0.7095,0.9249), vec2(0.7031,0.933), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.3793,0.1532), vec3(-0.2817,0.3839,0.1488), vec3(-0.2759,0.3355,0.1502), vec3(-0.2267,-0.0552,-0.9724), vec2(0.7231,0.9333), vec2(0.7227,0.9293), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.3793,0.1532), vec3(-0.2817,0.3839,0.1488), vec3(-0.2759,0.3355,0.1502), vec3(-0.2267,-0.0552,-0.9724), vec2(0.7231,0.9333), vec2(0.7227,0.9293), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.3196,0.1557), vec3(-0.3111,0.302,0.1397), vec3(-0.3172,0.2987,0.1569), vec3(-0.7528,0.6414,-0.1482), vec2(0.7085,0.9448), vec2(0.6978,0.946), vec2(0.7002,0.9511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2229,0.4313,0.1683), vec3(-0.2247,0.4212,0.1335), vec3(-0.1646,0.4319,0.1512), vec3(0.0908,-0.9578,0.2728), vec2(0.6797,0.3838), vec2(0.6895,0.3877), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2896,0.3294,0.1522), vec3(-0.2759,0.3355,0.1502), vec3(-0.2916,0.3317,0.1509), vec3(-0.0721,0.4543,0.8879), vec2(0.71,0.9376), vec2(0.7104,0.9305), vec2(0.7051,0.937), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2896,0.3294,0.1522), vec3(-0.2759,0.3355,0.1502), vec3(-0.2916,0.3317,0.1509), vec3(-0.0721,0.4543,0.8879), vec2(0.71,0.9376), vec2(0.7104,0.9305), vec2(0.7051,0.937), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2751,0.3271,0.1502), vec3(-0.2742,0.3697,0.1541), vec3(-0.2916,0.3317,0.1509), vec3(0.0163,-0.0928,0.9955), vec2(0.0872,0.3154), vec2(0.0552,0.3184), vec2(0.085,0.3262), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2896,0.3294,0.1522), vec3(-0.2992,0.3793,0.1532), vec3(-0.2759,0.3355,0.1502), vec3(-0.1401,-0.008,-0.9901), vec2(0.71,0.9376), vec2(0.7231,0.9333), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2896,0.3294,0.1522), vec3(-0.2992,0.3793,0.1532), vec3(-0.2759,0.3355,0.1502), vec3(-0.1401,-0.008,-0.9901), vec2(0.71,0.9376), vec2(0.7231,0.9333), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2742,0.3697,0.1541), vec3(-0.2751,0.3271,0.1502), vec3(-0.2562,0.3661,0.1524), vec3(0.0753,-0.0938,0.9927), vec2(0.0552,0.3184), vec2(0.0872,0.3154), vec2(0.0586,0.3052), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2229,0.4313,0.1683), vec3(-0.2471,0.3823,0.1566), vec3(-0.2247,0.4212,0.1335), vec3(0.885,-0.4577,0.0852), vec2(0.0112,0.2886), vec2(0.0463,0.3003), vec2(0.0285,0.272), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2896,0.3294,0.1522), vec3(-0.2916,0.3317,0.1509), vec3(-0.2992,0.3196,0.1557), vec3(-0.1126,0.424,0.8986), vec2(0.71,0.9376), vec2(0.7051,0.937), vec2(0.7085,0.9448), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2621,0.3059,0.1492), vec3(-0.2705,0.3332,0.1514), vec3(-0.276,0.3179,0.1604), vec3(0.6997,0.1598,0.6963), vec2(0.6987,0.9209), vec2(0.7095,0.9249), vec2(0.7061,0.9179), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0298,0.4113,0.1437), vec3(0.2126,0.4259,0.0846), vec3(0.0356,0.4692,0.2337), vec3(0.2326,-0.8249,0.5152), vec2(0.7104,0.3188), vec2(0.6943,0.3525), vec2(0.6729,0.3022), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2817,0.3839,0.1488), vec3(-0.2687,0.3755,0.1646), vec3(-0.2759,0.3355,0.1502), vec3(0.7885,0.0774,-0.6101), vec2(0.7227,0.9293), vec2(0.7217,0.9251), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2742,0.3697,0.1541), vec3(-0.2562,0.3661,0.1524), vec3(-0.2709,0.387,0.158), vec3(0.0468,-0.2277,0.9726), vec2(0.0552,0.3184), vec2(0.0586,0.3052), vec2(0.0417,0.3159), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2705,0.3332,0.1514), vec3(-0.2759,0.3355,0.1502), vec3(-0.2687,0.3755,0.1646), vec3(0.3151,0.2704,-0.9097), vec2(0.7095,0.9249), vec2(0.7104,0.9305), vec2(0.7217,0.9251), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2471,0.3823,0.1566), vec3(-0.2709,0.387,0.158), vec3(-0.2562,0.3661,0.1524), vec3(0.0065,-0.2544,0.9671), vec2(0.0463,0.3003), vec2(0.0417,0.3159), vec2(0.0586,0.3052), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.3793,0.1532), vec3(-0.296,0.401,0.1674), vec3(-0.2817,0.3839,0.1488), vec3(-0.3338,0.5512,-0.7647), vec2(0.7231,0.9333), vec2(0.73,0.9303), vec2(0.7227,0.9293), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.3793,0.1532), vec3(-0.296,0.401,0.1674), vec3(-0.2817,0.3839,0.1488), vec3(-0.3338,0.5512,-0.7647), vec2(0.7231,0.9333), vec2(0.73,0.9303), vec2(0.7227,0.9293), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2963,0.3133,0.1625), vec3(-0.2992,0.3196,0.1557), vec3(-0.3172,0.2987,0.1569), vec3(-0.5295,0.5001,0.6852), vec2(0.709,0.9503), vec2(0.7085,0.9448), vec2(0.7002,0.9511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3026,0.368,0.1704), vec3(-0.2992,0.3793,0.1532), vec3(-0.2896,0.3294,0.1522), vec3(-0.9379,-0.175,-0.2996), vec2(0.7246,0.9386), vec2(0.7231,0.9333), vec2(0.71,0.9376), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.245,0.4383,0.176), vec3(-0.2681,0.4406,0.1418), vec3(-0.2709,0.387,0.158), vec3(-0.8044,0.2096,0.5559), vec2(0.0072,0.3042), vec2(0.0091,0.332), vec2(0.0417,0.3159), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2813,0.4047,0.164), vec3(-0.2687,0.3755,0.1646), vec3(-0.2817,0.3839,0.1488), vec3(0.8053,0.3397,-0.4859), vec2(0.7261,0.9275), vec2(0.7217,0.9251), vec2(0.7227,0.9293), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.3196,0.1557), vec3(-0.3026,0.368,0.1704), vec3(-0.2896,0.3294,0.1522), vec3(-0.5177,0.2157,-0.8279), vec2(0.7085,0.9448), vec2(0.7246,0.9386), vec2(0.71,0.9376), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2817,0.3839,0.1488), vec3(-0.296,0.401,0.1674), vec3(-0.2813,0.4047,0.164), vec3(-0.3204,0.5609,-0.7633), vec2(0.7227,0.9293), vec2(0.73,0.9303), vec2(0.7261,0.9275), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2817,0.3839,0.1488), vec3(-0.296,0.401,0.1674), vec3(-0.2813,0.4047,0.164), vec3(-0.3204,0.5609,-0.7633), vec2(0.7227,0.9293), vec2(0.73,0.9303), vec2(0.7261,0.9275), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2813,0.3963,0.156), vec3(-0.2734,0.4012,0.1678), vec3(-0.2993,0.3908,0.1587), vec3(0.3136,-0.9333,0.1751), vec2(0.8062,0.0298), vec2(0.7979,0.0298), vec2(0.8101,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2813,0.3963,0.156), vec3(-0.2734,0.4012,0.1678), vec3(-0.2993,0.3908,0.1587), vec3(0.3136,-0.9333,0.1751), vec2(0.8062,0.0298), vec2(0.7979,0.0298), vec2(0.8101,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2741,0.3016,0.1608), vec3(-0.276,0.3179,0.1604), vec3(-0.2963,0.3133,0.1625), vec3(0.0954,0.0344,0.9948), vec2(0.7017,0.915), vec2(0.7061,0.9179), vec2(0.708,0.9115), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2681,0.4406,0.1418), vec3(-0.245,0.4383,0.176), vec3(-0.2819,0.4988,0.1685), vec3(-0.7692,-0.4079,0.4919), vec2(0.6812,0.3989), vec2(0.6748,0.3892), vec2(0.6606,0.4077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2471,0.3823,0.1566), vec3(-0.245,0.4383,0.176), vec3(-0.2709,0.387,0.158), vec3(-0.009,-0.3271,0.945), vec2(0.0463,0.3003), vec2(0.0072,0.3042), vec2(0.0417,0.3159), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.276,0.3179,0.1604), vec3(-0.2705,0.3332,0.1514), vec3(-0.2706,0.358,0.1792), vec3(0.9541,-0.2217,0.2013), vec2(0.7061,0.9179), vec2(0.7095,0.9249), vec2(0.7197,0.9203), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2992,0.3793,0.1532), vec3(-0.3026,0.368,0.1704), vec3(-0.296,0.401,0.1674), vec3(-0.9794,0.1895,-0.0696), vec2(0.7231,0.9333), vec2(0.7246,0.9386), vec2(0.73,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2993,0.3908,0.1587), vec3(-0.2964,0.413,0.1793), vec3(-0.2813,0.3963,0.156), vec3(-0.3068,0.6687,-0.6773), vec2(0.8062,0.0298), vec2(0.8032,0.0186), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2993,0.3908,0.1587), vec3(-0.2964,0.413,0.1793), vec3(-0.2813,0.3963,0.156), vec3(-0.3068,0.6687,-0.6773), vec2(0.8062,0.0298), vec2(0.8032,0.0186), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2687,0.3755,0.1646), vec3(-0.2706,0.358,0.1792), vec3(-0.2705,0.3332,0.1514), vec3(0.9964,-0.0613,0.0588), vec2(0.7217,0.9251), vec2(0.7197,0.9203), vec2(0.7095,0.9249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2734,0.4012,0.1678), vec3(-0.3014,0.3892,0.1728), vec3(-0.2993,0.3908,0.1587), vec3(0.386,-0.9214,-0.0456), vec2(0.7979,0.0298), vec2(0.8076,0.0161), vec2(0.8101,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2734,0.4012,0.1678), vec3(-0.3014,0.3892,0.1728), vec3(-0.2993,0.3908,0.1587), vec3(0.386,-0.9214,-0.0456), vec2(0.7979,0.0298), vec2(0.8076,0.0161), vec2(0.8101,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2813,0.3963,0.156), vec3(-0.2829,0.4158,0.1756), vec3(-0.2734,0.4012,0.1678), vec3(0.4905,0.6381,-0.5935), vec2(0.7979,0.0298), vec2(0.7983,0.019), vec2(0.7939,0.0249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2813,0.3963,0.156), vec3(-0.2829,0.4158,0.1756), vec3(-0.2734,0.4012,0.1678), vec3(0.4905,0.6381,-0.5935), vec2(0.7979,0.0298), vec2(0.7983,0.019), vec2(0.7939,0.0249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.245,0.4383,0.176), vec3(-0.2471,0.3823,0.1566), vec3(-0.2229,0.4313,0.1683), vec3(0.2191,-0.3266,0.9194), vec2(0.0072,0.3042), vec2(0.0463,0.3003), vec2(0.0112,0.2886), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1981,0.4475,0.1815), vec3(-0.2229,0.4313,0.1683), vec3(-0.1646,0.4319,0.1512), vec3(0.1856,-0.7745,0.6047), vec2(0.6753,0.3745), vec2(0.6797,0.3838), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2963,0.3133,0.1625), vec3(-0.2868,0.3562,0.1833), vec3(-0.2992,0.3196,0.1557), vec3(-0.9161,0.009,0.4008), vec2(0.709,0.9503), vec2(0.7261,0.9458), vec2(0.7085,0.9448), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2813,0.4047,0.164), vec3(-0.2698,0.4046,0.1768), vec3(-0.2687,0.3755,0.1646), vec3(0.7111,0.2955,-0.638), vec2(0.7261,0.9275), vec2(0.7266,0.9252), vec2(0.7217,0.9251), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2963,0.3133,0.1625), vec3(-0.276,0.3179,0.1604), vec3(-0.2868,0.3562,0.1833), vec3(0.1954,-0.4614,0.8654), vec2(0.708,0.9115), vec2(0.7061,0.9179), vec2(0.7212,0.9158), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2813,0.4047,0.164), vec3(-0.296,0.401,0.1674), vec3(-0.2698,0.4046,0.1768), vec3(-0.1994,0.9616,0.1887), vec2(0.7261,0.9275), vec2(0.73,0.9303), vec2(0.7266,0.9252), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2813,0.4047,0.164), vec3(-0.296,0.401,0.1674), vec3(-0.2698,0.4046,0.1768), vec3(-0.1994,0.9616,0.1887), vec2(0.7261,0.9275), vec2(0.73,0.9303), vec2(0.7266,0.9252), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2868,0.3562,0.1833), vec3(-0.3026,0.368,0.1704), vec3(-0.2992,0.3196,0.1557), vec3(-0.7166,-0.2482,0.6519), vec2(0.7261,0.9458), vec2(0.7246,0.9386), vec2(0.7085,0.9448), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2993,0.3908,0.1587), vec3(-0.3014,0.3892,0.1728), vec3(-0.2964,0.413,0.1793), vec3(-0.9646,0.2361,-0.1177), vec2(0.8062,0.0298), vec2(0.8101,0.0254), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2993,0.3908,0.1587), vec3(-0.3014,0.3892,0.1728), vec3(-0.2964,0.413,0.1793), vec3(-0.9646,0.2361,-0.1177), vec2(0.8062,0.0298), vec2(0.8101,0.0254), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2829,0.4158,0.1756), vec3(-0.2813,0.3963,0.156), vec3(-0.2964,0.413,0.1793), vec3(-0.3239,0.6574,-0.6803), vec2(0.7983,0.019), vec2(0.7979,0.0298), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2829,0.4158,0.1756), vec3(-0.2813,0.3963,0.156), vec3(-0.2964,0.413,0.1793), vec3(-0.3239,0.6574,-0.6803), vec2(0.7983,0.019), vec2(0.7979,0.0298), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3,0.3963,0.1845), vec3(-0.296,0.401,0.1674), vec3(-0.3026,0.368,0.1704), vec3(-0.9677,0.1772,-0.1795), vec2(0.7329,0.9343), vec2(0.73,0.9303), vec2(0.7246,0.9386), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2706,0.358,0.1792), vec3(-0.2868,0.3562,0.1833), vec3(-0.276,0.3179,0.1604), vec3(0.265,-0.4379,0.8591), vec2(0.7197,0.9203), vec2(0.7212,0.9158), vec2(0.7061,0.9179), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0298,0.4113,0.1437), vec3(0.0356,0.4692,0.2337), vec3(-0.0877,0.4253,0.1457), vec3(-0.0909,-0.835,0.5427), vec2(0.7104,0.3188), vec2(0.6729,0.3022), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2734,0.4123,0.1851), vec3(-0.3014,0.3892,0.1728), vec3(-0.2734,0.4012,0.1678), vec3(0.4156,-0.7657,0.4908), vec2(0.7939,0.0249), vec2(0.8076,0.0161), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2734,0.4123,0.1851), vec3(-0.3014,0.3892,0.1728), vec3(-0.2734,0.4012,0.1678), vec3(0.4156,-0.7657,0.4908), vec2(0.7939,0.0249), vec2(0.8076,0.0161), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2229,0.4313,0.1683), vec3(-0.1981,0.4475,0.1815), vec3(-0.245,0.4383,0.176), vec3(0.0459,-0.6712,0.7398), vec2(0.6797,0.3838), vec2(0.6753,0.3745), vec2(0.6748,0.3892), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2829,0.4158,0.1756), vec3(-0.2734,0.4123,0.1851), vec3(-0.2734,0.4012,0.1678), vec3(0.6483,0.6422,-0.4089), vec2(0.7983,0.019), vec2(0.7939,0.0161), vec2(0.7939,0.0249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2829,0.4158,0.1756), vec3(-0.2734,0.4123,0.1851), vec3(-0.2734,0.4012,0.1678), vec3(0.6483,0.6422,-0.4089), vec2(0.7983,0.019), vec2(0.7939,0.0161), vec2(0.7939,0.0249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3,0.3963,0.1845), vec3(-0.2698,0.4046,0.1768), vec3(-0.296,0.401,0.1674), vec3(-0.208,0.9542,0.2152), vec2(0.7344,0.9249), vec2(0.7266,0.9252), vec2(0.73,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3,0.3963,0.1845), vec3(-0.2698,0.4046,0.1768), vec3(-0.296,0.401,0.1674), vec3(-0.208,0.9542,0.2152), vec2(0.7344,0.9249), vec2(0.7266,0.9252), vec2(0.73,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2698,0.4046,0.1768), vec3(-0.2691,0.3851,0.1933), vec3(-0.2687,0.3755,0.1646), vec3(0.9993,0.0363,0.0038), vec2(0.7266,0.9252), vec2(0.7261,0.9222), vec2(0.7217,0.9251), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2706,0.358,0.1792), vec3(-0.2687,0.3755,0.1646), vec3(-0.2691,0.3851,0.1933), vec3(0.9963,-0.0759,0.0411), vec2(0.7197,0.9203), vec2(0.7217,0.9251), vec2(0.7261,0.9222), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0877,0.4253,0.1457), vec3(-0.1512,0.4789,0.2403), vec3(-0.1646,0.4319,0.1512), vec3(-0.0415,-0.8813,0.4708), vec2(0.6943,0.3525), vec2(0.6538,0.3569), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2964,0.413,0.1793), vec3(-0.3014,0.3892,0.1728), vec3(-0.2999,0.4047,0.1887), vec3(-0.9587,0.243,-0.1477), vec2(0.8032,0.0186), vec2(0.8101,0.0254), vec2(0.8076,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2964,0.413,0.1793), vec3(-0.3014,0.3892,0.1728), vec3(-0.2999,0.4047,0.1887), vec3(-0.9587,0.243,-0.1477), vec2(0.8032,0.0186), vec2(0.8101,0.0254), vec2(0.8076,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3014,0.3892,0.1728), vec3(-0.2734,0.4123,0.1851), vec3(-0.2999,0.4047,0.1887), vec3(0.2882,-0.6986,0.6549), vec2(0.8076,0.0161), vec2(0.7939,0.0249), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3014,0.3892,0.1728), vec3(-0.2734,0.4123,0.1851), vec3(-0.2999,0.4047,0.1887), vec3(0.2882,-0.6986,0.6549), vec2(0.8076,0.0161), vec2(0.7939,0.0249), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2829,0.4158,0.1756), vec3(-0.2964,0.413,0.1793), vec3(-0.2827,0.4189,0.1921), vec3(-0.2469,0.9537,-0.172), vec2(0.7983,0.019), vec2(0.8032,0.0186), vec2(0.7988,0.0137), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2829,0.4158,0.1756), vec3(-0.2964,0.413,0.1793), vec3(-0.2827,0.4189,0.1921), vec3(-0.2469,0.9537,-0.172), vec2(0.7983,0.019), vec2(0.8032,0.0186), vec2(0.7988,0.0137), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2868,0.3562,0.1833), vec3(-0.2901,0.3857,0.1965), vec3(-0.3026,0.368,0.1704), vec3(-0.7345,-0.3462,0.5836), vec2(0.7261,0.9458), vec2(0.7344,0.9394), vec2(0.7246,0.9386), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3,0.3963,0.1845), vec3(-0.3026,0.368,0.1704), vec3(-0.2901,0.3857,0.1965), vec3(-0.8334,-0.1839,0.5213), vec2(0.7329,0.9343), vec2(0.7246,0.9386), vec2(0.7344,0.9394), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.307,0.5452,0.1573), vec3(-0.268,0.5421,0.2329), vec3(-0.3619,0.6312,0.1621), vec3(-0.7709,-0.5131,0.3775), vec2(0.6499,0.4253), vec2(0.6328,0.4023), vec2(0.626,0.4536), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2734,0.4123,0.1851), vec3(-0.2829,0.4158,0.1756), vec3(-0.2827,0.4189,0.1921), vec3(0.4845,0.8591,-0.1651), vec2(0.7939,0.0161), vec2(0.7983,0.019), vec2(0.7988,0.0137), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2734,0.4123,0.1851), vec3(-0.2829,0.4158,0.1756), vec3(-0.2827,0.4189,0.1921), vec3(0.4845,0.8591,-0.1651), vec2(0.7939,0.0161), vec2(0.7983,0.019), vec2(0.7988,0.0137), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2262,0.4761,0.2084), vec3(-0.2819,0.4988,0.1685), vec3(-0.245,0.4383,0.176), vec3(-0.6333,-0.2971,0.7146), vec2(0.6597,0.3828), vec2(0.6606,0.4077), vec2(0.6748,0.3892), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2691,0.3851,0.1933), vec3(-0.2868,0.3562,0.1833), vec3(-0.2706,0.358,0.1792), vec3(0.2647,-0.4565,0.8495), vec2(0.7261,0.9222), vec2(0.7212,0.9158), vec2(0.7197,0.9203), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3,0.3963,0.1845), vec3(-0.2901,0.3857,0.1965), vec3(-0.2698,0.4046,0.1768), vec3(-0.0327,0.7373,0.6748), vec2(0.7344,0.9249), vec2(0.73,0.9196), vec2(0.7266,0.9252), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3,0.3963,0.1845), vec3(-0.2901,0.3857,0.1965), vec3(-0.2698,0.4046,0.1768), vec3(-0.0327,0.7373,0.6748), vec2(0.7344,0.9249), vec2(0.73,0.9196), vec2(0.7266,0.9252), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.307,0.5452,0.1573), vec3(-0.2819,0.4988,0.1685), vec3(-0.268,0.5421,0.2329), vec3(-0.8373,-0.3519,0.4185), vec2(0.6499,0.4253), vec2(0.6606,0.4077), vec2(0.6328,0.4023), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2964,0.413,0.1793), vec3(-0.2999,0.4047,0.1887), vec3(-0.2924,0.4178,0.1944), vec3(-0.8781,0.4712,0.0829), vec2(0.8032,0.0186), vec2(0.8076,0.0161), vec2(0.8022,0.0132), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2964,0.413,0.1793), vec3(-0.2999,0.4047,0.1887), vec3(-0.2924,0.4178,0.1944), vec3(-0.8781,0.4712,0.0829), vec2(0.8032,0.0186), vec2(0.8076,0.0161), vec2(0.8022,0.0132), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2924,0.4178,0.1944), vec3(-0.2827,0.4189,0.1921), vec3(-0.2964,0.413,0.1793), vec3(-0.1663,0.9519,-0.2573), vec2(0.8022,0.0132), vec2(0.7988,0.0137), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2924,0.4178,0.1944), vec3(-0.2827,0.4189,0.1921), vec3(-0.2964,0.413,0.1793), vec3(-0.1663,0.9519,-0.2573), vec2(0.8022,0.0132), vec2(0.7988,0.0137), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2262,0.4761,0.2084), vec3(-0.245,0.4383,0.176), vec3(-0.1981,0.4475,0.1815), vec3(0.0435,-0.6631,0.7473), vec2(0.6597,0.3828), vec2(0.6748,0.3892), vec2(0.6753,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2691,0.3851,0.1933), vec3(-0.2698,0.4046,0.1768), vec3(-0.2901,0.3857,0.1965), vec3(0.1338,0.6418,0.7551), vec2(0.7261,0.9222), vec2(0.7266,0.9252), vec2(0.73,0.9196), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2691,0.3851,0.1933), vec3(-0.2698,0.4046,0.1768), vec3(-0.2901,0.3857,0.1965), vec3(0.1338,0.6418,0.7551), vec2(0.7261,0.9222), vec2(0.7266,0.9252), vec2(0.73,0.9196), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1512,0.4789,0.2403), vec3(-0.1981,0.4475,0.1815), vec3(-0.1646,0.4319,0.1512), vec3(0.0085,-0.8851,0.4653), vec2(0.6538,0.3569), vec2(0.6753,0.3745), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2691,0.3851,0.1933), vec3(-0.2901,0.3857,0.1965), vec3(-0.2868,0.3562,0.1833), vec3(0.1292,-0.3947,0.9097), vec2(0.7261,0.9222), vec2(0.73,0.9196), vec2(0.7212,0.9158), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2734,0.4123,0.1851), vec3(-0.2791,0.4161,0.207), vec3(-0.2999,0.4047,0.1887), vec3(0.2963,-0.9248,0.2387), vec2(0.7939,0.0249), vec2(0.7939,0.0161), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2734,0.4123,0.1851), vec3(-0.2791,0.4161,0.207), vec3(-0.2999,0.4047,0.1887), vec3(0.2963,-0.9248,0.2387), vec2(0.7939,0.0249), vec2(0.7939,0.0161), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2827,0.4189,0.1921), vec3(-0.2791,0.4161,0.207), vec3(-0.2734,0.4123,0.1851), vec3(0.5834,0.8121,0.0091), vec2(0.7988,0.0137), vec2(0.7983,0.0078), vec2(0.7939,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2827,0.4189,0.1921), vec3(-0.2791,0.4161,0.207), vec3(-0.2734,0.4123,0.1851), vec3(0.5834,0.8121,0.0091), vec2(0.7988,0.0137), vec2(0.7983,0.0078), vec2(0.7939,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2864,0.4151,0.2089), vec3(-0.2924,0.4178,0.1944), vec3(-0.2999,0.4047,0.1887), vec3(-0.8548,0.3123,0.4145), vec2(0.8018,0.0073), vec2(0.8022,0.0132), vec2(0.8076,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2864,0.4151,0.2089), vec3(-0.2924,0.4178,0.1944), vec3(-0.2999,0.4047,0.1887), vec3(-0.8548,0.3123,0.4145), vec2(0.8018,0.0073), vec2(0.8022,0.0132), vec2(0.8076,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2827,0.4189,0.1921), vec3(-0.2924,0.4178,0.1944), vec3(-0.2864,0.4151,0.2089), vec3(-0.0596,0.9767,0.206), vec2(0.7988,0.0137), vec2(0.8022,0.0132), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2827,0.4189,0.1921), vec3(-0.2924,0.4178,0.1944), vec3(-0.2864,0.4151,0.2089), vec3(-0.0596,0.9767,0.206), vec2(0.7988,0.0137), vec2(0.8022,0.0132), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2864,0.4151,0.2089), vec3(-0.2999,0.4047,0.1887), vec3(-0.2791,0.4161,0.207), vec3(0.2159,-0.9199,0.3273), vec2(0.7983,0.0078), vec2(0.8018,0.0073), vec2(0.7939,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2864,0.4151,0.2089), vec3(-0.2999,0.4047,0.1887), vec3(-0.2791,0.4161,0.207), vec3(0.2159,-0.9199,0.3273), vec2(0.7983,0.0078), vec2(0.8018,0.0073), vec2(0.7939,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2791,0.4161,0.207), vec3(-0.2827,0.4189,0.1921), vec3(-0.2864,0.4151,0.2089), vec3(-0.0864,0.976,0.1999), vec2(0.7983,0.0078), vec2(0.7988,0.0137), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2791,0.4161,0.207), vec3(-0.2827,0.4189,0.1921), vec3(-0.2864,0.4151,0.2089), vec3(-0.0864,0.976,0.1999), vec2(0.7983,0.0078), vec2(0.7988,0.0137), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2262,0.4761,0.2084), vec3(-0.268,0.5421,0.2329), vec3(-0.2819,0.4988,0.1685), vec3(-0.6165,-0.5848,0.5272), vec2(0.6597,0.3828), vec2(0.6328,0.4023), vec2(0.6606,0.4077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0784,0.4764,0.2396), vec3(-0.0877,0.4253,0.1457), vec3(0.0356,0.4692,0.2337), vec3(-0.0313,-0.8767,0.48), vec2(0.6577,0.3379), vec2(0.6943,0.3525), vec2(0.6729,0.3022), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1512,0.4789,0.2403), vec3(-0.0877,0.4253,0.1457), vec3(-0.0784,0.4764,0.2396), vec3(-0.025,-0.8772,0.4796), vec2(0.6538,0.3569), vec2(0.6943,0.3525), vec2(0.6577,0.3379), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1981,0.4475,0.1815), vec3(-0.1512,0.4789,0.2403), vec3(-0.2262,0.4761,0.2084), vec3(-0.2217,-0.776,0.5905), vec2(0.6753,0.3745), vec2(0.6538,0.3569), vec2(0.6597,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2035,0.5083,0.2584), vec3(-0.268,0.5421,0.2329), vec3(-0.2262,0.4761,0.2084), vec3(-0.5435,-0.5712,0.6151), vec2(0.6387,0.3745), vec2(0.6328,0.4023), vec2(0.6597,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3247,0.6241,0.3071), vec3(-0.3619,0.6312,0.1621), vec3(-0.268,0.5421,0.2329), vec3(-0.7394,-0.6546,0.1575), vec2(0.5903,0.4189), vec2(0.626,0.4536), vec2(0.6328,0.4023), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2262,0.4761,0.2084), vec3(-0.1512,0.4789,0.2403), vec3(-0.2035,0.5083,0.2584), vec3(-0.2253,-0.7689,0.5984), vec2(0.6597,0.3828), vec2(0.6538,0.3569), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2035,0.5083,0.2584), vec3(-0.2629,0.5997,0.3442), vec3(-0.268,0.5421,0.2329), vec3(-0.5456,-0.7339,0.4046), vec2(0.6387,0.3745), vec2(0.5879,0.3926), vec2(0.6328,0.4023), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.5619,0.7139,-0.0213), 0.7972, bestT)) {
        if (triHit(ro, rd, vec3(-0.6452,0.587,-0.5472), vec3(-0.415,0.6746,-0.417), vec3(-0.5739,0.58,-0.1872), vec3(0.4015,-0.9107,-0.0972), vec2(0.6055,0.0903), vec2(0.6772,0.1162), vec2(0.6597,0.1782), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7222,0.5337,-0.3307), vec3(-0.7287,0.4342,-0.1501), vec3(-0.6502,0.5963,-0.2365), vec3(-0.8056,0.5308,0.2631), vec2(0.1591,0.7239), vec2(0.2158,0.7061), vec2(0.177,0.7528), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5076,0.7602,-0.0802), vec3(-0.5739,0.58,-0.1872), vec3(-0.415,0.6746,-0.417), vec3(0.7956,-0.4978,0.3453), vec2(0.7031,0.1914), vec2(0.6597,0.1782), vec2(0.6772,0.1162), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5398,0.8028,-0.3826), vec3(-0.6502,0.5963,-0.2365), vec3(-0.5649,0.8387,-0.0581), vec3(-0.9077,0.4037,-0.1147), vec2(0.113,0.8263), vec2(0.177,0.7528), vec2(0.2054,0.8118), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5398,0.8028,-0.3826), vec3(-0.5649,0.8387,-0.0581), vec3(-0.4084,1.0733,-0.2135), vec3(-0.861,0.494,-0.1211), vec2(0.113,0.8263), vec2(0.2054,0.8118), vec2(0.1307,0.9007), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5739,0.58,-0.1872), vec3(-0.707,0.41,-0.1454), vec3(-0.6522,0.475,-0.3119), vec3(0.7897,-0.6131,0.0205), vec2(0.6597,0.1782), vec2(0.6265,0.1968), vec2(0.6216,0.1567), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.415,0.6746,-0.417), vec3(-0.4433,0.8552,-0.0938), vec3(-0.5076,0.7602,-0.0802), vec3(0.7996,-0.4917,0.3448), vec2(0.6772,0.1162), vec2(0.7397,0.1714), vec2(0.7031,0.1914), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2935,0.5622,-0.2445), vec3(-0.355,0.5796,-0.0773), vec3(-0.377,0.6763,-0.2198), vec3(-0.8074,-0.5385,-0.2412), vec2(0.8633,0.3774), vec2(0.876,0.4189), vec2(0.8945,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.377,0.6763,-0.2198), vec3(-0.4061,0.7269,-0.0345), vec3(-0.3608,0.7702,-0.2462), vec3(-0.9759,0.1157,-0.1848), vec2(0.8945,0.3745), vec2(0.9102,0.4072), vec2(0.9258,0.3682), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4433,0.8552,-0.0938), vec3(-0.4054,0.959,-0.1428), vec3(-0.3608,0.7702,-0.2462), vec3(-0.859,0.0746,-0.5065), vec2(0.6313,0.5754), vec2(0.6128,0.6121), vec2(0.6768,0.592), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.355,0.5796,-0.0773), vec3(-0.2935,0.5622,-0.2445), vec3(-0.2973,0.5236,-0.1371), vec3(-0.79,-0.5675,-0.2318), vec2(0.876,0.4189), vec2(0.8633,0.3774), vec2(0.8584,0.4111), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4433,0.8552,-0.0938), vec3(-0.3608,0.7702,-0.2462), vec3(-0.4061,0.7269,-0.0345), vec3(-0.8853,-0.3807,-0.2671), vec2(0.9443,0.3955), vec2(0.9258,0.3682), vec2(0.9102,0.4072), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6914,0.6379,0.0312), vec3(-0.6502,0.5963,-0.2365), vec3(-0.7287,0.4342,-0.1501), vec3(-0.9194,0.3418,-0.1947), vec2(0.2499,0.7439), vec2(0.177,0.7528), vec2(0.2158,0.7061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4061,0.7269,-0.0345), vec3(-0.377,0.6763,-0.2198), vec3(-0.355,0.5796,-0.0773), vec3(-0.9486,-0.3099,-0.0644), vec2(0.9102,0.4072), vec2(0.8945,0.3745), vec2(0.876,0.4189), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.707,0.41,-0.1454), vec3(-0.5739,0.58,-0.1872), vec3(-0.6614,0.6393,0.0135), vec3(0.7487,-0.4716,0.4658), vec2(0.6265,0.1968), vec2(0.6597,0.1782), vec2(0.6719,0.2217), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6502,0.5963,-0.2365), vec3(-0.6914,0.6379,0.0312), vec3(-0.5649,0.8387,-0.0581), vec3(-0.8666,0.4552,-0.2042), vec2(0.177,0.7528), vec2(0.2499,0.7439), vec2(0.2054,0.8118), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5076,0.7602,-0.0802), vec3(-0.6614,0.6393,0.0135), vec3(-0.5739,0.58,-0.1872), vec3(0.7046,-0.5356,0.4654), vec2(0.7031,0.1914), vec2(0.6719,0.2217), vec2(0.6597,0.1782), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4619,1.123,0.0276), vec3(-0.4084,1.0733,-0.2135), vec3(-0.5649,0.8387,-0.0581), vec3(-0.874,0.3999,-0.2762), vec2(0.1959,0.8832), vec2(0.1307,0.9007), vec2(0.2054,0.8118), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4433,0.8552,-0.0938), vec3(-0.4602,0.954,0.0957), vec3(-0.4054,0.959,-0.1428), vec3(-0.946,0.2453,-0.212), vec2(0.6313,0.5754), vec2(0.5757,0.5515), vec2(0.6128,0.6121), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.355,0.5796,-0.0773), vec3(-0.3811,0.6045,0.0276), vec3(-0.4061,0.7269,-0.0345), vec3(-0.9455,-0.2786,-0.1686), vec2(0.876,0.4189), vec2(0.8877,0.437), vec2(0.9102,0.4072), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4433,0.8552,-0.0938), vec3(-0.4602,0.954,0.0957), vec3(-0.5076,0.7602,-0.0802), vec3(0.803,-0.4961,0.3302), vec2(0.7397,0.1714), vec2(0.7583,0.21), vec2(0.7031,0.1914), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4061,0.7269,-0.0345), vec3(-0.4025,0.7849,0.0996), vec3(-0.4433,0.8552,-0.0938), vec3(-0.9668,-0.224,0.1229), vec2(0.9102,0.4072), vec2(0.9219,0.4341), vec2(0.9443,0.3955), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4076,1.068,0.0469), vec3(-0.4054,0.959,-0.1428), vec3(-0.4602,0.954,0.0957), vec3(-0.9192,0.337,-0.2039), vec2(0.5581,0.5881), vec2(0.6128,0.6121), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.707,0.41,-0.1454), vec3(-0.6614,0.6393,0.0135), vec3(-0.8812,0.3586,0.2215), vec3(0.8459,-0.407,0.3446), vec2(0.6265,0.1968), vec2(0.6719,0.2217), vec2(0.6348,0.2788), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4061,0.7269,-0.0345), vec3(-0.3811,0.6045,0.0276), vec3(-0.4025,0.7849,0.0996), vec3(-0.9837,-0.1537,0.0929), vec2(0.9102,0.4072), vec2(0.8877,0.437), vec2(0.9219,0.4341), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7287,0.4342,-0.1501), vec3(-0.8913,0.3465,0.2172), vec3(-0.6914,0.6379,0.0312), vec3(-0.8655,0.4121,-0.2847), vec2(0.2158,0.7061), vec2(0.321,0.6643), vec2(0.2499,0.7439), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4602,0.954,0.0957), vec3(-0.4433,0.8552,-0.0938), vec3(-0.4025,0.7849,0.0996), vec3(-0.9437,-0.32,0.0832), vec2(0.9639,0.4326), vec2(0.9443,0.3955), vec2(0.9219,0.4341), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6614,0.6393,0.0135), vec3(-0.5076,0.7602,-0.0802), vec3(-0.6982,0.9336,0.1809), vec3(0.6596,-0.3076,0.6858), vec2(0.6719,0.2217), vec2(0.7031,0.1914), vec2(0.7188,0.2417), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5649,0.8387,-0.0581), vec3(-0.694,0.9748,0.1675), vec3(-0.4619,1.123,0.0276), vec3(-0.6507,0.4254,-0.629), vec2(0.2054,0.8118), vec2(0.2583,0.8077), vec2(0.1959,0.8832), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.694,0.9748,0.1675), vec3(-0.5649,0.8387,-0.0581), vec3(-0.6914,0.6379,0.0312), vec3(-0.7782,0.2304,-0.5843), vec2(0.2583,0.8077), vec2(0.2054,0.8118), vec2(0.2499,0.7439), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8913,0.3465,0.2172), vec3(-0.7287,0.4342,-0.1501), vec3(-1.0356,0.1474,0.0736), vec3(-0.7361,0.6554,-0.1693), vec2(0.321,0.6643), vec2(0.2158,0.7061), vec2(0.3049,0.6011), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8812,0.3586,0.2215), vec3(-1.0292,0.1387,0.0741), vec3(-0.707,0.41,-0.1454), vec3(0.7176,-0.6502,0.2497), vec2(0.6348,0.2788), vec2(0.5811,0.2627), vec2(0.6265,0.1968), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4602,0.954,0.0957), vec3(-0.6982,0.9336,0.1809), vec3(-0.5076,0.7602,-0.0802), vec3(0.2979,-0.6805,0.6694), vec2(0.7583,0.21), vec2(0.7188,0.2417), vec2(0.7031,0.1914), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3811,0.6045,0.0276), vec3(-0.3619,0.6312,0.1621), vec3(-0.4025,0.7849,0.0996), vec3(-0.9672,-0.1844,0.1746), vec2(0.8877,0.437), vec2(0.8994,0.4624), vec2(0.9219,0.4341), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4025,0.7849,0.0996), vec3(-0.3684,0.8582,0.2643), vec3(-0.4602,0.954,0.0957), vec3(-0.8992,-0.2993,0.319), vec2(0.9219,0.4341), vec2(0.9355,0.4678), vec2(0.9639,0.4326), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3684,0.8582,0.2643), vec3(-0.4025,0.7849,0.0996), vec3(-0.3619,0.6312,0.1621), vec3(-0.9541,-0.1455,0.2619), vec2(0.9355,0.4678), vec2(0.9219,0.4341), vec2(0.8994,0.4624), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6614,0.6393,0.0135), vec3(-0.6982,0.9336,0.1809), vec3(-0.8326,0.7385,0.3604), vec3(0.8661,-0.161,0.4733), vec2(0.6719,0.2217), vec2(0.7188,0.2417), vec2(0.6855,0.2949), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6914,0.6379,0.0312), vec3(-0.836,0.7408,0.3564), vec3(-0.694,0.9748,0.1675), vec3(-0.8783,0.1735,-0.4456), vec2(0.2499,0.7439), vec2(0.3357,0.7244), vec2(0.2583,0.8077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.8326,0.7385,0.3604), vec3(-0.8812,0.3586,0.2215), vec3(-0.6614,0.6393,0.0135), vec3(0.8251,-0.2841,0.4883), vec2(0.6855,0.2949), vec2(0.6348,0.2788), vec2(0.6719,0.2217), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.836,0.7408,0.3564), vec3(-0.6914,0.6379,0.0312), vec3(-0.8913,0.3465,0.2172), vec3(-0.8406,0.2812,-0.463), vec2(0.3357,0.7244), vec2(0.2499,0.7439), vec2(0.321,0.6643), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7658,1.0732,0.4874), vec3(-0.694,0.9748,0.1675), vec3(-0.836,0.7408,0.3564), vec3(-0.9035,0.3082,-0.2977), vec2(0.3376,0.8015), vec2(0.2583,0.8077), vec2(0.3357,0.7244), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7654,1.0496,0.4916), vec3(-0.8326,0.7385,0.3604), vec3(-0.6982,0.9336,0.1809), vec3(0.8919,-0.3252,0.3141), vec2(0.7446,0.3018), vec2(0.6855,0.2949), vec2(0.7188,0.2417), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.0801,0.6589,0.476), 0.4992, bestT)) {
        if (triHit(ro, rd, vec3(-0.3619,0.6312,0.1621), vec3(-0.3247,0.6241,0.3071), vec3(-0.3684,0.8582,0.2643), vec3(-0.9613,-0.1357,0.2398), vec2(0.8994,0.4624), vec2(0.9048,0.4922), vec2(0.9355,0.4678), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2906,0.6699,0.4202), vec3(-0.3684,0.8582,0.2643), vec3(-0.3247,0.6241,0.3071), vec3(-0.9372,-0.1148,0.3295), vec2(0.9194,0.5139), vec2(0.9355,0.4678), vec2(0.9048,0.4922), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2906,0.6699,0.4202), vec3(-0.2964,0.8264,0.4735), vec3(-0.3684,0.8582,0.2643), vec3(-0.9427,-0.1385,0.3036), vec2(0.9194,0.5139), vec2(0.9487,0.5181), vec2(0.9355,0.4678), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3247,0.6241,0.3071), vec3(-0.2629,0.5997,0.3442), vec3(-0.2906,0.6699,0.4202), vec3(-0.5478,-0.7047,0.4508), vec2(0.5903,0.4189), vec2(0.5879,0.3926), vec2(0.5479,0.3999), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2906,0.6699,0.4202), vec3(-0.2693,0.7143,0.5315), vec3(-0.2964,0.8264,0.4735), vec3(-0.9663,-0.1145,0.2305), vec2(0.9194,0.5139), vec2(0.9336,0.5352), vec2(0.9487,0.5181), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2629,0.5997,0.3442), vec3(-0.3247,0.6241,0.3071), vec3(-0.268,0.5421,0.2329), vec3(-0.5355,-0.7399,0.4072), vec2(0.5879,0.3926), vec2(0.5903,0.4189), vec2(0.6328,0.4023), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2964,0.8264,0.4735), vec3(-0.2686,0.8211,0.5736), vec3(-0.2851,0.9446,0.5332), vec3(-0.9632,-0.0419,0.2654), vec2(0.9487,0.5181), vec2(0.9551,0.5383), vec2(0.9795,0.5261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2686,0.8211,0.5736), vec3(-0.2964,0.8264,0.4735), vec3(-0.2693,0.7143,0.5315), vec3(-0.9603,-0.0969,0.2617), vec2(0.9551,0.5383), vec2(0.9487,0.5181), vec2(0.9336,0.5352), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2394,0.9491,0.5873), vec3(-0.2851,0.9446,0.5332), vec3(-0.2686,0.8211,0.5736), vec3(-0.7639,0.1061,0.6366), vec2(0.9834,0.5398), vec2(0.9795,0.5261), vec2(0.9551,0.5383), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2693,0.7143,0.5315), vec3(-0.223,0.7617,0.7035), vec3(-0.2686,0.8211,0.5736), vec3(-0.9525,-0.1063,0.2854), vec2(0.9336,0.5352), vec2(0.9497,0.5688), vec2(0.9551,0.5383), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2693,0.7143,0.5315), vec3(-0.2906,0.6699,0.4202), vec3(-0.1765,0.6824,0.5223), vec3(-0.2625,-0.8777,0.4009), vec2(0.502,0.3828), vec2(0.5479,0.3999), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2629,0.5997,0.3442), vec3(-0.1765,0.6824,0.5223), vec3(-0.2906,0.6699,0.4202), vec3(-0.4006,-0.7414,0.5384), vec2(0.5879,0.3926), vec2(0.519,0.3477), vec2(0.5479,0.3999), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2394,0.9491,0.5873), vec3(-0.2686,0.8211,0.5736), vec3(-0.2206,0.8347,0.6991), vec3(-0.9258,0.1755,0.335), vec2(0.9834,0.5398), vec2(0.9551,0.5383), vec2(0.9624,0.5649), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2206,0.8347,0.6991), vec3(-0.2686,0.8211,0.5736), vec3(-0.223,0.7617,0.7035), vec3(-0.9347,0.0521,0.3517), vec2(0.9624,0.5649), vec2(0.9551,0.5383), vec2(0.9497,0.5688), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1588,0.7379,0.6714), vec3(-0.223,0.7617,0.7035), vec3(-0.2693,0.7143,0.5315), vec3(-0.1917,-0.9319,0.308), vec2(0.4553,0.3228), vec2(0.4319,0.3452), vec2(0.502,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2035,0.5083,0.2584), vec3(-0.1703,0.5815,0.3619), vec3(-0.2629,0.5997,0.3442), vec3(-0.2636,-0.7457,0.6119), vec2(0.6387,0.3745), vec2(0.5928,0.3579), vec2(0.5879,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1703,0.5815,0.3619), vec3(-0.1765,0.6824,0.5223), vec3(-0.2629,0.5997,0.3442), vec3(-0.2587,-0.8222,0.5071), vec2(0.5928,0.3579), vec2(0.519,0.3477), vec2(0.5879,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1765,0.6824,0.5223), vec3(-0.1588,0.7379,0.6714), vec3(-0.2693,0.7143,0.5315), vec3(-0.2709,-0.8913,0.3637), vec2(0.519,0.3477), vec2(0.4553,0.3228), vec2(0.502,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1765,0.6824,0.5223), vec3(-0.1703,0.5815,0.3619), vec3(-0.092,0.6566,0.5118), vec3(-0.1902,-0.8344,0.5174), vec2(0.519,0.3477), vec2(0.5928,0.3579), vec2(0.5347,0.3164), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2035,0.5083,0.2584), vec3(-0.0628,0.5566,0.3559), vec3(-0.1703,0.5815,0.3619), vec3(-0.1481,-0.7844,0.6023), vec2(0.6387,0.3745), vec2(0.6079,0.3198), vec2(0.5928,0.3579), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1512,0.4789,0.2403), vec3(-0.0628,0.5566,0.3559), vec3(-0.2035,0.5083,0.2584), vec3(-0.1929,-0.7397,0.6447), vec2(0.6538,0.3569), vec2(0.6079,0.3198), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0388,0.6998,0.6101), vec3(-0.1588,0.7379,0.6714), vec3(-0.1765,0.6824,0.5223), vec3(-0.111,-0.9271,0.3581), vec2(0.5,0.2856), vec2(0.4553,0.3228), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1703,0.5815,0.3619), vec3(-0.0628,0.5566,0.3559), vec3(-0.092,0.6566,0.5118), vec3(-0.167,-0.8438,0.51), vec2(0.5928,0.3579), vec2(0.6079,0.3198), vec2(0.5347,0.3164), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.092,0.6566,0.5118), vec3(-0.0388,0.6998,0.6101), vec3(-0.1765,0.6824,0.5223), vec3(-0.2,-0.8525,0.4829), vec2(0.5347,0.3164), vec2(0.5,0.2856), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0628,0.5566,0.3559), vec3(-0.1512,0.4789,0.2403), vec3(-0.0784,0.4764,0.2396), vec3(-0.0223,-0.8217,0.5694), vec2(0.6079,0.3198), vec2(0.6538,0.3569), vec2(0.6577,0.3379), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1588,0.7379,0.6714), vec3(-0.0388,0.6998,0.6101), vec3(-0.0062,0.7186,0.7143), vec3(-0.1852,-0.9553,0.2306), vec2(0.4553,0.3228), vec2(0.5,0.2856), vec2(0.4705,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0234,0.6343,0.5082), vec3(-0.092,0.6566,0.5118), vec3(-0.0628,0.5566,0.3559), vec3(-0.2463,-0.8361,0.4902), vec2(0.5474,0.2915), vec2(0.5347,0.3164), vec2(0.6079,0.3198), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.092,0.6566,0.5118), vec3(-0.0002,0.6775,0.6323), vec3(-0.0388,0.6998,0.6101), vec3(-0.6308,-0.5243,0.572), vec2(0.5347,0.3164), vec2(0.5029,0.2666), vec2(0.5,0.2856), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0002,0.6775,0.6323), vec3(-0.092,0.6566,0.5118), vec3(-0.0234,0.6343,0.5082), vec3(-0.2712,-0.892,0.3616), vec2(0.5029,0.2666), vec2(0.5347,0.3164), vec2(0.5474,0.2915), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0628,0.5566,0.3559), vec3(-0.0784,0.4764,0.2396), vec3(0.0438,0.5483,0.344), vec3(-0.0002,-0.8233,0.5676), vec2(0.6079,0.3198), vec2(0.6577,0.3379), vec2(0.623,0.2847), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0062,0.7186,0.7143), vec3(-0.0388,0.6998,0.6101), vec3(-0.0002,0.6775,0.6323), vec3(-0.6045,-0.729,0.321), vec2(0.4705,0.2559), vec2(0.5,0.2856), vec2(0.5029,0.2666), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0438,0.5483,0.344), vec3(-0.0234,0.6343,0.5082), vec3(-0.0628,0.5566,0.3559), vec3(-0.0177,-0.8888,0.4579), vec2(0.623,0.2847), vec2(0.5474,0.2915), vec2(0.6079,0.3198), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0356,0.4692,0.2337), vec3(0.0438,0.5483,0.344), vec3(-0.0784,0.4764,0.2396), vec3(-0.0217,-0.8112,0.5844), vec2(0.6729,0.3022), vec2(0.623,0.2847), vec2(0.6577,0.3379), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0234,0.6343,0.5082), vec3(0.0516,0.6249,0.5053), vec3(-0.0002,0.6775,0.6323), vec3(-0.1038,-0.933,0.3445), vec2(0.5474,0.2915), vec2(0.5581,0.2642), vec2(0.5029,0.2666), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0002,0.6775,0.6323), vec3(0.0565,0.6672,0.6497), vec3(-0.0062,0.7186,0.7143), vec3(-0.2854,-0.8651,0.4125), vec2(0.5029,0.2666), vec2(0.5068,0.2446), vec2(0.4705,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0234,0.6343,0.5082), vec3(0.0438,0.5483,0.344), vec3(0.0516,0.6249,0.5053), vec3(-0.0961,-0.8975,0.4304), vec2(0.5474,0.2915), vec2(0.623,0.2847), vec2(0.5581,0.2642), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0565,0.6672,0.6497), vec3(-0.0002,0.6775,0.6323), vec3(0.0516,0.6249,0.5053), vec3(-0.2556,-0.9255,0.2795), vec2(0.5068,0.2446), vec2(0.5029,0.2666), vec2(0.5581,0.2642), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1128,0.6741,0.6297), vec3(0.0565,0.6672,0.6497), vec3(0.0516,0.6249,0.5053), vec3(0.2103,-0.9402,0.2681), vec2(0.5029,0.2666), vec2(0.5068,0.2446), vec2(0.5581,0.2642), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0516,0.6249,0.5053), vec3(0.0438,0.5483,0.344), vec3(0.1355,0.625,0.4986), vec3(0.0354,-0.9036,0.4269), vec2(0.5581,0.2642), vec2(0.623,0.2847), vec2(0.5474,0.2915), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0356,0.4692,0.2337), vec3(0.2059,0.4764,0.1815), vec3(0.0438,0.5483,0.344), vec3(0.2062,-0.8018,0.5608), vec2(0.6729,0.3022), vec2(0.6577,0.3379), vec2(0.623,0.2847), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1128,0.6741,0.6297), vec3(0.125,0.7146,0.7114), vec3(0.0565,0.6672,0.6497), vec3(0.2499,-0.8817,0.4003), vec2(0.5029,0.2666), vec2(0.4705,0.2559), vec2(0.5068,0.2446), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1128,0.6741,0.6297), vec3(0.0516,0.6249,0.5053), vec3(0.1355,0.625,0.4986), vec3(0.0296,-0.9345,0.3547), vec2(0.5029,0.2666), vec2(0.5581,0.2642), vec2(0.5474,0.2915), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1927,0.5532,0.3058), vec3(0.1355,0.625,0.4986), vec3(0.0438,0.5483,0.344), vec3(0.1269,-0.9166,0.3791), vec2(0.6079,0.3198), vec2(0.5474,0.2915), vec2(0.623,0.2847), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1128,0.6741,0.6297), vec3(0.1517,0.6939,0.6058), vec3(0.125,0.7146,0.7114), vec3(0.5724,-0.7653,0.2943), vec2(0.5029,0.2666), vec2(0.5,0.2856), vec2(0.4705,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1927,0.5532,0.3058), vec3(0.0438,0.5483,0.344), vec3(0.2059,0.4764,0.1815), vec3(0.1631,-0.8315,0.531), vec2(0.6079,0.3198), vec2(0.623,0.2847), vec2(0.6577,0.3379), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1355,0.625,0.4986), vec3(0.2073,0.6421,0.4978), vec3(0.1128,0.6741,0.6297), vec3(0.2182,-0.901,0.3749), vec2(0.5474,0.2915), vec2(0.5347,0.3164), vec2(0.5029,0.2666), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1517,0.6939,0.6058), vec3(0.1128,0.6741,0.6297), vec3(0.2073,0.6421,0.4978), vec3(0.6244,-0.5281,0.5755), vec2(0.5,0.2856), vec2(0.5029,0.2666), vec2(0.5347,0.3164), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1355,0.625,0.4986), vec3(0.1927,0.5532,0.3058), vec3(0.2073,0.6421,0.4978), vec3(0.2163,-0.8922,0.3965), vec2(0.5474,0.2915), vec2(0.6079,0.3198), vec2(0.5347,0.3164), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2974,0.6605,0.5019), vec3(0.1517,0.6939,0.6058), vec3(0.2073,0.6421,0.4978), vec3(0.1529,-0.8578,0.4908), vec2(0.519,0.3477), vec2(0.5,0.2856), vec2(0.5347,0.3164), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3051,0.5718,0.3045), vec3(0.2073,0.6421,0.4978), vec3(0.1927,0.5532,0.3058), vec3(0.1536,-0.9011,0.4054), vec2(0.5928,0.3579), vec2(0.5347,0.3164), vec2(0.6079,0.3198), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.2349,1.1038,0.2361), 0.6658, bestT)) {
        if (triHit(ro, rd, vec3(-0.694,0.9748,0.1675), vec3(-0.7658,1.0732,0.4874), vec3(-0.4506,1.0918,0.204), vec3(-0.3634,0.8644,-0.3475), vec2(0.2583,0.8077), vec2(0.3376,0.8015), vec2(0.2422,0.8833), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7654,1.0496,0.4916), vec3(-0.6982,0.9336,0.1809), vec3(-0.3858,0.9651,0.3073), vec3(-0.0435,-0.939,0.3411), vec2(0.7446,0.3018), vec2(0.7188,0.2417), vec2(0.7905,0.2461), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.7658,1.0732,0.4874), vec3(-0.4392,1.0158,0.5496), vec3(-0.4506,1.0918,0.204), vec3(0.1306,0.9692,0.2089), vec2(0.3376,0.8015), vec2(0.323,0.8909), vec2(0.2422,0.8833), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4619,1.123,0.0276), vec3(-0.694,0.9748,0.1675), vec3(-0.4506,1.0918,0.204), vec3(-0.4481,0.875,0.1834), vec2(0.1959,0.8832), vec2(0.2583,0.8077), vec2(0.2422,0.8833), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4393,0.9677,0.5597), vec3(-0.7654,1.0496,0.4916), vec3(-0.3858,0.9651,0.3073), vec3(-0.2357,-0.971,-0.0398), vec2(0.8066,0.2964), vec2(0.7446,0.3018), vec2(0.7905,0.2461), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3858,0.9651,0.3073), vec3(-0.6982,0.9336,0.1809), vec3(-0.4602,0.954,0.0957), vec3(0.0923,-0.9955,0.0196), vec2(0.7905,0.2461), vec2(0.7188,0.2417), vec2(0.7583,0.21), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3858,0.9651,0.3073), vec3(-0.4602,0.954,0.0957), vec3(-0.3684,0.8582,0.2643), vec3(-0.9011,-0.2798,0.3311), vec2(0.9741,0.4766), vec2(0.9639,0.4326), vec2(0.9355,0.4678), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4392,1.0158,0.5496), vec3(-0.3066,1.0289,0.5137), vec3(-0.4506,1.0918,0.204), vec3(-0.0386,0.9756,0.2159), vec2(0.323,0.8909), vec2(0.3037,0.9254), vec2(0.2422,0.8833), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4076,1.068,0.0469), vec3(-0.4602,0.954,0.0957), vec3(-0.3063,1.1127,0.2748), vec3(-0.8253,0.4964,0.2692), vec2(0.5581,0.5881), vec2(0.5757,0.5515), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4054,0.959,-0.1428), vec3(-0.4076,1.068,0.0469), vec3(-0.3598,1.0755,-0.1564), vec3(-0.9196,0.336,-0.2033), vec2(0.6128,0.6121), vec2(0.5581,0.5881), vec2(0.5923,0.6455), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3858,0.9651,0.3073), vec3(-0.3063,1.1127,0.2748), vec3(-0.4602,0.954,0.0957), vec3(-0.8239,0.5019,0.2632), vec2(0.5156,0.5129), vec2(0.4844,0.5562), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3507,1.131,0.0504), vec3(-0.3598,1.0755,-0.1564), vec3(-0.4076,1.068,0.0469), vec3(-0.7301,0.6675,-0.1465), vec2(0.54,0.6082), vec2(0.5923,0.6455), vec2(0.5581,0.5881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2851,0.9446,0.5332), vec3(-0.4393,0.9677,0.5597), vec3(-0.3858,0.9651,0.3073), vec3(-0.152,-0.9881,-0.0219), vec2(0.8296,0.2837), vec2(0.8066,0.2964), vec2(0.7905,0.2461), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4619,1.123,0.0276), vec3(-0.4506,1.0918,0.204), vec3(-0.1892,1.2103,0.1001), vec3(-0.344,0.9206,0.1848), vec2(0.1959,0.8832), vec2(0.2422,0.8833), vec2(0.187,0.9585), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2098,1.2248,-0.123), vec3(-0.4084,1.0733,-0.2135), vec3(-0.4619,1.123,0.0276), vec3(-0.4985,0.8206,-0.2796), vec2(0.1346,0.9552), vec2(0.1307,0.9007), vec2(0.1959,0.8832), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3507,1.131,0.0504), vec3(-0.4076,1.068,0.0469), vec3(-0.3063,1.1127,0.2748), vec3(-0.733,0.6508,0.1979), vec2(0.54,0.6082), vec2(0.5581,0.5881), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3684,0.8582,0.2643), vec3(-0.2964,0.8264,0.4735), vec3(-0.3858,0.9651,0.3073), vec3(-0.924,-0.2623,0.2783), vec2(0.9355,0.4678), vec2(0.9487,0.5181), vec2(0.9741,0.4766), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3598,1.0755,-0.1564), vec3(-0.3507,1.131,0.0504), vec3(-0.304,1.1638,-0.1397), vec3(-0.8306,0.5461,-0.1095), vec2(0.5923,0.6455), vec2(0.54,0.6082), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2851,0.9446,0.5332), vec3(-0.3858,0.9651,0.3073), vec3(-0.2964,0.8264,0.4735), vec3(-0.9112,-0.1129,0.3961), vec2(0.9795,0.5261), vec2(0.9741,0.4766), vec2(0.9487,0.5181), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2954,1.1667,0.07), vec3(-0.3507,1.131,0.0504), vec3(-0.3063,1.1127,0.2748), vec3(-0.5782,0.796,0.1791), vec2(0.522,0.6201), vec2(0.54,0.6082), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3507,1.131,0.0504), vec3(-0.2954,1.1667,0.07), vec3(-0.304,1.1638,-0.1397), vec3(-0.5456,0.838,0.0108), vec2(0.54,0.6082), vec2(0.522,0.6201), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1873,1.1851,0.2073), vec3(-0.4506,1.0918,0.204), vec3(-0.3066,1.0289,0.5137), vec3(-0.3192,0.8888,0.3288), vec2(0.2139,0.9588), vec2(0.2422,0.8833), vec2(0.3037,0.9254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3063,1.1127,0.2748), vec3(-0.3858,0.9651,0.3073), vec3(-0.2431,1.0326,0.5065), vec3(-0.7745,0.5021,0.3849), vec2(0.4844,0.5562), vec2(0.5156,0.5129), vec2(0.4255,0.4902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2851,0.9446,0.5332), vec3(-0.2431,1.0326,0.5065), vec3(-0.3858,0.9651,0.3073), vec3(-0.7784,0.4906,0.3916), vec2(0.4451,0.4561), vec2(0.4255,0.4902), vec2(0.5156,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2098,1.2248,-0.123), vec3(-0.4619,1.123,0.0276), vec3(-0.1892,1.2103,0.1001), vec3(-0.3257,0.9411,0.0911), vec2(0.1346,0.9552), vec2(0.1959,0.8832), vec2(0.187,0.9585), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1892,1.2103,0.1001), vec3(-0.4506,1.0918,0.204), vec3(-0.1873,1.1851,0.2073), vec3(-0.3283,0.9182,0.2218), vec2(0.187,0.9585), vec2(0.2422,0.8833), vec2(0.2139,0.9588), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.304,1.1638,-0.1397), vec3(-0.2954,1.1667,0.07), vec3(-0.2098,1.2248,-0.123), vec3(-0.5448,0.8385,0.0107), vec2(0.5713,0.667), vec2(0.522,0.6201), vec2(0.5479,0.6924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1892,1.2103,0.1001), vec3(-0.2954,1.1667,0.07), vec3(-0.3063,1.1127,0.2748), vec3(-0.4218,0.882,0.2101), vec2(0.4873,0.6418), vec2(0.522,0.6201), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2851,0.9446,0.5332), vec3(-0.2173,0.9882,0.5964), vec3(-0.2431,1.0326,0.5065), vec3(-0.7415,0.4924,0.4557), vec2(0.4451,0.4561), vec2(0.4021,0.4541), vec2(0.4255,0.4902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2394,0.9491,0.5873), vec3(-0.2173,0.9882,0.5964), vec3(-0.2851,0.9446,0.5332), vec3(-0.7448,0.2799,0.6058), vec2(0.4197,0.4434), vec2(0.4021,0.4541), vec2(0.4451,0.4561), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2098,1.2248,-0.123), vec3(-0.2181,1.209,-0.2888), vec3(-0.304,1.1638,-0.1397), vec3(-0.536,0.8425,-0.0535), vec2(0.5479,0.6924), vec2(0.5986,0.7261), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1708,1.0742,0.4927), vec3(-0.3063,1.1127,0.2748), vec3(-0.2431,1.0326,0.5065), vec3(-0.4004,0.8267,0.3952), vec2(0.3997,0.5129), vec2(0.4844,0.5562), vec2(0.4255,0.4902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2954,1.1667,0.07), vec3(-0.1892,1.2103,0.1001), vec3(-0.2098,1.2248,-0.123), vec3(-0.4013,0.9109,0.0961), vec2(0.522,0.6201), vec2(0.4873,0.6418), vec2(0.5479,0.6924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3063,1.1127,0.2748), vec3(-0.1867,1.1529,0.2987), vec3(-0.1892,1.2103,0.1001), vec3(-0.3542,0.8971,0.2639), vec2(0.4844,0.5562), vec2(0.4431,0.5828), vec2(0.4873,0.6418), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1867,1.1529,0.2987), vec3(-0.3063,1.1127,0.2748), vec3(-0.1708,1.0742,0.4927), vec3(-0.3618,0.8531,0.3759), vec2(0.4431,0.5828), vec2(0.4844,0.5562), vec2(0.3997,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3066,1.0289,0.5137), vec3(-0.1549,1.1017,0.511), vec3(-0.1873,1.1851,0.2073), vec3(-0.4112,0.8669,0.2818), vec2(0.3037,0.9254), vec2(0.2869,0.9689), vec2(0.2139,0.9588), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2173,0.9882,0.5964), vec3(-0.2394,0.9491,0.5873), vec3(-0.1895,0.9608,0.6622), vec3(-0.8057,0.3428,0.4831), vec2(0.4021,0.4541), vec2(0.4197,0.4434), vec2(0.3818,0.4258), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2431,1.0326,0.5065), vec3(-0.2173,0.9882,0.5964), vec3(-0.1493,1.046,0.5666), vec3(-0.4264,0.7566,0.4957), vec2(0.4255,0.4902), vec2(0.4021,0.4541), vec2(0.3779,0.4863), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1708,1.0742,0.4927), vec3(-0.2431,1.0326,0.5065), vec3(-0.1493,1.046,0.5666), vec3(-0.3895,0.8175,0.4244), vec2(0.3997,0.5129), vec2(0.4255,0.4902), vec2(0.3779,0.4863), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2098,1.2248,-0.123), vec3(-0.1892,1.2103,0.1001), vec3(-0.1026,1.2524,-0.0956), vec3(-0.2692,0.9591,0.087), vec2(0.5479,0.6924), vec2(0.4873,0.6418), vec2(0.5176,0.7183), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1892,1.2103,0.1001), vec3(-0.1867,1.1529,0.2987), vec3(-0.1053,1.2263,0.1013), vec3(-0.1835,0.9437,0.2752), vec2(0.4873,0.6418), vec2(0.4431,0.5828), vec2(0.4646,0.6636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1867,1.1529,0.2987), vec3(-0.1708,1.0742,0.4927), vec3(-0.1014,1.1714,0.3051), vec3(-0.2226,0.8969,0.3822), vec2(0.4431,0.5828), vec2(0.3997,0.5129), vec2(0.4148,0.6013), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1493,1.046,0.5666), vec3(-0.2173,0.9882,0.5964), vec3(-0.0904,1.0326,0.6747), vec3(-0.5021,0.7811,0.3711), vec2(0.3779,0.4863), vec2(0.4021,0.4541), vec2(0.3335,0.4575), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1026,1.2524,-0.0956), vec3(-0.1183,1.2581,-0.2881), vec3(-0.2098,1.2248,-0.123), vec3(-0.261,0.964,0.0499), vec2(0.5176,0.7183), vec2(0.5781,0.7605), vec2(0.5479,0.6924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0988,1.1034,0.5004), vec3(-0.1708,1.0742,0.4927), vec3(-0.1493,1.046,0.5666), vec3(-0.3792,0.8227,0.4234), vec2(0.3718,0.5288), vec2(0.3997,0.5129), vec2(0.3779,0.4863), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1892,1.2103,0.1001), vec3(-0.1053,1.2263,0.1013), vec3(-0.1026,1.2524,-0.0956), vec3(-0.1871,0.9741,0.1266), vec2(0.4873,0.6418), vec2(0.4646,0.6636), vec2(0.5176,0.7183), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1014,1.1714,0.3051), vec3(-0.1053,1.2263,0.1013), vec3(-0.1867,1.1529,0.2987), vec3(-0.2226,0.9402,0.2577), vec2(0.4148,0.6013), vec2(0.4646,0.6636), vec2(0.4431,0.5828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1708,1.0742,0.4927), vec3(-0.0988,1.1034,0.5004), vec3(-0.1014,1.1714,0.3051), vec3(-0.3859,0.8697,0.3077), vec2(0.3997,0.5129), vec2(0.3718,0.5288), vec2(0.4148,0.6013), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0988,1.1034,0.5004), vec3(-0.1493,1.046,0.5666), vec3(-0.0904,1.0326,0.6747), vec3(-0.4614,0.8139,0.353), vec2(0.3718,0.5288), vec2(0.3779,0.4863), vec2(0.3335,0.4575), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1026,1.2524,-0.0956), vec3(-0.1053,1.2263,0.1013), vec3(0.0525,1.2574,-0.0752), vec3(-0.0492,0.9902,0.1307), vec2(0.5176,0.7183), vec2(0.4646,0.6636), vec2(0.4724,0.7621), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1053,1.2263,0.1013), vec3(-0.1014,1.1714,0.3051), vec3(0.0586,1.2297,0.1127), vec3(-0.0381,0.9647,0.2607), vec2(0.4646,0.6636), vec2(0.4148,0.6013), vec2(0.4136,0.707), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1014,1.1714,0.3051), vec3(-0.0988,1.1034,0.5004), vec3(0.0636,1.1791,0.3044), vec3(-0.0427,0.9434,0.3288), vec2(0.4148,0.6013), vec2(0.3718,0.5288), vec2(0.3613,0.6421), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1026,1.2524,-0.0956), vec3(0.0525,1.2574,-0.0752), vec3(0.0547,1.2888,-0.2749), vec3(-0.0522,0.9866,0.1546), vec2(0.5176,0.7183), vec2(0.4724,0.7621), vec2(0.541,0.8092), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0586,1.2297,0.1127), vec3(0.0525,1.2574,-0.0752), vec3(-0.1053,1.2263,0.1013), vec3(-0.0307,0.9887,0.1469), vec2(0.4136,0.707), vec2(0.4724,0.7621), vec2(0.4646,0.6636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0636,1.1791,0.3044), vec3(0.0586,1.2297,0.1127), vec3(-0.1014,1.1714,0.3051), vec3(-0.0441,0.9657,0.256), vec2(0.3613,0.6421), vec2(0.4136,0.707), vec2(0.4148,0.6013), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0665,1.1034,0.498), vec3(0.0636,1.1791,0.3044), vec3(-0.0988,1.1034,0.5004), vec3(0.0056,0.9313,0.3642), vec2(0.3103,0.5667), vec2(0.3613,0.6421), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0665,1.1034,0.498), vec3(-0.0988,1.1034,0.5004), vec3(0.0684,1.0415,0.6663), vec3(0.0053,0.9387,0.3448), vec2(0.3103,0.5667), vec2(0.3718,0.5288), vec2(0.2681,0.4941), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0586,1.2297,0.1127), vec3(0.2036,1.2155,0.106), vec3(0.0525,1.2574,-0.0752), vec3(0.1025,0.9845,0.142), vec2(0.4136,0.707), vec2(0.4646,0.6636), vec2(0.4724,0.7621), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0636,1.1791,0.3044), vec3(0.2219,1.1589,0.3009), vec3(0.0586,1.2297,0.1127), vec3(0.1281,0.9598,0.2499), vec2(0.3613,0.6421), vec2(0.4148,0.6013), vec2(0.4136,0.707), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2046,1.25,-0.0969), vec3(0.0525,1.2574,-0.0752), vec3(0.2036,1.2155,0.106), vec3(0.0718,0.9833,0.1674), vec2(0.5176,0.7183), vec2(0.4724,0.7621), vec2(0.4646,0.6636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2036,1.2155,0.106), vec3(0.0586,1.2297,0.1127), vec3(0.2219,1.1589,0.3009), vec3(0.1057,0.9575,0.2684), vec2(0.4646,0.6636), vec2(0.4136,0.707), vec2(0.4148,0.6013), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.2493,0.2265,0.1318), 0.1935, bestT)) {
        if (triHit(ro, rd, vec3(-0.2855,0.1979,0.1176), vec3(-0.2941,0.1129,0.0792), vec3(-0.2945,0.2033,0.1034), vec3(0.858,0.1362,-0.4952), vec2(0.6597,0.9368), vec2(0.6416,0.9413), vec2(0.6602,0.9415), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2828,0.2046,0.1311), vec3(-0.2765,0.117,0.1056), vec3(-0.2855,0.1979,0.1176), vec3(0.9554,0.1446,-0.2574), vec2(0.6616,0.9326), vec2(0.6416,0.933), vec2(0.6597,0.9368), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1921,0.1822,0.1372), vec3(-0.1947,0.18,0.1373), vec3(-0.1972,0.1851,0.1252), vec3(0.5642,-0.7169,-0.4096), vec2(0.8008,0.0405), vec2(0.7993,0.0405), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1921,0.1822,0.1372), vec3(-0.1947,0.18,0.1373), vec3(-0.1972,0.1851,0.1252), vec3(0.5642,-0.7169,-0.4096), vec2(0.8008,0.0405), vec2(0.7993,0.0405), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1947,0.18,0.1373), vec3(-0.1921,0.1822,0.1372), vec3(-0.2101,0.1863,0.1234), vec3(-0.4169,0.5621,0.7144), vec2(0.7954,0.0483), vec2(0.7993,0.0405), vec2(0.7954,0.0522), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1947,0.18,0.1373), vec3(-0.1921,0.1822,0.1372), vec3(-0.2101,0.1863,0.1234), vec3(-0.4169,0.5621,0.7144), vec2(0.7954,0.0483), vec2(0.7993,0.0405), vec2(0.7954,0.0522), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1947,0.18,0.1373), vec3(-0.2101,0.1863,0.1234), vec3(-0.1972,0.1851,0.1252), vec3(-0.0374,-0.9261,-0.3753), vec2(0.7993,0.0405), vec2(0.7954,0.0483), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1947,0.18,0.1373), vec3(-0.2101,0.1863,0.1234), vec3(-0.1972,0.1851,0.1252), vec3(-0.0374,-0.9261,-0.3753), vec2(0.7993,0.0405), vec2(0.7954,0.0483), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1929,0.1887,0.1245), vec3(-0.1921,0.1822,0.1372), vec3(-0.1972,0.1851,0.1252), vec3(0.5533,-0.7266,-0.4074), vec2(0.8018,0.0459), vec2(0.8008,0.0405), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1929,0.1887,0.1245), vec3(-0.1921,0.1822,0.1372), vec3(-0.1972,0.1851,0.1252), vec3(0.5533,-0.7266,-0.4074), vec2(0.8018,0.0459), vec2(0.8008,0.0405), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2045,0.191,0.1156), vec3(-0.1972,0.1851,0.1252), vec3(-0.2101,0.1863,0.1234), vec3(-0.0101,-0.8503,-0.5263), vec2(0.7993,0.0498), vec2(0.7998,0.0454), vec2(0.7954,0.0483), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2045,0.191,0.1156), vec3(-0.1972,0.1851,0.1252), vec3(-0.2101,0.1863,0.1234), vec3(-0.0101,-0.8503,-0.5263), vec2(0.7993,0.0498), vec2(0.7998,0.0454), vec2(0.7954,0.0483), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1921,0.1822,0.1372), vec3(-0.1943,0.1969,0.1263), vec3(-0.2101,0.1863,0.1234), vec3(-0.46,0.4809,0.7464), vec2(0.7993,0.0405), vec2(0.8008,0.0405), vec2(0.7954,0.0522), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1921,0.1822,0.1372), vec3(-0.1943,0.1969,0.1263), vec3(-0.2101,0.1863,0.1234), vec3(-0.46,0.4809,0.7464), vec2(0.7993,0.0405), vec2(0.8008,0.0405), vec2(0.7954,0.0522), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1921,0.1822,0.1372), vec3(-0.1929,0.1887,0.1245), vec3(-0.1943,0.1969,0.1263), vec3(0.9862,0.1633,0.0265), vec2(0.8008,0.0405), vec2(0.8018,0.0459), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1921,0.1822,0.1372), vec3(-0.1929,0.1887,0.1245), vec3(-0.1943,0.1969,0.1263), vec3(0.9862,0.1633,0.0265), vec2(0.8008,0.0405), vec2(0.8018,0.0459), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2045,0.191,0.1156), vec3(-0.2101,0.1863,0.1234), vec3(-0.2143,0.193,0.1207), vec3(-0.4613,-0.5715,-0.6786), vec2(0.7993,0.0498), vec2(0.7954,0.0483), vec2(0.7954,0.0522), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2045,0.191,0.1156), vec3(-0.2101,0.1863,0.1234), vec3(-0.2143,0.193,0.1207), vec3(-0.4613,-0.5715,-0.6786), vec2(0.7993,0.0498), vec2(0.7954,0.0483), vec2(0.7954,0.0522), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1929,0.1887,0.1245), vec3(-0.1972,0.1851,0.1252), vec3(-0.1988,0.1981,0.1148), vec3(0.3541,-0.5556,-0.7523), vec2(0.8018,0.0459), vec2(0.7998,0.0454), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1929,0.1887,0.1245), vec3(-0.1972,0.1851,0.1252), vec3(-0.1988,0.1981,0.1148), vec3(0.3541,-0.5556,-0.7523), vec2(0.8018,0.0459), vec2(0.7998,0.0454), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2045,0.191,0.1156), vec3(-0.1988,0.1981,0.1148), vec3(-0.1972,0.1851,0.1252), vec3(0.5076,-0.4971,-0.7038), vec2(0.7993,0.0498), vec2(0.8022,0.0503), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2045,0.191,0.1156), vec3(-0.1988,0.1981,0.1148), vec3(-0.1972,0.1851,0.1252), vec3(0.5076,-0.4971,-0.7038), vec2(0.7993,0.0498), vec2(0.8022,0.0503), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2143,0.193,0.1207), vec3(-0.2101,0.1863,0.1234), vec3(-0.1943,0.1969,0.1263), vec3(-0.3028,0.1977,0.9323), vec2(0.7988,0.0571), vec2(0.7954,0.0522), vec2(0.8008,0.0405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2143,0.193,0.1207), vec3(-0.2101,0.1863,0.1234), vec3(-0.1943,0.1969,0.1263), vec3(-0.3028,0.1977,0.9323), vec2(0.7988,0.0571), vec2(0.7954,0.0522), vec2(0.8008,0.0405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2081,0.1871,0.122), vec3(-0.1975,0.2006,0.1245), vec3(-0.2078,0.1904,0.1306), vec3(0.7486,-0.6298,0.2073), vec2(0.6699,0.8994), vec2(0.6724,0.9015), vec2(0.6724,0.8991), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2081,0.1871,0.122), vec3(-0.1975,0.2006,0.1245), vec3(-0.2078,0.1904,0.1306), vec3(0.7486,-0.6298,0.2073), vec2(0.6699,0.8994), vec2(0.6724,0.9015), vec2(0.6724,0.8991), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2081,0.1871,0.122), vec3(-0.2078,0.1904,0.1306), vec3(-0.2242,0.2016,0.1227), vec3(-0.6309,-0.7164,0.2978), vec2(0.6699,0.8994), vec2(0.668,0.8992), vec2(0.6689,0.9045), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2081,0.1871,0.122), vec3(-0.2068,0.1946,0.1152), vec3(-0.1975,0.2006,0.1245), vec3(0.75,-0.5119,-0.4189), vec2(0.6699,0.8994), vec2(0.6709,0.9019), vec2(0.6724,0.9015), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2081,0.1871,0.122), vec3(-0.2068,0.1946,0.1152), vec3(-0.1975,0.2006,0.1245), vec3(0.75,-0.5119,-0.4189), vec2(0.6699,0.8994), vec2(0.6709,0.9019), vec2(0.6724,0.9015), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2081,0.1871,0.122), vec3(-0.2242,0.2016,0.1227), vec3(-0.2068,0.1946,0.1152), vec3(-0.5053,-0.5295,-0.6814), vec2(0.6699,0.8994), vec2(0.6689,0.9045), vec2(0.6709,0.9019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1988,0.1981,0.1148), vec3(-0.1943,0.1969,0.1263), vec3(-0.1929,0.1887,0.1245), vec3(0.9126,0.231,-0.3372), vec2(0.8022,0.0503), vec2(0.8047,0.0469), vec2(0.8018,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1988,0.1981,0.1148), vec3(-0.1943,0.1969,0.1263), vec3(-0.1929,0.1887,0.1245), vec3(0.9126,0.231,-0.3372), vec2(0.8022,0.0503), vec2(0.8047,0.0469), vec2(0.8018,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2078,0.1904,0.1306), vec3(-0.1975,0.2006,0.1245), vec3(-0.2019,0.1962,0.1332), vec3(0.7005,-0.7135,-0.0165), vec2(0.6724,0.8991), vec2(0.6724,0.9015), vec2(0.6729,0.9003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2078,0.1904,0.1306), vec3(-0.1975,0.2006,0.1245), vec3(-0.2019,0.1962,0.1332), vec3(0.7005,-0.7135,-0.0165), vec2(0.6724,0.8991), vec2(0.6724,0.9015), vec2(0.6729,0.9003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2165,0.2035,0.1131), vec3(-0.2045,0.191,0.1156), vec3(-0.2143,0.193,0.1207), vec3(-0.4598,-0.5802,-0.6723), vec2(0.7988,0.0571), vec2(0.7993,0.0498), vec2(0.7954,0.0522), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2165,0.2035,0.1131), vec3(-0.2045,0.191,0.1156), vec3(-0.2143,0.193,0.1207), vec3(-0.4598,-0.5802,-0.6723), vec2(0.7988,0.0571), vec2(0.7993,0.0498), vec2(0.7954,0.0522), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2045,0.191,0.1156), vec3(-0.2165,0.2035,0.1131), vec3(-0.1988,0.1981,0.1148), vec3(0.046,-0.1584,-0.9863), vec2(0.7993,0.0498), vec2(0.7988,0.0571), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2045,0.191,0.1156), vec3(-0.2165,0.2035,0.1131), vec3(-0.1988,0.1981,0.1148), vec3(0.046,-0.1584,-0.9863), vec2(0.7993,0.0498), vec2(0.7988,0.0571), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2078,0.1904,0.1306), vec3(-0.2019,0.1962,0.1332), vec3(-0.2242,0.2066,0.1357), vec3(-0.061,-0.3567,0.9322), vec2(0.6724,0.8991), vec2(0.6729,0.9003), vec2(0.6768,0.8984), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.201,0.2014,0.1176), vec3(-0.1975,0.2006,0.1245), vec3(-0.2068,0.1946,0.1152), vec3(0.754,-0.4913,-0.436), vec2(0.6719,0.9022), vec2(0.6724,0.9015), vec2(0.6709,0.9019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.201,0.2014,0.1176), vec3(-0.1975,0.2006,0.1245), vec3(-0.2068,0.1946,0.1152), vec3(0.754,-0.4913,-0.436), vec2(0.6719,0.9022), vec2(0.6724,0.9015), vec2(0.6709,0.9019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1943,0.1969,0.1263), vec3(-0.2031,0.2087,0.1222), vec3(-0.2143,0.193,0.1207), vec3(-0.2913,0.1149,0.9497), vec2(0.8008,0.0405), vec2(0.8047,0.0469), vec2(0.7988,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2242,0.2066,0.1357), vec3(-0.2242,0.2016,0.1227), vec3(-0.2078,0.1904,0.1306), vec3(-0.6282,-0.727,0.2771), vec2(0.666,0.9059), vec2(0.6689,0.9045), vec2(0.668,0.8992), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1943,0.1969,0.1263), vec3(-0.2031,0.2087,0.1222), vec3(-0.2143,0.193,0.1207), vec3(-0.2913,0.1149,0.9497), vec2(0.8008,0.0405), vec2(0.8047,0.0469), vec2(0.7988,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1988,0.1981,0.1148), vec3(-0.2031,0.2087,0.1222), vec3(-0.1943,0.1969,0.1263), vec3(0.8127,0.5163,-0.27), vec2(0.8022,0.0503), vec2(0.8066,0.0532), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1988,0.1981,0.1148), vec3(-0.2031,0.2087,0.1222), vec3(-0.1943,0.1969,0.1263), vec3(0.8127,0.5163,-0.27), vec2(0.8022,0.0503), vec2(0.8066,0.0532), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2143,0.193,0.1207), vec3(-0.2031,0.2087,0.1222), vec3(-0.2165,0.2035,0.1131), vec3(-0.6169,0.3694,0.6949), vec2(0.7988,0.0571), vec2(0.8047,0.0469), vec2(0.8047,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2143,0.193,0.1207), vec3(-0.2031,0.2087,0.1222), vec3(-0.2165,0.2035,0.1131), vec3(-0.6169,0.3694,0.6949), vec2(0.7988,0.0571), vec2(0.8047,0.0469), vec2(0.8047,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.201,0.2014,0.1176), vec3(-0.2068,0.1946,0.1152), vec3(-0.2245,0.2105,0.1122), vec3(0.2682,0.1198,-0.9559), vec2(0.6719,0.9022), vec2(0.6709,0.9019), vec2(0.6709,0.9054), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2242,0.2016,0.1227), vec3(-0.2245,0.2105,0.1122), vec3(-0.2068,0.1946,0.1152), vec3(-0.5036,-0.6639,-0.5529), vec2(0.6689,0.9045), vec2(0.6709,0.9054), vec2(0.6709,0.9019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2019,0.1962,0.1332), vec3(-0.1975,0.2006,0.1245), vec3(-0.2156,0.2151,0.1394), vec3(0.7465,0.3558,0.5622), vec2(0.6729,0.9003), vec2(0.6724,0.9015), vec2(0.6763,0.9014), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.209,0.2127,0.1158), vec3(-0.1988,0.1981,0.1148), vec3(-0.2165,0.2035,0.1131), vec3(0.1457,0.1682,-0.9749), vec2(0.8047,0.0571), vec2(0.8022,0.0503), vec2(0.7988,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.209,0.2127,0.1158), vec3(-0.1988,0.1981,0.1148), vec3(-0.2165,0.2035,0.1131), vec3(0.1457,0.1682,-0.9749), vec2(0.8047,0.0571), vec2(0.8022,0.0503), vec2(0.7988,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2156,0.2151,0.1394), vec3(-0.2242,0.2066,0.1357), vec3(-0.2019,0.1962,0.1332), vec3(-0.0575,-0.3498,0.9351), vec2(0.6763,0.9014), vec2(0.6768,0.8984), vec2(0.6729,0.9003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.209,0.2127,0.1158), vec3(-0.2031,0.2087,0.1222), vec3(-0.1988,0.1981,0.1148), vec3(0.7579,0.5501,-0.3507), vec2(0.8047,0.0571), vec2(0.8066,0.0532), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.209,0.2127,0.1158), vec3(-0.2031,0.2087,0.1222), vec3(-0.1988,0.1981,0.1148), vec3(0.7579,0.5501,-0.3507), vec2(0.8047,0.0571), vec2(0.8066,0.0532), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1975,0.2006,0.1245), vec3(-0.201,0.2014,0.1176), vec3(-0.209,0.2214,0.1266), vec3(0.8007,0.4799,-0.3587), vec2(0.6724,0.9015), vec2(0.6719,0.9022), vec2(0.6748,0.9036), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.209,0.2127,0.1158), vec3(-0.2165,0.2035,0.1131), vec3(-0.2031,0.2087,0.1222), vec3(-0.6128,0.2849,0.7371), vec2(0.8066,0.0532), vec2(0.8047,0.0571), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.209,0.2127,0.1158), vec3(-0.2165,0.2035,0.1131), vec3(-0.2031,0.2087,0.1222), vec3(-0.6128,0.2849,0.7371), vec2(0.8066,0.0532), vec2(0.8047,0.0571), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.201,0.2014,0.1176), vec3(-0.2245,0.2105,0.1122), vec3(-0.2161,0.2205,0.116), vec3(0.2725,0.1324,-0.953), vec2(0.6719,0.9022), vec2(0.6709,0.9054), vec2(0.6733,0.9051), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.209,0.2214,0.1266), vec3(-0.2156,0.2151,0.1394), vec3(-0.1975,0.2006,0.1245), vec3(0.7471,0.3601,0.5587), vec2(0.6748,0.9036), vec2(0.6763,0.9014), vec2(0.6724,0.9015), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2161,0.2205,0.116), vec3(-0.209,0.2214,0.1266), vec3(-0.201,0.2014,0.1176), vec3(0.697,0.5054,-0.5087), vec2(0.6733,0.9051), vec2(0.6748,0.9036), vec2(0.6719,0.9022), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3179,0.2051,0.1303), vec3(-0.3026,0.2046,0.1436), vec3(-0.3142,0.2377,0.1374), vec3(-0.655,-0.0879,0.7505), vec2(0.6621,0.9518), vec2(0.6626,0.9553), vec2(0.6699,0.9569), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3179,0.2051,0.1303), vec3(-0.3026,0.2046,0.1436), vec3(-0.3142,0.2377,0.1374), vec3(-0.655,-0.0879,0.7505), vec2(0.6621,0.9518), vec2(0.6626,0.9553), vec2(0.6699,0.9569), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3179,0.2051,0.1303), vec3(-0.3142,0.2377,0.1374), vec3(-0.3113,0.2061,0.1113), vec3(-0.9316,0.1769,-0.3175), vec2(0.6621,0.9518), vec2(0.6699,0.9569), vec2(0.6611,0.947), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2855,0.1979,0.1176), vec3(-0.2945,0.2033,0.1034), vec3(-0.2781,0.2509,0.1293), vec3(0.8433,0.0024,-0.5375), vec2(0.6597,0.9368), vec2(0.6602,0.9415), vec2(0.6738,0.9299), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3138,0.2416,0.1646), vec3(-0.3658,0.1783,0.1606), vec3(-0.3198,0.2334,0.1448), vec3(0.7717,-0.6352,0.031), vec2(0.667,0.9621), vec2(0.6719,0.9874), vec2(0.6714,0.9616), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2828,0.2046,0.1311), vec3(-0.2855,0.1979,0.1176), vec3(-0.2781,0.2509,0.1293), vec3(0.9847,-0.1054,-0.139), vec2(0.6616,0.9326), vec2(0.6597,0.9368), vec2(0.6738,0.9299), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2242,0.2016,0.1227), vec3(-0.2242,0.2066,0.1357), vec3(-0.2642,0.252,0.1391), vec3(-0.7179,-0.6504,0.248), vec2(0.6689,0.9045), vec2(0.666,0.9059), vec2(0.6729,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3198,0.2334,0.1448), vec3(-0.377,0.1831,0.1345), vec3(-0.3275,0.2454,0.1328), vec3(0.5081,-0.4247,-0.7493), vec2(0.6714,0.9616), vec2(0.6797,0.9842), vec2(0.6777,0.96), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2245,0.2105,0.1122), vec3(-0.2242,0.2016,0.1227), vec3(-0.2642,0.252,0.1391), vec3(-0.7782,-0.4881,-0.3952), vec2(0.6709,0.9054), vec2(0.6689,0.9045), vec2(0.6729,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2828,0.2046,0.1311), vec3(-0.2823,0.2633,0.151), vec3(-0.3026,0.2046,0.1436), vec3(0.5137,-0.2788,0.8114), vec2(0.6616,0.9326), vec2(0.6704,0.9276), vec2(0.6616,0.9293), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3113,0.2061,0.1113), vec3(-0.2912,0.2678,0.1233), vec3(-0.2945,0.2033,0.1034), vec3(-0.3711,0.2922,-0.8814), vec2(0.6611,0.947), vec2(0.6816,0.9366), vec2(0.6602,0.9415), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2242,0.2066,0.1357), vec3(-0.2156,0.2151,0.1394), vec3(-0.2621,0.2588,0.1561), vec3(-0.0244,-0.3787,0.9252), vec2(0.6768,0.8984), vec2(0.6763,0.9014), vec2(0.6895,0.9083), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3224,0.2504,0.1681), vec3(-0.3735,0.1887,0.169), vec3(-0.3138,0.2416,0.1646), vec3(0.2229,-0.1712,0.9597), vec2(0.6948,0.9653), vec2(0.6895,0.9845), vec2(0.6978,0.9676), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2161,0.2205,0.116), vec3(-0.2245,0.2105,0.1122), vec3(-0.2626,0.2624,0.1267), vec3(0.0611,0.3096,-0.9489), vec2(0.6733,0.9051), vec2(0.6709,0.9054), vec2(0.6787,0.9224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3333,0.2559,0.1415), vec3(-0.3275,0.2454,0.1328), vec3(-0.3845,0.1951,0.1428), vec3(-0.4809,0.3888,-0.7859), vec2(0.6841,0.9601), vec2(0.6777,0.96), vec2(0.6826,0.9829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2156,0.2151,0.1394), vec3(-0.209,0.2214,0.1266), vec3(-0.2486,0.2649,0.1521), vec3(0.7498,0.3556,0.5579), vec2(0.6763,0.9014), vec2(0.6748,0.9036), vec2(0.6885,0.9112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3142,0.2377,0.1374), vec3(-0.3026,0.2046,0.1436), vec3(-0.2989,0.262,0.1566), vec3(-0.7025,-0.1134,0.7026), vec2(0.6699,0.9569), vec2(0.6626,0.9553), vec2(0.6597,0.9627), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3142,0.2377,0.1374), vec3(-0.3026,0.2046,0.1436), vec3(-0.2989,0.262,0.1566), vec3(-0.7025,-0.1134,0.7026), vec2(0.6699,0.9569), vec2(0.6626,0.9553), vec2(0.6597,0.9627), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.334,0.2585,0.1588), vec3(-0.3871,0.1963,0.158), vec3(-0.3224,0.2504,0.1681), vec3(-0.4243,0.3515,0.8345), vec2(0.6904,0.9625), vec2(0.6855,0.9836), vec2(0.6948,0.9653), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3333,0.2559,0.1415), vec3(-0.3871,0.1963,0.158), vec3(-0.334,0.2585,0.1588), vec3(-0.7535,0.6454,-0.125), vec2(0.6841,0.9601), vec2(0.6855,0.9836), vec2(0.6904,0.9625), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3198,0.2334,0.1448), vec3(-0.3142,0.2377,0.1374), vec3(-0.3138,0.2416,0.1646), vec3(0.6787,-0.7279,0.0977), vec2(0.6714,0.9616), vec2(0.6699,0.9569), vec2(0.667,0.9621), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.209,0.2214,0.1266), vec3(-0.2161,0.2205,0.116), vec3(-0.2562,0.2716,0.1288), vec3(0.6312,0.6139,-0.474), vec2(0.6748,0.9036), vec2(0.6733,0.9051), vec2(0.6831,0.9197), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3198,0.2334,0.1448), vec3(-0.3275,0.2454,0.1328), vec3(-0.3142,0.2377,0.1374), vec3(-0.2216,-0.7575,-0.614), vec2(0.6714,0.9616), vec2(0.6777,0.96), vec2(0.6699,0.9569), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3142,0.2377,0.1374), vec3(-0.3087,0.2728,0.1275), vec3(-0.3113,0.2061,0.1113), vec3(-0.9721,0.0899,-0.2167), vec2(0.6699,0.9569), vec2(0.6851,0.9453), vec2(0.6611,0.947), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2621,0.2588,0.1561), vec3(-0.2642,0.252,0.1391), vec3(-0.2242,0.2066,0.1357), vec3(-0.6924,-0.6352,0.3422), vec2(0.6689,0.9228), vec2(0.6729,0.9229), vec2(0.666,0.9059), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2781,0.2509,0.1293), vec3(-0.2823,0.2633,0.151), vec3(-0.2828,0.2046,0.1311), vec3(0.9674,-0.0889,0.2372), vec2(0.6738,0.9299), vec2(0.6704,0.9276), vec2(0.6616,0.9326), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2912,0.2678,0.1233), vec3(-0.2781,0.2509,0.1293), vec3(-0.2945,0.2033,0.1034), vec3(0.6145,0.2039,-0.7621), vec2(0.6816,0.9366), vec2(0.6738,0.9299), vec2(0.6602,0.9415), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2642,0.252,0.1391), vec3(-0.2626,0.2624,0.1267), vec3(-0.2245,0.2105,0.1122), vec3(-0.7708,-0.4362,-0.4642), vec2(0.6729,0.9229), vec2(0.6787,0.9224), vec2(0.6709,0.9054), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2989,0.262,0.1566), vec3(-0.3026,0.2046,0.1436), vec3(-0.2823,0.2633,0.151), vec3(0.3286,-0.228,0.9166), vec2(0.667,0.9286), vec2(0.6616,0.9293), vec2(0.6704,0.9276), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2486,0.2649,0.1521), vec3(-0.2621,0.2588,0.1561), vec3(-0.2156,0.2151,0.1394), vec3(0.3019,-0.042,0.9524), vec2(0.6885,0.9112), vec2(0.6895,0.9083), vec2(0.6763,0.9014), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2989,0.262,0.1566), vec3(-0.3138,0.2416,0.1646), vec3(-0.3142,0.2377,0.1374), vec3(0.8185,-0.5698,0.0729), vec2(0.665,0.9622), vec2(0.667,0.9621), vec2(0.6699,0.9569), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2912,0.2678,0.1233), vec3(-0.3113,0.2061,0.1113), vec3(-0.3087,0.2728,0.1275), vec3(-0.1602,0.2383,-0.9579), vec2(0.6816,0.9366), vec2(0.6611,0.947), vec2(0.6851,0.9453), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3138,0.2416,0.1646), vec3(-0.2989,0.262,0.1566), vec3(-0.3224,0.2504,0.1681), vec3(0.4222,0.0446,0.9054), vec2(0.6978,0.9676), vec2(0.7031,0.9639), vec2(0.6948,0.9653), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2626,0.2624,0.1267), vec3(-0.2562,0.2716,0.1288), vec3(-0.2161,0.2205,0.116), vec3(-0.0121,0.2343,-0.9721), vec2(0.6787,0.9224), vec2(0.6831,0.9197), vec2(0.6733,0.9051), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3142,0.2377,0.1374), vec3(-0.3275,0.2454,0.1328), vec3(-0.3087,0.2728,0.1275), vec3(0.1623,-0.2911,-0.9428), vec2(0.6699,0.9569), vec2(0.6777,0.96), vec2(0.6851,0.9453), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2488,0.2727,0.145), vec3(-0.2486,0.2649,0.1521), vec3(-0.209,0.2214,0.1266), vec3(0.7741,0.4356,0.4593), vec2(0.6865,0.9154), vec2(0.6885,0.9112), vec2(0.6748,0.9036), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2642,0.252,0.1391), vec3(-0.2781,0.2509,0.1293), vec3(-0.2626,0.2624,0.1267), vec3(0.4398,-0.7159,-0.5422), vec2(0.6729,0.9229), vec2(0.6738,0.9299), vec2(0.6787,0.9224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2642,0.252,0.1391), vec3(-0.2781,0.2509,0.1293), vec3(-0.2626,0.2624,0.1267), vec3(0.4398,-0.7159,-0.5422), vec2(0.6729,0.9229), vec2(0.6738,0.9299), vec2(0.6787,0.9224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2562,0.2716,0.1288), vec3(-0.2488,0.2727,0.145), vec3(-0.209,0.2214,0.1266), vec3(0.6748,0.6494,-0.3506), vec2(0.6831,0.9197), vec2(0.6865,0.9154), vec2(0.6748,0.9036), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2823,0.2633,0.151), vec3(-0.2781,0.2509,0.1293), vec3(-0.2642,0.252,0.1391), vec3(-0.2452,-0.8604,0.4468), vec2(0.6694,0.9261), vec2(0.6738,0.9299), vec2(0.6729,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2642,0.252,0.1391), vec3(-0.2621,0.2588,0.1561), vec3(-0.2823,0.2633,0.151), vec3(-0.2917,-0.874,0.3886), vec2(0.6729,0.9229), vec2(0.6689,0.9228), vec2(0.6694,0.9261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3275,0.2454,0.1328), vec3(-0.3333,0.2559,0.1415), vec3(-0.3087,0.2728,0.1275), vec3(-0.613,0.2784,-0.7394), vec2(0.6777,0.96), vec2(0.6841,0.9601), vec2(0.6851,0.9453), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2621,0.2588,0.1561), vec3(-0.2486,0.2649,0.1521), vec3(-0.2823,0.2633,0.151), vec3(-0.0545,0.6332,0.772), vec2(0.6895,0.9083), vec2(0.6885,0.9112), vec2(0.6948,0.9047), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2781,0.2509,0.1293), vec3(-0.2792,0.2774,0.1273), vec3(-0.2626,0.2624,0.1267), vec3(-0.1077,-0.0811,-0.9909), vec2(0.6738,0.9299), vec2(0.686,0.9303), vec2(0.6787,0.9224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2912,0.2678,0.1233), vec3(-0.2792,0.2774,0.1273), vec3(-0.2781,0.2509,0.1293), vec3(0.353,-0.0588,-0.9338), vec2(0.6816,0.9366), vec2(0.686,0.9303), vec2(0.6738,0.9299), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2969,0.2939,0.1638), vec3(-0.3224,0.2504,0.1681), vec3(-0.2989,0.262,0.1566), vec3(0.5156,-0.2201,0.8281), vec2(0.7056,0.9552), vec2(0.6948,0.9653), vec2(0.7031,0.9639), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.334,0.2585,0.1588), vec3(-0.3224,0.2504,0.1681), vec3(-0.3172,0.2987,0.1569), vec3(-0.4968,0.2451,0.8326), vec2(0.6904,0.9625), vec2(0.6948,0.9653), vec2(0.7002,0.9511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2562,0.2716,0.1288), vec3(-0.2626,0.2624,0.1267), vec3(-0.2792,0.2774,0.1273), vec3(0.1057,0.1546,-0.9823), vec2(0.6831,0.9197), vec2(0.6787,0.9224), vec2(0.686,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.334,0.2585,0.1588), vec3(-0.3111,0.302,0.1397), vec3(-0.3333,0.2559,0.1415), vec3(-0.8979,0.4289,-0.099), vec2(0.6904,0.9625), vec2(0.6978,0.946), vec2(0.6841,0.9601), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2823,0.2633,0.151), vec3(-0.2969,0.2939,0.1638), vec3(-0.2989,0.262,0.1566), vec3(0.3286,-0.228,0.9165), vec2(0.6948,0.9047), vec2(0.7041,0.9084), vec2(0.6987,0.9007), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2741,0.3016,0.1608), vec3(-0.2823,0.2633,0.151), vec3(-0.2486,0.2649,0.1521), vec3(-0.0204,-0.2446,0.9694), vec2(0.7017,0.915), vec2(0.6948,0.9047), vec2(0.6885,0.9112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3111,0.302,0.1397), vec3(-0.3087,0.2728,0.1275), vec3(-0.3333,0.2559,0.1415), vec3(-0.608,0.263,-0.7491), vec2(0.6978,0.946), vec2(0.6851,0.9453), vec2(0.6841,0.9601), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3087,0.2728,0.1275), vec3(-0.2918,0.2934,0.1192), vec3(-0.2912,0.2678,0.1233), vec3(-0.2736,-0.1605,-0.9484), vec2(0.6851,0.9453), vec2(0.6899,0.9363), vec2(0.6816,0.9366), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2912,0.2678,0.1233), vec3(-0.2918,0.2934,0.1192), vec3(-0.2792,0.2774,0.1273), vec3(0.4066,-0.1379,-0.9032), vec2(0.6816,0.9366), vec2(0.6899,0.9363), vec2(0.686,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,0.2987,0.1569), vec3(-0.3224,0.2504,0.1681), vec3(-0.2969,0.2939,0.1638), vec3(-0.2569,0.2433,0.9353), vec2(0.7002,0.9511), vec2(0.6948,0.9653), vec2(0.7056,0.9552), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2488,0.2727,0.145), vec3(-0.2621,0.3059,0.1492), vec3(-0.2486,0.2649,0.1521), vec3(0.8929,0.315,0.3219), vec2(0.6865,0.9154), vec2(0.6987,0.9209), vec2(0.6885,0.9112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2488,0.2727,0.145), vec3(-0.2562,0.2716,0.1288), vec3(-0.2693,0.3041,0.1403), vec3(0.7965,0.4595,-0.393), vec2(0.6865,0.9154), vec2(0.6831,0.9197), vec2(0.6978,0.9262), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2562,0.2716,0.1288), vec3(-0.2792,0.2774,0.1273), vec3(-0.2693,0.3041,0.1403), vec3(0.1594,0.3859,-0.9087), vec2(0.6831,0.9197), vec2(0.686,0.9303), vec2(0.6978,0.9262), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2969,0.2939,0.1638), vec3(-0.2823,0.2633,0.151), vec3(-0.2741,0.3016,0.1608), vec3(0.2191,-0.2868,0.9326), vec2(0.7041,0.9084), vec2(0.6948,0.9047), vec2(0.7017,0.915), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3172,0.2987,0.1569), vec3(-0.3111,0.302,0.1397), vec3(-0.334,0.2585,0.1588), vec3(-0.8977,0.3612,-0.2523), vec2(0.7002,0.9511), vec2(0.6978,0.946), vec2(0.6904,0.9625), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3087,0.2728,0.1275), vec3(-0.3076,0.2979,0.1233), vec3(-0.2918,0.2934,0.1192), vec3(-0.2918,-0.1443,-0.9455), vec2(0.6851,0.9453), vec2(0.6929,0.9417), vec2(0.6899,0.9363), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2741,0.3016,0.1608), vec3(-0.2486,0.2649,0.1521), vec3(-0.2621,0.3059,0.1492), vec3(0.6221,0.2556,0.7401), vec2(0.7017,0.915), vec2(0.6885,0.9112), vec2(0.6987,0.9209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3111,0.302,0.1397), vec3(-0.3076,0.2979,0.1233), vec3(-0.3087,0.2728,0.1275), vec3(-0.9776,0.008,-0.2101), vec2(0.6978,0.946), vec2(0.6929,0.9417), vec2(0.6851,0.9453), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.278,0.3023,0.1288), vec3(-0.2792,0.2774,0.1273), vec3(-0.2918,0.2934,0.1192), vec3(0.5627,0.0242,-0.8263), vec2(0.6948,0.9307), vec2(0.686,0.9303), vec2(0.6899,0.9363), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2693,0.3041,0.1403), vec3(-0.2621,0.3059,0.1492), vec3(-0.2488,0.2727,0.145), vec3(0.6894,0.3544,-0.6317), vec2(0.6978,0.9262), vec2(0.6987,0.9209), vec2(0.6865,0.9154), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2792,0.2774,0.1273), vec3(-0.278,0.3023,0.1288), vec3(-0.2693,0.3041,0.1403), vec3(0.7978,-0.0003,-0.6029), vec2(0.686,0.9303), vec2(0.6948,0.9307), vec2(0.6978,0.9262), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2969,0.2939,0.1638), vec3(-0.2963,0.3133,0.1625), vec3(-0.3172,0.2987,0.1569), vec3(-0.3028,0.0713,0.9504), vec2(0.7056,0.9552), vec2(0.709,0.9503), vec2(0.7002,0.9511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2963,0.3133,0.1625), vec3(-0.2969,0.2939,0.1638), vec3(-0.2741,0.3016,0.1608), vec3(0.1096,0.0618,0.9921), vec2(0.708,0.9115), vec2(0.7041,0.9084), vec2(0.7017,0.915), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2621,0.3059,0.1492), vec3(-0.276,0.3179,0.1604), vec3(-0.2741,0.3016,0.1608), vec3(0.6735,0.0952,0.733), vec2(0.6987,0.9209), vec2(0.7061,0.9179), vec2(0.7017,0.915), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.0058,0.844,0.9847), 0.7186, bestT)) {
        if (triHit(ro, rd, vec3(-0.6528,0.8259,0.987), vec3(-0.5022,0.7972,1.1502), vec3(-0.6246,0.8438,0.9745), vec3(-0.3275,0.8316,0.4486), vec2(0.7759,0.2017), vec2(0.856,0.2378), vec2(0.7871,0.188), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5022,0.7972,1.1502), vec3(-0.4716,0.8333,1.1211), vec3(-0.6246,0.8438,0.9745), vec3(-0.4228,0.7587,0.4956), vec2(0.856,0.2378), vec2(0.8667,0.2188), vec2(0.7871,0.188), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6246,0.8438,0.9745), vec3(-0.2206,0.8347,0.6991), vec3(-0.6528,0.8259,0.987), vec3(-0.5346,0.2903,-0.7936), vec2(0.7871,0.188), vec2(0.8828,0.0078), vec2(0.772,0.1953), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6528,0.8259,0.987), vec3(-0.2206,0.8347,0.6991), vec3(-0.5022,0.7972,1.1502), vec3(-0.0595,-0.9911,-0.1193), vec2(0.6626,0.879), vec2(0.5181,0.8101), vec2(0.6143,0.9227), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3571,0.8021,1.2586), vec3(-0.4716,0.8333,1.1211), vec3(-0.5022,0.7972,1.1502), vec3(-0.4071,0.7574,0.5105), vec2(0.9097,0.2598), vec2(0.8667,0.2188), vec2(0.856,0.2378), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.6246,0.8438,0.9745), vec3(-0.4716,0.8333,1.1211), vec3(-0.1895,0.9608,0.6622), vec3(-0.121,0.9731,0.1961), vec2(0.7871,0.188), vec2(0.8667,0.2188), vec2(0.9395,0.0122), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3571,0.8021,1.2586), vec3(-0.3209,0.8259,1.2002), vec3(-0.4716,0.8333,1.1211), vec3(-0.1167,0.9433,0.3107), vec2(0.9097,0.2598), vec2(0.9238,0.2378), vec2(0.8667,0.2188), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3571,0.8021,1.2586), vec3(-0.5022,0.7972,1.1502), vec3(-0.1765,0.8238,0.8463), vec3(0.0548,-0.9981,-0.0283), vec2(0.583,0.9531), vec2(0.6143,0.9227), vec2(0.5103,0.8556), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1895,0.9608,0.6622), vec3(-0.2206,0.8347,0.6991), vec3(-0.6246,0.8438,0.9745), vec3(-0.5621,-0.101,-0.8209), vec2(0.9395,0.0122), vec2(0.8828,0.0078), vec2(0.7871,0.188), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4716,0.8333,1.1211), vec3(-0.3209,0.8259,1.2002), vec3(-0.1549,0.9242,0.8049), vec3(-0.065,0.9744,0.2151), vec2(0.8667,0.2188), vec2(0.9238,0.2378), vec2(0.9678,0.0742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1765,0.8238,0.8463), vec3(-0.5022,0.7972,1.1502), vec3(-0.2206,0.8347,0.6991), vec3(0.0096,-0.997,-0.0767), vec2(0.5103,0.8556), vec2(0.6143,0.9227), vec2(0.5181,0.8101), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3209,0.8259,1.2002), vec3(-0.3571,0.8021,1.2586), vec3(-0.1559,0.8264,1.3144), vec3(-0.188,0.9451,0.2673), vec2(0.9238,0.2378), vec2(0.9097,0.2598), vec2(0.9834,0.2876), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1549,0.9242,0.8049), vec3(-0.1895,0.9608,0.6622), vec3(-0.4716,0.8333,1.1211), vec3(-0.024,0.9669,0.254), vec2(0.9678,0.0742), vec2(0.9395,0.0122), vec2(0.8667,0.2188), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1765,0.8238,0.8463), vec3(-0.1531,0.8121,0.8625), vec3(-0.3571,0.8021,1.2586), vec3(-0.3273,-0.9252,-0.1919), vec2(0.5103,0.8556), vec2(0.5044,0.8627), vec2(0.583,0.9531), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1559,0.8264,1.3144), vec3(-0.3571,0.8021,1.2586), vec3(-0.1531,0.8121,0.8625), vec3(0.1109,-0.9933,0.032), vec2(0.5425,0.9952), vec2(0.583,0.9531), vec2(0.5044,0.8627), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2394,0.9491,0.5873), vec3(-0.2206,0.8347,0.6991), vec3(-0.1895,0.9608,0.6622), vec3(-0.8063,0.3403,0.4839), vec2(0.9834,0.5398), vec2(0.9624,0.5649), vec2(0.9893,0.5574), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1559,0.8264,1.3144), vec3(-0.1526,0.8502,1.2431), vec3(-0.3209,0.8259,1.2002), vec3(-0.2111,0.9301,0.3006), vec2(0.9834,0.2876), vec2(0.9893,0.2559), vec2(0.9238,0.2378), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2206,0.8347,0.6991), vec3(-0.223,0.7617,0.7035), vec3(-0.1765,0.8238,0.8463), vec3(-0.9557,0.049,0.2903), vec2(0.9624,0.5649), vec2(0.9497,0.5688), vec2(0.9639,0.5957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1141,0.8857,0.9595), vec3(-0.1549,0.9242,0.8049), vec3(-0.3209,0.8259,1.2002), vec3(0.0007,0.9704,0.2416), vec2(0.9888,0.1299), vec2(0.9678,0.0742), vec2(0.9238,0.2378), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1141,0.8857,0.9595), vec3(-0.3209,0.8259,1.2002), vec3(-0.1526,0.8502,1.2431), vec3(-0.1672,0.9808,0.1), vec2(0.9888,0.1299), vec2(0.9238,0.2378), vec2(0.9893,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1895,0.9608,0.6622), vec3(-0.2206,0.8347,0.6991), vec3(-0.1549,0.9242,0.8049), vec3(-0.9027,0.31,0.2985), vec2(0.9893,0.5574), vec2(0.9624,0.5649), vec2(0.981,0.5898), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1765,0.8238,0.8463), vec3(-0.223,0.7617,0.7035), vec3(-0.1531,0.8121,0.8625), vec3(-0.6318,-0.6142,0.4729), vec2(0.3652,0.3052), vec2(0.4319,0.3452), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2206,0.8347,0.6991), vec3(-0.1765,0.8238,0.8463), vec3(-0.1549,0.9242,0.8049), vec3(-0.9024,0.3151,0.294), vec2(0.9624,0.5649), vec2(0.9639,0.5957), vec2(0.981,0.5898), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.223,0.7617,0.7035), vec3(-0.1588,0.7379,0.6714), vec3(-0.1531,0.8121,0.8625), vec3(-0.1599,-0.9185,0.3618), vec2(0.4319,0.3452), vec2(0.4553,0.3228), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1895,0.9608,0.6622), vec3(-0.0904,1.0326,0.6747), vec3(-0.2173,0.9882,0.5964), vec3(-0.5463,0.666,0.5079), vec2(0.3818,0.4258), vec2(0.3335,0.4575), vec2(0.4021,0.4541), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1526,0.8502,1.2431), vec3(-0.1531,0.8121,0.8625), vec3(-0.1559,0.8264,1.3144), vec3(-0.994,0.1092,-0.0097), vec2(0.1605,0.1201), vec2(0.3655,0.2837), vec2(0.1392,0.0742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1549,0.9242,0.8049), vec3(-0.1765,0.8238,0.8463), vec3(-0.1141,0.8857,0.9595), vec3(-0.8924,0.322,0.316), vec2(0.3389,0.3511), vec2(0.3652,0.3052), vec2(0.2981,0.2656), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1141,0.8857,0.9595), vec3(-0.1765,0.8238,0.8463), vec3(-0.1531,0.8121,0.8625), vec3(-0.6479,-0.4585,0.6082), vec2(0.2981,0.2656), vec2(0.3652,0.3052), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1141,0.8857,0.9595), vec3(-0.1531,0.8121,0.8625), vec3(-0.1526,0.8502,1.2431), vec3(-0.8528,0.5197,-0.0509), vec2(0.2981,0.2656), vec2(0.3655,0.2837), vec2(0.1605,0.1201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1549,0.9242,0.8049), vec3(-0.0486,0.9584,0.8329), vec3(-0.1895,0.9608,0.6622), vec3(-0.3651,0.8766,0.3135), vec2(0.3389,0.3511), vec2(0.2795,0.3838), vec2(0.3818,0.4258), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1559,0.8264,1.3144), vec3(-0.0373,0.8418,1.3421), vec3(-0.1526,0.8502,1.2431), vec3(-0.1921,0.9335,0.3027), vec2(0.1392,0.0742), vec2(0.0641,0.1128), vec2(0.1605,0.1201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1559,0.8264,1.3144), vec3(-0.1531,0.8121,0.8625), vec3(-0.0279,0.8169,0.9852), vec3(0.0073,-0.9995,0.0316), vec2(0.2128,0.1001), vec2(0.3655,0.2837), vec2(0.3682,0.1938), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0904,1.0326,0.6747), vec3(-0.1895,0.9608,0.6622), vec3(-0.0486,0.9584,0.8329), vec3(-0.5561,0.6865,0.4686), vec2(0.3335,0.4575), vec2(0.3818,0.4258), vec2(0.2795,0.3838), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1588,0.7379,0.6714), vec3(-0.0062,0.7186,0.7143), vec3(-0.1531,0.8121,0.8625), vec3(-0.2154,-0.908,0.3594), vec2(0.4553,0.3228), vec2(0.4705,0.2559), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0486,0.9584,0.8329), vec3(-0.1549,0.9242,0.8049), vec3(-0.1141,0.8857,0.9595), vec3(-0.3653,0.876,0.3148), vec2(0.2795,0.3838), vec2(0.3389,0.3511), vec2(0.2981,0.2656), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0355,0.88,1.2599), vec3(-0.1141,0.8857,0.9595), vec3(-0.1526,0.8502,1.2431), vec3(-0.2578,0.9624,0.0854), vec2(0.0988,0.1636), vec2(0.2981,0.2656), vec2(0.1605,0.1201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0355,0.88,1.2599), vec3(-0.1526,0.8502,1.2431), vec3(-0.0373,0.8418,1.3421), vec3(-0.28,0.8727,0.4), vec2(0.0988,0.1636), vec2(0.1605,0.1201), vec2(0.0641,0.1128), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0373,0.8418,1.3421), vec3(-0.1559,0.8264,1.3144), vec3(-0.0279,0.8169,0.9852), vec3(0.1121,-0.9911,0.0721), vec2(0.2598,0.0532), vec2(0.2128,0.1001), vec2(0.3682,0.1938), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0279,0.8169,0.9852), vec3(-0.1531,0.8121,0.8625), vec3(-0.0193,0.801,0.8549), vec3(-0.076,-0.9903,0.1161), vec2(0.3682,0.1938), vec2(0.3655,0.2837), vec2(0.4097,0.2319), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1141,0.8857,0.9595), vec3(-0.0355,0.88,1.2599), vec3(-0.0486,0.9584,0.8329), vec3(-0.5734,0.8025,0.1649), vec2(0.2981,0.2656), vec2(0.0988,0.1636), vec2(0.2795,0.3838), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1531,0.8121,0.8625), vec3(-0.0062,0.7186,0.7143), vec3(-0.0193,0.801,0.8549), vec3(-0.0437,-0.8639,0.5018), vec2(0.3655,0.2837), vec2(0.4705,0.2559), vec2(0.4097,0.2319), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0904,1.0326,0.6747), vec3(0.0684,1.0415,0.6663), vec3(-0.0988,1.1034,0.5004), vec3(-0.0323,0.9254,0.3777), vec2(0.3335,0.4575), vec2(0.2681,0.4941), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0904,1.0326,0.6747), vec3(-0.0486,0.9584,0.8329), vec3(0.0684,1.0415,0.6663), vec3(-0.0282,0.9023,0.4301), vec2(0.3335,0.4575), vec2(0.2795,0.3838), vec2(0.2681,0.4941), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0486,0.9584,0.8329), vec3(-0.0355,0.88,1.2599), vec3(0.0702,0.9751,0.8387), vec3(-0.1451,0.9723,0.183), vec2(0.2795,0.3838), vec2(0.0988,0.1636), vec2(0.2196,0.418), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0279,0.8169,0.9852), vec3(0.0691,0.8194,1.0051), vec3(-0.0373,0.8418,1.3421), vec3(0.0108,-0.9975,0.0699), vec2(0.3682,0.1938), vec2(0.3975,0.1587), vec2(0.2598,0.0532), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0373,0.8418,1.3421), vec3(0.0777,0.8399,1.3582), vec3(-0.0355,0.88,1.2599), vec3(-0.0439,0.9062,0.4206), vec2(0.0641,0.1128), vec2(-0.0063,0.1499), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0193,0.801,0.8549), vec3(0.0649,0.7908,0.8551), vec3(-0.0279,0.8169,0.9852), vec3(-0.1192,-0.9864,0.1128), vec2(0.4097,0.2319), vec2(0.4326,0.2061), vec2(0.3682,0.1938), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0062,0.7186,0.7143), vec3(0.06,0.7205,0.7351), vec3(-0.0193,0.801,0.8549), vec3(-0.1298,-0.8609,0.492), vec2(0.4705,0.2559), vec2(0.4744,0.23), vec2(0.4097,0.2319), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0702,0.9751,0.8387), vec3(0.0684,1.0415,0.6663), vec3(-0.0486,0.9584,0.8329), vec3(-0.1467,0.9225,0.357), vec2(0.2196,0.418), vec2(0.2681,0.4941), vec2(0.2795,0.3838), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0649,0.7908,0.8551), vec3(-0.0193,0.801,0.8549), vec3(0.06,0.7205,0.7351), vec3(-0.104,-0.8562,0.506), vec2(0.4326,0.2061), vec2(0.4097,0.2319), vec2(0.4744,0.23), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0691,0.8194,1.0051), vec3(-0.0279,0.8169,0.9852), vec3(0.0649,0.7908,0.8551), vec3(-0.0137,-0.9822,0.1872), vec2(0.3975,0.1587), vec2(0.3682,0.1938), vec2(0.4326,0.2061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0777,0.8399,1.3582), vec3(-0.0373,0.8418,1.3421), vec3(0.0691,0.8194,1.0051), vec3(-0.0246,-0.998,0.0587), vec2(0.3057,0.0132), vec2(0.2598,0.0532), vec2(0.3975,0.1587), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.06,0.7205,0.7351), vec3(-0.0062,0.7186,0.7143), vec3(0.0565,0.6672,0.6497), vec3(-0.1421,-0.8368,0.5288), vec2(0.4744,0.23), vec2(0.4705,0.2559), vec2(0.5068,0.2446), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.078,0.8968,1.2755), vec3(0.0702,0.9751,0.8387), vec3(-0.0355,0.88,1.2599), vec3(-0.1675,0.9699,0.1768), vec2(0.0361,0.2051), vec2(0.2196,0.418), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.078,0.8968,1.2755), vec3(-0.0355,0.88,1.2599), vec3(0.0777,0.8399,1.3582), vec3(-0.1958,0.808,0.5556), vec2(0.0361,0.2051), vec2(0.0988,0.1636), vec2(-0.0063,0.1499), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.06,0.7205,0.7351), vec3(0.0565,0.6672,0.6497), vec3(0.125,0.7146,0.7114), vec3(0.1138,-0.8447,0.523), vec2(0.4744,0.23), vec2(0.5068,0.2446), vec2(0.4705,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.06,0.7205,0.7351), vec3(0.1495,0.7958,0.8511), vec3(0.0649,0.7908,0.8551), vec3(0.0739,-0.8617,0.502), vec2(0.4744,0.23), vec2(0.4097,0.2319), vec2(0.4326,0.2061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0649,0.7908,0.8551), vec3(0.1649,0.811,0.9809), vec3(0.0691,0.8194,1.0051), vec3(-0.0382,-0.9815,0.1878), vec2(0.4326,0.2061), vec2(0.3682,0.1938), vec2(0.3975,0.1587), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1874,0.9512,0.8276), vec3(0.0684,1.0415,0.6663), vec3(0.0702,0.9751,0.8387), vec3(0.2191,0.9113,0.3487), vec2(0.2795,0.3838), vec2(0.2681,0.4941), vec2(0.2196,0.418), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.125,0.7146,0.7114), vec3(0.1495,0.7958,0.8511), vec3(0.06,0.7205,0.7351), vec3(0.0985,-0.8678,0.487), vec2(0.4705,0.2559), vec2(0.4097,0.2319), vec2(0.4744,0.23), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1918,0.8348,1.3369), vec3(0.0777,0.8399,1.3582), vec3(0.0691,0.8194,1.0051), vec3(-0.0341,-0.9977,0.0589), vec2(0.2598,0.0532), vec2(0.3057,0.0132), vec2(0.3975,0.1587), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.078,0.8968,1.2755), vec3(0.1916,0.8716,1.2551), vec3(0.0702,0.9751,0.8387), vec3(0.2418,0.9559,0.167), vec2(0.0361,0.2051), vec2(0.0988,0.1636), vec2(0.2196,0.418), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0777,0.8399,1.3582), vec3(0.1916,0.8716,1.2551), vec3(0.078,0.8968,1.2755), vec3(0.2737,0.7918,0.546), vec2(-0.0063,0.1499), vec2(0.0988,0.1636), vec2(0.0361,0.2051), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1495,0.7958,0.8511), vec3(0.1649,0.811,0.9809), vec3(0.0649,0.7908,0.8551), vec3(0.0632,-0.992,0.1089), vec2(0.4097,0.2319), vec2(0.3682,0.1938), vec2(0.4326,0.2061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1649,0.811,0.9809), vec3(0.1918,0.8348,1.3369), vec3(0.0691,0.8194,1.0051), vec3(-0.0688,-0.9951,0.0717), vec2(0.3682,0.1938), vec2(0.2598,0.0532), vec2(0.3975,0.1587), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1874,0.9512,0.8276), vec3(0.0702,0.9751,0.8387), vec3(0.1916,0.8716,1.2551), vec3(0.2128,0.961,0.1767), vec2(0.2795,0.3838), vec2(0.2196,0.418), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1918,0.8348,1.3369), vec3(0.1916,0.8716,1.2551), vec3(0.0777,0.8399,1.3582), vec3(0.1169,0.9056,0.4078), vec2(0.0641,0.1128), vec2(0.0988,0.1636), vec2(-0.0063,0.1499), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1874,0.9512,0.8276), vec3(0.2265,1.0228,0.6675), vec3(0.0684,1.0415,0.6663), vec3(0.1028,0.8983,0.4273), vec2(0.2795,0.3838), vec2(0.3335,0.4575), vec2(0.2681,0.4941), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1495,0.7958,0.8511), vec3(0.125,0.7146,0.7114), vec3(0.2839,0.7987,0.8526), vec3(0.0131,-0.8656,0.5006), vec2(0.4097,0.2319), vec2(0.4705,0.2559), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1495,0.7958,0.8511), vec3(0.2839,0.7987,0.8526), vec3(0.1649,0.811,0.9809), vec3(0.0201,-0.9933,0.1141), vec2(0.4097,0.2319), vec2(0.3655,0.2837), vec2(0.3682,0.1938), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2539,0.8743,0.9512), vec3(0.1874,0.9512,0.8276), vec3(0.1916,0.8716,1.2551), vec3(0.6304,0.7642,0.1359), vec2(0.2981,0.2656), vec2(0.2795,0.3838), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1649,0.811,0.9809), vec3(0.3128,0.8085,1.3042), vec3(0.1918,0.8348,1.3369), vec3(-0.1906,-0.9784,0.0798), vec2(0.3682,0.1938), vec2(0.2128,0.1001), vec2(0.2598,0.0532), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2765,0.7245,0.6616), vec3(0.2839,0.7987,0.8526), vec3(0.125,0.7146,0.7114), vec3(0.1753,-0.92,0.3505), vec2(0.4553,0.3228), vec2(0.3655,0.2837), vec2(0.4705,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1918,0.8348,1.3369), vec3(0.3068,0.8336,1.2331), vec3(0.1916,0.8716,1.2551), vec3(0.3548,0.8527,0.3834), vec2(0.0641,0.1128), vec2(0.1605,0.1201), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2539,0.8743,0.9512), vec3(0.29,0.9104,0.7949), vec3(0.1874,0.9512,0.8276), vec3(0.433,0.8513,0.2962), vec2(0.2981,0.2656), vec2(0.3389,0.3511), vec2(0.2795,0.3838), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3068,0.8336,1.2331), vec3(0.2539,0.8743,0.9512), vec3(0.1916,0.8716,1.2551), vec3(0.3255,0.9425,0.0751), vec2(0.1605,0.1201), vec2(0.2981,0.2656), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1649,0.811,0.9809), vec3(0.2839,0.7987,0.8526), vec3(0.3128,0.8085,1.3042), vec3(-0.0746,-0.9969,0.0265), vec2(0.3682,0.1938), vec2(0.3655,0.2837), vec2(0.2128,0.1001), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3128,0.8085,1.3042), vec3(0.3068,0.8336,1.2331), vec3(0.1918,0.8348,1.3369), vec3(0.2785,0.9129,0.2983), vec2(0.1392,0.0742), vec2(0.1605,0.1201), vec2(0.0641,0.1128), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2539,0.8743,0.9512), vec3(0.3068,0.8336,1.2331), vec3(0.2839,0.7987,0.8526), vec3(0.8759,0.4728,-0.0961), vec2(0.2981,0.2656), vec2(0.1605,0.1201), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2839,0.7987,0.8526), vec3(0.3072,0.8089,0.8354), vec3(0.2539,0.8743,0.9512), vec3(0.6451,-0.4985,0.5791), vec2(0.3655,0.2837), vec2(0.3652,0.3052), vec2(0.2981,0.2656), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2539,0.8743,0.9512), vec3(0.3072,0.8089,0.8354), vec3(0.29,0.9104,0.7949), vec3(0.9238,0.2666,0.2749), vec2(0.2981,0.2656), vec2(0.3652,0.3052), vec2(0.3389,0.3511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3068,0.8336,1.2331), vec3(0.3128,0.8085,1.3042), vec3(0.2839,0.7987,0.8526), vec3(0.9962,0.0571,-0.0651), vec2(0.1605,0.1201), vec2(0.1392,0.0742), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2839,0.7987,0.8526), vec3(0.3434,0.7443,0.6907), vec3(0.3072,0.8089,0.8354), vec3(0.6133,-0.6527,0.4448), vec2(0.3655,0.2837), vec2(0.4319,0.3452), vec2(0.3652,0.3052), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2539,0.8743,0.9512), vec3(0.4725,0.7972,1.1826), vec3(0.29,0.9104,0.7949), vec3(0.0845,0.9665,0.2423), vec2(0.9888,0.1299), vec2(0.9238,0.2378), vec2(0.9678,0.0742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3068,0.8336,1.2331), vec3(0.4725,0.7972,1.1826), vec3(0.2539,0.8743,0.9512), vec3(0.2408,0.966,0.0944), vec2(0.9893,0.2559), vec2(0.9238,0.2378), vec2(0.9888,0.1299), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3128,0.8085,1.3042), vec3(0.4725,0.7972,1.1826), vec3(0.3068,0.8336,1.2331), vec3(0.2901,0.91,0.2963), vec2(0.9834,0.2876), vec2(0.9238,0.2378), vec2(0.9893,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2839,0.7987,0.8526), vec3(0.3072,0.8089,0.8354), vec3(0.5116,0.7688,1.2393), vec3(0.2497,-0.943,-0.2198), vec2(0.5044,0.8627), vec2(0.5103,0.8556), vec2(0.583,0.9531), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2839,0.7987,0.8526), vec3(0.5116,0.7688,1.2393), vec3(0.3128,0.8085,1.3042), vec3(-0.1852,-0.9821,0.0333), vec2(0.5044,0.8627), vec2(0.583,0.9531), vec2(0.5425,0.9952), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5116,0.7688,1.2393), vec3(0.4725,0.7972,1.1826), vec3(0.3128,0.8085,1.3042), vec3(0.2732,0.9224,0.273), vec2(0.9097,0.2598), vec2(0.9238,0.2378), vec2(0.9834,0.2876), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6225,0.7921,1.0967), vec3(0.29,0.9104,0.7949), vec3(0.4725,0.7972,1.1826), vec3(0.1532,0.9657,0.2097), vec2(0.8667,0.2188), vec2(0.9678,0.0742), vec2(0.9238,0.2378), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5116,0.7688,1.2393), vec3(0.3072,0.8089,0.8354), vec3(0.6532,0.7521,1.1242), vec3(-0.1392,-0.9899,-0.0276), vec2(0.583,0.9531), vec2(0.5103,0.8556), vec2(0.6143,0.9227), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4725,0.7972,1.1826), vec3(0.5116,0.7688,1.2393), vec3(0.6225,0.7921,1.0967), vec3(0.2126,0.9246,0.316), vec2(0.9238,0.2378), vec2(0.9097,0.2598), vec2(0.8667,0.2188), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6532,0.7521,1.1242), vec3(0.6225,0.7921,1.0967), vec3(0.5116,0.7688,1.2393), vec3(0.4886,0.7173,0.4967), vec2(0.856,0.2378), vec2(0.8667,0.2188), vec2(0.9097,0.2598), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.0848,1.0487,-0.7701), 0.5766, bestT)) {
        if (triHit(ro, rd, vec3(-0.1291,1.1248,-0.9945), vec3(-0.1129,1.0379,-1.0453), vec3(-0.1225,1.0103,-0.9978), vec3(-0.9729,-0.0498,-0.2259), vec2(0.8413,0.8647), vec2(0.8789,0.8451), vec2(0.8682,0.8246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1359,0.9601,-0.9373), vec3(-0.0556,0.9332,-1.0519), vec3(-0.0557,0.8774,-0.9996), vec3(-0.7862,-0.4215,-0.4519), vec2(0.8579,0.7921), vec2(0.9146,0.807), vec2(0.9111,0.7754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1359,0.9601,-0.9373), vec3(-0.1225,1.0103,-0.9978), vec3(-0.0556,0.9332,-1.0519), vec3(-0.8016,-0.3605,-0.477), vec2(0.8579,0.7921), vec2(0.8682,0.8246), vec2(0.9146,0.807), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0557,0.8774,-0.9996), vec3(0.0246,0.8546,-1.0211), vec3(-0.0636,0.7597,-0.8899), vec3(-0.3619,-0.6226,-0.6938), vec2(0.9111,0.7754), vec2(0.9473,0.7694), vec2(0.9053,0.7095), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1595,1.0416,-0.8834), vec3(-0.1291,1.1248,-0.9945), vec3(-0.1225,1.0103,-0.9978), vec3(-0.954,-0.0467,-0.2961), vec2(0.8188,0.809), vec2(0.8413,0.8647), vec2(0.8682,0.8246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1034,1.203,-0.9856), vec3(-0.1291,1.1248,-0.9945), vec3(-0.1386,1.1318,-0.8635), vec3(-0.9436,0.32,-0.0854), vec2(0.8232,0.8921), vec2(0.8413,0.8647), vec2(0.793,0.8396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1595,1.0416,-0.8834), vec3(-0.1225,1.0103,-0.9978), vec3(-0.1359,0.9601,-0.9373), vec3(-0.9545,-0.0884,-0.2849), vec2(0.8188,0.809), vec2(0.8682,0.8246), vec2(0.8579,0.7921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0235,0.7289,-0.8979), vec3(0.0246,0.8546,-1.0211), vec3(0.1126,0.7543,-0.8939), vec3(0.2258,-0.6829,-0.6948), vec2(0.9434,0.6992), vec2(0.9473,0.7694), vec2(0.9053,0.7095), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0235,0.7289,-0.8979), vec3(-0.0636,0.7597,-0.8899), vec3(0.0246,0.8546,-1.0211), vec3(-0.2984,-0.6667,-0.683), vec2(0.9434,0.6992), vec2(0.9053,0.7095), vec2(0.9473,0.7694), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1359,0.9601,-0.9373), vec3(-0.0557,0.8774,-0.9996), vec3(-0.1626,0.9264,-0.8692), vec3(-0.7799,-0.3827,-0.4953), vec2(0.8579,0.7921), vec2(0.9111,0.7754), vec2(0.8408,0.7628), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0636,0.7597,-0.8899), vec3(-0.1326,0.8331,-0.8819), vec3(-0.0557,0.8774,-0.9996), vec3(-0.6165,-0.5145,-0.596), vec2(0.9053,0.7095), vec2(0.8701,0.7329), vec2(0.9111,0.7754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1326,0.8331,-0.8819), vec3(-0.1626,0.9264,-0.8692), vec3(-0.0557,0.8774,-0.9996), vec3(-0.7928,-0.1757,-0.5835), vec2(0.8701,0.7329), vec2(0.8408,0.7628), vec2(0.9111,0.7754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1386,1.1318,-0.8635), vec3(-0.1291,1.1248,-0.9945), vec3(-0.1595,1.0416,-0.8834), vec3(-0.9666,0.2426,-0.083), vec2(0.793,0.8396), vec2(0.8413,0.8647), vec2(0.8188,0.809), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1595,1.0416,-0.8834), vec3(-0.1359,0.9601,-0.9373), vec3(-0.1626,0.9264,-0.8692), vec3(-0.927,-0.0213,-0.3744), vec2(0.8188,0.809), vec2(0.8579,0.7921), vec2(0.8408,0.7628), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1386,1.1318,-0.8635), vec3(-0.067,1.2195,-0.8407), vec3(-0.1034,1.203,-0.9856), vec3(-0.7842,0.6071,0.1279), vec2(0.793,0.8396), vec2(0.7632,0.8768), vec2(0.8232,0.8921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0305,1.2385,-0.834), vec3(-0.0379,1.2724,-0.9711), vec3(-0.067,1.2195,-0.8407), vec3(-0.4817,0.8442,0.2349), vec2(0.752,0.8905), vec2(0.8032,0.9231), vec2(0.7632,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0412,1.2517,-0.8264), vec3(0.0391,1.2821,-0.9588), vec3(-0.0305,1.2385,-0.834), vec3(-0.2004,0.9542,0.2221), vec2(0.7329,0.9139), vec2(0.7847,0.9484), vec2(0.752,0.8905), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0636,0.7597,-0.8899), vec3(0.0235,0.7289,-0.8979), vec3(-0.0502,0.7035,-0.761), vec3(-0.341,-0.8742,-0.3456), vec2(0.9053,0.7095), vec2(0.9434,0.6992), vec2(0.897,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0636,0.7597,-0.8899), vec3(-0.1457,0.8339,-0.7521), vec3(-0.1326,0.8331,-0.8819), vec3(-0.7308,-0.679,-0.0702), vec2(0.9053,0.7095), vec2(0.8394,0.6953), vec2(0.8701,0.7329), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1626,0.9264,-0.8692), vec3(-0.1326,0.8331,-0.8819), vec3(-0.1729,0.923,-0.7467), vec3(-0.9516,-0.2946,-0.0879), vec2(0.8408,0.7628), vec2(0.8701,0.7329), vec2(0.813,0.7246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1595,1.0416,-0.8834), vec3(-0.1626,0.9264,-0.8692), vec3(-0.1839,1.0134,-0.732), vec3(-0.9874,0.0072,-0.1579), vec2(0.8188,0.809), vec2(0.8408,0.7628), vec2(0.7852,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1386,1.1318,-0.8635), vec3(-0.1595,1.0416,-0.8834), vec3(-0.163,1.1046,-0.7268), vec3(-0.9606,0.2498,-0.122), vec2(0.793,0.8396), vec2(0.8188,0.809), vec2(0.7583,0.7926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.067,1.2195,-0.8407), vec3(-0.1386,1.1318,-0.8635), vec3(-0.0915,1.1911,-0.7203), vec3(-0.7735,0.6337,-0.0081), vec2(0.7632,0.8768), vec2(0.793,0.8396), vec2(0.7261,0.8356), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1115,1.2341,-0.8373), vec3(0.1745,1.1829,-0.7263), vec3(0.1464,1.213,-0.8455), vec3(0.5314,0.8426,0.0869), vec2(0.752,0.8905), vec2(0.7261,0.8356), vec2(0.7632,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0636,0.7597,-0.8899), vec3(-0.0502,0.7035,-0.761), vec3(-0.1021,0.7528,-0.7565), vec3(-0.6803,-0.6952,-0.2322), vec2(0.9053,0.7095), vec2(0.897,0.6543), vec2(0.8691,0.6699), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1457,0.8339,-0.7521), vec3(-0.0636,0.7597,-0.8899), vec3(-0.1021,0.7528,-0.7565), vec3(-0.8539,-0.4453,-0.2693), vec2(0.8394,0.6953), vec2(0.9053,0.7095), vec2(0.8691,0.6699), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0305,1.2385,-0.834), vec3(-0.067,1.2195,-0.8407), vec3(-0.0915,1.1911,-0.7203), vec3(-0.4741,0.8736,0.1096), vec2(0.752,0.8905), vec2(0.7632,0.8768), vec2(0.7261,0.8356), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1115,1.2341,-0.8373), vec3(0.0412,1.2517,-0.8264), vec3(0.1116,1.2113,-0.719), vec3(0.2655,0.9467,0.1823), vec2(0.752,0.8905), vec2(0.7329,0.9139), vec2(0.708,0.8591), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1457,0.8339,-0.7521), vec3(-0.1729,0.923,-0.7467), vec3(-0.1326,0.8331,-0.8819), vec3(-0.9538,-0.2848,-0.0951), vec2(0.8394,0.6953), vec2(0.813,0.7246), vec2(0.8701,0.7329), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0305,1.2385,-0.834), vec3(-0.0266,1.2155,-0.7158), vec3(0.0412,1.2517,-0.8264), vec3(-0.1986,0.9609,0.1928), vec2(0.752,0.8905), vec2(0.708,0.8591), vec2(0.7329,0.9139), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1729,0.923,-0.7467), vec3(-0.1839,1.0134,-0.732), vec3(-0.1626,0.9264,-0.8692), vec3(-0.9905,-0.1071,-0.086), vec2(0.813,0.7246), vec2(0.7852,0.755), vec2(0.8408,0.7628), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.163,1.1046,-0.7268), vec3(-0.1595,1.0416,-0.8834), vec3(-0.1839,1.0134,-0.732), vec3(-0.967,0.2281,-0.1134), vec2(0.7583,0.7926), vec2(0.8188,0.809), vec2(0.7852,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.163,1.1046,-0.7268), vec3(-0.0915,1.1911,-0.7203), vec3(-0.1386,1.1318,-0.8635), vec3(-0.7702,0.6377,-0.0107), vec2(0.7583,0.7926), vec2(0.7261,0.8356), vec2(0.793,0.8396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1115,1.2341,-0.8373), vec3(0.1116,1.2113,-0.719), vec3(0.1745,1.1829,-0.7263), vec3(0.4214,0.8905,0.1715), vec2(0.752,0.8905), vec2(0.708,0.8591), vec2(0.7261,0.8356), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0915,1.1911,-0.7203), vec3(-0.0266,1.2155,-0.7158), vec3(-0.0305,1.2385,-0.834), vec3(-0.3577,0.9145,0.1891), vec2(0.7261,0.8356), vec2(0.708,0.8591), vec2(0.752,0.8905), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0431,1.2256,-0.7075), vec3(0.1116,1.2113,-0.719), vec3(0.0412,1.2517,-0.8264), vec3(0.2329,0.9506,0.2052), vec2(0.689,0.8833), vec2(0.708,0.8591), vec2(0.7329,0.9139), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0431,1.2256,-0.7075), vec3(0.0412,1.2517,-0.8264), vec3(-0.0266,1.2155,-0.7158), vec3(-0.1647,0.9628,0.2142), vec2(0.689,0.8833), vec2(0.7329,0.9139), vec2(0.708,0.8591), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1457,0.8339,-0.7521), vec3(-0.1021,0.7528,-0.7565), vec3(-0.1645,0.8068,-0.6892), vec3(-0.8088,-0.4129,-0.4188), vec2(0.8394,0.6953), vec2(0.8691,0.6699), vec2(0.8223,0.6716), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1729,0.923,-0.7467), vec3(-0.1457,0.8339,-0.7521), vec3(-0.1787,0.9141,-0.6864), vec3(-0.9502,-0.2814,-0.134), vec2(0.813,0.7246), vec2(0.8394,0.6953), vec2(0.7944,0.7068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1021,0.7528,-0.7565), vec3(-0.0502,0.7035,-0.761), vec3(-0.1552,0.6968,-0.6602), vec3(-0.5655,-0.5383,-0.6248), vec2(0.8691,0.6699), vec2(0.897,0.6543), vec2(0.8418,0.6313), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1729,0.923,-0.7467), vec3(-0.1787,0.9141,-0.6864), vec3(-0.1839,1.0134,-0.732), vec3(-0.9885,-0.1027,-0.1114), vec2(0.813,0.7246), vec2(0.7944,0.7068), vec2(0.7852,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1645,0.8068,-0.6892), vec3(-0.1787,0.9141,-0.6864), vec3(-0.1457,0.8339,-0.7521), vec3(-0.937,-0.116,-0.3294), vec2(0.8223,0.6716), vec2(0.7944,0.7068), vec2(0.8394,0.6953), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1552,0.6968,-0.6602), vec3(-0.1645,0.8068,-0.6892), vec3(-0.1021,0.7528,-0.7565), vec3(-0.7963,-0.2165,-0.5649), vec2(0.8418,0.6313), vec2(0.8223,0.6716), vec2(0.8691,0.6699), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.163,1.1046,-0.7268), vec3(-0.1839,1.0134,-0.732), vec3(-0.1917,0.9951,-0.6299), vec3(-0.9738,0.225,-0.0339), vec2(0.7583,0.7926), vec2(0.7852,0.755), vec2(0.7549,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.163,1.1046,-0.7268), vec3(-0.1921,1.1,-0.6186), vec3(-0.0915,1.1911,-0.7203), vec3(-0.7523,0.6351,-0.1752), vec2(0.7583,0.7926), vec2(0.7285,0.7654), vec2(0.7261,0.8356), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1917,0.9951,-0.6299), vec3(-0.1839,1.0134,-0.732), vec3(-0.1787,0.9141,-0.6864), vec3(-0.9912,-0.0942,-0.0925), vec2(0.7549,0.7261), vec2(0.7852,0.755), vec2(0.7944,0.7068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0915,1.1911,-0.7203), vec3(-0.1393,1.1856,-0.6081), vec3(-0.0266,1.2155,-0.7158), vec3(-0.3447,0.9333,-0.1011), vec2(0.7261,0.8356), vec2(0.6973,0.8024), vec2(0.708,0.8591), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1116,1.2113,-0.719), vec3(0.0431,1.2256,-0.7075), vec3(0.1437,1.218,-0.6105), vec3(0.1847,0.9761,-0.1146), vec2(0.708,0.8591), vec2(0.689,0.8833), vec2(0.6719,0.8322), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0266,1.2155,-0.7158), vec3(-0.0534,1.224,-0.606), vec3(0.0431,1.2256,-0.7075), vec3(-0.1295,0.9857,-0.1077), vec2(0.708,0.8591), vec2(0.6719,0.8322), vec2(0.689,0.8833), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.163,1.1046,-0.7268), vec3(-0.1917,0.9951,-0.6299), vec3(-0.1921,1.1,-0.6186), vec3(-0.9658,0.0245,-0.2583), vec2(0.7583,0.7926), vec2(0.7549,0.7261), vec2(0.7285,0.7654), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1393,1.1856,-0.6081), vec3(-0.0915,1.1911,-0.7203), vec3(-0.1921,1.1,-0.6186), vec3(-0.7913,0.526,-0.3116), vec2(0.6973,0.8024), vec2(0.7261,0.8356), vec2(0.7285,0.7654), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0534,1.224,-0.606), vec3(-0.0266,1.2155,-0.7158), vec3(-0.1393,1.1856,-0.6081), vec3(-0.3991,0.9016,-0.1669), vec2(0.6719,0.8322), vec2(0.708,0.8591), vec2(0.6973,0.8024), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0397,1.2314,-0.5995), vec3(0.1437,1.218,-0.6105), vec3(0.0431,1.2256,-0.7075), vec3(0.1232,0.9911,-0.0497), vec2(0.6499,0.8623), vec2(0.6719,0.8322), vec2(0.689,0.8833), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0431,1.2256,-0.7075), vec3(-0.0534,1.224,-0.606), vec3(0.0397,1.2314,-0.5995), vec3(-0.0753,0.9956,-0.056), vec2(0.689,0.8833), vec2(0.6719,0.8322), vec2(0.6499,0.8623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1917,0.9951,-0.6299), vec3(-0.2216,1.0497,-0.5036), vec3(-0.1921,1.1,-0.6186), vec3(-0.9706,0.0225,-0.2395), vec2(0.7549,0.7261), vec2(0.6914,0.731), vec2(0.7285,0.7654), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1921,1.1,-0.6186), vec3(-0.2216,1.0497,-0.5036), vec3(-0.1393,1.1856,-0.6081), vec3(-0.8518,0.5238,0.0106), vec2(0.7285,0.7654), vec2(0.6914,0.731), vec2(0.6973,0.8024), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0534,1.224,-0.606), vec3(-0.1393,1.1856,-0.6081), vec3(-0.1965,1.1708,-0.4782), vec3(-0.4056,0.911,-0.0749), vec2(0.6719,0.8322), vec2(0.6973,0.8024), vec2(0.6626,0.7659), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0534,1.224,-0.606), vec3(-0.1165,1.2459,-0.4606), vec3(0.0397,1.2314,-0.5995), vec3(-0.0658,0.9821,-0.1765), vec2(0.6719,0.8322), vec2(0.6309,0.8002), vec2(0.6499,0.8623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1965,1.1708,-0.4782), vec3(-0.1393,1.1856,-0.6081), vec3(-0.2216,1.0497,-0.5036), vec3(-0.8941,0.2619,-0.3633), vec2(0.6626,0.7659), vec2(0.6973,0.8024), vec2(0.6914,0.731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0534,1.224,-0.606), vec3(-0.1965,1.1708,-0.4782), vec3(-0.1165,1.2459,-0.4606), vec3(-0.5932,0.7173,-0.3654), vec2(0.6719,0.8322), vec2(0.6626,0.7659), vec2(0.6309,0.8002), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1165,1.2459,-0.4606), vec3(0.0774,1.258,-0.472), vec3(0.0397,1.2314,-0.5995), vec3(-0.072,0.9804,-0.1833), vec2(0.6309,0.8002), vec2(0.605,0.8419), vec2(0.6499,0.8623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1165,1.2459,-0.4606), vec3(-0.1183,1.2581,-0.2881), vec3(0.0774,1.258,-0.472), vec3(-0.0663,0.9953,-0.0709), vec2(0.6309,0.8002), vec2(0.5781,0.7605), vec2(0.605,0.8419), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.0247,0.9924,-1.2324), 0.4731, bestT)) {
        if (triHit(ro, rd, vec3(0.0203,0.9213,-1.305), vec3(0.0208,0.9417,-1.3068), vec3(0.0272,0.9213,-1.3039), vec3(0.1665,-0.0879,-0.9821), vec2(0.1787,0.4258), vec2(0.1682,0.4253), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0203,0.9213,-1.305), vec3(0.0134,0.9217,-1.3036), vec3(0.0208,0.9417,-1.3068), vec3(-0.2153,-0.0764,-0.9736), vec2(0.1787,0.4258), vec2(0.1788,0.4224), vec2(0.1682,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0339,0.938,-1.3024), vec3(0.0272,0.9213,-1.3039), vec3(0.0208,0.9417,-1.3068), vec3(0.3051,-0.0406,-0.9515), vec2(0.1709,0.4185), vec2(0.1788,0.4224), vec2(0.1682,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0077,0.9388,-1.3018), vec3(0.0208,0.9417,-1.3068), vec3(0.0134,0.9217,-1.3036), vec3(-0.3489,-0.0209,-0.9369), vec2(0.1709,0.4185), vec2(0.1682,0.4253), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0197,0.9007,-1.2988), vec3(0.0203,0.9213,-1.305), vec3(0.0272,0.9213,-1.3039), vec3(0.1585,-0.2903,-0.9437), vec2(0.1897,0.4253), vec2(0.1787,0.4258), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0134,0.9217,-1.3036), vec3(0.0203,0.9213,-1.305), vec3(0.0197,0.9007,-1.2988), vec3(-0.2183,-0.2785,-0.9353), vec2(0.1788,0.4224), vec2(0.1787,0.4258), vec2(0.1897,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0218,0.9721,-1.3035), vec3(0.0476,0.9715,-1.2942), vec3(0.0208,0.9417,-1.3068), vec3(0.3383,0.0907,-0.9366), vec2(0.1527,0.4214), vec2(0.1553,0.4082), vec2(0.1682,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0218,0.9721,-1.3035), vec3(0.0208,0.9417,-1.3068), vec3(-0.0035,0.9731,-1.2931), vec3(-0.374,0.1126,-0.9206), vec2(0.1527,0.4214), vec2(0.1682,0.4253), vec2(0.1553,0.4082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0339,0.938,-1.3024), vec3(0.0208,0.9417,-1.3068), vec3(0.0476,0.9715,-1.2942), vec3(0.3376,0.0915,-0.9368), vec2(0.1709,0.4185), vec2(0.1682,0.4253), vec2(0.1553,0.4082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0077,0.9388,-1.3018), vec3(-0.0035,0.9731,-1.2931), vec3(0.0208,0.9417,-1.3068), vec3(-0.3727,0.1137,-0.921), vec2(0.1709,0.4185), vec2(0.1553,0.4082), vec2(0.1682,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0306,0.9197,-1.2979), vec3(0.0197,0.9007,-1.2988), vec3(0.0272,0.9213,-1.3039), vec3(0.7471,-0.4002,-0.5307), vec2(0.1805,0.4194), vec2(0.1897,0.4253), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0366,0.9303,-1.2939), vec3(0.0272,0.9213,-1.3039), vec3(0.0339,0.938,-1.3024), vec3(0.8086,-0.2832,-0.5157), vec2(0.1758,0.4146), vec2(0.1788,0.4224), vec2(0.1709,0.4185), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0134,0.9217,-1.3036), vec3(0.0197,0.9007,-1.2988), vec3(0.0101,0.9204,-1.2974), vec3(-0.7938,-0.3527,-0.4955), vec2(0.1788,0.4224), vec2(0.1897,0.4253), vec2(0.1805,0.4194), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0049,0.9312,-1.2932), vec3(0.0077,0.9388,-1.3018), vec3(0.0134,0.9217,-1.3036), vec3(-0.8463,-0.2317,-0.4797), vec2(0.1758,0.4146), vec2(0.1709,0.4185), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0366,0.9303,-1.2939), vec3(0.0306,0.9197,-1.2979), vec3(0.0272,0.9213,-1.3039), vec3(0.8058,-0.2646,-0.5298), vec2(0.1758,0.4146), vec2(0.1805,0.4194), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0101,0.9204,-1.2974), vec3(0.0049,0.9312,-1.2932), vec3(0.0134,0.9217,-1.3036), vec3(-0.8433,-0.2153,-0.4924), vec2(0.1805,0.4194), vec2(0.1758,0.4146), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0197,0.9007,-1.2988), vec3(0.0306,0.9197,-1.2979), vec3(0.0207,0.9306,-1.2959), vec3(0.0899,-0.1,0.9909), vec2(0.1727,0.0288), vec2(0.1566,0.0337), vec2(0.1493,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0207,0.9306,-1.2959), vec3(0.0101,0.9204,-1.2974), vec3(0.0197,0.9007,-1.2988), vec3(-0.052,-0.0956,0.9941), vec2(0.1493,0.0254), vec2(0.1566,0.0337), vec2(0.1727,0.0288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0207,0.9306,-1.2959), vec3(0.0306,0.9197,-1.2979), vec3(0.0366,0.9303,-1.2939), vec3(-0.1216,-0.2854,0.9507), vec2(0.1493,0.0254), vec2(0.1566,0.0337), vec2(0.1471,0.0366), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0049,0.9312,-1.2932), vec3(0.0101,0.9204,-1.2974), vec3(0.0207,0.9306,-1.2959), vec3(0.1457,-0.2937,0.9447), vec2(0.1471,0.0366), vec2(0.1566,0.0337), vec2(0.1493,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0218,0.9721,-1.3035), vec3(0.0238,1.0227,-1.2882), vec3(0.0476,0.9715,-1.2942), vec3(0.3314,0.2613,-0.9066), vec2(0.1527,0.4214), vec2(0.1267,0.4126), vec2(0.1553,0.4082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0218,0.9721,-1.3035), vec3(-0.0035,0.9731,-1.2931), vec3(0.0238,1.0227,-1.2882), vec3(-0.3552,0.2826,-0.891), vec2(0.1527,0.4214), vec2(0.1553,0.4082), vec2(0.1267,0.4126), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0281,0.9189,-1.297), vec3(0.0204,0.9138,-1.2874), vec3(0.02,0.909,-1.2986), vec3(0.7281,-0.6393,0.2473), vec2(0.6035,0.0146), vec2(0.6035,0.02), vec2(0.5996,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0204,0.9138,-1.2874), vec3(0.0126,0.9194,-1.2967), vec3(0.02,0.909,-1.2986), vec3(-0.7534,-0.5941,0.2819), vec2(0.6035,0.02), vec2(0.6035,0.0146), vec2(0.5996,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0209,0.9278,-1.2833), vec3(0.0281,0.9189,-1.297), vec3(0.02,0.909,-1.2986), vec3(-0.5414,0.549,-0.6368), vec2(0.6738,0.0146), vec2(0.6675,0.0195), vec2(0.6631,0.0156), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.02,0.909,-1.2986), vec3(0.0126,0.9194,-1.2967), vec3(0.0209,0.9278,-1.2833), vec3(0.5444,0.5162,-0.6612), vec2(0.6631,0.0156), vec2(0.6675,0.0195), vec2(0.6738,0.0146), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0207,0.9306,-1.2959), vec3(0.0366,0.9303,-1.2939), vec3(0.0221,0.9685,-1.2872), vec3(-0.1224,-0.2162,0.9687), vec2(0.1493,0.0254), vec2(0.1471,0.0366), vec2(0.1191,0.02), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0207,0.9306,-1.2959), vec3(0.0221,0.9685,-1.2872), vec3(0.0049,0.9312,-1.2932), vec3(0.1515,-0.2246,0.9626), vec2(0.1493,0.0254), vec2(0.1191,0.02), vec2(0.1471,0.0366), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0353,0.9302,-1.2926), vec3(0.0267,0.9206,-1.2859), vec3(0.0281,0.9189,-1.297), vec3(0.7926,-0.5788,0.1916), vec2(0.6089,0.0132), vec2(0.6064,0.0181), vec2(0.6035,0.0146), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0126,0.9194,-1.2967), vec3(0.0147,0.9209,-1.2856), vec3(0.0063,0.9311,-1.292), vec3(-0.8173,-0.5292,0.2277), vec2(0.6035,0.0146), vec2(0.6064,0.0181), vec2(0.6089,0.0132), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0209,0.9278,-1.2833), vec3(0.0353,0.9302,-1.2926), vec3(0.0281,0.9189,-1.297), vec3(-0.5126,0.5745,-0.6381), vec2(0.6738,0.0146), vec2(0.6729,0.0225), vec2(0.6675,0.0195), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0495,1.1065,-1.2887), vec3(0.0264,1.1093,-1.2897), vec3(0.0549,1.1486,-1.2938), vec3(0.0301,-0.1251,-0.9917), vec2(0.9502,0.9297), vec2(0.9575,0.9365), vec2(0.9385,0.9414), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0126,0.9194,-1.2967), vec3(0.0063,0.9311,-1.292), vec3(0.0209,0.9278,-1.2833), vec3(0.5182,0.5425,-0.6612), vec2(0.6675,0.0195), vec2(0.6729,0.0225), vec2(0.6738,0.0146), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0553,0.9659,-1.2737), vec3(0.0339,0.938,-1.3024), vec3(0.0476,0.9715,-1.2942), vec3(0.8792,-0.2607,-0.3989), vec2(0.1602,0.3975), vec2(0.1709,0.4185), vec2(0.1553,0.4082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0267,0.9206,-1.2859), vec3(0.0204,0.9138,-1.2874), vec3(0.0281,0.9189,-1.297), vec3(0.6969,-0.69,0.1953), vec2(0.6064,0.0181), vec2(0.6035,0.02), vec2(0.6035,0.0146), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0366,0.9303,-1.2939), vec3(0.0339,0.938,-1.3024), vec3(0.0553,0.9659,-1.2737), vec3(0.8689,-0.1952,-0.4549), vec2(0.1758,0.4146), vec2(0.1709,0.4185), vec2(0.1602,0.3975), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0002,1.1503,-1.2926), vec3(0.0264,1.1093,-1.2897), vec3(0.0031,1.1079,-1.2876), vec3(-0.0826,-0.122,-0.9891), vec2(0.9385,0.9414), vec2(0.9575,0.9365), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0147,0.9209,-1.2856), vec3(0.0126,0.9194,-1.2967), vec3(0.0204,0.9138,-1.2874), vec3(-0.7271,-0.6479,0.2272), vec2(0.6064,0.0181), vec2(0.6035,0.0146), vec2(0.6035,0.02), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0077,0.9388,-1.3018), vec3(0.0049,0.9312,-1.2932), vec3(-0.0105,0.968,-1.2722), vec3(-0.8984,-0.1402,-0.4162), vec2(0.1709,0.4185), vec2(0.1758,0.4146), vec2(0.1602,0.3975), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0035,0.9731,-1.2931), vec3(0.0077,0.9388,-1.3018), vec3(-0.0105,0.968,-1.2722), vec3(-0.9104,-0.2061,-0.3587), vec2(0.1553,0.4082), vec2(0.1709,0.4185), vec2(0.1602,0.3975), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0264,1.1093,-1.2897), vec3(0.0495,1.1065,-1.2887), vec3(0.0256,1.0775,-1.2801), vec3(0.0085,-0.2916,-0.9565), vec2(0.9575,0.9365), vec2(0.9502,0.9297), vec2(0.9653,0.924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0264,1.1093,-1.2897), vec3(0.0256,1.0775,-1.2801), vec3(0.0031,1.1079,-1.2876), vec3(-0.0697,-0.2892,-0.9547), vec2(0.9575,0.9365), vec2(0.9653,0.924), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0267,0.9206,-1.2859), vec3(0.0353,0.9302,-1.2926), vec3(0.0345,0.9331,-1.2787), vec3(0.7887,-0.591,0.1693), vec2(0.6064,0.0181), vec2(0.6089,0.0132), vec2(0.6128,0.0171), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0063,0.9311,-1.292), vec3(0.0147,0.9209,-1.2856), vec3(0.008,0.9339,-1.2781), vec3(-0.8152,-0.5418,0.2049), vec2(0.6089,0.0132), vec2(0.6064,0.0181), vec2(0.6128,0.0171), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0616,1.0246,-1.2731), vec3(0.0476,0.9715,-1.2942), vec3(0.0238,1.0227,-1.2882), vec3(0.3441,0.2665,-0.9003), vec2(0.1293,0.3911), vec2(0.1553,0.4082), vec2(0.1267,0.4126), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0366,0.9303,-1.2939), vec3(0.0553,0.9659,-1.2737), vec3(0.0221,0.9685,-1.2872), vec3(-0.3806,-0.2981,0.8754), vec2(0.1471,0.0366), vec2(0.1133,0.0479), vec2(0.1191,0.02), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0132,1.0269,-1.2715), vec3(0.0238,1.0227,-1.2882), vec3(-0.0035,0.9731,-1.2931), vec3(-0.367,0.2884,-0.8844), vec2(0.1293,0.3911), vec2(0.1267,0.4126), vec2(0.1553,0.4082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0221,0.9685,-1.2872), vec3(-0.0105,0.968,-1.2722), vec3(0.0049,0.9312,-1.2932), vec3(0.4004,-0.3225,0.8577), vec2(0.1191,0.02), vec2(0.1133,0.0479), vec2(0.1471,0.0366), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0238,1.0227,-1.2882), vec3(0.0245,1.049,-1.2911), vec3(0.0616,1.0246,-1.2731), vec3(0.3713,-0.1135,-0.9215), vec2(0.1267,0.4126), vec2(0.1132,0.4111), vec2(0.1293,0.3911), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0238,1.0227,-1.2882), vec3(-0.0132,1.0269,-1.2715), vec3(0.0245,1.049,-1.2911), vec3(-0.4184,-0.0899,-0.9038), vec2(0.1267,0.4126), vec2(0.1293,0.3911), vec2(0.1132,0.4111), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0245,1.049,-1.2911), vec3(0.0256,1.0775,-1.2801), vec3(0.0466,1.0749,-1.2779), vec3(0.1392,0.3529,-0.9252), vec2(0.1132,0.4111), vec2(0.0977,0.4062), vec2(0.1012,0.396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0046,1.0762,-1.2769), vec3(0.0256,1.0775,-1.2801), vec3(0.0245,1.049,-1.2911), vec3(-0.1594,0.3621,-0.9184), vec2(0.1012,0.396), vec2(0.0977,0.4062), vec2(0.1132,0.4111), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0895,1.1007,-1.2792), vec3(0.0495,1.1065,-1.2887), vec3(0.1002,1.1412,-1.2791), vec3(0.2239,-0.0565,-0.973), vec2(0.939,0.9193), vec2(0.9502,0.9297), vec2(0.9277,0.9287), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0209,0.9278,-1.2833), vec3(0.0537,0.9659,-1.2709), vec3(0.0353,0.9302,-1.2926), vec3(-0.498,0.6231,-0.6032), vec2(0.6738,0.0146), vec2(0.6929,0.0283), vec2(0.6729,0.0225), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0466,1.0749,-1.2779), vec3(0.0256,1.0775,-1.2801), vec3(0.0495,1.1065,-1.2887), vec3(0.0578,-0.3283,-0.9428), vec2(0.959,0.9182), vec2(0.9653,0.924), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0895,1.1007,-1.2792), vec3(0.0466,1.0749,-1.2779), vec3(0.0495,1.1065,-1.2887), vec3(0.1726,-0.3335,-0.9268), vec2(0.939,0.9193), vec2(0.959,0.9182), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0245,1.049,-1.2911), vec3(0.0466,1.0749,-1.2779), vec3(0.0691,1.0453,-1.2758), vec3(0.3331,0.1871,-0.9241), vec2(0.1132,0.4111), vec2(0.1012,0.396), vec2(0.1183,0.3872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0209,0.9278,-1.2833), vec3(0.0063,0.9311,-1.292), vec3(-0.0088,0.9678,-1.2695), vec3(0.508,0.5922,-0.6255), vec2(0.6738,0.0146), vec2(0.6729,0.0225), vec2(0.6929,0.0283), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0031,1.1079,-1.2876), vec3(0.0256,1.0775,-1.2801), vec3(0.0046,1.0762,-1.2769), vec3(-0.121,-0.323,-0.9386), vec2(0.9502,0.9297), vec2(0.9653,0.924), vec2(0.959,0.9182), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0204,0.9138,-1.2874), vec3(0.0267,0.9206,-1.2859), vec3(0.0214,0.9337,-1.2711), vec3(0.4546,-0.5775,0.6781), vec2(0.6035,0.02), vec2(0.6064,0.0181), vec2(0.6133,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0214,0.9337,-1.2711), vec3(0.0147,0.9209,-1.2856), vec3(0.0204,0.9138,-1.2874), vec3(-0.4574,-0.5503,0.6985), vec2(0.6133,0.0229), vec2(0.6064,0.0181), vec2(0.6035,0.02), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0345,0.9331,-1.2787), vec3(0.0353,0.9302,-1.2926), vec3(0.0537,0.9659,-1.2709), vec3(0.8354,-0.5263,0.1587), vec2(0.6128,0.0171), vec2(0.6089,0.0132), vec2(0.627,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0245,1.049,-1.2911), vec3(-0.0195,1.048,-1.2738), vec3(0.0046,1.0762,-1.2769), vec3(-0.3622,0.2091,-0.9083), vec2(0.1132,0.4111), vec2(0.1183,0.3872), vec2(0.1012,0.396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0031,1.1079,-1.2876), vec3(0.0046,1.0762,-1.2769), vec3(-0.0366,1.1046,-1.2763), vec3(-0.2344,-0.3212,-0.9175), vec2(0.9502,0.9297), vec2(0.959,0.9182), vec2(0.939,0.9193), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0691,1.0453,-1.2758), vec3(0.0616,1.0246,-1.2731), vec3(0.0245,1.049,-1.2911), vec3(0.2999,-0.226,-0.9268), vec2(0.1183,0.3872), vec2(0.1293,0.3911), vec2(0.1132,0.4111), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0366,1.1046,-1.2763), vec3(-0.0447,1.1457,-1.2758), vec3(0.0031,1.1079,-1.2876), vec3(-0.2706,-0.0415,-0.9618), vec2(0.939,0.9193), vec2(0.9277,0.9287), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.008,0.9339,-1.2781), vec3(-0.0088,0.9678,-1.2695), vec3(0.0063,0.9311,-1.292), vec3(-0.8585,-0.4738,0.1962), vec2(0.6128,0.0171), vec2(0.627,0.0107), vec2(0.6089,0.0132), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0195,1.048,-1.2738), vec3(0.0245,1.049,-1.2911), vec3(-0.0132,1.0269,-1.2715), vec3(-0.3547,-0.2058,-0.9121), vec2(0.1183,0.3872), vec2(0.1132,0.4111), vec2(0.1293,0.3911), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0345,0.9331,-1.2787), vec3(0.0214,0.9337,-1.2711), vec3(0.0267,0.9206,-1.2859), vec3(0.3655,-0.6256,0.6892), vec2(0.6128,0.0171), vec2(0.6133,0.0229), vec2(0.6064,0.0181), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0147,0.9209,-1.2856), vec3(0.0214,0.9337,-1.2711), vec3(0.008,0.9339,-1.2781), vec3(-0.3719,-0.6031,0.7056), vec2(0.6064,0.0181), vec2(0.6133,0.0229), vec2(0.6128,0.0171), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0476,0.9715,-1.2942), vec3(0.0707,1.0118,-1.2608), vec3(0.0553,0.9659,-1.2737), vec3(0.9008,-0.1935,-0.3887), vec2(0.1553,0.4082), vec2(0.1375,0.3843), vec2(0.1602,0.3975), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0707,1.0118,-1.2608), vec3(0.0476,0.9715,-1.2942), vec3(0.0616,1.0246,-1.2731), vec3(0.8135,0.0159,-0.5814), vec2(0.1375,0.3843), vec2(0.1553,0.4082), vec2(0.1293,0.3911), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0035,0.9731,-1.2931), vec3(-0.0105,0.968,-1.2722), vec3(-0.0225,1.0147,-1.2588), vec3(-0.9275,-0.137,-0.3477), vec2(0.1553,0.4082), vec2(0.1602,0.3975), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0756,1.069,-1.2668), vec3(0.0466,1.0749,-1.2779), vec3(0.0895,1.1007,-1.2792), vec3(0.2396,-0.4422,-0.8643), vec2(0.9492,0.9088), vec2(0.959,0.9182), vec2(0.939,0.9193), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0132,1.0269,-1.2715), vec3(-0.0035,0.9731,-1.2931), vec3(-0.0225,1.0147,-1.2588), vec3(-0.836,0.067,-0.5446), vec2(0.1293,0.3911), vec2(0.1553,0.4082), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0756,1.069,-1.2668), vec3(0.0691,1.0453,-1.2758), vec3(0.0466,1.0749,-1.2779), vec3(0.3894,0.2321,-0.8914), vec2(0.1071,0.3804), vec2(0.1183,0.3872), vec2(0.1012,0.396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0221,0.9685,-1.2872), vec3(0.0553,0.9659,-1.2737), vec3(0.024,1.01,-1.2573), vec3(-0.3541,-0.5356,0.7666), vec2(0.1191,0.02), vec2(0.1133,0.0479), vec2(0.0786,0.0205), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0046,1.0762,-1.2769), vec3(-0.0241,1.072,-1.2646), vec3(-0.0366,1.1046,-1.2763), vec3(-0.3044,-0.4247,-0.8527), vec2(0.959,0.9182), vec2(0.9492,0.9088), vec2(0.939,0.9193), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0221,0.9685,-1.2872), vec3(0.024,1.01,-1.2573), vec3(-0.0105,0.968,-1.2722), vec3(0.3547,-0.5573,0.7507), vec2(0.1191,0.02), vec2(0.0786,0.0205), vec2(0.1133,0.0479), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0241,1.072,-1.2646), vec3(0.0046,1.0762,-1.2769), vec3(-0.0195,1.048,-1.2738), vec3(-0.4133,0.2567,-0.8736), vec2(0.1071,0.3804), vec2(0.1012,0.396), vec2(0.1183,0.3872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0209,0.9278,-1.2833), vec3(0.0222,0.9542,-1.2609), vec3(0.0537,0.9659,-1.2709), vec3(-0.4366,0.5939,-0.6757), vec2(0.6738,0.0146), vec2(0.6895,0.0127), vec2(0.6929,0.0283), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0088,0.9678,-1.2695), vec3(0.0222,0.9542,-1.2609), vec3(0.0209,0.9278,-1.2833), vec3(0.4415,0.5669,-0.6955), vec2(0.6929,0.0283), vec2(0.6895,0.0127), vec2(0.6738,0.0146), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0345,0.9331,-1.2787), vec3(0.0443,0.9615,-1.2604), vec3(0.0214,0.9337,-1.2711), vec3(0.3806,-0.5898,0.7122), vec2(0.6128,0.0171), vec2(0.627,0.0166), vec2(0.6133,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0443,0.9615,-1.2604), vec3(0.0345,0.9331,-1.2787), vec3(0.0537,0.9659,-1.2709), vec3(0.7318,-0.5297,0.4288), vec2(0.627,0.0166), vec2(0.6128,0.0171), vec2(0.627,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0214,0.9337,-1.2711), vec3(0.0007,0.9628,-1.2594), vec3(0.008,0.9339,-1.2781), vec3(-0.3838,-0.5663,0.7294), vec2(0.6133,0.0229), vec2(0.627,0.0166), vec2(0.6128,0.0171), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0088,0.9678,-1.2695), vec3(0.008,0.9339,-1.2781), vec3(0.0007,0.9628,-1.2594), vec3(-0.7435,-0.4842,0.4612), vec2(0.627,0.0107), vec2(0.6128,0.0171), vec2(0.627,0.0166), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0756,1.069,-1.2668), vec3(0.0835,1.0539,-1.2573), vec3(0.0691,1.0453,-1.2758), vec3(0.7841,0.0212,-0.6202), vec2(0.1071,0.3804), vec2(0.1159,0.375), vec2(0.1183,0.3872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0366,1.1046,-1.2763), vec3(-0.0634,1.116,-1.2473), vec3(-0.0447,1.1457,-1.2758), vec3(-0.7548,-0.1408,-0.6406), vec2(0.939,0.9193), vec2(0.9258,0.9136), vec2(0.9277,0.9287), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0616,1.0246,-1.2731), vec3(0.0691,1.0453,-1.2758), vec3(0.0827,1.035,-1.2462), vec3(0.7977,-0.3502,-0.4909), vec2(0.1293,0.3911), vec2(0.1183,0.3872), vec2(0.1272,0.3721), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0195,1.048,-1.2738), vec3(-0.0325,1.0575,-1.2547), vec3(-0.0241,1.072,-1.2646), vec3(-0.8084,0.0697,-0.5844), vec2(0.1183,0.3872), vec2(0.1159,0.375), vec2(0.1071,0.3804), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0132,1.0269,-1.2715), vec3(-0.0325,1.0385,-1.2436), vec3(-0.0195,1.048,-1.2738), vec3(-0.839,-0.2998,-0.4541), vec2(0.1293,0.3911), vec2(0.1272,0.3721), vec2(0.1183,0.3872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0756,1.069,-1.2668), vec3(0.0895,1.1007,-1.2792), vec3(0.1081,1.0805,-1.2418), vec3(0.631,-0.5064,-0.5877), vec2(0.9492,0.9088), vec2(0.939,0.9193), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0214,0.9337,-1.2711), vec3(0.0443,0.9615,-1.2604), vec3(0.0223,0.953,-1.2548), vec3(0.4086,-0.6026,0.6855), vec2(0.6133,0.0229), vec2(0.627,0.0166), vec2(0.623,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0223,0.953,-1.2548), vec3(0.0007,0.9628,-1.2594), vec3(0.0214,0.9337,-1.2711), vec3(-0.4137,-0.5774,0.7039), vec2(0.623,0.0254), vec2(0.627,0.0166), vec2(0.6133,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0708,0.9994,-1.2479), vec3(0.0553,0.9659,-1.2737), vec3(0.0707,1.0118,-1.2608), vec3(0.9376,-0.2458,-0.2458), vec2(0.1456,0.3794), vec2(0.1602,0.3975), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0707,1.0118,-1.2608), vec3(0.0616,1.0246,-1.2731), vec3(0.0827,1.035,-1.2462), vec3(0.7914,-0.028,-0.6106), vec2(0.1375,0.3843), vec2(0.1293,0.3911), vec2(0.1272,0.3721), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0835,1.0539,-1.2573), vec3(0.0827,1.035,-1.2462), vec3(0.0691,1.0453,-1.2758), vec3(0.814,-0.3168,-0.4868), vec2(0.1159,0.375), vec2(0.1272,0.3721), vec2(0.1183,0.3872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0366,1.1046,-1.2763), vec3(-0.0241,1.072,-1.2646), vec3(-0.0548,1.0855,-1.2381), vec3(-0.687,-0.4654,-0.558), vec2(0.939,0.9193), vec2(0.9492,0.9088), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0708,0.9994,-1.2479), vec3(0.024,1.01,-1.2573), vec3(0.0553,0.9659,-1.2737), vec3(-0.2787,-0.5016,0.819), vec2(0.0795,0.0581), vec2(0.0786,0.0205), vec2(0.1133,0.0479), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0228,1.0022,-1.2458), vec3(-0.0225,1.0147,-1.2588), vec3(-0.0105,0.968,-1.2722), vec3(-0.9611,-0.1871,-0.2033), vec2(0.1456,0.3794), vec2(0.1375,0.3843), vec2(0.1602,0.3975), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0105,0.968,-1.2722), vec3(0.024,1.01,-1.2573), vec3(-0.0228,1.0022,-1.2458), vec3(0.284,-0.5188,0.8064), vec2(0.1133,0.0479), vec2(0.0786,0.0205), vec2(0.0795,0.0581), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0325,1.0385,-1.2436), vec3(-0.0132,1.0269,-1.2715), vec3(-0.0225,1.0147,-1.2588), vec3(-0.8182,0.0223,-0.5745), vec2(0.1272,0.3721), vec2(0.1293,0.3911), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1182,1.1104,-1.2514), vec3(0.1081,1.0805,-1.2418), vec3(0.0895,1.1007,-1.2792), vec3(0.7009,-0.4205,-0.5762), vec2(0.9258,0.9136), vec2(0.9326,0.9033), vec2(0.939,0.9193), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0195,1.048,-1.2738), vec3(-0.0325,1.0385,-1.2436), vec3(-0.0325,1.0575,-1.2547), vec3(-0.8529,-0.266,-0.4493), vec2(0.1183,0.3872), vec2(0.1272,0.3721), vec2(0.1159,0.375), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0443,0.9615,-1.2604), vec3(0.0537,0.9659,-1.2709), vec3(0.0531,0.9893,-1.2384), vec3(0.724,-0.5535,0.4118), vec2(0.627,0.0166), vec2(0.627,0.0107), vec2(0.6416,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0088,0.9678,-1.2695), vec3(0.0007,0.9628,-1.2594), vec3(-0.0054,0.9911,-1.2371), vec3(-0.738,-0.508,0.4441), vec2(0.627,0.0107), vec2(0.627,0.0166), vec2(0.6416,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0835,1.0539,-1.2573), vec3(0.0756,1.069,-1.2668), vec3(0.1081,1.0805,-1.2418), vec3(0.6344,-0.1454,-0.7592), vec2(0.9487,0.9006), vec2(0.9492,0.9088), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0222,0.9542,-1.2609), vec3(0.0237,0.9823,-1.2333), vec3(0.0537,0.9659,-1.2709), vec3(-0.4394,0.6406,-0.6297), vec2(0.6895,0.0127), vec2(0.7075,0.0103), vec2(0.6929,0.0283), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0222,0.9542,-1.2609), vec3(-0.0088,0.9678,-1.2695), vec3(0.0237,0.9823,-1.2333), vec3(0.4492,0.6133,-0.6497), vec2(0.6895,0.0127), vec2(0.6929,0.0283), vec2(0.7075,0.0103), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0634,1.116,-1.2473), vec3(-0.0366,1.1046,-1.2763), vec3(-0.0548,1.0855,-1.2381), vec3(-0.7503,-0.3762,-0.5436), vec2(0.9258,0.9136), vec2(0.939,0.9193), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0325,1.0575,-1.2547), vec3(-0.0548,1.0855,-1.2381), vec3(-0.0241,1.072,-1.2646), vec3(-0.676,-0.1052,-0.7294), vec2(0.9487,0.9006), vec2(0.9326,0.9033), vec2(0.9492,0.9088), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0531,0.9893,-1.2384), vec3(0.0537,0.9659,-1.2709), vec3(0.0669,0.9981,-1.2461), vec3(0.6431,-0.6158,0.4553), vec2(0.6416,0.0176), vec2(0.627,0.0107), vec2(0.644,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0054,0.9911,-1.2371), vec3(-0.0189,1.0007,-1.2442), vec3(-0.0088,0.9678,-1.2695), vec3(-0.6592,-0.5754,0.4842), vec2(0.6416,0.0176), vec2(0.644,0.0107), vec2(0.627,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0223,0.953,-1.2548), vec3(0.0443,0.9615,-1.2604), vec3(0.0234,0.9737,-1.2352), vec3(0.413,-0.6369,0.651), vec2(0.623,0.0254), vec2(0.627,0.0166), vec2(0.6338,0.0288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0669,0.9981,-1.2461), vec3(0.0537,0.9659,-1.2709), vec3(0.0237,0.9823,-1.2333), vec3(-0.4243,0.6559,-0.6244), vec2(0.7124,0.0312), vec2(0.6929,0.0283), vec2(0.7075,0.0103), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0223,0.953,-1.2548), vec3(0.0234,0.9737,-1.2352), vec3(0.0007,0.9628,-1.2594), vec3(-0.4216,-0.6107,0.6703), vec2(0.623,0.0254), vec2(0.6338,0.0288), vec2(0.627,0.0166), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0189,1.0007,-1.2442), vec3(0.0237,0.9823,-1.2333), vec3(-0.0088,0.9678,-1.2695), vec3(0.4354,0.6294,-0.6437), vec2(0.7124,0.0312), vec2(0.7075,0.0103), vec2(0.6929,0.0283), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.024,1.01,-1.2573), vec3(0.0708,0.9994,-1.2479), vec3(0.025,1.0288,-1.2381), vec3(-0.2901,-0.6767,0.6767), vec2(0.0786,0.0205), vec2(0.0795,0.0581), vec2(0.0575,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.024,1.01,-1.2573), vec3(0.025,1.0288,-1.2381), vec3(-0.0228,1.0022,-1.2458), vec3(0.2782,-0.6941,0.6639), vec2(0.0786,0.0205), vec2(0.0575,0.0215), vec2(0.0795,0.0581), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0708,0.9994,-1.2479), vec3(0.0707,1.0118,-1.2608), vec3(0.0777,1.0163,-1.2308), vec3(0.9612,-0.194,-0.1961), vec2(0.1456,0.3794), vec2(0.1375,0.3843), vec2(0.1392,0.3677), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0827,1.035,-1.2462), vec3(0.0777,1.0163,-1.2308), vec3(0.0707,1.0118,-1.2608), vec3(0.9127,-0.377,-0.1573), vec2(0.1272,0.3721), vec2(0.1392,0.3677), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0531,0.9893,-1.2384), vec3(0.0234,0.9737,-1.2352), vec3(0.0443,0.9615,-1.2604), vec3(0.4082,-0.6416,0.6494), vec2(0.6416,0.0176), vec2(0.6338,0.0288), vec2(0.627,0.0166), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0228,1.0022,-1.2458), vec3(-0.0279,1.0196,-1.2284), vec3(-0.0225,1.0147,-1.2588), vec3(-0.9792,-0.1338,-0.1524), vec2(0.1456,0.3794), vec2(0.1392,0.3677), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0054,0.9911,-1.2371), vec3(0.0007,0.9628,-1.2594), vec3(0.0234,0.9737,-1.2352), vec3(-0.4167,-0.6162,0.6683), vec2(0.6416,0.0176), vec2(0.627,0.0166), vec2(0.6338,0.0288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0325,1.0385,-1.2436), vec3(-0.0225,1.0147,-1.2588), vec3(-0.0279,1.0196,-1.2284), vec3(-0.9403,-0.3201,-0.1157), vec2(0.1272,0.3721), vec2(0.1375,0.3843), vec2(0.1392,0.3677), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0827,1.035,-1.2462), vec3(0.0835,1.0539,-1.2573), vec3(0.1083,1.0581,-1.2222), vec3(0.7877,-0.3338,-0.5177), vec2(0.9507,0.8915), vec2(0.9487,0.9006), vec2(0.9331,0.8916), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1081,1.0805,-1.2418), vec3(0.1083,1.0581,-1.2222), vec3(0.0835,1.0539,-1.2573), vec3(0.7633,-0.421,-0.49), vec2(0.9326,0.9033), vec2(0.9331,0.8916), vec2(0.9487,0.9006), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0325,1.0385,-1.2436), vec3(-0.0555,1.0631,-1.2185), vec3(-0.0325,1.0575,-1.2547), vec3(-0.8292,-0.2844,-0.4813), vec2(0.9507,0.8915), vec2(0.9331,0.8916), vec2(0.9487,0.9006), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0777,1.0163,-1.2308), vec3(0.025,1.0288,-1.2381), vec3(0.0708,0.9994,-1.2479), vec3(-0.2521,-0.6353,0.73), vec2(0.0604,0.0635), vec2(0.0575,0.0215), vec2(0.0795,0.0581), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0228,1.0022,-1.2458), vec3(0.025,1.0288,-1.2381), vec3(-0.0279,1.0196,-1.2284), vec3(0.2453,-0.6507,0.7186), vec2(0.0795,0.0581), vec2(0.0575,0.0215), vec2(0.0604,0.0635), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0548,1.0855,-1.2381), vec3(-0.0325,1.0575,-1.2547), vec3(-0.0555,1.0631,-1.2185), vec3(-0.8091,-0.3722,-0.4547), vec2(0.9326,0.9033), vec2(0.9487,0.9006), vec2(0.9331,0.8916), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0777,1.0163,-1.2308), vec3(0.0669,0.9981,-1.2461), vec3(0.0237,0.9823,-1.2333), vec3(-0.4252,0.7162,-0.5534), vec2(0.7241,0.0342), vec2(0.7124,0.0312), vec2(0.7075,0.0103), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0189,1.0007,-1.2442), vec3(-0.0279,1.0196,-1.2284), vec3(0.0237,0.9823,-1.2333), vec3(0.4432,0.6897,-0.5726), vec2(0.7124,0.0312), vec2(0.7241,0.0342), vec2(0.7075,0.0103), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0531,0.9893,-1.2384), vec3(0.0669,0.9981,-1.2461), vec3(0.059,0.9946,-1.2196), vec3(0.5568,-0.8288,0.0561), vec2(0.6416,0.0176), vec2(0.644,0.0107), vec2(0.6494,0.0205), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0054,0.9911,-1.2371), vec3(-0.0101,0.9967,-1.2181), vec3(-0.0189,1.0007,-1.2442), vec3(-0.6043,-0.7924,0.0826), vec2(0.6416,0.0176), vec2(0.6494,0.0205), vec2(0.644,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0827,1.035,-1.2462), vec3(0.1083,1.0581,-1.2222), vec3(0.0777,1.0163,-1.2308), vec3(0.7876,-0.5053,-0.3525), vec2(0.9507,0.8915), vec2(0.9331,0.8916), vec2(0.9521,0.8813), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0669,0.9981,-1.2461), vec3(0.0777,1.0163,-1.2308), vec3(0.059,0.9946,-1.2196), vec3(0.7877,-0.596,0.1561), vec2(0.644,0.0107), vec2(0.6543,0.0088), vec2(0.6494,0.0205), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0101,0.9967,-1.2181), vec3(-0.0279,1.0196,-1.2284), vec3(-0.0189,1.0007,-1.2442), vec3(-0.8147,-0.5472,0.1918), vec2(0.6494,0.0205), vec2(0.6543,0.0088), vec2(0.644,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0325,1.0385,-1.2436), vec3(-0.0279,1.0196,-1.2284), vec3(-0.0555,1.0631,-1.2185), vec3(-0.8322,-0.4553,-0.3164), vec2(0.9507,0.8915), vec2(0.9521,0.8813), vec2(0.9331,0.8916), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0234,0.9737,-1.2352), vec3(0.0531,0.9893,-1.2384), vec3(0.0242,0.9836,-1.2161), vec3(0.461,-0.7959,0.3926), vec2(0.6338,0.0288), vec2(0.6416,0.0176), vec2(0.6411,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0234,0.9737,-1.2352), vec3(0.0242,0.9836,-1.2161), vec3(-0.0054,0.9911,-1.2371), vec3(-0.4905,-0.7671,0.4135), vec2(0.6338,0.0288), vec2(0.6411,0.0327), vec2(0.6416,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.059,0.9946,-1.2196), vec3(0.0242,0.9836,-1.2161), vec3(0.0531,0.9893,-1.2384), vec3(0.3115,-0.9361,0.1633), vec2(0.6494,0.0205), vec2(0.6411,0.0327), vec2(0.6416,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0054,0.9911,-1.2371), vec3(0.0242,0.9836,-1.2161), vec3(-0.0101,0.9967,-1.2181), vec3(-0.361,-0.9152,0.179), vec2(0.6416,0.0176), vec2(0.6411,0.0327), vec2(0.6494,0.0205), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0237,0.9823,-1.2333), vec3(0.0255,1.0146,-1.2005), vec3(0.0777,1.0163,-1.2308), vec3(-0.3903,0.6668,-0.6348), vec2(0.7075,0.0103), vec2(0.728,0.0068), vec2(0.7241,0.0342), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0268,1.0537,-1.1946), vec3(0.025,1.0288,-1.2381), vec3(0.0777,1.0163,-1.2308), vec3(-0.2647,-0.8325,0.4867), vec2(0.0181,0.0254), vec2(0.0575,0.0215), vec2(0.0604,0.0635), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0237,0.9823,-1.2333), vec3(-0.0279,1.0196,-1.2284), vec3(0.0255,1.0146,-1.2005), vec3(0.4014,0.6423,-0.6529), vec2(0.7075,0.0103), vec2(0.7241,0.0342), vec2(0.728,0.0068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0279,1.0196,-1.2284), vec3(0.025,1.0288,-1.2381), vec3(0.0268,1.0537,-1.1946), vec3(0.2349,-0.8479,0.4754), vec2(0.0604,0.0635), vec2(0.0575,0.0215), vec2(0.0181,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1083,1.0581,-1.2222), vec3(0.1081,1.0805,-1.2418), vec3(0.1311,1.0655,-1.1875), vec3(0.8069,-0.3845,-0.4484), vec2(0.9331,0.8916), vec2(0.9326,0.9033), vec2(0.918,0.8853), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0555,1.0631,-1.2185), vec3(-0.0762,1.0718,-1.1828), vec3(-0.0548,1.0855,-1.2381), vec3(-0.8487,-0.3328,-0.411), vec2(0.9331,0.8916), vec2(0.918,0.8853), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1164,1.0297,-1.1856), vec3(0.0777,1.0163,-1.2308), vec3(0.1083,1.0581,-1.2222), vec3(0.7423,-0.4411,-0.5044), vec2(0.9282,0.8737), vec2(0.9521,0.8813), vec2(0.9331,0.8916), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0777,1.0163,-1.2308), vec3(0.1164,1.0297,-1.1856), vec3(0.059,0.9946,-1.2196), vec3(0.6278,-0.706,-0.3276), vec2(0.9521,0.8813), vec2(0.9282,0.8737), vec2(0.9595,0.8706), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0636,1.0353,-1.1816), vec3(-0.0555,1.0631,-1.2185), vec3(-0.0279,1.0196,-1.2284), vec3(-0.79,-0.394,-0.4697), vec2(0.9282,0.8737), vec2(0.9331,0.8916), vec2(0.9521,0.8813), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0101,0.9967,-1.2181), vec3(-0.0636,1.0353,-1.1816), vec3(-0.0279,1.0196,-1.2284), vec3(-0.6839,-0.6661,-0.2976), vec2(0.9595,0.8706), vec2(0.9282,0.8737), vec2(0.9521,0.8813), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0268,1.0537,-1.1946), vec3(0.0777,1.0163,-1.2308), vec3(0.0255,1.0146,-1.2005), vec3(-0.4998,0.1461,-0.8538), vec2(0.7461,0.0093), vec2(0.7241,0.0342), vec2(0.728,0.0068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0255,1.0146,-1.2005), vec3(-0.0279,1.0196,-1.2284), vec3(0.0268,1.0537,-1.1946), vec3(0.4688,0.1168,-0.8756), vec2(0.728,0.0068), vec2(0.7241,0.0342), vec2(0.7461,0.0093), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0242,0.9836,-1.2161), vec3(0.059,0.9946,-1.2196), vec3(0.025,0.9843,-1.1811), vec3(0.3014,-0.9534,0.0119), vec2(0.9727,0.8625), vec2(0.9595,0.8706), vec2(0.9663,0.8491), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0242,0.9836,-1.2161), vec3(0.025,0.9843,-1.1811), vec3(-0.0101,0.9967,-1.2181), vec3(-0.3588,-0.933,0.0269), vec2(0.9727,0.8625), vec2(0.9663,0.8491), vec2(0.9595,0.8706), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0869,1.1306,-1.1897), vec3(-0.0548,1.0855,-1.2381), vec3(-0.0762,1.0718,-1.1828), vec3(-0.8935,-0.2088,-0.3977), vec2(0.9058,0.9043), vec2(0.9326,0.9033), vec2(0.918,0.8853), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1083,1.0581,-1.2222), vec3(0.1311,1.0655,-1.1875), vec3(0.1164,1.0297,-1.1856), vec3(0.813,-0.3603,-0.4575), vec2(0.9331,0.8916), vec2(0.918,0.8853), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0683,0.9912,-1.1866), vec3(0.059,0.9946,-1.2196), vec3(0.1164,1.0297,-1.1856), vec3(0.6094,-0.753,-0.2481), vec2(0.9502,0.8593), vec2(0.9595,0.8706), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0683,0.9912,-1.1866), vec3(0.025,0.9843,-1.1811), vec3(0.059,0.9946,-1.2196), vec3(0.138,-0.9805,-0.1396), vec2(0.9502,0.8593), vec2(0.9663,0.8491), vec2(0.9595,0.8706), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0101,0.9967,-1.2181), vec3(-0.018,0.9938,-1.1847), vec3(-0.0636,1.0353,-1.1816), vec3(-0.6653,-0.7134,-0.2202), vec2(0.9595,0.8706), vec2(0.9502,0.8593), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.018,0.9938,-1.1847), vec3(-0.0101,0.9967,-1.2181), vec3(0.025,0.9843,-1.1811), vec3(-0.2036,-0.97,-0.1326), vec2(0.9502,0.8593), vec2(0.9595,0.8706), vec2(0.9663,0.8491), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0636,1.0353,-1.1816), vec3(-0.0762,1.0718,-1.1828), vec3(-0.0555,1.0631,-1.2185), vec3(-0.8535,-0.309,-0.4196), vec2(0.9282,0.8737), vec2(0.918,0.8853), vec2(0.9331,0.8916), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0702,0.9749,-1.1466), vec3(0.0683,0.9912,-1.1866), vec3(0.1164,1.0297,-1.1856), vec3(0.5954,-0.7334,-0.3281), vec2(0.9424,0.8424), vec2(0.9502,0.8593), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0683,0.9912,-1.1866), vec3(0.0702,0.9749,-1.1466), vec3(0.025,0.9843,-1.1811), vec3(0.098,-0.9199,-0.3796), vec2(0.9502,0.8593), vec2(0.9424,0.8424), vec2(0.9663,0.8491), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.018,0.9938,-1.1847), vec3(-0.0192,0.9776,-1.1446), vec3(-0.0636,1.0353,-1.1816), vec3(-0.6537,-0.6948,-0.2997), vec2(0.9502,0.8593), vec2(0.9424,0.8424), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.018,0.9938,-1.1847), vec3(0.025,0.9843,-1.1811), vec3(-0.0192,0.9776,-1.1446), vec3(-0.1709,-0.9117,-0.3735), vec2(0.9502,0.8593), vec2(0.9663,0.8491), vec2(0.9424,0.8424), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1164,1.0297,-1.1856), vec3(0.1311,1.0655,-1.1875), vec3(0.155,1.0506,-1.1183), vec3(0.8504,-0.3714,-0.3726), vec2(0.9282,0.8737), vec2(0.918,0.8853), vec2(0.8975,0.8658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0978,1.0584,-1.1126), vec3(-0.0762,1.0718,-1.1828), vec3(-0.0636,1.0353,-1.1816), vec3(-0.8875,-0.3179,-0.3335), vec2(0.8975,0.8658), vec2(0.918,0.8853), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0253,0.9655,-1.1402), vec3(0.025,0.9843,-1.1811), vec3(0.0702,0.9749,-1.1466), vec3(0.1287,-0.9008,-0.4147), vec2(0.959,0.832), vec2(0.9663,0.8491), vec2(0.9424,0.8424), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1164,1.0297,-1.1856), vec3(0.1162,0.999,-1.1352), vec3(0.0702,0.9749,-1.1466), vec3(0.4993,-0.7399,-0.4507), vec2(0.9282,0.8737), vec2(0.9214,0.851), vec2(0.9424,0.8424), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0253,0.9655,-1.1402), vec3(-0.0192,0.9776,-1.1446), vec3(0.025,0.9843,-1.1811), vec3(-0.202,-0.8906,-0.4074), vec2(0.959,0.832), vec2(0.9424,0.8424), vec2(0.9663,0.8491), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0636,1.0353,-1.1816), vec3(-0.0192,0.9776,-1.1446), vec3(-0.0631,1.0045,-1.1311), vec3(-0.5637,-0.7071,-0.4268), vec2(0.9282,0.8737), vec2(0.9424,0.8424), vec2(0.9214,0.851), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1164,1.0297,-1.1856), vec3(0.155,1.0506,-1.1183), vec3(0.1162,0.999,-1.1352), vec3(0.8071,-0.5047,-0.3063), vec2(0.9282,0.8737), vec2(0.8975,0.8658), vec2(0.9214,0.851), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0631,1.0045,-1.1311), vec3(-0.0978,1.0584,-1.1126), vec3(-0.0636,1.0353,-1.1816), vec3(-0.8496,-0.4535,-0.2691), vec2(0.9214,0.851), vec2(0.8975,0.8658), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0253,0.9655,-1.1402), vec3(0.0702,0.9749,-1.1466), vec3(0.0643,0.9578,-1.12), vec3(0.1026,-0.8474,-0.5209), vec2(0.959,0.832), vec2(0.9424,0.8424), vec2(0.9409,0.829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0131,0.9602,-1.1182), vec3(-0.0192,0.9776,-1.1446), vec3(0.0253,0.9655,-1.1402), vec3(-0.1777,-0.8393,-0.5138), vec2(0.9409,0.829), vec2(0.9424,0.8424), vec2(0.959,0.832), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0702,0.9749,-1.1466), vec3(0.1162,0.999,-1.1352), vec3(0.0643,0.9578,-1.12), vec3(0.5013,-0.7747,-0.3853), vec2(0.9424,0.8424), vec2(0.9214,0.851), vec2(0.9409,0.829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0192,0.9776,-1.1446), vec3(-0.0131,0.9602,-1.1182), vec3(-0.0631,1.0045,-1.1311), vec3(-0.5649,-0.7422,-0.3606), vec2(0.9424,0.8424), vec2(0.9409,0.829), vec2(0.9214,0.851), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1113,0.9767,-1.1011), vec3(0.0643,0.9578,-1.12), vec3(0.1162,0.999,-1.1352), vec3(0.4807,-0.7649,-0.4288), vec2(0.9175,0.8345), vec2(0.9409,0.829), vec2(0.9214,0.851), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1113,0.9767,-1.1011), vec3(0.1162,0.999,-1.1352), vec3(0.155,1.0506,-1.1183), vec3(0.8134,-0.5344,-0.2298), vec2(0.9175,0.8345), vec2(0.9214,0.851), vec2(0.8975,0.8658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0579,0.9819,-1.0973), vec3(-0.0631,1.0045,-1.1311), vec3(-0.0131,0.9602,-1.1182), vec3(-0.5454,-0.7334,-0.4057), vec2(0.9175,0.8345), vec2(0.9214,0.851), vec2(0.9409,0.829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0631,1.0045,-1.1311), vec3(-0.0579,0.9819,-1.0973), vec3(-0.0978,1.0584,-1.1126), vec3(-0.8543,-0.4831,-0.1919), vec2(0.9214,0.851), vec2(0.9175,0.8345), vec2(0.8975,0.8658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0253,0.9655,-1.1402), vec3(0.0643,0.9578,-1.12), vec3(0.0251,0.9086,-1.0737), vec3(0.1838,-0.7471,-0.6388), vec2(0.959,0.832), vec2(0.9409,0.829), vec2(0.9512,0.7986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0251,0.9086,-1.0737), vec3(-0.0131,0.9602,-1.1182), vec3(0.0253,0.9655,-1.1402), vec3(-0.2582,-0.7335,-0.6287), vec2(0.9512,0.7986), vec2(0.9409,0.829), vec2(0.959,0.832), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1113,0.9767,-1.1011), vec3(0.108,0.9282,-1.0556), vec3(0.0643,0.9578,-1.12), vec3(0.4947,-0.6118,-0.6173), vec2(0.9175,0.8345), vec2(0.9146,0.807), vec2(0.9409,0.829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1113,0.9767,-1.1011), vec3(0.155,1.0506,-1.1183), vec3(0.1718,1.0291,-1.0517), vec3(0.7617,-0.5353,-0.3651), vec2(0.9175,0.8345), vec2(0.8975,0.8658), vec2(0.8789,0.8451), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0579,0.9819,-1.0973), vec3(-0.0131,0.9602,-1.1182), vec3(-0.0556,0.9332,-1.0519), vec3(-0.5585,-0.5796,-0.5935), vec2(0.9175,0.8345), vec2(0.9409,0.829), vec2(0.9146,0.807), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1129,1.0379,-1.0453), vec3(-0.0978,1.0584,-1.1126), vec3(-0.0579,0.9819,-1.0973), vec3(-0.8088,-0.487,-0.3297), vec2(0.8789,0.8451), vec2(0.8975,0.8658), vec2(0.9175,0.8345), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0251,0.9086,-1.0737), vec3(0.0643,0.9578,-1.12), vec3(0.108,0.9282,-1.0556), vec3(0.3043,-0.77,-0.5608), vec2(0.9512,0.7986), vec2(0.9409,0.829), vec2(0.9146,0.807), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0251,0.9086,-1.0737), vec3(-0.0556,0.9332,-1.0519), vec3(-0.0131,0.9602,-1.1182), vec3(-0.376,-0.749,-0.5456), vec2(0.9512,0.7986), vec2(0.9146,0.807), vec2(0.9409,0.829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.108,0.9282,-1.0556), vec3(0.1113,0.9767,-1.1011), vec3(0.1818,1.0009,-1.0046), vec3(0.7654,-0.4667,-0.4431), vec2(0.9146,0.807), vec2(0.9175,0.8345), vec2(0.8682,0.8246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1818,1.0009,-1.0046), vec3(0.1113,0.9767,-1.1011), vec3(0.1718,1.0291,-1.0517), vec3(0.7656,-0.4661,-0.4434), vec2(0.8682,0.8246), vec2(0.9175,0.8345), vec2(0.8789,0.8451), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0556,0.9332,-1.0519), vec3(-0.1225,1.0103,-0.9978), vec3(-0.0579,0.9819,-1.0973), vec3(-0.8118,-0.4183,-0.4074), vec2(0.9146,0.807), vec2(0.8682,0.8246), vec2(0.9175,0.8345), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1129,1.0379,-1.0453), vec3(-0.0579,0.9819,-1.0973), vec3(-0.1225,1.0103,-0.9978), vec3(-0.812,-0.4177,-0.4077), vec2(0.8789,0.8451), vec2(0.9175,0.8345), vec2(0.8682,0.8246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0251,0.9086,-1.0737), vec3(0.108,0.9282,-1.0556), vec3(0.107,0.8724,-1.0033), vec3(0.3056,-0.6544,-0.6917), vec2(0.9512,0.7986), vec2(0.9146,0.807), vec2(0.9111,0.7754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0557,0.8774,-0.9996), vec3(-0.0556,0.9332,-1.0519), vec3(0.0251,0.9086,-1.0737), vec3(-0.3761,-0.6331,-0.6765), vec2(0.9111,0.7754), vec2(0.9146,0.807), vec2(0.9512,0.7986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0251,0.9086,-1.0737), vec3(0.107,0.8724,-1.0033), vec3(0.0246,0.8546,-1.0211), vec3(0.2919,-0.6692,-0.6833), vec2(0.9512,0.7986), vec2(0.9111,0.7754), vec2(0.9473,0.7694), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0246,0.8546,-1.0211), vec3(-0.0557,0.8774,-0.9996), vec3(0.0251,0.9086,-1.0737), vec3(-0.3627,-0.6491,-0.6687), vec2(0.9473,0.7694), vec2(0.9111,0.7754), vec2(0.9512,0.7986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.108,0.9282,-1.0556), vec3(0.1818,1.0009,-1.0046), vec3(0.1948,0.9499,-0.9448), vec3(0.7556,-0.4084,-0.512), vec2(0.9146,0.807), vec2(0.8682,0.8246), vec2(0.8579,0.7921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.107,0.8724,-1.0033), vec3(0.108,0.9282,-1.0556), vec3(0.1948,0.9499,-0.9448), vec3(0.7376,-0.4688,-0.486), vec2(0.9111,0.7754), vec2(0.9146,0.807), vec2(0.8579,0.7921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.107,0.8724,-1.0033), vec3(0.1126,0.7543,-0.8939), vec3(0.0246,0.8546,-1.0211), vec3(0.2916,-0.6426,-0.7086), vec2(0.9111,0.7754), vec2(0.9053,0.7095), vec2(0.9473,0.7694), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.0447,1.1818,-1.1423), 0.3943, bestT)) {
        if (triHit(ro, rd, vec3(0.0276,1.1524,-1.293), vec3(0.0549,1.1486,-1.2938), vec3(0.0264,1.1093,-1.2897), vec3(-0.0418,-0.0735,-0.9964), vec2(0.9448,0.9506), vec2(0.9385,0.9414), vec2(0.9575,0.9365), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0276,1.1524,-1.293), vec3(0.0264,1.1093,-1.2897), vec3(0.0002,1.1503,-1.2926), vec3(-0.0073,-0.0746,-0.9972), vec2(0.9448,0.9506), vec2(0.9575,0.9365), vec2(0.9385,0.9414), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0549,1.1486,-1.2938), vec3(0.0276,1.1524,-1.293), vec3(0.0616,1.2017,-1.2761), vec3(0.0137,0.3149,-0.949), vec2(0.9385,0.9414), vec2(0.9448,0.9506), vec2(0.9199,0.9523), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0549,1.1486,-1.2938), vec3(0.1002,1.1412,-1.2791), vec3(0.0495,1.1065,-1.2887), vec3(0.2843,-0.1517,-0.9467), vec2(0.9385,0.9414), vec2(0.9277,0.9287), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0025,1.2037,-1.2747), vec3(0.0276,1.1524,-1.293), vec3(0.0002,1.1503,-1.2926), vec3(-0.0368,0.3169,-0.9477), vec2(0.9199,0.9523), vec2(0.9448,0.9506), vec2(0.9385,0.9414), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0002,1.1503,-1.2926), vec3(0.0031,1.1079,-1.2876), vec3(-0.0447,1.1457,-1.2758), vec3(-0.3355,-0.133,-0.9326), vec2(0.9385,0.9414), vec2(0.9502,0.9297), vec2(0.9277,0.9287), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0297,1.2063,-1.2753), vec3(0.0616,1.2017,-1.2761), vec3(0.0276,1.1524,-1.293), vec3(0.0192,0.3114,-0.9501), vec2(0.9238,0.9641), vec2(0.9199,0.9523), vec2(0.9448,0.9506), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0297,1.2063,-1.2753), vec3(0.0276,1.1524,-1.293), vec3(-0.0025,1.2037,-1.2747), vec3(-0.0434,0.3134,-0.9486), vec2(0.9238,0.9641), vec2(0.9448,0.9506), vec2(0.9199,0.9523), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1002,1.1412,-1.2791), vec3(0.0549,1.1486,-1.2938), vec3(0.1119,1.1803,-1.2617), vec3(0.3398,0.2953,-0.893), vec2(0.9277,0.9287), vec2(0.9385,0.9414), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0616,1.2017,-1.2761), vec3(0.1119,1.1803,-1.2617), vec3(0.0549,1.1486,-1.2938), vec3(0.3651,0.2528,-0.896), vec2(0.9199,0.9523), vec2(0.9136,0.9346), vec2(0.9385,0.9414), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0447,1.1457,-1.2758), vec3(-0.0533,1.1854,-1.258), vec3(0.0002,1.1503,-1.2926), vec3(-0.361,0.3165,-0.8772), vec2(0.9277,0.9287), vec2(0.9136,0.9346), vec2(0.9385,0.9414), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0025,1.2037,-1.2747), vec3(0.0002,1.1503,-1.2926), vec3(-0.0533,1.1854,-1.258), vec3(-0.3886,0.2763,-0.879), vec2(0.9199,0.9523), vec2(0.9385,0.9414), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0895,1.1007,-1.2792), vec3(0.1002,1.1412,-1.2791), vec3(0.1182,1.1104,-1.2514), vec3(0.7154,-0.1861,-0.6735), vec2(0.939,0.9193), vec2(0.9277,0.9287), vec2(0.9258,0.9136), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1256,1.155,-1.2567), vec3(0.1002,1.1412,-1.2791), vec3(0.1119,1.1803,-1.2617), vec3(0.5953,0.1709,-0.7851), vec2(0.916,0.9254), vec2(0.9277,0.9287), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1256,1.155,-1.2567), vec3(0.1182,1.1104,-1.2514), vec3(0.1002,1.1412,-1.2791), vec3(0.7044,-0.1995,-0.6812), vec2(0.916,0.9254), vec2(0.9258,0.9136), vec2(0.9277,0.9287), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0533,1.1854,-1.258), vec3(-0.0447,1.1457,-1.2758), vec3(-0.0683,1.161,-1.2524), vec3(-0.6186,0.2077,-0.7578), vec2(0.9136,0.9346), vec2(0.9277,0.9287), vec2(0.916,0.9254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0683,1.161,-1.2524), vec3(-0.0447,1.1457,-1.2758), vec3(-0.0634,1.116,-1.2473), vec3(-0.7451,-0.1548,-0.6488), vec2(0.916,0.9254), vec2(0.9277,0.9287), vec2(0.9258,0.9136), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0297,1.2063,-1.2753), vec3(0.0842,1.2542,-1.2024), vec3(0.0616,1.2017,-1.2761), vec3(0.0974,0.7963,-0.597), vec2(0.9238,0.9641), vec2(0.8848,0.9547), vec2(0.9199,0.9523), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0025,1.2037,-1.2747), vec3(-0.0185,1.2574,-1.2001), vec3(0.0297,1.2063,-1.2753), vec3(-0.0754,0.8014,-0.5934), vec2(0.9199,0.9523), vec2(0.8848,0.9547), vec2(0.9238,0.9641), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0842,1.2542,-1.2024), vec3(0.1119,1.1803,-1.2617), vec3(0.0616,1.2017,-1.2761), vec3(0.4527,0.6548,-0.6053), vec2(0.8848,0.9547), vec2(0.9136,0.9346), vec2(0.9199,0.9523), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0025,1.2037,-1.2747), vec3(-0.0533,1.1854,-1.258), vec3(-0.0185,1.2574,-1.2001), vec3(-0.4382,0.6821,-0.5854), vec2(0.9199,0.9523), vec2(0.9136,0.9346), vec2(0.8848,0.9547), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1256,1.155,-1.2567), vec3(0.1119,1.1803,-1.2617), vec3(0.146,1.1846,-1.1975), vec3(0.8154,0.3543,-0.4578), vec2(0.916,0.9254), vec2(0.9136,0.9346), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1182,1.1104,-1.2514), vec3(0.1256,1.155,-1.2567), vec3(0.1451,1.1235,-1.1949), vec3(0.9022,-0.1967,-0.3838), vec2(0.9258,0.9136), vec2(0.916,0.9254), vec2(0.9058,0.9043), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0683,1.161,-1.2524), vec3(-0.0842,1.1917,-1.1923), vec3(-0.0533,1.1854,-1.258), vec3(-0.8121,0.4038,-0.4212), vec2(0.916,0.9254), vec2(0.8936,0.9229), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0634,1.116,-1.2473), vec3(-0.0869,1.1306,-1.1897), vec3(-0.0683,1.161,-1.2524), vec3(-0.929,-0.14,-0.3426), vec2(0.9258,0.9136), vec2(0.9058,0.9043), vec2(0.916,0.9254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1182,1.1104,-1.2514), vec3(0.1451,1.1235,-1.1949), vec3(0.1081,1.0805,-1.2418), vec3(0.8623,-0.3927,-0.3197), vec2(0.9258,0.9136), vec2(0.9058,0.9043), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0548,1.0855,-1.2381), vec3(-0.0869,1.1306,-1.1897), vec3(-0.0634,1.116,-1.2473), vec3(-0.8982,-0.339,-0.2798), vec2(0.9326,0.9033), vec2(0.9058,0.9043), vec2(0.9258,0.9136), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0842,1.2542,-1.2024), vec3(0.0297,1.2063,-1.2753), vec3(0.0333,1.2646,-1.1954), vec3(0.0818,0.8033,-0.5899), vec2(0.8848,0.9547), vec2(0.9238,0.9641), vec2(0.8823,0.9742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0185,1.2574,-1.2001), vec3(0.0333,1.2646,-1.1954), vec3(0.0297,1.2063,-1.2753), vec3(-0.0585,0.8076,-0.5868), vec2(0.8848,0.9547), vec2(0.8823,0.9742), vec2(0.9238,0.9641), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0842,1.2542,-1.2024), vec3(0.1301,1.2217,-1.1957), vec3(0.1119,1.1803,-1.2617), vec3(0.5351,0.6413,-0.55), vec2(0.8848,0.9547), vec2(0.8867,0.9351), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1301,1.2217,-1.1957), vec3(0.146,1.1846,-1.1975), vec3(0.1119,1.1803,-1.2617), vec3(0.8096,0.3698,-0.4558), vec2(0.8867,0.9351), vec2(0.8936,0.9229), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.066,1.2277,-1.1912), vec3(-0.0185,1.2574,-1.2001), vec3(-0.0533,1.1854,-1.258), vec3(-0.5194,0.6735,-0.5259), vec2(0.8867,0.9351), vec2(0.8848,0.9547), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.146,1.1846,-1.1975), vec3(0.1451,1.1235,-1.1949), vec3(0.1256,1.155,-1.2567), vec3(0.9494,-0.0281,-0.3127), vec2(0.8936,0.9229), vec2(0.9058,0.9043), vec2(0.916,0.9254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.066,1.2277,-1.1912), vec3(-0.0533,1.1854,-1.258), vec3(-0.0842,1.1917,-1.1923), vec3(-0.8049,0.4198,-0.4194), vec2(0.8867,0.9351), vec2(0.9136,0.9346), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0683,1.161,-1.2524), vec3(-0.0869,1.1306,-1.1897), vec3(-0.0842,1.1917,-1.1923), vec3(-0.9624,0.0306,-0.2698), vec2(0.916,0.9254), vec2(0.9058,0.9043), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1451,1.1235,-1.1949), vec3(0.1311,1.0655,-1.1875), vec3(0.1081,1.0805,-1.2418), vec3(0.8602,-0.2625,-0.4371), vec2(0.9058,0.9043), vec2(0.918,0.8853), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.146,1.1846,-1.1975), vec3(0.1736,1.1174,-1.1088), vec3(0.1451,1.1235,-1.1949), vec3(0.9482,-0.0282,-0.3165), vec2(0.8936,0.9229), vec2(0.8779,0.8866), vec2(0.9058,0.9043), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1301,1.2217,-1.1957), vec3(0.0842,1.2542,-1.2024), vec3(0.1492,1.2285,-1.0988), vec3(0.5861,0.7921,-0.1706), vec2(0.8867,0.9351), vec2(0.8848,0.9547), vec2(0.8535,0.9227), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.146,1.1846,-1.1975), vec3(0.1301,1.2217,-1.1957), vec3(0.1711,1.1755,-1.1019), vec3(0.8971,0.3949,-0.198), vec2(0.8936,0.9229), vec2(0.8867,0.9351), vec2(0.8638,0.9044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0333,1.2646,-1.1954), vec3(0.0891,1.2885,-1.0937), vec3(0.0842,1.2542,-1.2024), vec3(0.1496,0.941,-0.3037), vec2(0.8823,0.9742), vec2(0.8408,0.9507), vec2(0.8848,0.9547), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1451,1.1235,-1.1949), vec3(0.1736,1.1174,-1.1088), vec3(0.1311,1.0655,-1.1875), vec3(0.9109,-0.2598,-0.3205), vec2(0.9058,0.9043), vec2(0.8779,0.8866), vec2(0.918,0.8853), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0185,1.2574,-1.2001), vec3(-0.0164,1.2918,-1.0914), vec3(0.0333,1.2646,-1.1954), vec3(-0.1048,0.9488,-0.2978), vec2(0.8848,0.9547), vec2(0.8408,0.9507), vec2(0.8823,0.9742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.066,1.2277,-1.1912), vec3(-0.0802,1.2356,-1.0936), vec3(-0.0185,1.2574,-1.2001), vec3(-0.5438,0.8265,-0.1455), vec2(0.8867,0.9351), vec2(0.8535,0.9227), vec2(0.8848,0.9547), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0869,1.1306,-1.1897), vec3(-0.1118,1.1262,-1.1024), vec3(-0.0842,1.1917,-1.1923), vec3(-0.9614,0.0304,-0.2734), vec2(0.9058,0.9043), vec2(0.8779,0.8866), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0842,1.1917,-1.1923), vec3(-0.1055,1.184,-1.0956), vec3(-0.066,1.2277,-1.1912), vec3(-0.8791,0.4497,-0.1579), vec2(0.8936,0.9229), vec2(0.8638,0.9044), vec2(0.8867,0.9351), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0869,1.1306,-1.1897), vec3(-0.0762,1.0718,-1.1828), vec3(-0.1118,1.1262,-1.1024), vec3(-0.9387,-0.2031,-0.2787), vec2(0.9058,0.9043), vec2(0.918,0.8853), vec2(0.8779,0.8866), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.155,1.0506,-1.1183), vec3(0.1311,1.0655,-1.1875), vec3(0.1736,1.1174,-1.1088), vec3(0.9113,-0.2039,-0.3577), vec2(0.8975,0.8658), vec2(0.918,0.8853), vec2(0.8779,0.8866), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1711,1.1755,-1.1019), vec3(0.1736,1.1174,-1.1088), vec3(0.146,1.1846,-1.1975), vec3(0.9664,0.0707,-0.2471), vec2(0.8638,0.9044), vec2(0.8779,0.8866), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0978,1.0584,-1.1126), vec3(-0.1118,1.1262,-1.1024), vec3(-0.0762,1.0718,-1.1828), vec3(-0.9373,-0.1468,-0.3161), vec2(0.8975,0.8658), vec2(0.8779,0.8866), vec2(0.918,0.8853), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1492,1.2285,-1.0988), vec3(0.1711,1.1755,-1.1019), vec3(0.1301,1.2217,-1.1957), vec3(0.8999,0.3854,-0.2039), vec2(0.8535,0.9227), vec2(0.8638,0.9044), vec2(0.8867,0.9351), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0891,1.2885,-1.0937), vec3(0.1492,1.2285,-1.0988), vec3(0.0842,1.2542,-1.2024), vec3(0.6742,0.695,-0.2499), vec2(0.8408,0.9507), vec2(0.8535,0.9227), vec2(0.8848,0.9547), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1118,1.1262,-1.1024), vec3(-0.1055,1.184,-1.0956), vec3(-0.0842,1.1917,-1.1923), vec3(-0.9704,0.13,-0.2035), vec2(0.8779,0.8866), vec2(0.8638,0.9044), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0185,1.2574,-1.2001), vec3(-0.0802,1.2356,-1.0936), vec3(-0.0164,1.2918,-1.0914), vec3(-0.6406,0.7356,-0.2202), vec2(0.8848,0.9547), vec2(0.8535,0.9227), vec2(0.8408,0.9507), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0891,1.2885,-1.0937), vec3(0.0333,1.2646,-1.1954), vec3(0.0367,1.3,-1.0928), vec3(0.1966,0.9248,-0.3257), vec2(0.8408,0.9507), vec2(0.8823,0.9742), vec2(0.8354,0.9704), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0802,1.2356,-1.0936), vec3(-0.066,1.2277,-1.1912), vec3(-0.1055,1.184,-1.0956), vec3(-0.8829,0.4401,-0.1638), vec2(0.8535,0.9227), vec2(0.8867,0.9351), vec2(0.8638,0.9044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0164,1.2918,-1.0914), vec3(0.0367,1.3,-1.0928), vec3(0.0333,1.2646,-1.1954), vec3(-0.154,0.9356,-0.3178), vec2(0.8408,0.9507), vec2(0.8354,0.9704), vec2(0.8823,0.9742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.155,1.0506,-1.1183), vec3(0.1736,1.1174,-1.1088), vec3(0.1718,1.0291,-1.0517), vec3(0.9278,-0.2161,-0.304), vec2(0.8975,0.8658), vec2(0.8779,0.8866), vec2(0.8789,0.8451), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0978,1.0584,-1.1126), vec3(-0.1129,1.0379,-1.0453), vec3(-0.1118,1.1262,-1.1024), vec3(-0.9521,-0.1581,-0.2616), vec2(0.8975,0.8658), vec2(0.8789,0.8451), vec2(0.8779,0.8866), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1736,1.1174,-1.1088), vec3(0.1711,1.1755,-1.1019), vec3(0.1956,1.1148,-1.0019), vec3(0.9777,0.0655,-0.1995), vec2(0.8779,0.8866), vec2(0.8638,0.9044), vec2(0.8413,0.8647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1711,1.1755,-1.1019), vec3(0.1492,1.2285,-1.0988), vec3(0.1752,1.1944,-0.9918), vec3(0.9169,0.3863,-0.1001), vec2(0.8638,0.9044), vec2(0.8535,0.9227), vec2(0.8232,0.8921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1291,1.1248,-0.9945), vec3(-0.1055,1.184,-1.0956), vec3(-0.1118,1.1262,-1.1024), vec3(-0.9799,0.1254,-0.1554), vec2(0.8413,0.8647), vec2(0.8638,0.9044), vec2(0.8779,0.8866), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0802,1.2356,-1.0936), vec3(-0.1055,1.184,-1.0956), vec3(-0.1034,1.203,-0.9856), vec3(-0.8951,0.442,-0.0592), vec2(0.8535,0.9227), vec2(0.8638,0.9044), vec2(0.8232,0.8921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0891,1.2885,-1.0937), vec3(0.1148,1.2677,-0.9745), vec3(0.1492,1.2285,-1.0988), vec3(0.7057,0.708,-0.0281), vec2(0.8408,0.9507), vec2(0.8032,0.9231), vec2(0.8535,0.9227), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1956,1.1148,-1.0019), vec3(0.1718,1.0291,-1.0517), vec3(0.1736,1.1174,-1.1088), vec3(0.9675,-0.1512,-0.2026), vec2(0.8413,0.8647), vec2(0.8789,0.8451), vec2(0.8779,0.8866), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0891,1.2885,-1.0937), vec3(0.0367,1.3,-1.0928), vec3(0.1148,1.2677,-0.9745), vec3(0.2142,0.969,0.123), vec2(0.8408,0.9507), vec2(0.8354,0.9704), vec2(0.8032,0.9231), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0164,1.2918,-1.0914), vec3(-0.0802,1.2356,-1.0936), vec3(-0.0379,1.2724,-0.9711), vec3(-0.6612,0.7502,0.0027), vec2(0.8408,0.9507), vec2(0.8535,0.9227), vec2(0.8032,0.9231), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0164,1.2918,-1.0914), vec3(-0.0379,1.2724,-0.9711), vec3(0.0367,1.3,-1.0928), vec3(-0.1487,0.9801,0.1312), vec2(0.8408,0.9507), vec2(0.8032,0.9231), vec2(0.8354,0.9704), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1291,1.1248,-0.9945), vec3(-0.1118,1.1262,-1.1024), vec3(-0.1129,1.0379,-1.0453), vec3(-0.9831,-0.091,-0.1586), vec2(0.8413,0.8647), vec2(0.8779,0.8866), vec2(0.8789,0.8451), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1752,1.1944,-0.9918), vec3(0.1956,1.1148,-1.0019), vec3(0.1711,1.1755,-1.1019), vec3(0.9631,0.2571,-0.0796), vec2(0.8232,0.8921), vec2(0.8413,0.8647), vec2(0.8638,0.9044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1034,1.203,-0.9856), vec3(-0.1055,1.184,-1.0956), vec3(-0.1291,1.1248,-0.9945), vec3(-0.9481,0.3159,-0.0364), vec2(0.8232,0.8921), vec2(0.8638,0.9044), vec2(0.8413,0.8647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1752,1.1944,-0.9918), vec3(0.1492,1.2285,-1.0988), vec3(0.1148,1.2677,-0.9745), vec3(0.773,0.6342,0.0138), vec2(0.8232,0.8921), vec2(0.8535,0.9227), vec2(0.8032,0.9231), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1818,1.0009,-1.0046), vec3(0.1718,1.0291,-1.0517), vec3(0.1956,1.1148,-1.0019), vec3(0.9567,-0.1091,-0.2698), vec2(0.8682,0.8246), vec2(0.8789,0.8451), vec2(0.8413,0.8647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1034,1.203,-0.9856), vec3(-0.0379,1.2724,-0.9711), vec3(-0.0802,1.2356,-1.0936), vec3(-0.7313,0.6804,0.0479), vec2(0.8232,0.8921), vec2(0.8032,0.9231), vec2(0.8535,0.9227), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0391,1.2821,-0.9588), vec3(0.1148,1.2677,-0.9745), vec3(0.0367,1.3,-1.0928), vec3(0.2107,0.9695,0.1254), vec2(0.7847,0.9484), vec2(0.8032,0.9231), vec2(0.8354,0.9704), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0391,1.2821,-0.9588), vec3(0.0367,1.3,-1.0928), vec3(-0.0379,1.2724,-0.9711), vec3(-0.1451,0.9804,0.1335), vec2(0.7847,0.9484), vec2(0.8354,0.9704), vec2(0.8032,0.9231), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1818,1.0009,-1.0046), vec3(0.1956,1.1148,-1.0019), vec3(0.2258,1.0298,-0.8921), vec3(0.9351,-0.1048,-0.3385), vec2(0.8682,0.8246), vec2(0.8413,0.8647), vec2(0.8188,0.809), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1956,1.1148,-1.0019), vec3(0.1752,1.1944,-0.9918), vec3(0.2114,1.1211,-0.8714), vec3(0.9566,0.2616,-0.1281), vec2(0.8413,0.8647), vec2(0.8232,0.8921), vec2(0.793,0.8396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1148,1.2677,-0.9745), vec3(0.1464,1.213,-0.8455), vec3(0.1752,1.1944,-0.9918), vec3(0.7779,0.624,0.074), vec2(0.8032,0.9231), vec2(0.7632,0.8768), vec2(0.8232,0.8921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0379,1.2724,-0.9711), vec3(-0.1034,1.203,-0.9856), vec3(-0.067,1.2195,-0.8407), vec3(-0.7341,0.6704,0.1081), vec2(0.8032,0.9231), vec2(0.8232,0.8921), vec2(0.7632,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1148,1.2677,-0.9745), vec3(0.0391,1.2821,-0.9588), vec3(0.1115,1.2341,-0.8373), vec3(0.229,0.9442,0.2367), vec2(0.8032,0.9231), vec2(0.7847,0.9484), vec2(0.752,0.8905), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2114,1.1211,-0.8714), vec3(0.2258,1.0298,-0.8921), vec3(0.1956,1.1148,-1.0019), vec3(0.975,0.1829,-0.1266), vec2(0.793,0.8396), vec2(0.8188,0.809), vec2(0.8413,0.8647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0379,1.2724,-0.9711), vec3(-0.0305,1.2385,-0.834), vec3(0.0391,1.2821,-0.9588), vec3(-0.1599,0.9561,0.2454), vec2(0.8032,0.9231), vec2(0.752,0.8905), vec2(0.7847,0.9484), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2114,1.1211,-0.8714), vec3(0.1752,1.1944,-0.9918), vec3(0.1464,1.213,-0.8455), vec3(0.8251,0.5576,0.0917), vec2(0.793,0.8396), vec2(0.8232,0.8921), vec2(0.7632,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1464,1.213,-0.8455), vec3(0.1148,1.2677,-0.9745), vec3(0.1115,1.2341,-0.8373), vec3(0.5429,0.8127,0.2118), vec2(0.7632,0.8768), vec2(0.8032,0.9231), vec2(0.752,0.8905), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0412,1.2517,-0.8264), vec3(0.1115,1.2341,-0.8373), vec3(0.0391,1.2821,-0.9588), vec3(0.2683,0.9398,0.2116), vec2(0.7329,0.9139), vec2(0.752,0.8905), vec2(0.7847,0.9484), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.2083,0.8747,-0.666), 0.5771, bestT)) {
        if (triHit(ro, rd, vec3(0.1707,0.516,-0.5268), vec3(0.1834,0.468,-0.435), vec3(0.0245,0.4777,-0.5095), vec3(0.1696,-0.8638,-0.4744), vec2(0.854,0.5461), vec2(0.835,0.5125), vec2(0.9023,0.511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2523,0.5005,-0.4246), vec3(0.1834,0.468,-0.435), vec3(0.1707,0.516,-0.5268), vec3(0.4342,-0.7725,-0.4634), vec2(0.8125,0.5249), vec2(0.835,0.5125), vec2(0.854,0.5461), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1707,0.516,-0.5268), vec3(0.2215,0.5452,-0.5248), vec3(0.2523,0.5005,-0.4246), vec3(0.4528,-0.7543,-0.4755), vec2(0.854,0.5461), vec2(0.8364,0.5576), vec2(0.8125,0.5249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0177,0.5812,-0.6647), vec3(0.1707,0.516,-0.5268), vec3(0.0245,0.4777,-0.5095), vec3(0.1488,-0.8199,-0.5529), vec2(0.9282,0.5854), vec2(0.854,0.5461), vec2(0.9023,0.511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1707,0.516,-0.5268), vec3(0.1276,0.6113,-0.6764), vec3(0.2215,0.5452,-0.5248), vec3(0.4264,-0.7021,-0.5703), vec2(0.854,0.5461), vec2(0.8833,0.6074), vec2(0.8364,0.5576), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1276,0.6113,-0.6764), vec3(0.1707,0.516,-0.5268), vec3(0.0177,0.5812,-0.6647), vec3(0.162,-0.8104,-0.563), vec2(0.8833,0.6074), vec2(0.854,0.5461), vec2(0.9282,0.5854), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1969,0.6146,-0.6148), vec3(0.2215,0.5452,-0.5248), vec3(0.1276,0.6113,-0.6764), vec3(0.5577,-0.5767,-0.597), vec2(0.8491,0.5974), vec2(0.8364,0.5576), vec2(0.8833,0.6074), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1969,0.6146,-0.6148), vec3(0.2749,0.6448,-0.5119), vec3(0.2215,0.5452,-0.5248), vec3(0.7916,-0.3599,-0.4938), vec2(0.8389,0.3125), vec2(0.8564,0.333), vec2(0.8335,0.334), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1276,0.6113,-0.6764), vec3(0.0177,0.5812,-0.6647), vec3(0.0242,0.6559,-0.7694), vec3(0.1609,-0.8079,-0.567), vec2(0.8833,0.6074), vec2(0.9282,0.5854), vec2(0.939,0.6411), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0242,0.6559,-0.7694), vec3(0.0177,0.5812,-0.6647), vec3(-0.0775,0.6176,-0.6718), vec3(-0.2553,-0.7793,-0.5722), vec2(0.939,0.6411), vec2(0.9282,0.5854), vec2(0.8833,0.6074), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1969,0.6146,-0.6148), vec3(0.1276,0.6113,-0.6764), vec3(0.2104,0.6855,-0.6684), vec3(0.5636,-0.563,-0.6044), vec2(0.8491,0.5974), vec2(0.8833,0.6074), vec2(0.8418,0.6313), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1015,0.6988,-0.7644), vec3(0.1276,0.6113,-0.6764), vec3(0.0242,0.6559,-0.7694), vec3(0.3773,-0.5981,-0.7071), vec2(0.897,0.6543), vec2(0.8833,0.6074), vec2(0.939,0.6411), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0242,0.6559,-0.7694), vec3(-0.0775,0.6176,-0.6718), vec3(-0.0502,0.7035,-0.761), vec3(-0.4446,-0.5729,-0.6885), vec2(0.939,0.6411), vec2(0.8833,0.6074), vec2(0.897,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1276,0.6113,-0.6764), vec3(0.1015,0.6988,-0.7644), vec3(0.2104,0.6855,-0.6684), vec3(0.5295,-0.5177,-0.672), vec2(0.8833,0.6074), vec2(0.897,0.6543), vec2(0.8418,0.6313), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2857,0.7538,-0.4936), vec3(0.2749,0.6448,-0.5119), vec3(0.1969,0.6146,-0.6148), vec3(0.7937,0.0233,-0.6079), vec2(0.8813,0.3306), vec2(0.8564,0.333), vec2(0.8389,0.3125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2104,0.6855,-0.6684), vec3(0.2445,0.7664,-0.5986), vec3(0.1969,0.6146,-0.6148), vec3(0.9494,-0.2828,-0.1366), vec2(0.8511,0.2983), vec2(0.875,0.3071), vec2(0.8389,0.3125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0242,0.6559,-0.7694), vec3(0.0235,0.7289,-0.8979), vec3(0.1015,0.6988,-0.7644), vec3(0.4569,-0.7725,-0.4411), vec2(0.939,0.6411), vec2(0.9434,0.6992), vec2(0.897,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0242,0.6559,-0.7694), vec3(-0.0502,0.7035,-0.761), vec3(0.0235,0.7289,-0.8979), vec3(-0.5228,-0.7425,-0.4189), vec2(0.939,0.6411), vec2(0.897,0.6543), vec2(0.9434,0.6992), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1565,0.7449,-0.7623), vec3(0.2104,0.6855,-0.6684), vec3(0.1015,0.6988,-0.7644), vec3(0.5025,-0.5714,-0.6488), vec2(0.8691,0.6699), vec2(0.8418,0.6313), vec2(0.897,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2857,0.7538,-0.4936), vec3(0.1969,0.6146,-0.6148), vec3(0.2445,0.7664,-0.5986), vec3(0.8937,-0.2395,-0.3793), vec2(0.8813,0.3306), vec2(0.8389,0.3125), vec2(0.875,0.3071), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1126,0.7543,-0.8939), vec3(0.1015,0.6988,-0.7644), vec3(0.0235,0.7289,-0.8979), vec3(0.2707,-0.8931,-0.3594), vec2(0.9053,0.7095), vec2(0.897,0.6543), vec2(0.9434,0.6992), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1565,0.7449,-0.7623), vec3(0.1015,0.6988,-0.7644), vec3(0.1126,0.7543,-0.8939), vec3(0.6252,-0.7353,-0.2616), vec2(0.8691,0.6699), vec2(0.897,0.6543), vec2(0.9053,0.7095), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2104,0.6855,-0.6684), vec3(0.1565,0.7449,-0.7623), vec3(0.2251,0.7949,-0.6979), vec3(0.7556,-0.2636,-0.5996), vec2(0.8418,0.6313), vec2(0.8691,0.6699), vec2(0.8223,0.6716), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2104,0.6855,-0.6684), vec3(0.2251,0.7949,-0.6979), vec3(0.2445,0.7664,-0.5986), vec3(0.951,-0.1934,-0.2411), vec2(0.8511,0.2983), vec2(0.8716,0.2856), vec2(0.875,0.3071), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1565,0.7449,-0.7623), vec3(0.1126,0.7543,-0.8939), vec3(0.2052,0.8231,-0.76), vec3(0.812,-0.4964,-0.3069), vec2(0.8691,0.6699), vec2(0.9053,0.7095), vec2(0.8394,0.6953), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2052,0.8231,-0.76), vec3(0.2251,0.7949,-0.6979), vec3(0.1565,0.7449,-0.7623), vec3(0.7627,-0.4613,-0.4533), vec2(0.8394,0.6953), vec2(0.8223,0.6716), vec2(0.8691,0.6699), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2445,0.7664,-0.5986), vec3(0.2599,0.8541,-0.5537), vec3(0.2857,0.7538,-0.4936), vec3(0.9316,0.0224,-0.3628), vec2(0.875,0.3071), vec2(0.8999,0.3076), vec2(0.8813,0.3306), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1862,0.8233,-0.8891), vec3(0.2052,0.8231,-0.76), vec3(0.1126,0.7543,-0.8939), vec3(0.6838,-0.7225,-0.102), vec2(0.8701,0.7329), vec2(0.8394,0.6953), vec2(0.9053,0.7095), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2445,0.7664,-0.5986), vec3(0.2251,0.7949,-0.6979), vec3(0.2599,0.8541,-0.5537), vec3(0.9758,-0.0643,-0.2089), vec2(0.875,0.3071), vec2(0.8716,0.2856), vec2(0.8999,0.3076), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4904,0.7376,-0.5767), vec3(0.2971,0.9071,-0.5253), vec3(0.5211,0.7828,-0.6301), vec3(-0.5687,-0.4371,-0.6968), vec2(0.6665,0.0669), vec2(0.7339,0.0747), vec2(0.6582,0.0444), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.107,0.8724,-1.0033), vec3(0.1862,0.8233,-0.8891), vec3(0.1126,0.7543,-0.8939), vec3(0.5562,-0.5505,-0.6225), vec2(0.9111,0.7754), vec2(0.8701,0.7329), vec2(0.9053,0.7095), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2251,0.7949,-0.6979), vec3(0.2052,0.8231,-0.76), vec3(0.246,0.901,-0.696), vec3(0.9124,-0.1733,-0.3708), vec2(0.8223,0.6716), vec2(0.8394,0.6953), vec2(0.7944,0.7068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.246,0.901,-0.696), vec3(0.2599,0.8541,-0.5537), vec3(0.2251,0.7949,-0.6979), vec3(0.9696,-0.1883,-0.1564), vec2(0.8931,0.2773), vec2(0.8999,0.3076), vec2(0.8716,0.2856), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2052,0.8231,-0.76), vec3(0.1862,0.8233,-0.8891), vec3(0.238,0.9103,-0.756), vec3(0.9292,-0.343,-0.1374), vec2(0.8394,0.6953), vec2(0.8701,0.7329), vec2(0.813,0.7246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2986,0.8471,-0.4587), vec3(0.2599,0.8541,-0.5537), vec3(0.2838,0.9058,-0.511), vec3(0.9176,-0.1096,-0.382), vec2(0.9253,0.3237), vec2(0.8999,0.3076), vec2(0.9258,0.3066), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1862,0.8233,-0.8891), vec3(0.107,0.8724,-1.0033), vec3(0.2225,0.9145,-0.8779), vec3(0.7534,-0.2231,-0.6185), vec2(0.8701,0.7329), vec2(0.9111,0.7754), vec2(0.8408,0.7628), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.238,0.9103,-0.756), vec3(0.246,0.901,-0.696), vec3(0.2052,0.8231,-0.76), vec3(0.9241,-0.3392,-0.1762), vec2(0.813,0.7246), vec2(0.7944,0.7068), vec2(0.8394,0.6953), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2225,0.9145,-0.8779), vec3(0.238,0.9103,-0.756), vec3(0.1862,0.8233,-0.8891), vec3(0.9268,-0.3523,-0.1303), vec2(0.8408,0.7628), vec2(0.813,0.7246), vec2(0.8701,0.7329), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2986,0.8471,-0.4587), vec3(0.2838,0.9058,-0.511), vec3(0.2971,0.9071,-0.5253), vec3(-0.5362,-0.6328,-0.5586), vec2(0.7319,0.0942), vec2(0.7373,0.0801), vec2(0.7339,0.0747), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3306,0.9739,-0.5625), vec3(0.5211,0.7828,-0.6301), vec3(0.2971,0.9071,-0.5253), vec3(-0.5079,-0.2108,-0.8352), vec2(0.7368,0.0562), vec2(0.6582,0.0444), vec2(0.7339,0.0747), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.246,0.901,-0.696), vec3(0.2784,0.9301,-0.5362), vec3(0.2599,0.8541,-0.5537), vec3(0.9669,-0.1991,-0.1597), vec2(0.8931,0.2773), vec2(0.9243,0.2998), vec2(0.8999,0.3076), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2838,0.9058,-0.511), vec3(0.2599,0.8541,-0.5537), vec3(0.2784,0.9301,-0.5362), vec3(0.9281,-0.1478,-0.3417), vec2(0.9258,0.3066), vec2(0.8999,0.3076), vec2(0.9243,0.2998), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1948,0.9499,-0.9448), vec3(0.2225,0.9145,-0.8779), vec3(0.107,0.8724,-1.0033), vec3(0.7317,-0.4296,-0.5292), vec2(0.8579,0.7921), vec2(0.8408,0.7628), vec2(0.9111,0.7754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2838,0.9058,-0.511), vec3(0.2784,0.9301,-0.5362), vec3(0.2971,0.9071,-0.5253), vec3(-0.5113,-0.6697,-0.5386), vec2(0.7373,0.0801), vec2(0.7417,0.0767), vec2(0.7339,0.0747), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3306,0.9739,-0.5625), vec3(0.3886,1.0265,-0.5208), vec3(0.5211,0.7828,-0.6301), vec3(0.1788,0.4818,-0.8579), vec2(0.0115,0.9512), vec2(0.0388,0.9443), vec2(0.0175,0.8508), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3306,0.9739,-0.5625), vec3(0.2971,0.9071,-0.5253), vec3(0.2784,0.9301,-0.5362), vec3(-0.0556,-0.4645,-0.8838), vec2(0.7368,0.0562), vec2(0.7339,0.0747), vec2(0.7417,0.0767), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.246,0.901,-0.696), vec3(0.238,0.9103,-0.756), vec3(0.2552,0.9999,-0.7419), vec3(0.9743,-0.1629,-0.1554), vec2(0.7944,0.7068), vec2(0.813,0.7246), vec2(0.7852,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.246,0.901,-0.696), vec3(0.2665,0.9809,-0.6403), vec3(0.2784,0.9301,-0.5362), vec3(0.9763,-0.1279,-0.1746), vec2(0.8931,0.2773), vec2(0.915,0.2778), vec2(0.9243,0.2998), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.238,0.9103,-0.756), vec3(0.2225,0.9145,-0.8779), vec3(0.2552,0.9999,-0.7419), vec3(0.9772,-0.1674,-0.1303), vec2(0.813,0.7246), vec2(0.8408,0.7628), vec2(0.7852,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2784,0.9301,-0.5362), vec3(0.3053,1.0334,-0.5155), vec3(0.2838,0.9058,-0.511), vec3(0.9185,-0.1671,-0.3583), vec2(0.7202,0.6946), vec2(0.6914,0.731), vec2(0.7139,0.6836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.246,0.901,-0.696), vec3(0.2552,0.9999,-0.7419), vec3(0.2665,0.9809,-0.6403), vec3(0.9784,-0.1547,-0.137), vec2(0.7944,0.7068), vec2(0.7852,0.755), vec2(0.7549,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2225,0.9145,-0.8779), vec3(0.1948,0.9499,-0.9448), vec3(0.2258,1.0298,-0.8921), vec3(0.9063,-0.0776,-0.4155), vec2(0.8408,0.7628), vec2(0.8579,0.7921), vec2(0.8188,0.809), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2258,1.0298,-0.8921), vec3(0.2552,0.9999,-0.7419), vec3(0.2225,0.9145,-0.8779), vec3(0.9779,-0.0533,-0.2021), vec2(0.8188,0.809), vec2(0.7852,0.755), vec2(0.8408,0.7628), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3053,1.0334,-0.5155), vec3(0.2784,0.9301,-0.5362), vec3(0.2665,0.9809,-0.6403), vec3(0.9555,-0.2064,-0.2106), vec2(0.6914,0.731), vec2(0.7202,0.6946), vec2(0.7549,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.274,1.076,-0.6265), vec3(0.3306,0.9739,-0.5625), vec3(0.2784,0.9301,-0.5362), vec3(0.0128,-0.5259,-0.8504), vec2(0.7651,0.0596), vec2(0.7368,0.0562), vec2(0.7417,0.0767), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1948,0.9499,-0.9448), vec3(0.1818,1.0009,-1.0046), vec3(0.2258,1.0298,-0.8921), vec3(0.9335,-0.1463,-0.3273), vec2(0.8579,0.7921), vec2(0.8682,0.8246), vec2(0.8188,0.809), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2552,0.9999,-0.7419), vec3(0.2402,1.0922,-0.7359), vec3(0.2665,0.9809,-0.6403), vec3(0.9833,0.1647,-0.078), vec2(0.7852,0.755), vec2(0.7583,0.7926), vec2(0.7549,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.274,1.076,-0.6265), vec3(0.3886,1.0265,-0.5208), vec3(0.3306,0.9739,-0.5625), vec3(0.6462,-0.1147,-0.7545), vec2(0.0097,0.9876), vec2(0.0388,0.9443), vec2(0.0115,0.9512), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2738,1.0857,-0.6291), vec3(0.3053,1.0334,-0.5155), vec3(0.2665,0.9809,-0.6403), vec3(0.9585,-0.0368,-0.2828), vec2(0.7285,0.7654), vec2(0.6914,0.731), vec2(0.7549,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2402,1.0922,-0.7359), vec3(0.2552,0.9999,-0.7419), vec3(0.2258,1.0298,-0.8921), vec3(0.9732,0.1682,-0.157), vec2(0.7583,0.7926), vec2(0.7852,0.755), vec2(0.8188,0.809), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2738,1.0857,-0.6291), vec3(0.2665,0.9809,-0.6403), vec3(0.2402,1.0922,-0.7359), vec3(0.9529,-0.0344,-0.3013), vec2(0.7285,0.7654), vec2(0.7549,0.7261), vec2(0.7583,0.7926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2258,1.0298,-0.8921), vec3(0.2114,1.1211,-0.8714), vec3(0.2402,1.0922,-0.7359), vec3(0.9676,0.1905,-0.1654), vec2(0.8188,0.809), vec2(0.793,0.8396), vec2(0.7583,0.7926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.274,1.076,-0.6265), vec3(0.2888,1.1559,-0.4891), vec3(0.3886,1.0265,-0.5208), vec3(0.6612,0.6154,-0.429), vec2(0.0097,0.9876), vec2(0.0479,0.9786), vec2(0.0388,0.9443), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2269,1.1744,-0.6162), vec3(0.3053,1.0334,-0.5155), vec3(0.2738,1.0857,-0.6291), vec3(0.8822,0.4699,-0.0284), vec2(0.6973,0.8024), vec2(0.6914,0.731), vec2(0.7285,0.7654), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1745,1.1829,-0.7263), vec3(0.2738,1.0857,-0.6291), vec3(0.2402,1.0922,-0.7359), vec3(0.7813,0.5879,-0.2096), vec2(0.7261,0.8356), vec2(0.7285,0.7654), vec2(0.7583,0.7926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2888,1.1559,-0.4891), vec3(0.3053,1.0334,-0.5155), vec3(0.2269,1.1744,-0.6162), vec3(0.8912,0.2069,-0.4036), vec2(0.6626,0.7659), vec2(0.6914,0.731), vec2(0.6973,0.8024), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2402,1.0922,-0.7359), vec3(0.2114,1.1211,-0.8714), vec3(0.1745,1.1829,-0.7263), vec3(0.8068,0.589,-0.0462), vec2(0.7583,0.7926), vec2(0.793,0.8396), vec2(0.7261,0.8356), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2738,1.0857,-0.6291), vec3(0.1745,1.1829,-0.7263), vec3(0.2269,1.1744,-0.6162), vec3(0.8074,0.4769,-0.3473), vec2(0.7285,0.7654), vec2(0.7261,0.8356), vec2(0.6973,0.8024), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1464,1.213,-0.8455), vec3(0.1745,1.1829,-0.7263), vec3(0.2114,1.1211,-0.8714), vec3(0.8099,0.585,-0.0436), vec2(0.7632,0.8768), vec2(0.7261,0.8356), vec2(0.793,0.8396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2888,1.1559,-0.4891), vec3(0.2269,1.1744,-0.6162), vec3(0.1437,1.218,-0.6105), vec3(0.4568,0.8847,-0.0935), vec2(0.6626,0.7659), vec2(0.6973,0.8024), vec2(0.6719,0.8322), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1745,1.1829,-0.7263), vec3(0.1116,1.2113,-0.719), vec3(0.2269,1.1744,-0.6162), vec3(0.3965,0.9104,-0.118), vec2(0.7261,0.8356), vec2(0.708,0.8591), vec2(0.6973,0.8024), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1437,1.218,-0.6105), vec3(0.2269,1.1744,-0.6162), vec3(0.1116,1.2113,-0.719), vec3(0.4457,0.8757,-0.1858), vec2(0.6719,0.8322), vec2(0.6973,0.8024), vec2(0.708,0.8591), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2145,1.2357,-0.4681), vec3(0.2888,1.1559,-0.4891), vec3(0.1437,1.218,-0.6105), vec3(0.6193,0.6799,-0.3927), vec2(0.6309,0.8002), vec2(0.6626,0.7659), vec2(0.6719,0.8322), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0397,1.2314,-0.5995), vec3(0.2145,1.2357,-0.4681), vec3(0.1437,1.218,-0.6105), vec3(0.1083,0.9784,-0.1759), vec2(0.6499,0.8623), vec2(0.6309,0.8002), vec2(0.6719,0.8322), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0397,1.2314,-0.5995), vec3(0.0774,1.258,-0.472), vec3(0.2145,1.2357,-0.4681), vec3(0.1626,0.9552,-0.2473), vec2(0.6499,0.8623), vec2(0.605,0.8419), vec2(0.6309,0.8002), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0774,1.258,-0.472), vec3(0.2235,1.2489,-0.295), vec3(0.2145,1.2357,-0.4681), vec3(0.1624,0.9832,-0.0833), vec2(0.605,0.8419), vec2(0.5781,0.7605), vec2(0.6309,0.8002), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.4185,0.9297,0.4757), 0.7621, bestT)) {
        if (triHit(ro, rd, vec3(0.5809,1.1418,0.0118), vec3(0.2894,1.2094,0.101), vec3(0.59,1.1121,0.1851), vec3(0.2665,0.9522,0.1494), vec2(0.1959,0.8832), vec2(0.187,0.9585), vec2(0.2422,0.8833), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5875,0.8021,0.0289), vec3(0.5685,0.9389,0.0708), vec3(0.5621,0.8478,0.2026), vec3(0.9879,0.1014,0.1177), vec2(0.9219,0.4341), vec2(0.9639,0.4326), vec2(0.9355,0.4678), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4369,1.1065,0.2613), vec3(0.5363,1.0889,0.0264), vec3(0.4651,1.148,0.0386), vec3(0.6451,0.7323,0.2181), vec2(0.4844,0.5562), vec2(0.5581,0.5881), vec2(0.54,0.6082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.59,1.1121,0.1851), vec3(0.8299,0.9754,0.1343), vec3(0.5809,1.1418,0.0118), vec3(0.5105,0.8516,0.1194), vec2(0.2422,0.8833), vec2(0.2583,0.8077), vec2(0.1959,0.8832), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5363,1.0889,0.0264), vec3(0.4369,1.1065,0.2613), vec3(0.5685,0.9389,0.0708), vec3(0.8877,0.2949,0.3535), vec2(0.5581,0.5881), vec2(0.4844,0.5562), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4369,1.1065,0.2613), vec3(0.4651,1.148,0.0386), vec3(0.4018,1.181,0.0636), vec3(0.5173,0.8271,0.2196), vec2(0.4844,0.5562), vec2(0.54,0.6082), vec2(0.522,0.6201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2894,1.2094,0.101), vec3(0.4369,1.1065,0.2613), vec3(0.4018,1.181,0.0636), vec3(0.3222,0.9034,0.283), vec2(0.4873,0.6418), vec2(0.4844,0.5562), vec2(0.522,0.6201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2969,1.1777,0.2054), vec3(0.59,1.1121,0.1851), vec3(0.2894,1.2094,0.101), vec3(0.2282,0.9361,0.2676), vec2(0.2139,0.9588), vec2(0.2422,0.8833), vec2(0.187,0.9585), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5685,0.9389,0.0708), vec3(0.8374,0.9354,0.1435), vec3(0.5035,0.9444,0.2858), vec3(-0.0185,-0.9996,0.0199), vec2(0.7583,0.21), vec2(0.7188,0.2417), vec2(0.7905,0.2461), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2894,1.2094,0.101), vec3(0.2036,1.2155,0.106), vec3(0.3018,1.1439,0.2935), vec3(0.0863,0.945,0.3156), vec2(0.4873,0.6418), vec2(0.4646,0.6636), vec2(0.4431,0.5828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5035,0.9444,0.2858), vec3(0.5621,0.8478,0.2026), vec3(0.5685,0.9389,0.0708), vec3(0.9085,0.322,0.2665), vec2(0.9741,0.4766), vec2(0.9355,0.4678), vec2(0.9639,0.4326), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5035,0.9444,0.2858), vec3(0.5685,0.9389,0.0708), vec3(0.4369,1.1065,0.2613), vec3(0.8801,0.3998,0.2559), vec2(0.5156,0.5129), vec2(0.5757,0.5515), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2894,1.2094,0.101), vec3(0.3018,1.1439,0.2935), vec3(0.4369,1.1065,0.2613), vec3(0.3184,0.9036,0.2866), vec2(0.4873,0.6418), vec2(0.4431,0.5828), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2219,1.1589,0.3009), vec3(0.3018,1.1439,0.2935), vec3(0.2036,1.2155,0.106), vec3(0.2006,0.9456,0.2561), vec2(0.4148,0.6013), vec2(0.4431,0.5828), vec2(0.4646,0.6636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.59,1.1121,0.1851), vec3(0.9245,1.0477,0.4517), vec3(0.8299,0.9754,0.1343), vec3(0.4174,0.8511,-0.3184), vec2(0.2422,0.8833), vec2(0.3376,0.8015), vec2(0.2583,0.8077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4164,0.6455,0.3852), vec3(0.4596,0.607,0.2552), vec3(0.5621,0.8478,0.2026), vec3(0.8785,-0.2913,0.3787), vec2(0.9194,0.5139), vec2(0.9048,0.4922), vec2(0.9355,0.4678), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8374,0.9354,0.1435), vec3(0.925,1.0246,0.4541), vec3(0.5035,0.9444,0.2858), vec3(0.0821,-0.9638,0.2536), vec2(0.7188,0.2417), vec2(0.7446,0.3018), vec2(0.7905,0.2461), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2969,1.1777,0.2054), vec3(0.4354,1.0061,0.4966), vec3(0.59,1.1121,0.1851), vec3(0.2262,0.8825,0.4124), vec2(0.2139,0.9588), vec2(0.3037,0.9254), vec2(0.2422,0.8833), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9245,1.0477,0.4517), vec3(0.9609,0.7237,0.3181), vec3(0.8299,0.9754,0.1343), vec3(0.9147,0.2376,-0.3269), vec2(0.3376,0.8015), vec2(0.3357,0.7244), vec2(0.2583,0.8077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.925,1.0246,0.4541), vec3(0.8374,0.9354,0.1435), vec3(0.9592,0.7218,0.3213), vec3(-0.9118,-0.2469,0.3283), vec2(0.7446,0.3018), vec2(0.7188,0.2417), vec2(0.6855,0.2949), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5621,0.8478,0.2026), vec3(0.5035,0.9444,0.2858), vec3(0.4269,0.8003,0.4537), vec3(0.8668,0.1068,0.487), vec2(0.9355,0.4678), vec2(0.9741,0.4766), vec2(0.9487,0.5181), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3009,1.0575,0.482), vec3(0.4369,1.1065,0.2613), vec3(0.3018,1.1439,0.2935), vec3(0.3313,0.8571,0.3945), vec2(0.3997,0.5129), vec2(0.4844,0.5562), vec2(0.4431,0.5828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4369,1.1065,0.2613), vec3(0.3712,1.0137,0.4927), vec3(0.5035,0.9444,0.2858), vec3(0.8272,0.3992,0.3954), vec2(0.4844,0.5562), vec2(0.4255,0.4902), vec2(0.5156,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4269,0.8003,0.4537), vec3(0.4164,0.6455,0.3852), vec3(0.5621,0.8478,0.2026), vec3(0.8719,-0.2465,0.4231), vec2(0.9487,0.5181), vec2(0.9194,0.5139), vec2(0.9355,0.4678), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2219,1.1589,0.3009), vec3(0.3009,1.0575,0.482), vec3(0.3018,1.1439,0.2935), vec3(0.2043,0.8895,0.4087), vec2(0.4148,0.6013), vec2(0.3997,0.5129), vec2(0.4431,0.5828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2219,1.1589,0.3009), vec3(0.0636,1.1791,0.3044), vec3(0.2311,1.0915,0.493), vec3(0.1268,0.938,0.3227), vec2(0.4148,0.6013), vec2(0.3613,0.6421), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.394,0.5822,0.2921), vec3(0.2974,0.6605,0.5019), vec3(0.3051,0.5718,0.3045), vec3(0.1626,-0.8976,0.4097), vec2(0.5879,0.3926), vec2(0.519,0.3477), vec2(0.5928,0.3579), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.59,1.1121,0.1851), vec3(0.569,0.9904,0.5263), vec3(0.9245,1.0477,0.4517), vec3(-0.0824,0.9403,0.3303), vec2(0.2422,0.8833), vec2(0.323,0.8909), vec2(0.3376,0.8015), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.394,0.5822,0.2921), vec3(0.4164,0.6455,0.3852), vec3(0.2974,0.6605,0.5019), vec3(0.3554,-0.8103,0.4659), vec2(0.5879,0.3926), vec2(0.5479,0.3999), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4354,1.0061,0.4966), vec3(0.2969,1.1777,0.2054), vec3(0.2872,1.0857,0.5012), vec3(0.4614,0.8428,0.2771), vec2(0.3037,0.9254), vec2(0.2139,0.9588), vec2(0.2869,0.9689), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.569,0.9904,0.5263), vec3(0.59,1.1121,0.1851), vec3(0.4354,1.0061,0.4966), vec3(0.0357,0.9406,0.3376), vec2(0.323,0.8909), vec2(0.2422,0.8833), vec2(0.3037,0.9254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3712,1.0137,0.4927), vec3(0.4369,1.1065,0.2613), vec3(0.3009,1.0575,0.482), vec3(0.4268,0.7908,0.4387), vec2(0.4255,0.4902), vec2(0.4844,0.5562), vec2(0.3997,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4088,0.9233,0.5176), vec3(0.4269,0.8003,0.4537), vec3(0.5035,0.9444,0.2858), vec3(0.9261,-0.0578,0.3729), vec2(0.9795,0.5261), vec2(0.9487,0.5181), vec2(0.9741,0.4766), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5035,0.9444,0.2858), vec3(0.925,1.0246,0.4541), vec3(0.5684,0.9418,0.5355), vec3(0.2115,-0.9752,-0.065), vec2(0.7905,0.2461), vec2(0.7446,0.3018), vec2(0.8066,0.2964), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3009,1.0575,0.482), vec3(0.2219,1.1589,0.3009), vec3(0.2311,1.0915,0.493), vec3(0.4561,0.8464,0.2749), vec2(0.3997,0.5129), vec2(0.4148,0.6013), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0665,1.1034,0.498), vec3(0.2311,1.0915,0.493), vec3(0.0636,1.1791,0.3044), vec3(0.0776,0.9289,0.3622), vec2(0.3103,0.5667), vec2(0.3718,0.5288), vec2(0.3613,0.6421), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4088,0.9233,0.5176), vec3(0.5035,0.9444,0.2858), vec3(0.3712,1.0137,0.4927), vec3(0.8153,0.4426,0.3733), vec2(0.4451,0.4561), vec2(0.5156,0.5129), vec2(0.4255,0.4902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2073,0.6421,0.4978), vec3(0.3051,0.5718,0.3045), vec3(0.2974,0.6605,0.5019), vec3(0.1647,-0.8973,0.4096), vec2(0.5347,0.3164), vec2(0.5928,0.3579), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5035,0.9444,0.2858), vec3(0.5684,0.9418,0.5355), vec3(0.4088,0.9233,0.5176), vec3(0.1201,-0.9919,-0.0414), vec2(0.7905,0.2461), vec2(0.8066,0.2964), vec2(0.8296,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4164,0.6455,0.3852), vec3(0.4269,0.8003,0.4537), vec3(0.3847,0.6911,0.5128), vec3(0.9329,-0.1969,0.3016), vec2(0.9194,0.5139), vec2(0.9487,0.5181), vec2(0.9336,0.5352), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3847,0.6911,0.5128), vec3(0.2974,0.6605,0.5019), vec3(0.4164,0.6455,0.3852), vec3(0.2633,-0.8859,0.3818), vec2(0.502,0.3828), vec2(0.519,0.3477), vec2(0.5479,0.3999), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3917,0.7995,0.558), vec3(0.3847,0.6911,0.5128), vec3(0.4269,0.8003,0.4537), vec3(0.9307,-0.1903,0.3123), vec2(0.9551,0.5383), vec2(0.9336,0.5352), vec2(0.9487,0.5181), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3917,0.7995,0.558), vec3(0.4269,0.8003,0.4537), vec3(0.4088,0.9233,0.5176), vec3(0.9473,-0.0268,0.3192), vec2(0.9551,0.5383), vec2(0.9487,0.5181), vec2(0.9795,0.5261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2815,1.0368,0.5638), vec3(0.3712,1.0137,0.4927), vec3(0.3009,1.0575,0.482), vec3(0.4664,0.8251,0.3189), vec2(0.3779,0.4863), vec2(0.4255,0.4902), vec2(0.3997,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2815,1.0368,0.5638), vec3(0.3009,1.0575,0.482), vec3(0.2311,1.0915,0.493), vec3(0.4556,0.8315,0.318), vec2(0.3779,0.4863), vec2(0.3997,0.5129), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3712,1.0137,0.4927), vec3(0.3471,0.9734,0.5877), vec3(0.4088,0.9233,0.5176), vec3(0.8058,0.4438,0.3922), vec2(0.4255,0.4902), vec2(0.4021,0.4541), vec2(0.4451,0.4561), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2815,1.0368,0.5638), vec3(0.3471,0.9734,0.5877), vec3(0.3712,1.0137,0.4927), vec3(0.536,0.7201,0.4407), vec2(0.3779,0.4863), vec2(0.4021,0.4541), vec2(0.4255,0.4902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3659,0.9305,0.5737), vec3(0.3917,0.7995,0.558), vec3(0.4088,0.9233,0.5176), vec3(0.7969,0.085,0.5981), vec2(0.9834,0.5398), vec2(0.9551,0.5383), vec2(0.9795,0.5261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0684,1.0415,0.6663), vec3(0.2311,1.0915,0.493), vec3(0.0665,1.1034,0.498), vec3(0.0776,0.9361,0.3431), vec2(0.2681,0.4941), vec2(0.3718,0.5288), vec2(0.3103,0.5667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3847,0.6911,0.5128), vec3(0.2765,0.7245,0.6616), vec3(0.2974,0.6605,0.5019), vec3(0.2616,-0.8835,0.3885), vec2(0.502,0.3828), vec2(0.4553,0.3228), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3659,0.9305,0.5737), vec3(0.4088,0.9233,0.5176), vec3(0.3471,0.9734,0.5877), vec3(0.7943,0.1581,0.5866), vec2(0.4197,0.4434), vec2(0.4451,0.4561), vec2(0.4021,0.4541), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2265,1.0228,0.6675), vec3(0.2815,1.0368,0.5638), vec3(0.2311,1.0915,0.493), vec3(0.4292,0.8365,0.3407), vec2(0.3335,0.4575), vec2(0.3779,0.4863), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3847,0.6911,0.5128), vec3(0.3917,0.7995,0.558), vec3(0.3434,0.7443,0.6907), vec3(0.9464,-0.1744,0.2719), vec2(0.9336,0.5352), vec2(0.9551,0.5383), vec2(0.9497,0.5688), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2974,0.6605,0.5019), vec3(0.2765,0.7245,0.6616), vec3(0.1517,0.6939,0.6058), vec3(0.0573,-0.9241,0.3779), vec2(0.519,0.3477), vec2(0.4553,0.3228), vec2(0.5,0.2856), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3203,0.9451,0.6507), vec3(0.3659,0.9305,0.5737), vec3(0.3471,0.9734,0.5877), vec3(0.8564,0.2251,0.4646), vec2(0.3818,0.4258), vec2(0.4197,0.4434), vec2(0.4021,0.4541), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3468,0.8168,0.6862), vec3(0.3917,0.7995,0.558), vec3(0.3659,0.9305,0.5737), vec3(0.9394,0.1477,0.3095), vec2(0.9624,0.5649), vec2(0.9551,0.5383), vec2(0.9834,0.5398), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2815,1.0368,0.5638), vec3(0.2265,1.0228,0.6675), vec3(0.3471,0.9734,0.5877), vec3(0.5601,0.728,0.3954), vec2(0.3779,0.4863), vec2(0.3335,0.4575), vec2(0.4021,0.4541), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2265,1.0228,0.6675), vec3(0.2311,1.0915,0.493), vec3(0.0684,1.0415,0.6663), vec3(0.1064,0.9242,0.3667), vec2(0.3335,0.4575), vec2(0.3718,0.5288), vec2(0.2681,0.4941), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3434,0.7443,0.6907), vec3(0.2765,0.7245,0.6616), vec3(0.3847,0.6911,0.5128), vec3(0.141,-0.9391,0.3132), vec2(0.4319,0.3452), vec2(0.4553,0.3228), vec2(0.502,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3203,0.9451,0.6507), vec3(0.3471,0.9734,0.5877), vec3(0.2265,1.0228,0.6675), vec3(0.5966,0.6064,0.5257), vec2(0.3818,0.4258), vec2(0.4021,0.4541), vec2(0.3335,0.4575), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3203,0.9451,0.6507), vec3(0.3468,0.8168,0.6862), vec3(0.3659,0.9305,0.5737), vec3(0.8452,0.2968,0.4444), vec2(0.9893,0.5574), vec2(0.9624,0.5649), vec2(0.9834,0.5398), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3468,0.8168,0.6862), vec3(0.3434,0.7443,0.6907), vec3(0.3917,0.7995,0.558), vec3(0.9424,-0.0227,0.3336), vec2(0.9624,0.5649), vec2(0.9497,0.5688), vec2(0.9551,0.5383), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.125,0.7146,0.7114), vec3(0.1517,0.6939,0.6058), vec3(0.2765,0.7245,0.6616), vec3(0.1365,-0.9651,0.2233), vec2(0.4705,0.2559), vec2(0.5,0.2856), vec2(0.4553,0.3228), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.29,0.9104,0.7949), vec3(0.3468,0.8168,0.6862), vec3(0.3203,0.9451,0.6507), vec3(0.9294,0.263,0.259), vec2(0.981,0.5898), vec2(0.9624,0.5649), vec2(0.9893,0.5574), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2265,1.0228,0.6675), vec3(0.1874,0.9512,0.8276), vec3(0.3203,0.9451,0.6507), vec3(0.6179,0.6502,0.4422), vec2(0.3335,0.4575), vec2(0.2795,0.3838), vec2(0.3818,0.4258), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2839,0.7987,0.8526), vec3(0.2765,0.7245,0.6616), vec3(0.3434,0.7443,0.6907), vec3(0.1191,-0.9271,0.3554), vec2(0.3655,0.2837), vec2(0.4553,0.3228), vec2(0.4319,0.3452), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3072,0.8089,0.8354), vec3(0.3434,0.7443,0.6907), vec3(0.3468,0.8168,0.6862), vec3(0.9666,-0.0287,0.2546), vec2(0.9639,0.5957), vec2(0.9497,0.5688), vec2(0.9624,0.5649), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.29,0.9104,0.7949), vec3(0.3203,0.9451,0.6507), vec3(0.1874,0.9512,0.8276), vec3(0.433,0.8513,0.2963), vec2(0.3389,0.3511), vec2(0.3818,0.4258), vec2(0.2795,0.3838), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3468,0.8168,0.6862), vec3(0.3203,0.9451,0.6507), vec3(0.773,0.7885,0.9429), vec3(0.505,-0.1316,-0.853), vec2(0.8828,0.0078), vec2(0.9395,0.0122), vec2(0.7871,0.188), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.29,0.9104,0.7949), vec3(0.3072,0.8089,0.8354), vec3(0.3468,0.8168,0.6862), vec3(0.9295,0.2617,0.2601), vec2(0.981,0.5898), vec2(0.9639,0.5957), vec2(0.9624,0.5649), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.29,0.9104,0.7949), vec3(0.6225,0.7921,1.0967), vec3(0.3203,0.9451,0.6507), vec3(0.1105,0.9607,0.2548), vec2(0.9678,0.0742), vec2(0.8667,0.2188), vec2(0.9395,0.0122), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.773,0.7885,0.9429), vec3(0.8022,0.7663,0.9538), vec3(0.3468,0.8168,0.6862), vec3(0.5099,0.2695,-0.8169), vec2(0.7871,0.188), vec2(0.772,0.1953), vec2(0.8828,0.0078), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3468,0.8168,0.6862), vec3(0.6532,0.7521,1.1242), vec3(0.3072,0.8089,0.8354), vec3(-0.0973,-0.9922,-0.0783), vec2(0.5181,0.8101), vec2(0.6143,0.9227), vec2(0.5103,0.8556), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.773,0.7885,0.9429), vec3(0.3203,0.9451,0.6507), vec3(0.6225,0.7921,1.0967), vec3(0.2122,0.9595,0.1855), vec2(0.7871,0.188), vec2(0.9395,0.0122), vec2(0.8667,0.2188), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6532,0.7521,1.1242), vec3(0.3468,0.8168,0.6862), vec3(0.8022,0.7663,0.9538), vec3(-0.0406,-0.9922,-0.118), vec2(0.6143,0.9227), vec2(0.5181,0.8101), vec2(0.6626,0.879), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8022,0.7663,0.9538), vec3(0.773,0.7885,0.9429), vec3(0.6532,0.7521,1.1242), vec3(0.4327,0.7849,0.4435), vec2(0.7759,0.2017), vec2(0.7871,0.188), vec2(0.856,0.2378), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6225,0.7921,1.0967), vec3(0.6532,0.7521,1.1242), vec3(0.773,0.7885,0.9429), vec3(0.5058,0.7179,0.4783), vec2(0.8667,0.2188), vec2(0.856,0.2378), vec2(0.7871,0.188), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.4264,0.919,-0.3075), 0.6604, bestT)) {
        if (triHit(ro, rd, vec3(0.579,0.7917,-0.6004), vec3(0.7466,0.6214,-0.7183), vec3(0.5211,0.7828,-0.6301), vec3(0.2373,0.6998,-0.6738), vec2(0.041,0.8383), vec2(0.0387,0.755), vec2(0.0175,0.8508), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4904,0.7376,-0.5767), vec3(0.5211,0.7828,-0.6301), vec3(0.6959,0.5716,-0.7158), vec3(-0.6905,-0.3057,-0.6555), vec2(0.6665,0.0669), vec2(0.6582,0.0444), vec2(0.5928,0.0532), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6092,0.7757,-0.5267), vec3(0.7646,0.6244,-0.6263), vec3(0.579,0.7917,-0.6004), vec3(0.6575,0.7458,-0.1071), vec2(0.0714,0.8306), vec2(0.0676,0.7512), vec2(0.041,0.8383), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.579,0.7917,-0.6004), vec3(0.5211,0.7828,-0.6301), vec3(0.3886,1.0265,-0.5208), vec3(0.3215,0.5274,-0.7865), vec2(0.041,0.8383), vec2(0.0175,0.8508), vec2(0.0388,0.9443), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4669,0.673,-0.5008), vec3(0.4904,0.7376,-0.5767), vec3(0.6973,0.5457,-0.5774), vec3(-0.5236,-0.5621,-0.6403), vec2(0.6753,0.0967), vec2(0.6665,0.0669), vec2(0.6055,0.0903), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6129,0.7673,-0.4086), vec3(0.7646,0.6244,-0.6263), vec3(0.6092,0.7757,-0.5267), vec3(0.7067,0.707,0.0286), vec2(0.113,0.8263), vec2(0.0676,0.7512), vec2(0.0714,0.8306), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4904,0.7376,-0.5767), vec3(0.2986,0.8471,-0.4587), vec3(0.2971,0.9071,-0.5253), vec3(-0.6408,-0.5772,-0.5061), vec2(0.6665,0.0669), vec2(0.7319,0.0942), vec2(0.7339,0.0747), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6092,0.7757,-0.5267), vec3(0.579,0.7917,-0.6004), vec3(0.4492,1.0103,-0.4202), vec3(0.7714,0.6094,-0.1833), vec2(0.0714,0.8306), vec2(0.041,0.8383), vec2(0.0729,0.9232), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3886,1.0265,-0.5208), vec3(0.4492,1.0103,-0.4202), vec3(0.579,0.7917,-0.6004), vec3(0.6858,0.6601,-0.3065), vec2(0.0388,0.9443), vec2(0.0729,0.9232), vec2(0.041,0.8383), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4904,0.7376,-0.5767), vec3(0.4669,0.673,-0.5008), vec3(0.2986,0.8471,-0.4587), vec3(-0.6416,-0.4748,-0.6024), vec2(0.6665,0.0669), vec2(0.6753,0.0967), vec2(0.7319,0.0942), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4669,0.673,-0.5008), vec3(0.6973,0.5457,-0.5774), vec3(0.479,0.647,-0.4371), vec3(-0.5287,-0.8162,-0.233), vec2(0.6753,0.0967), vec2(0.6055,0.0903), vec2(0.6772,0.1162), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3526,1.0047,-0.4359), vec3(0.2838,0.9058,-0.511), vec3(0.3053,1.0334,-0.5155), vec3(0.8229,-0.1576,-0.5459), vec2(0.6636,0.7075), vec2(0.7139,0.6836), vec2(0.6914,0.731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3053,1.0334,-0.5155), vec3(0.2888,1.1559,-0.4891), vec3(0.3526,1.0047,-0.4359), vec3(0.8718,0.2124,-0.4415), vec2(0.6914,0.731), vec2(0.6626,0.7659), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3611,0.7942,-0.3749), vec3(0.2857,0.7538,-0.4936), vec3(0.2599,0.8541,-0.5537), vec3(0.8539,-0.0878,-0.513), vec2(0.9224,0.3472), vec2(0.8813,0.3306), vec2(0.8999,0.3076), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2749,0.6448,-0.5119), vec3(0.3698,0.6006,-0.375), vec3(0.2215,0.5452,-0.5248), vec3(0.7303,-0.3123,-0.6075), vec2(0.8564,0.333), vec2(0.8613,0.3623), vec2(0.8335,0.334), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2888,1.1559,-0.4891), vec3(0.3218,1.1718,-0.3826), vec3(0.3886,1.0265,-0.5208), vec3(0.7126,0.627,-0.3148), vec2(0.0479,0.9786), vec2(0.0743,0.9632), vec2(0.0388,0.9443), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3611,0.7942,-0.3749), vec3(0.2599,0.8541,-0.5537), vec3(0.2986,0.8471,-0.4587), vec3(0.8163,0.4959,-0.2961), vec2(0.9224,0.3472), vec2(0.8999,0.3076), vec2(0.9253,0.3237), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2749,0.6448,-0.5119), vec3(0.2857,0.7538,-0.4936), vec3(0.3698,0.6006,-0.375), vec3(0.8236,0.0135,-0.567), vec2(0.8564,0.333), vec2(0.8813,0.3306), vec2(0.8613,0.3623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2986,0.8471,-0.4587), vec3(0.2838,0.9058,-0.511), vec3(0.3631,0.9697,-0.4108), vec3(0.8302,-0.2397,-0.5033), vec2(0.7051,0.6558), vec2(0.7139,0.6836), vec2(0.6606,0.6909), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3631,0.9697,-0.4108), vec3(0.2838,0.9058,-0.511), vec3(0.3526,1.0047,-0.4359), vec3(0.8201,-0.151,-0.5519), vec2(0.6606,0.6909), vec2(0.7139,0.6836), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6092,0.7757,-0.5267), vec3(0.4492,1.0103,-0.4202), vec3(0.6129,0.7673,-0.4086), vec3(0.829,0.5591,0.0141), vec2(0.0714,0.8306), vec2(0.0729,0.9232), vec2(0.113,0.8263), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2888,1.1559,-0.4891), vec3(0.2145,1.2357,-0.4681), vec3(0.3218,1.1718,-0.3826), vec3(0.6551,0.6905,-0.3066), vec2(0.6626,0.7659), vec2(0.6309,0.8002), vec2(0.625,0.74), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3611,0.7942,-0.3749), vec3(0.2986,0.8471,-0.4587), vec3(0.4669,0.673,-0.5008), vec3(-0.7062,-0.7031,0.0832), vec2(0.7344,0.1177), vec2(0.7319,0.0942), vec2(0.6753,0.0967), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2523,0.5005,-0.4246), vec3(0.2215,0.5452,-0.5248), vec3(0.3698,0.6006,-0.375), vec3(0.6797,-0.5693,-0.4625), vec2(0.8335,0.3569), vec2(0.8335,0.334), vec2(0.8613,0.3623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4492,1.0103,-0.4202), vec3(0.3886,1.0265,-0.5208), vec3(0.3218,1.1718,-0.3826), vec3(0.7052,0.6312,-0.3228), vec2(0.0729,0.9232), vec2(0.0388,0.9443), vec2(0.0743,0.9632), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4669,0.673,-0.5008), vec3(0.479,0.647,-0.4371), vec3(0.3611,0.7942,-0.3749), vec3(-0.796,-0.598,-0.0935), vec2(0.6753,0.0967), vec2(0.6772,0.1162), vec2(0.7344,0.1177), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3218,1.1718,-0.3826), vec3(0.3526,1.0047,-0.4359), vec3(0.2888,1.1559,-0.4891), vec3(0.9076,0.2697,-0.3216), vec2(0.625,0.74), vec2(0.6636,0.7075), vec2(0.6626,0.7659), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.717,0.5541,-0.2672), vec3(0.7646,0.6244,-0.6263), vec3(0.6129,0.7673,-0.4086), vec3(0.8145,0.5394,0.2136), vec2(0.177,0.7528), vec2(0.0676,0.7512), vec2(0.113,0.8263), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2986,0.8471,-0.4587), vec3(0.3631,0.9697,-0.4108), vec3(0.347,0.8328,-0.3789), vec3(0.816,-0.2201,-0.5345), vec2(0.7051,0.6558), vec2(0.6606,0.6909), vec2(0.6782,0.6387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6973,0.5457,-0.5774), vec3(0.6421,0.5536,-0.2143), vec3(0.479,0.647,-0.4371), vec3(-0.4459,-0.8938,-0.0481), vec2(0.6055,0.0903), vec2(0.6597,0.1782), vec2(0.6772,0.1162), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3611,0.7942,-0.3749), vec3(0.2986,0.8471,-0.4587), vec3(0.347,0.8328,-0.3789), vec3(0.8453,0.2606,-0.4664), vec2(0.6948,0.6187), vec2(0.7051,0.6558), vec2(0.6782,0.6387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3631,0.9697,-0.4108), vec3(0.3526,1.0047,-0.4359), vec3(0.3931,1.0878,-0.3236), vec3(0.9344,0.0244,-0.3553), vec2(0.6606,0.6909), vec2(0.6636,0.7075), vec2(0.6216,0.6965), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2523,0.5005,-0.4246), vec3(0.3059,0.4804,-0.3073), vec3(0.1834,0.468,-0.435), vec3(0.4424,-0.8279,-0.3447), vec2(0.8125,0.5249), vec2(0.7827,0.4976), vec2(0.835,0.5125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5204,0.7269,-0.2855), vec3(0.3698,0.6006,-0.375), vec3(0.2857,0.7538,-0.4936), vec3(0.6313,-0.227,-0.7415), vec2(0.8945,0.3745), vec2(0.8613,0.3623), vec2(0.8813,0.3306), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2857,0.7538,-0.4936), vec3(0.3611,0.7942,-0.3749), vec3(0.5204,0.7269,-0.2855), vec3(0.5693,0.5973,-0.565), vec2(0.8813,0.3306), vec2(0.9224,0.3472), vec2(0.8945,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2235,1.2489,-0.295), vec3(0.3218,1.1718,-0.3826), vec3(0.2145,1.2357,-0.4681), vec3(0.5623,0.8219,-0.0918), vec2(0.5781,0.7605), vec2(0.625,0.74), vec2(0.6309,0.8002), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3915,0.9591,-0.3513), vec3(0.347,0.8328,-0.3789), vec3(0.3631,0.9697,-0.4108), vec3(0.8679,-0.2068,-0.4516), vec2(0.6465,0.6724), vec2(0.6782,0.6387), vec2(0.6606,0.6909), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3526,1.0047,-0.4359), vec3(0.3218,1.1718,-0.3826), vec3(0.3203,1.1942,-0.3004), vec3(0.9809,0.1916,-0.0344), vec2(0.6636,0.7075), vec2(0.625,0.74), vec2(0.5986,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2523,0.5005,-0.4246), vec3(0.3698,0.6006,-0.375), vec3(0.3059,0.4804,-0.3073), vec3(0.6848,-0.5982,-0.4161), vec2(0.8335,0.3569), vec2(0.8613,0.3623), vec2(0.8379,0.3799), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3218,1.1718,-0.3826), vec3(0.3203,1.1942,-0.3004), vec3(0.4492,1.0103,-0.4202), vec3(0.757,0.6338,-0.159), vec2(0.0743,0.9632), vec2(0.0942,0.9587), vec2(0.0729,0.9232), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4745,0.7963,-0.2836), vec3(0.3611,0.7942,-0.3749), vec3(0.479,0.647,-0.4371), vec3(-0.4761,-0.6373,0.6059), vec2(0.7378,0.1396), vec2(0.7344,0.1177), vec2(0.6772,0.1162), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3915,0.9591,-0.3513), vec3(0.3631,0.9697,-0.4108), vec3(0.3931,1.0878,-0.3236), vec3(0.9048,0.0787,-0.4186), vec2(0.6465,0.6724), vec2(0.6606,0.6909), vec2(0.6216,0.6965), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3931,1.0878,-0.3236), vec3(0.3526,1.0047,-0.4359), vec3(0.3203,1.1942,-0.3004), vec3(0.5876,0.5344,-0.6076), vec2(0.6216,0.6965), vec2(0.6636,0.7075), vec2(0.5986,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5,1.065,-0.2303), vec3(0.6129,0.7673,-0.4086), vec3(0.4492,1.0103,-0.4202), vec3(0.7828,0.5102,-0.3564), vec2(0.1307,0.9007), vec2(0.113,0.8263), vec2(0.0729,0.9232), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0774,1.258,-0.472), vec3(0.0547,1.2888,-0.2749), vec3(0.2235,1.2489,-0.295), vec3(0.214,0.9686,-0.1266), vec2(0.605,0.8419), vec2(0.541,0.8092), vec2(0.5781,0.7605), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3611,0.7942,-0.3749), vec3(0.347,0.8328,-0.3789), vec3(0.4745,0.7963,-0.2836), vec3(0.6189,0.1468,-0.7716), vec2(0.6948,0.6187), vec2(0.6782,0.6387), vec2(0.6768,0.592), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.409,0.5869,-0.2991), vec3(0.3059,0.4804,-0.3073), vec3(0.3698,0.6006,-0.375), vec3(0.6595,-0.6031,-0.4487), vec2(0.8633,0.3774), vec2(0.8379,0.3799), vec2(0.8613,0.3623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3218,1.1718,-0.3826), vec3(0.2235,1.2489,-0.295), vec3(0.3203,1.1942,-0.3004), vec3(0.4696,0.8539,-0.2241), vec2(0.625,0.74), vec2(0.5781,0.7605), vec2(0.5986,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3698,0.6006,-0.375), vec3(0.5204,0.7269,-0.2855), vec3(0.409,0.5869,-0.2991), vec3(0.7149,-0.524,-0.463), vec2(0.8613,0.3623), vec2(0.8945,0.3745), vec2(0.8633,0.3774), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5,1.065,-0.2303), vec3(0.4492,1.0103,-0.4202), vec3(0.3203,1.1942,-0.3004), vec3(0.6332,0.682,-0.3659), vec2(0.1307,0.9007), vec2(0.0729,0.9232), vec2(0.0942,0.9587), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4745,0.7963,-0.2836), vec3(0.5204,0.7269,-0.2855), vec3(0.3611,0.7942,-0.3749), vec3(0.571,0.3978,-0.7181), vec2(0.9258,0.3682), vec2(0.8945,0.3745), vec2(0.9224,0.3472), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.347,0.8328,-0.3789), vec3(0.3915,0.9591,-0.3513), vec3(0.5271,0.9793,-0.1694), vec3(0.8002,-0.1551,-0.5793), vec2(0.6782,0.6387), vec2(0.6465,0.6724), vec2(0.6128,0.6121), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.479,0.647,-0.4371), vec3(0.5875,0.8923,-0.1386), vec3(0.4745,0.7963,-0.2836), vec3(-0.2667,-0.6948,0.6679), vec2(0.6772,0.1162), vec2(0.7397,0.1714), vec2(0.7378,0.1396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3931,1.0878,-0.3236), vec3(0.4692,1.0861,-0.173), vec3(0.3915,0.9591,-0.3513), vec3(0.8897,0.0853,-0.4486), vec2(0.6216,0.6965), vec2(0.5923,0.6455), vec2(0.6465,0.6724), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5271,0.9793,-0.1694), vec3(0.4745,0.7963,-0.2836), vec3(0.347,0.8328,-0.3789), vec3(0.625,0.2761,-0.7302), vec2(0.6128,0.6121), vec2(0.6768,0.592), vec2(0.6782,0.6387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3931,1.0878,-0.3236), vec3(0.3203,1.1942,-0.3004), vec3(0.4079,1.1731,-0.1494), vec3(0.7373,0.5799,-0.3466), vec2(0.6216,0.6965), vec2(0.5986,0.7261), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6119,0.7612,-0.11), vec3(0.479,0.647,-0.4371), vec3(0.6421,0.5536,-0.2143), vec3(-0.8199,-0.348,0.4547), vec2(0.7031,0.1914), vec2(0.6772,0.1162), vec2(0.6597,0.1782), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6514,0.8346,-0.0829), vec3(0.717,0.5541,-0.2672), vec3(0.6129,0.7673,-0.4086), vec3(0.9257,0.3337,-0.1784), vec2(0.2054,0.8118), vec2(0.177,0.7528), vec2(0.113,0.8263), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3203,1.1942,-0.3004), vec3(0.2235,1.2489,-0.295), vec3(0.3107,1.2282,-0.1267), vec3(0.4805,0.8653,-0.1427), vec2(0.5986,0.7261), vec2(0.5781,0.7605), vec2(0.5479,0.6924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6129,0.7673,-0.4086), vec3(0.5,1.065,-0.2303), vec3(0.6514,0.8346,-0.0829), vec3(0.8724,0.448,-0.1957), vec2(0.113,0.8263), vec2(0.1307,0.9007), vec2(0.2054,0.8118), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.409,0.5869,-0.2991), vec3(0.5204,0.7269,-0.2855), vec3(0.465,0.5835,-0.1263), vec3(0.7677,-0.5856,-0.2602), vec2(0.8633,0.3774), vec2(0.8945,0.3745), vec2(0.876,0.4189), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4692,1.0861,-0.173), vec3(0.5271,0.9793,-0.1694), vec3(0.3915,0.9591,-0.3513), vec3(0.7237,0.3725,-0.5809), vec2(0.5923,0.6455), vec2(0.6128,0.6121), vec2(0.6465,0.6724), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6119,0.7612,-0.11), vec3(0.5875,0.8923,-0.1386), vec3(0.479,0.647,-0.4371), vec3(-0.9129,-0.0828,0.3998), vec2(0.7031,0.1914), vec2(0.7397,0.1714), vec2(0.6772,0.1162), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5204,0.7269,-0.2855), vec3(0.4745,0.7963,-0.2836), vec3(0.5817,0.7687,-0.1105), vec3(0.7629,0.5156,-0.3901), vec2(0.8945,0.3745), vec2(0.9258,0.3682), vec2(0.9102,0.4072), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0547,1.2888,-0.2749), vec3(0.2046,1.25,-0.0969), vec3(0.2235,1.2489,-0.295), vec3(0.232,0.9726,0.0167), vec2(0.541,0.8092), vec2(0.5176,0.7183), vec2(0.5781,0.7605), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5,1.065,-0.2303), vec3(0.3203,1.1942,-0.3004), vec3(0.3107,1.2282,-0.1267), vec3(0.61,0.7833,-0.1195), vec2(0.1307,0.9007), vec2(0.0942,0.9587), vec2(0.1346,0.9552), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4079,1.1731,-0.1494), vec3(0.4692,1.0861,-0.173), vec3(0.3931,1.0878,-0.3236), vec3(0.7161,0.6009,-0.3551), vec2(0.5713,0.667), vec2(0.5923,0.6455), vec2(0.6216,0.6965), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4745,0.7963,-0.2836), vec3(0.5271,0.9793,-0.1694), vec3(0.5875,0.8923,-0.1386), vec3(0.6864,0.2327,-0.6889), vec2(0.6768,0.592), vec2(0.6128,0.6121), vec2(0.6313,0.5754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3107,1.2282,-0.1267), vec3(0.4079,1.1731,-0.1494), vec3(0.3203,1.1942,-0.3004), vec3(0.4622,0.8747,-0.1456), vec2(0.5479,0.6924), vec2(0.5713,0.667), vec2(0.5986,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5875,0.8923,-0.1386), vec3(0.5817,0.7687,-0.1105), vec3(0.4745,0.7963,-0.2836), vec3(0.8274,-0.161,-0.538), vec2(0.9443,0.3955), vec2(0.9102,0.4072), vec2(0.9258,0.3682), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5817,0.7687,-0.1105), vec3(0.465,0.5835,-0.1263), vec3(0.5204,0.7269,-0.2855), vec3(0.84,-0.5149,-0.1713), vec2(0.9102,0.4072), vec2(0.876,0.4189), vec2(0.8945,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2046,1.25,-0.0969), vec3(0.3107,1.2282,-0.1267), vec3(0.2235,1.2489,-0.295), vec3(0.2048,0.9787,0.0141), vec2(0.5176,0.7183), vec2(0.5479,0.6924), vec2(0.5781,0.7605), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0547,1.2888,-0.2749), vec3(0.0525,1.2574,-0.0752), vec3(0.2046,1.25,-0.0969), vec3(0.0702,0.9853,0.1557), vec2(0.541,0.8092), vec2(0.4724,0.7621), vec2(0.5176,0.7183), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5809,1.1418,0.0118), vec3(0.5,1.065,-0.2303), vec3(0.3107,1.2282,-0.1267), vec3(0.4601,0.7904,-0.4045), vec2(0.1959,0.8832), vec2(0.1307,0.9007), vec2(0.1346,0.9552), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5271,0.9793,-0.1694), vec3(0.4692,1.0861,-0.173), vec3(0.5363,1.0889,0.0264), vec3(0.8452,0.4484,-0.2907), vec2(0.6128,0.6121), vec2(0.5923,0.6455), vec2(0.5581,0.5881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5809,1.1418,0.0118), vec3(0.6514,0.8346,-0.0829), vec3(0.5,1.065,-0.2303), vec3(0.8641,0.3183,-0.3899), vec2(0.1959,0.8832), vec2(0.2054,0.8118), vec2(0.1307,0.9007), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4079,1.1731,-0.1494), vec3(0.4651,1.148,0.0386), vec3(0.4692,1.0861,-0.173), vec3(0.7861,0.5972,-0.1595), vec2(0.5713,0.667), vec2(0.54,0.6082), vec2(0.5923,0.6455), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5875,0.8923,-0.1386), vec3(0.5271,0.9793,-0.1694), vec3(0.5685,0.9389,0.0708), vec3(0.8284,0.558,-0.0488), vec2(0.6313,0.5754), vec2(0.6128,0.6121), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5817,0.7687,-0.1105), vec3(0.5875,0.8923,-0.1386), vec3(0.5875,0.8021,0.0289), vec3(0.9982,-0.0534,-0.0287), vec2(0.9102,0.4072), vec2(0.9443,0.3955), vec2(0.9219,0.4341), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3107,1.2282,-0.1267), vec3(0.4018,1.181,0.0636), vec3(0.4079,1.1731,-0.1494), vec3(0.4901,0.8715,-0.0182), vec2(0.5479,0.6924), vec2(0.522,0.6201), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6119,0.7612,-0.11), vec3(0.5685,0.9389,0.0708), vec3(0.5875,0.8923,-0.1386), vec3(-0.9802,-0.1925,-0.0463), vec2(0.7031,0.1914), vec2(0.7583,0.21), vec2(0.7397,0.1714), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2046,1.25,-0.0969), vec3(0.2894,1.2094,0.101), vec3(0.3107,1.2282,-0.1267), vec3(0.2273,0.9685,0.1015), vec2(0.5176,0.7183), vec2(0.4873,0.6418), vec2(0.5479,0.6924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4651,1.148,0.0386), vec3(0.5363,1.0889,0.0264), vec3(0.4692,1.0861,-0.173), vec3(0.6021,0.7693,-0.2135), vec2(0.54,0.6082), vec2(0.5581,0.5881), vec2(0.5923,0.6455), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5363,1.0889,0.0264), vec3(0.5685,0.9389,0.0708), vec3(0.5271,0.9793,-0.1694), vec3(0.9758,0.168,-0.1398), vec2(0.5581,0.5881), vec2(0.5757,0.5515), vec2(0.6128,0.6121), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4018,1.181,0.0636), vec3(0.4651,1.148,0.0386), vec3(0.4079,1.1731,-0.1494), vec3(0.4552,0.8902,-0.0199), vec2(0.522,0.6201), vec2(0.54,0.6082), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5685,0.9389,0.0708), vec3(0.5875,0.8021,0.0289), vec3(0.5875,0.8923,-0.1386), vec3(0.9909,0.1183,0.0638), vec2(0.9639,0.4326), vec2(0.9219,0.4341), vec2(0.9443,0.3955), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3107,1.2282,-0.1267), vec3(0.2894,1.2094,0.101), vec3(0.5809,1.1418,0.0118), vec3(0.2546,0.9615,0.1035), vec2(0.1346,0.9552), vec2(0.187,0.9585), vec2(0.1959,0.8832), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3107,1.2282,-0.1267), vec3(0.2894,1.2094,0.101), vec3(0.4018,1.181,0.0636), vec3(0.2761,0.9554,0.105), vec2(0.5479,0.6924), vec2(0.4873,0.6418), vec2(0.522,0.6201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6514,0.8346,-0.0829), vec3(0.5809,1.1418,0.0118), vec3(0.8299,0.9754,0.1343), vec3(0.5939,0.3582,-0.7204), vec2(0.2054,0.8118), vec2(0.1959,0.8832), vec2(0.2583,0.8077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6119,0.7612,-0.11), vec3(0.8374,0.9354,0.1435), vec3(0.5685,0.9389,0.0708), vec3(-0.1892,-0.7227,0.6648), vec2(0.7031,0.1914), vec2(0.7188,0.2417), vec2(0.7583,0.21), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2046,1.25,-0.0969), vec3(0.2036,1.2155,0.106), vec3(0.2894,1.2094,0.101), vec3(0.0805,0.9826,0.1673), vec2(0.5176,0.7183), vec2(0.4646,0.6636), vec2(0.4873,0.6418), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.4257,0.2634,0.0165), 0.6018, bestT)) {
        if (triHit(ro, rd, vec3(0.1834,0.468,-0.435), vec3(0.1955,0.4342,-0.3442), vec3(0.0263,0.4056,-0.3337), vec3(0.1337,-0.9229,-0.3611), vec2(0.835,0.5125), vec2(0.811,0.4814), vec2(0.8599,0.4399), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0263,0.4056,-0.3337), vec3(0.1955,0.4342,-0.3442), vec3(0.0277,0.3772,-0.1851), vec3(0.1525,-0.9705,-0.1869), vec2(0.8599,0.4399), vec2(0.811,0.4814), vec2(0.8193,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2086,0.4134,-0.2086), vec3(0.0277,0.3772,-0.1851), vec3(0.1955,0.4342,-0.3442), vec3(0.1726,-0.9709,-0.1659), vec2(0.7788,0.4385), vec2(0.8193,0.3926), vec2(0.811,0.4814), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2086,0.4134,-0.2086), vec3(0.0322,0.3742,-0.0258), vec3(0.0277,0.3772,-0.1851), vec3(0.1929,-0.9809,-0.0244), vec2(0.7788,0.4385), vec2(0.7695,0.3516), vec2(0.8193,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2086,0.4134,-0.2086), vec3(0.2652,0.4255,-0.0794), vec3(0.0322,0.3742,-0.0258), vec3(0.2145,-0.9767,-0.0027), vec2(0.7788,0.4385), vec2(0.7344,0.4028), vec2(0.7695,0.3516), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2652,0.4255,-0.0794), vec3(0.2307,0.4111,0.0002), vec3(0.0322,0.3742,-0.0258), vec3(0.1937,-0.9766,-0.0931), vec2(0.7344,0.4028), vec2(0.7188,0.3711), vec2(0.7695,0.3516), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4661,0.3639,-0.0127), vec3(0.4837,0.3714,-0.0075), vec3(0.4833,0.3036,0.0019), vec3(0.3282,-0.1325,-0.9353), vec2(0.0582,0.3647), vec2(0.0585,0.3501), vec2(0.0958,0.3643), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4808,0.215,-0.0131), vec3(0.4816,0.2795,0.0069), vec3(0.4988,0.2178,-0.0088), vec3(0.1806,0.2896,-0.94), vec2(0.6602,0.9415), vec2(0.6816,0.9366), vec2(0.6611,0.947), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4993,0.3084,0.0035), vec3(0.4833,0.3036,0.0019), vec3(0.4837,0.3714,-0.0075), vec3(0.1391,-0.1375,-0.9807), vec2(0.096,0.353), vec2(0.0958,0.3643), vec2(0.0585,0.3501), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,0.3036,0.0019), vec3(0.4707,0.3135,0.013), vec3(0.4661,0.3639,-0.0127), vec3(-0.7602,-0.3484,-0.5484), vec2(0.0958,0.3643), vec2(0.0944,0.377), vec2(0.0582,0.3647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4517,0.3701,0.0033), vec3(0.4661,0.3639,-0.0127), vec3(0.4707,0.3135,0.013), vec3(-0.7568,-0.35,-0.552), vec2(0.0557,0.3804), vec2(0.0582,0.3647), vec2(0.0944,0.377), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4749,0.2095,0.0026), vec3(0.4701,0.2626,0.0155), vec3(0.4808,0.215,-0.0131), vec3(-0.9362,0.0001,-0.3514), vec2(0.6597,0.9368), vec2(0.6738,0.9299), vec2(0.6602,0.9415), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4816,0.2795,0.0069), vec3(0.4996,0.2846,0.0073), vec3(0.4988,0.2178,-0.0088), vec3(-0.041,0.2357,-0.971), vec2(0.6816,0.9366), vec2(0.6851,0.9453), vec2(0.6611,0.947), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4816,0.2795,0.0069), vec3(0.4808,0.215,-0.0131), vec3(0.4701,0.2626,0.0155), vec3(-0.7581,0.2018,-0.6201), vec2(0.6816,0.9366), vec2(0.6602,0.9415), vec2(0.6738,0.9299), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4833,0.3036,0.0019), vec3(0.4993,0.3084,0.0035), vec3(0.4996,0.2846,0.0073), vec3(0.1442,-0.1559,-0.9772), vec2(0.6899,0.9363), vec2(0.6929,0.9417), vec2(0.6851,0.9453), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.507,0.2494,0.016), vec3(0.4988,0.2178,-0.0088), vec3(0.4996,0.2846,0.0073), vec3(0.9066,0.0891,-0.4124), vec2(0.6699,0.9569), vec2(0.6611,0.947), vec2(0.6851,0.9453), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.505,0.3131,0.0197), vec3(0.4993,0.3084,0.0035), vec3(0.4837,0.3714,-0.0075), vec3(0.9146,0.1615,-0.3706), vec2(0.1024,0.3428), vec2(0.096,0.353), vec2(0.0585,0.3501), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4816,0.2795,0.0069), vec3(0.4833,0.3036,0.0019), vec3(0.4996,0.2846,0.0073), vec3(0.0845,-0.2066,-0.9748), vec2(0.6816,0.9366), vec2(0.6899,0.9363), vec2(0.6851,0.9453), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4816,0.2795,0.0069), vec3(0.4707,0.2891,0.0132), vec3(0.4833,0.3036,0.0019), vec3(-0.5763,-0.1267,-0.8073), vec2(0.6816,0.9366), vec2(0.686,0.9303), vec2(0.6899,0.9363), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4707,0.3135,0.013), vec3(0.4833,0.3036,0.0019), vec3(0.4707,0.2891,0.0132), vec3(-0.6634,-0.0046,-0.7483), vec2(0.6948,0.9307), vec2(0.6899,0.9363), vec2(0.686,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0275,0.3842,0.0553), vec3(0.0322,0.3742,-0.0258), vec3(0.2307,0.4111,0.0002), vec3(0.1647,-0.9777,0.1301), vec2(0.7422,0.335), vec2(0.7695,0.3516), vec2(0.7188,0.3711), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4996,0.2846,0.0073), vec3(0.4993,0.3084,0.0035), vec3(0.505,0.3131,0.0197), vec3(0.9459,-0.0405,-0.322), vec2(0.6851,0.9453), vec2(0.6929,0.9417), vec2(0.6978,0.946), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5266,0.2677,0.016), vec3(0.5191,0.2571,0.0087), vec3(0.4996,0.2846,0.0073), vec3(0.448,0.2764,-0.8503), vec2(0.6841,0.9601), vec2(0.6777,0.96), vec2(0.6851,0.9453), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5191,0.2571,0.0087), vec3(0.507,0.2494,0.016), vec3(0.4996,0.2846,0.0073), vec3(-0.3521,-0.2933,-0.8888), vec2(0.6777,0.96), vec2(0.6699,0.9569), vec2(0.6851,0.9453), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4701,0.2626,0.0155), vec3(0.4707,0.2891,0.0132), vec3(0.4816,0.2795,0.0069), vec3(-0.5379,-0.0613,-0.8408), vec2(0.6738,0.9299), vec2(0.686,0.9303), vec2(0.6816,0.9366), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4701,0.2152,0.0201), vec3(0.4701,0.2626,0.0155), vec3(0.4749,0.2095,0.0026), vec3(-0.9657,-0.0251,-0.2585), vec2(0.6616,0.9326), vec2(0.6738,0.9299), vec2(0.6597,0.9368), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4141,0.2222,0.0099), vec3(0.4066,0.2321,0.0153), vec3(0.4546,0.2739,0.016), vec3(-0.2541,0.307,-0.9172), vec2(0.6709,0.9054), vec2(0.6733,0.9051), vec2(0.6787,0.9224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4996,0.2846,0.0073), vec3(0.505,0.3131,0.0197), vec3(0.5266,0.2677,0.016), vec3(0.4498,0.2806,-0.8479), vec2(0.6851,0.9453), vec2(0.6978,0.946), vec2(0.6841,0.9601), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4707,0.3135,0.013), vec3(0.4704,0.3408,0.0268), vec3(0.4517,0.3701,0.0033), vec3(-0.8776,-0.223,0.4243), vec2(0.1046,0.3081), vec2(0.0872,0.3154), vec2(0.0678,0.2944), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4546,0.2739,0.016), vec3(0.4707,0.2891,0.0132), vec3(0.4701,0.2626,0.0155), vec3(-0.0951,-0.084,-0.9919), vec2(0.6787,0.9224), vec2(0.686,0.9303), vec2(0.6738,0.9299), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4066,0.2321,0.0153), vec3(0.4141,0.2222,0.0099), vec3(0.3922,0.213,0.0201), vec3(-0.4623,0.1284,-0.8774), vec2(0.6733,0.9051), vec2(0.6709,0.9054), vec2(0.6719,0.9022), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3974,0.2063,0.0165), vec3(0.3922,0.213,0.0201), vec3(0.4141,0.2222,0.0099), vec3(-0.4588,0.1163,-0.8809), vec2(0.6709,0.9019), vec2(0.6719,0.9022), vec2(0.6709,0.9054), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3974,0.2063,0.0165), vec3(0.4141,0.2222,0.0099), vec3(0.416,0.2133,0.0202), vec3(0.3789,-0.6648,-0.6438), vec2(0.6709,0.9019), vec2(0.6709,0.9054), vec2(0.6689,0.9045), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.507,0.2494,0.016), vec3(0.5191,0.2571,0.0087), vec3(0.5141,0.2452,0.022), vec3(0.0925,-0.7595,-0.6439), vec2(0.6699,0.9569), vec2(0.6777,0.96), vec2(0.6714,0.9616), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3997,0.2244,0.0166), vec3(0.4065,0.2152,0.0124), vec3(0.3895,0.2098,0.0177), vec3(-0.3433,0.165,-0.9246), vec2(0.8047,0.0571), vec2(0.7988,0.0571), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3997,0.2244,0.0166), vec3(0.4065,0.2152,0.0124), vec3(0.3895,0.2098,0.0177), vec3(-0.3433,0.165,-0.9246), vec2(0.8047,0.0571), vec2(0.7988,0.0571), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3953,0.2027,0.0174), vec3(0.3895,0.2098,0.0177), vec3(0.4065,0.2152,0.0124), vec3(-0.2494,-0.1578,-0.9555), vec2(0.7993,0.0498), vec2(0.8022,0.0503), vec2(0.7988,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3953,0.2027,0.0174), vec3(0.3895,0.2098,0.0177), vec3(0.4065,0.2152,0.0124), vec3(-0.2494,-0.1578,-0.9555), vec2(0.7993,0.0498), vec2(0.8022,0.0503), vec2(0.7988,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4546,0.2739,0.016), vec3(0.4494,0.2827,0.0189), vec3(0.4707,0.2891,0.0132), vec3(-0.2939,0.1342,-0.9464), vec2(0.6787,0.9224), vec2(0.6831,0.9197), vec2(0.686,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4059,0.2047,0.0203), vec3(0.3953,0.2027,0.0174), vec3(0.4065,0.2152,0.0124), vec3(0.3119,-0.5813,-0.7515), vec2(0.7954,0.0522), vec2(0.7993,0.0498), vec2(0.7988,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4059,0.2047,0.0203), vec3(0.3953,0.2027,0.0174), vec3(0.4065,0.2152,0.0124), vec3(0.3119,-0.5813,-0.7515), vec2(0.7954,0.0522), vec2(0.7993,0.0498), vec2(0.7988,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4494,0.2827,0.0189), vec3(0.4546,0.2739,0.016), vec3(0.4066,0.2321,0.0153), vec3(-0.1708,0.2121,-0.9622), vec2(0.6831,0.9197), vec2(0.6787,0.9224), vec2(0.6733,0.9051), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3997,0.2244,0.0166), vec3(0.3953,0.2205,0.0241), vec3(0.4065,0.2152,0.0124), vec3(0.7521,0.2874,0.5931), vec2(0.8066,0.0532), vec2(0.8047,0.0469), vec2(0.8047,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3997,0.2244,0.0166), vec3(0.3953,0.2205,0.0241), vec3(0.4065,0.2152,0.0124), vec3(0.7521,0.2874,0.5931), vec2(0.8066,0.0532), vec2(0.8047,0.0469), vec2(0.8047,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4585,0.2638,0.028), vec3(0.4141,0.2222,0.0099), vec3(0.4546,0.2739,0.016), vec3(0.6644,-0.4499,-0.5968), vec2(0.6729,0.9229), vec2(0.6709,0.9054), vec2(0.6787,0.9224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4863,0.3452,0.028), vec3(0.505,0.3131,0.0197), vec3(0.4855,0.3844,0.0085), vec3(0.7658,0.2984,0.5697), vec2(0.085,0.3262), vec2(0.1024,0.3428), vec2(0.054,0.3354), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4598,0.3152,0.0302), vec3(0.4707,0.3135,0.013), vec3(0.4707,0.2891,0.0132), vec3(-0.8443,-0.0026,-0.5359), vec2(0.6978,0.9262), vec2(0.6948,0.9307), vec2(0.686,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4059,0.2047,0.0203), vec3(0.4065,0.2152,0.0124), vec3(0.3953,0.2205,0.0241), vec3(0.7475,0.3709,0.5511), vec2(0.7988,0.0571), vec2(0.8047,0.0571), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4059,0.2047,0.0203), vec3(0.4065,0.2152,0.0124), vec3(0.3953,0.2205,0.0241), vec3(0.7475,0.3709,0.5511), vec2(0.7988,0.0571), vec2(0.8047,0.0571), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4141,0.2222,0.0099), vec3(0.4585,0.2638,0.028), vec3(0.416,0.2133,0.0202), vec3(0.6802,-0.4888,-0.5463), vec2(0.6709,0.9054), vec2(0.6729,0.9229), vec2(0.6689,0.9045), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3895,0.2098,0.0177), vec3(0.3953,0.2205,0.0241), vec3(0.3997,0.2244,0.0166), vec3(-0.8145,0.5491,-0.1873), vec2(0.8022,0.0503), vec2(0.8066,0.0532), vec2(0.8047,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3895,0.2098,0.0177), vec3(0.3953,0.2205,0.0241), vec3(0.3997,0.2244,0.0166), vec3(-0.8145,0.5491,-0.1873), vec2(0.8022,0.0503), vec2(0.8066,0.0532), vec2(0.8047,0.0571), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4546,0.2739,0.016), vec3(0.4701,0.2626,0.0155), vec3(0.4585,0.2638,0.028), vec3(-0.5408,-0.7198,-0.4352), vec2(0.6787,0.9224), vec2(0.6738,0.9299), vec2(0.6729,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4546,0.2739,0.016), vec3(0.4701,0.2626,0.0155), vec3(0.4585,0.2638,0.028), vec3(-0.5408,-0.7198,-0.4352), vec2(0.6787,0.9224), vec2(0.6738,0.9299), vec2(0.6729,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3974,0.2063,0.0165), vec3(0.416,0.2133,0.0202), vec3(0.4001,0.1989,0.0229), vec3(0.3539,-0.5315,-0.7696), vec2(0.6709,0.9019), vec2(0.6689,0.9045), vec2(0.6699,0.8994), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4019,0.2331,0.0271), vec3(0.4494,0.2827,0.0189), vec3(0.4066,0.2321,0.0153), vec3(-0.708,0.6226,-0.3334), vec2(0.6748,0.9036), vec2(0.6831,0.9197), vec2(0.6733,0.9051), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4059,0.2047,0.0203), vec3(0.4024,0.198,0.024), vec3(0.3953,0.2027,0.0174), vec3(0.3121,-0.5741,-0.7569), vec2(0.7954,0.0522), vec2(0.7954,0.0483), vec2(0.7993,0.0498), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4059,0.2047,0.0203), vec3(0.4024,0.198,0.024), vec3(0.3953,0.2027,0.0174), vec3(0.3121,-0.5741,-0.7569), vec2(0.7954,0.0522), vec2(0.7954,0.0483), vec2(0.7993,0.0498), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4598,0.3152,0.0302), vec3(0.4707,0.2891,0.0132), vec3(0.4494,0.2827,0.0189), vec3(-0.3491,0.4056,-0.8448), vec2(0.6978,0.9262), vec2(0.686,0.9303), vec2(0.6831,0.9197), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4066,0.2321,0.0153), vec3(0.3922,0.213,0.0201), vec3(0.4019,0.2331,0.0271), vec3(-0.787,0.5043,-0.3554), vec2(0.6733,0.9051), vec2(0.6719,0.9022), vec2(0.6748,0.9036), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3953,0.2027,0.0174), vec3(0.3901,0.1968,0.0283), vec3(0.3895,0.2098,0.0177), vec3(-0.6446,-0.4981,-0.58), vec2(0.7993,0.0498), vec2(0.7998,0.0454), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3953,0.2027,0.0174), vec3(0.3901,0.1968,0.0283), vec3(0.3895,0.2098,0.0177), vec3(-0.6446,-0.4981,-0.58), vec2(0.7993,0.0498), vec2(0.7998,0.0454), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3922,0.213,0.0201), vec3(0.3974,0.2063,0.0165), vec3(0.3903,0.2123,0.0276), vec3(-0.8257,-0.4967,-0.2674), vec2(0.6719,0.9022), vec2(0.6709,0.9019), vec2(0.6724,0.9015), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3922,0.213,0.0201), vec3(0.3974,0.2063,0.0165), vec3(0.3903,0.2123,0.0276), vec3(-0.8257,-0.4967,-0.2674), vec2(0.6719,0.9022), vec2(0.6709,0.9019), vec2(0.6724,0.9015), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4001,0.1989,0.0229), vec3(0.3903,0.2123,0.0276), vec3(0.3974,0.2063,0.0165), vec3(-0.8199,-0.5126,-0.255), vec2(0.6699,0.8994), vec2(0.6724,0.9015), vec2(0.6709,0.9019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4001,0.1989,0.0229), vec3(0.3903,0.2123,0.0276), vec3(0.3974,0.2063,0.0165), vec3(-0.8199,-0.5126,-0.255), vec2(0.6699,0.8994), vec2(0.6724,0.9015), vec2(0.6709,0.9019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5308,0.2703,0.0328), vec3(0.5266,0.2677,0.016), vec3(0.505,0.3131,0.0197), vec3(0.8579,0.4289,-0.2831), vec2(0.6904,0.9625), vec2(0.6841,0.9601), vec2(0.6978,0.946), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3953,0.2027,0.0174), vec3(0.4024,0.198,0.024), vec3(0.3901,0.1968,0.0283), vec3(-0.0992,-0.8522,-0.5137), vec2(0.7993,0.0498), vec2(0.7954,0.0483), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3953,0.2027,0.0174), vec3(0.4024,0.198,0.024), vec3(0.3901,0.1968,0.0283), vec3(-0.0992,-0.8522,-0.5137), vec2(0.7993,0.0498), vec2(0.7954,0.0483), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4701,0.2626,0.0155), vec3(0.4701,0.2152,0.0201), vec3(0.4786,0.2751,0.0358), vec3(-0.9287,0.0358,0.369), vec2(0.6738,0.9299), vec2(0.6616,0.9326), vec2(0.6704,0.9276), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3875,0.2087,0.03), vec3(0.3953,0.2205,0.0241), vec3(0.3895,0.2098,0.0177), vec3(-0.8508,0.5162,-0.0986), vec2(0.8047,0.0469), vec2(0.8066,0.0532), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3875,0.2087,0.03), vec3(0.3953,0.2205,0.0241), vec3(0.3895,0.2098,0.0177), vec3(-0.8508,0.5162,-0.0986), vec2(0.8047,0.0469), vec2(0.8066,0.0532), vec2(0.8022,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4059,0.2047,0.0203), vec3(0.3875,0.2087,0.03), vec3(0.4024,0.198,0.024), vec3(0.4879,0.2025,0.8491), vec2(0.7988,0.0571), vec2(0.8008,0.0405), vec2(0.7954,0.0522), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4059,0.2047,0.0203), vec3(0.3875,0.2087,0.03), vec3(0.4024,0.198,0.024), vec3(0.4879,0.2025,0.8491), vec2(0.7988,0.0571), vec2(0.8008,0.0405), vec2(0.7954,0.0522), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3875,0.2087,0.03), vec3(0.4059,0.2047,0.0203), vec3(0.3953,0.2205,0.0241), vec3(0.4798,0.1159,0.8697), vec2(0.8008,0.0405), vec2(0.7988,0.0571), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3875,0.2087,0.03), vec3(0.4059,0.2047,0.0203), vec3(0.3953,0.2205,0.0241), vec3(0.4798,0.1159,0.8697), vec2(0.8008,0.0405), vec2(0.7988,0.0571), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4001,0.1989,0.0229), vec3(0.416,0.2133,0.0202), vec3(0.4015,0.2021,0.0314), vec3(0.6793,-0.7155,0.1632), vec2(0.6699,0.8994), vec2(0.6689,0.9045), vec2(0.668,0.8992), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3857,0.2004,0.0285), vec3(0.3895,0.2098,0.0177), vec3(0.3901,0.1968,0.0283), vec3(-0.4943,-0.5606,-0.6643), vec2(0.8018,0.0459), vec2(0.8022,0.0503), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3857,0.2004,0.0285), vec3(0.3895,0.2098,0.0177), vec3(0.3901,0.1968,0.0283), vec3(-0.4943,-0.5606,-0.6643), vec2(0.8018,0.0459), vec2(0.8022,0.0503), vec2(0.7998,0.0454), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3903,0.2123,0.0276), vec3(0.4019,0.2331,0.0271), vec3(0.3922,0.213,0.0201), vec3(-0.8589,0.4785,-0.1825), vec2(0.6724,0.9015), vec2(0.6748,0.9036), vec2(0.6719,0.9022), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3875,0.2087,0.03), vec3(0.3895,0.2098,0.0177), vec3(0.3857,0.2004,0.0285), vec3(-0.9628,0.2291,-0.1436), vec2(0.8047,0.0469), vec2(0.8022,0.0503), vec2(0.8018,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3875,0.2087,0.03), vec3(0.3895,0.2098,0.0177), vec3(0.3857,0.2004,0.0285), vec3(-0.9628,0.2291,-0.1436), vec2(0.8047,0.0469), vec2(0.8022,0.0503), vec2(0.8018,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.507,0.2494,0.016), vec3(0.496,0.2738,0.0379), vec3(0.497,0.2163,0.0246), vec3(0.8325,-0.1111,0.5428), vec2(0.6699,0.9569), vec2(0.6597,0.9627), vec2(0.6626,0.9553), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4704,0.3408,0.0268), vec3(0.4707,0.3135,0.013), vec3(0.4649,0.3452,0.039), vec3(-0.8525,0.2293,-0.4698), vec2(0.7031,0.933), vec2(0.6948,0.9307), vec2(0.7095,0.9249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4585,0.2638,0.028), vec3(0.4701,0.2626,0.0155), vec3(0.4786,0.2751,0.0358), vec3(0.333,-0.8595,0.3878), vec2(0.6729,0.9229), vec2(0.6738,0.9299), vec2(0.6694,0.9261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4701,0.2152,0.0201), vec3(0.497,0.2163,0.0246), vec3(0.4786,0.2751,0.0358), vec3(-0.1513,-0.2308,0.9612), vec2(0.6616,0.9326), vec2(0.6616,0.9293), vec2(0.6704,0.9276), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5141,0.2452,0.022), vec3(0.5123,0.2535,0.0426), vec3(0.507,0.2494,0.016), vec3(-0.6421,-0.7287,0.2382), vec2(0.6714,0.9616), vec2(0.667,0.9621), vec2(0.6699,0.9569), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.416,0.2133,0.0202), vec3(0.4585,0.2638,0.028), vec3(0.4187,0.2183,0.0329), vec3(0.7541,-0.6498,0.0955), vec2(0.6689,0.9045), vec2(0.6729,0.9229), vec2(0.666,0.9059), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4015,0.2021,0.0314), vec3(0.3903,0.2123,0.0276), vec3(0.4001,0.1989,0.0229), vec3(-0.6897,-0.6297,0.3576), vec2(0.6724,0.8991), vec2(0.6724,0.9015), vec2(0.6699,0.8994), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4015,0.2021,0.0314), vec3(0.3903,0.2123,0.0276), vec3(0.4001,0.1989,0.0229), vec3(-0.6897,-0.6297,0.3576), vec2(0.6724,0.8991), vec2(0.6724,0.9015), vec2(0.6699,0.8994), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4649,0.3452,0.039), vec3(0.4707,0.3135,0.013), vec3(0.4598,0.3152,0.0302), vec3(-0.7943,0.2918,-0.5329), vec2(0.7095,0.9249), vec2(0.6948,0.9307), vec2(0.6978,0.9262), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4494,0.2827,0.0189), vec3(0.4019,0.2331,0.0271), vec3(0.4446,0.2845,0.0368), vec3(-0.7191,0.6462,-0.2555), vec2(0.6831,0.9197), vec2(0.6748,0.9036), vec2(0.6865,0.9154), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4187,0.2183,0.0329), vec3(0.4015,0.2021,0.0314), vec3(0.416,0.2133,0.0202), vec3(0.6721,-0.7266,0.1428), vec2(0.666,0.9059), vec2(0.668,0.8992), vec2(0.6689,0.9045), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4446,0.2845,0.0368), vec3(0.4598,0.3152,0.0302), vec3(0.4494,0.2827,0.0189), vec3(-0.885,0.377,-0.2732), vec2(0.6865,0.9154), vec2(0.6978,0.9262), vec2(0.6831,0.9197), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.505,0.3131,0.0197), vec3(0.514,0.3105,0.0343), vec3(0.5308,0.2703,0.0328), vec3(0.8224,0.359,-0.4413), vec2(0.6978,0.946), vec2(0.7002,0.9511), vec2(0.6904,0.9625), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.505,0.3131,0.0197), vec3(0.4863,0.3452,0.028), vec3(0.4894,0.3301,0.0409), vec3(0.8576,0.4245,0.2903), vec2(0.6978,0.946), vec2(0.7051,0.937), vec2(0.7085,0.9448), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3902,0.1918,0.0407), vec3(0.3901,0.1968,0.0283), vec3(0.4024,0.198,0.024), vec3(-0.0422,-0.9267,-0.3735), vec2(0.7993,0.0405), vec2(0.7998,0.0454), vec2(0.7954,0.0483), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3902,0.1918,0.0407), vec3(0.3901,0.1968,0.0283), vec3(0.4024,0.198,0.024), vec3(-0.0422,-0.9267,-0.3735), vec2(0.7993,0.0405), vec2(0.7998,0.0454), vec2(0.7954,0.0483), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4019,0.2331,0.0271), vec3(0.3903,0.2123,0.0276), vec3(0.411,0.2269,0.0384), vec3(-0.6168,0.3618,0.699), vec2(0.6748,0.9036), vec2(0.6724,0.9015), vec2(0.6763,0.9014), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4704,0.3408,0.0268), vec3(0.4635,0.3473,0.0388), vec3(0.4863,0.3452,0.028), vec3(-0.1855,0.8181,-0.5443), vec2(0.7031,0.933), vec2(0.7104,0.9305), vec2(0.7051,0.937), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4704,0.3408,0.0268), vec3(0.4635,0.3473,0.0388), vec3(0.4863,0.3452,0.028), vec3(-0.1855,0.8181,-0.5443), vec2(0.7031,0.933), vec2(0.7104,0.9305), vec2(0.7051,0.937), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3963,0.2079,0.0351), vec3(0.3903,0.2123,0.0276), vec3(0.4015,0.2021,0.0314), vec3(-0.6884,-0.7133,0.1318), vec2(0.6729,0.9003), vec2(0.6724,0.9015), vec2(0.6724,0.8991), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3963,0.2079,0.0351), vec3(0.3903,0.2123,0.0276), vec3(0.4015,0.2021,0.0314), vec3(-0.6884,-0.7133,0.1318), vec2(0.6729,0.9003), vec2(0.6724,0.9015), vec2(0.6724,0.8991), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.514,0.3105,0.0343), vec3(0.505,0.3131,0.0197), vec3(0.4894,0.3301,0.0409), vec3(0.5728,0.792,-0.2115), vec2(0.7002,0.9511), vec2(0.6978,0.946), vec2(0.7085,0.9448), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3876,0.1939,0.0411), vec3(0.4024,0.198,0.024), vec3(0.3875,0.2087,0.03), vec3(0.603,0.4842,0.634), vec2(0.7993,0.0405), vec2(0.7954,0.0522), vec2(0.8008,0.0405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3876,0.1939,0.0411), vec3(0.4024,0.198,0.024), vec3(0.3875,0.2087,0.03), vec3(0.603,0.4842,0.634), vec2(0.7993,0.0405), vec2(0.7954,0.0522), vec2(0.8008,0.0405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.496,0.2738,0.0379), vec3(0.507,0.2494,0.016), vec3(0.5123,0.2535,0.0426), vec3(-0.7853,-0.5697,0.2424), vec2(0.665,0.9622), vec2(0.6699,0.9569), vec2(0.667,0.9621), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3901,0.1968,0.0283), vec3(0.3876,0.1939,0.0411), vec3(0.3857,0.2004,0.0285), vec3(-0.6197,-0.732,-0.2832), vec2(0.7998,0.0454), vec2(0.8008,0.0405), vec2(0.8018,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3901,0.1968,0.0283), vec3(0.3876,0.1939,0.0411), vec3(0.3857,0.2004,0.0285), vec3(-0.6197,-0.732,-0.2832), vec2(0.7998,0.0454), vec2(0.8008,0.0405), vec2(0.8018,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.496,0.2738,0.0379), vec3(0.4786,0.2751,0.0358), vec3(0.497,0.2163,0.0246), vec3(-0.1308,-0.2252,0.9655), vec2(0.667,0.9286), vec2(0.6704,0.9276), vec2(0.6616,0.9293), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4015,0.2021,0.0314), vec3(0.4187,0.2183,0.0329), vec3(0.3963,0.2079,0.0351), vec3(0.2516,-0.3525,0.9013), vec2(0.6724,0.8991), vec2(0.6768,0.8984), vec2(0.6729,0.9003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3857,0.2004,0.0285), vec3(0.3876,0.1939,0.0411), vec3(0.3875,0.2087,0.03), vec3(-0.9599,0.1628,0.2282), vec2(0.8018,0.0459), vec2(0.8008,0.0405), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3857,0.2004,0.0285), vec3(0.3876,0.1939,0.0411), vec3(0.3875,0.2087,0.03), vec3(-0.9599,0.1628,0.2282), vec2(0.8018,0.0459), vec2(0.8008,0.0405), vec2(0.8047,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3963,0.2079,0.0351), vec3(0.411,0.2269,0.0384), vec3(0.3903,0.2123,0.0276), vec3(-0.6155,0.3575,0.7024), vec2(0.6729,0.9003), vec2(0.6763,0.9014), vec2(0.6724,0.9015), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4635,0.3473,0.0388), vec3(0.4704,0.3408,0.0268), vec3(0.4649,0.3452,0.039), vec3(-0.8042,-0.5723,-0.1607), vec2(0.7104,0.9305), vec2(0.7031,0.933), vec2(0.7095,0.9249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4584,0.3177,0.0381), vec3(0.4598,0.3152,0.0302), vec3(0.4446,0.2845,0.0368), vec3(-0.8853,0.3774,-0.2718), vec2(0.6987,0.9209), vec2(0.6978,0.9262), vec2(0.6865,0.9154), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3902,0.1918,0.0407), vec3(0.4024,0.198,0.024), vec3(0.3876,0.1939,0.0411), vec3(0.555,0.564,0.6114), vec2(0.7954,0.0483), vec2(0.7954,0.0522), vec2(0.7993,0.0405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3902,0.1918,0.0407), vec3(0.4024,0.198,0.024), vec3(0.3876,0.1939,0.0411), vec3(0.555,0.564,0.6114), vec2(0.7954,0.0483), vec2(0.7954,0.0522), vec2(0.7993,0.0405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4599,0.2706,0.045), vec3(0.4187,0.2183,0.0329), vec3(0.4585,0.2638,0.028), vec3(0.7485,-0.6342,0.1938), vec2(0.6689,0.9228), vec2(0.666,0.9059), vec2(0.6729,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.411,0.2269,0.0384), vec3(0.3963,0.2079,0.0351), vec3(0.4187,0.2183,0.0329), vec3(0.2495,-0.3475,0.9039), vec2(0.6763,0.9014), vec2(0.6729,0.9003), vec2(0.6768,0.8984), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4649,0.3452,0.039), vec3(0.4598,0.3152,0.0302), vec3(0.4584,0.3177,0.0381), vec3(-0.9441,0.2305,-0.2357), vec2(0.7095,0.9249), vec2(0.6978,0.9262), vec2(0.6987,0.9209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4585,0.2638,0.028), vec3(0.4786,0.2751,0.0358), vec3(0.4599,0.2706,0.045), vec3(0.3661,-0.873,0.3221), vec2(0.6729,0.9229), vec2(0.6694,0.9261), vec2(0.6689,0.9228), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3876,0.1939,0.0411), vec3(0.3901,0.1968,0.0283), vec3(0.3902,0.1918,0.0407), vec3(-0.6369,-0.7171,-0.2832), vec2(0.8008,0.0405), vec2(0.7998,0.0454), vec2(0.7993,0.0405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3876,0.1939,0.0411), vec3(0.3901,0.1968,0.0283), vec3(0.3902,0.1918,0.0407), vec3(-0.6369,-0.7171,-0.2832), vec2(0.8008,0.0405), vec2(0.7998,0.0454), vec2(0.7993,0.0405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4707,0.3392,0.0438), vec3(0.4863,0.3452,0.028), vec3(0.4635,0.3473,0.0388), vec3(0.355,0.6999,0.6198), vec2(0.71,0.9376), vec2(0.7051,0.937), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4707,0.3392,0.0438), vec3(0.4863,0.3452,0.028), vec3(0.4635,0.3473,0.0388), vec3(0.355,0.6999,0.6198), vec2(0.71,0.9376), vec2(0.7051,0.937), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5308,0.2703,0.0328), vec3(0.514,0.3105,0.0343), vec3(0.5214,0.2623,0.0443), vec3(0.6577,0.2478,0.7114), vec2(0.6904,0.9625), vec2(0.7002,0.9511), vec2(0.6948,0.9653), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4707,0.3392,0.0438), vec3(0.4894,0.3301,0.0409), vec3(0.4863,0.3452,0.028), vec3(0.4093,0.6399,0.6504), vec2(0.71,0.9376), vec2(0.7085,0.9448), vec2(0.7051,0.937), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4446,0.2845,0.0368), vec3(0.4019,0.2331,0.0271), vec3(0.4375,0.2751,0.0492), vec3(-0.7718,0.6349,0.0365), vec2(0.6865,0.9154), vec2(0.6748,0.9036), vec2(0.6885,0.9112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.411,0.2269,0.0384), vec3(0.4375,0.2751,0.0492), vec3(0.4019,0.2331,0.0271), vec3(-0.6926,0.2259,0.685), vec2(0.6763,0.9014), vec2(0.6885,0.9112), vec2(0.6748,0.9036), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4187,0.2183,0.0329), vec3(0.4599,0.2706,0.045), vec3(0.411,0.2269,0.0384), vec3(0.2153,-0.3764,0.9011), vec2(0.6768,0.8984), vec2(0.6895,0.9083), vec2(0.6763,0.9014), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.496,0.2738,0.0379), vec3(0.4955,0.3057,0.0452), vec3(0.4786,0.2751,0.0358), vec3(-0.1308,-0.2249,0.9656), vec2(0.6987,0.9007), vec2(0.7041,0.9084), vec2(0.6948,0.9047), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.514,0.3105,0.0343), vec3(0.4894,0.3301,0.0409), vec3(0.4947,0.3251,0.0441), vec3(0.6392,0.7564,0.1393), vec2(0.7002,0.9511), vec2(0.7085,0.9448), vec2(0.709,0.9503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4744,0.3297,0.0462), vec3(0.4649,0.3452,0.039), vec3(0.4584,0.3177,0.0381), vec3(-0.5047,0.0923,0.8584), vec2(0.7061,0.9179), vec2(0.7095,0.9249), vec2(0.6987,0.9209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.514,0.3105,0.0343), vec3(0.4947,0.3251,0.0441), vec3(0.4955,0.3057,0.0452), vec3(0.4923,0.0729,0.8674), vec2(0.7002,0.9511), vec2(0.709,0.9503), vec2(0.7056,0.9552), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4955,0.3057,0.0452), vec3(0.5214,0.2623,0.0443), vec3(0.514,0.3105,0.0343), vec3(0.4437,0.2463,0.8617), vec2(0.7056,0.9552), vec2(0.6948,0.9653), vec2(0.7002,0.9511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4446,0.2845,0.0368), vec3(0.4375,0.2751,0.0492), vec3(0.4584,0.3177,0.0381), vec3(-0.8964,0.3803,-0.2279), vec2(0.6865,0.9154), vec2(0.6885,0.9112), vec2(0.6987,0.9209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5123,0.2535,0.0426), vec3(0.5214,0.2623,0.0443), vec3(0.496,0.2738,0.0379), vec3(-0.2272,0.0465,0.9727), vec2(0.6978,0.9676), vec2(0.6948,0.9653), vec2(0.7031,0.9639), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4955,0.3057,0.0452), vec3(0.496,0.2738,0.0379), vec3(0.5214,0.2623,0.0443), vec3(-0.3335,-0.2171,0.9174), vec2(0.7056,0.9552), vec2(0.7031,0.9639), vec2(0.6948,0.9653), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4955,0.3057,0.0452), vec3(0.471,0.3131,0.048), vec3(0.4786,0.2751,0.0358), vec3(0.0165,-0.3022,0.9531), vec2(0.7041,0.9084), vec2(0.7017,0.915), vec2(0.6948,0.9047), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4599,0.2706,0.045), vec3(0.4786,0.2751,0.0358), vec3(0.4375,0.2751,0.0492), vec3(0.2608,0.5418,0.799), vec2(0.6895,0.9083), vec2(0.6948,0.9047), vec2(0.6885,0.9112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.471,0.3131,0.048), vec3(0.4744,0.3297,0.0462), vec3(0.4584,0.3177,0.0381), vec3(-0.5578,0.1977,0.8061), vec2(0.7017,0.915), vec2(0.7061,0.9179), vec2(0.6987,0.9209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4375,0.2751,0.0492), vec3(0.411,0.2269,0.0384), vec3(0.4599,0.2706,0.045), vec3(0.1256,-0.2836,0.9507), vec2(0.6885,0.9112), vec2(0.6763,0.9014), vec2(0.6895,0.9083), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.471,0.3131,0.048), vec3(0.4375,0.2751,0.0492), vec3(0.4786,0.2751,0.0358), vec3(0.302,-0.2357,0.9237), vec2(0.7017,0.915), vec2(0.6885,0.9112), vec2(0.6948,0.9047), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4584,0.3177,0.0381), vec3(0.4375,0.2751,0.0492), vec3(0.471,0.3131,0.048), vec3(-0.4545,0.4273,0.7815), vec2(0.6987,0.9209), vec2(0.6885,0.9112), vec2(0.7017,0.915), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4955,0.3057,0.0452), vec3(0.4947,0.3251,0.0441), vec3(0.471,0.3131,0.048), vec3(0.1308,0.0644,0.9893), vec2(0.7041,0.9084), vec2(0.708,0.9115), vec2(0.7017,0.915), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.471,0.3131,0.048), vec3(0.4947,0.3251,0.0441), vec3(0.4744,0.3297,0.0462), vec3(0.1215,0.0826,0.9891), vec2(0.7017,0.915), vec2(0.708,0.9115), vec2(0.7061,0.9179), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2307,0.4111,0.0002), vec3(0.2126,0.4259,0.0846), vec3(0.0275,0.3842,0.0553), vec3(0.1836,-0.9607,0.2082), vec2(0.7188,0.3711), vec2(0.6943,0.3525), vec2(0.7422,0.335), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4744,0.3297,0.0462), vec3(0.4729,0.3698,0.0655), vec3(0.4649,0.3452,0.039), vec3(-0.8234,-0.27,0.4992), vec2(0.7061,0.9179), vec2(0.7197,0.9203), vec2(0.7095,0.9249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4894,0.3301,0.0409), vec3(0.4896,0.368,0.0662), vec3(0.4947,0.3251,0.0441), vec3(0.7143,0.3851,-0.5843), vec2(0.7085,0.9448), vec2(0.7261,0.9458), vec2(0.709,0.9503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4947,0.3251,0.0441), vec3(0.4896,0.368,0.0662), vec3(0.4744,0.3297,0.0462), vec3(-0.0128,-0.4591,0.8883), vec2(0.708,0.9115), vec2(0.7212,0.9158), vec2(0.7061,0.9179), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.4596,0.4534,0.028), 0.6987, bestT)) {
        if (triHit(ro, rd, vec3(0.2059,0.4764,0.1815), vec3(0.0356,0.4692,0.2337), vec3(0.2126,0.4259,0.0846), vec3(0.1794,-0.8672,0.4644), vec2(0.6577,0.3379), vec2(0.6729,0.3022), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1955,0.4342,-0.3442), vec3(0.1834,0.468,-0.435), vec3(0.3059,0.4804,-0.3073), vec3(0.4595,-0.8107,-0.3627), vec2(0.811,0.4814), vec2(0.835,0.5125), vec2(0.7827,0.4976), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3059,0.4804,-0.3073), vec3(0.2086,0.4134,-0.2086), vec3(0.1955,0.4342,-0.3442), vec3(0.429,-0.8857,-0.1776), vec2(0.7827,0.4976), vec2(0.7788,0.4385), vec2(0.811,0.4814), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2059,0.4764,0.1815), vec3(0.3269,0.4862,0.1225), vec3(0.1927,0.5532,0.3058), vec3(0.3184,-0.7911,0.5224), vec2(0.6577,0.3379), vec2(0.6538,0.3569), vec2(0.6079,0.3198), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3269,0.4862,0.1225), vec3(0.2059,0.4764,0.1815), vec3(0.2126,0.4259,0.0846), vec3(0.2909,-0.84,0.458), vec2(0.6538,0.3569), vec2(0.6577,0.3379), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2126,0.4259,0.0846), vec3(0.2307,0.4111,0.0002), vec3(0.3519,0.4413,0.0185), vec3(0.2063,-0.9552,0.2121), vec2(0.6943,0.3525), vec2(0.7188,0.3711), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3282,0.4792,-0.1867), vec3(0.2652,0.4255,-0.0794), vec3(0.2086,0.4134,-0.2086), vec3(0.4969,-0.8568,-0.1377), vec2(0.7417,0.4658), vec2(0.7344,0.4028), vec2(0.7788,0.4385), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3059,0.4804,-0.3073), vec3(0.3282,0.4792,-0.1867), vec3(0.2086,0.4134,-0.2086), vec3(0.4937,-0.8639,-0.099), vec2(0.7827,0.4976), vec2(0.7417,0.4658), vec2(0.7788,0.4385), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3051,0.5718,0.3045), vec3(0.1927,0.5532,0.3058), vec3(0.3749,0.5116,0.1465), vec3(0.1533,-0.8991,0.41), vec2(0.5928,0.3579), vec2(0.6079,0.3198), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2652,0.4255,-0.0794), vec3(0.3953,0.4445,-0.0892), vec3(0.2307,0.4111,0.0002), vec3(0.1345,-0.9836,-0.12), vec2(0.7344,0.4028), vec2(0.7144,0.3921), vec2(0.7188,0.3711), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3519,0.4413,0.0185), vec3(0.3269,0.4862,0.1225), vec3(0.2126,0.4259,0.0846), vec3(0.3014,-0.8471,0.4378), vec2(0.6885,0.3687), vec2(0.6538,0.3569), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3749,0.5116,0.1465), vec3(0.1927,0.5532,0.3058), vec3(0.3269,0.4862,0.1225), vec3(0.2173,-0.8546,0.4716), vec2(0.6387,0.3745), vec2(0.6079,0.3198), vec2(0.6538,0.3569), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3712,0.4699,-0.0978), vec3(0.2652,0.4255,-0.0794), vec3(0.3282,0.4792,-0.1867), vec3(0.3354,-0.9063,-0.2571), vec2(0.7168,0.4312), vec2(0.7344,0.4028), vec2(0.7417,0.4658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3953,0.4445,-0.0892), vec3(0.3519,0.4413,0.0185), vec3(0.2307,0.4111,0.0002), vec3(0.2323,-0.9705,0.065), vec2(0.7144,0.3921), vec2(0.6885,0.3687), vec2(0.7188,0.3711), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.409,0.5869,-0.2991), vec3(0.3282,0.4792,-0.1867), vec3(0.3059,0.4804,-0.3073), vec3(0.7172,-0.6829,-0.1385), vec2(0.8633,0.3774), vec2(0.8457,0.4097), vec2(0.8379,0.3799), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3712,0.4699,-0.0978), vec3(0.4084,0.4509,-0.0754), vec3(0.2652,0.4255,-0.0794), vec3(0.1335,-0.6339,-0.7618), vec2(0.7168,0.4312), vec2(0.707,0.4131), vec2(0.7344,0.4028), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3953,0.4445,-0.0892), vec3(0.2652,0.4255,-0.0794), vec3(0.4084,0.4509,-0.0754), vec3(-0.1596,0.9444,-0.2873), vec2(0.7144,0.3921), vec2(0.7344,0.4028), vec2(0.707,0.4131), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.394,0.5822,0.2921), vec3(0.3051,0.5718,0.3045), vec3(0.3749,0.5116,0.1465), vec3(0.1629,-0.896,0.4131), vec2(0.5879,0.3926), vec2(0.5928,0.3579), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3519,0.4413,0.0185), vec3(0.402,0.4579,0.0307), vec3(0.3269,0.4862,0.1225), vec3(0.1896,-0.8842,0.4269), vec2(0.6885,0.3687), vec2(0.6753,0.3745), vec2(0.6538,0.3569), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3282,0.4792,-0.1867), vec3(0.3865,0.5216,-0.1742), vec3(0.3712,0.4699,-0.0978), vec3(0.5971,-0.7149,-0.3638), vec2(0.7417,0.4658), vec2(0.7241,0.478), vec2(0.7168,0.4312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3749,0.5116,0.1465), vec3(0.3269,0.4862,0.1225), vec3(0.4209,0.4831,0.0689), vec3(0.2303,-0.8614,0.4528), vec2(0.6387,0.3745), vec2(0.6538,0.3569), vec2(0.6597,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3282,0.4792,-0.1867), vec3(0.409,0.5869,-0.2991), vec3(0.3865,0.5216,-0.1742), vec3(0.6025,-0.7466,-0.282), vec2(0.8457,0.4097), vec2(0.8633,0.3774), vec2(0.8584,0.4111), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4209,0.4831,0.0689), vec3(0.3269,0.4862,0.1225), vec3(0.402,0.4579,0.0307), vec3(0.2307,-0.861,0.4534), vec2(0.6597,0.3828), vec2(0.6538,0.3569), vec2(0.6753,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4265,0.4329,-0.0144), vec3(0.3519,0.4413,0.0185), vec3(0.3953,0.4445,-0.0892), vec3(-0.1509,-0.9845,-0.0896), vec2(0.6895,0.3877), vec2(0.6885,0.3687), vec2(0.7144,0.3921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3519,0.4413,0.0185), vec3(0.4252,0.4445,0.018), vec3(0.402,0.4579,0.0307), vec3(0.0332,-0.6548,0.755), vec2(0.6885,0.3687), vec2(0.6797,0.3838), vec2(0.6753,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.424,0.5058,-0.0687), vec3(0.3712,0.4699,-0.0978), vec3(0.3865,0.5216,-0.1742), vec3(0.6487,-0.6844,-0.3329), vec2(0.6963,0.4434), vec2(0.7168,0.4312), vec2(0.7241,0.478), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4244,0.5355,0.1432), vec3(0.394,0.5822,0.2921), vec3(0.3749,0.5116,0.1465), vec3(0.4262,-0.8347,0.3488), vec2(0.6328,0.4023), vec2(0.5879,0.3926), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3519,0.4413,0.0185), vec3(0.4265,0.4329,-0.0144), vec3(0.4252,0.4445,0.018), vec3(0.0428,-0.94,0.3385), vec2(0.6885,0.3687), vec2(0.6895,0.3877), vec2(0.6797,0.3838), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4209,0.4831,0.0689), vec3(0.4244,0.5355,0.1432), vec3(0.3749,0.5116,0.1465), vec3(0.4,-0.7579,0.5154), vec2(0.6597,0.3828), vec2(0.6328,0.4023), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4581,0.4774,-0.0636), vec3(0.4084,0.4509,-0.0754), vec3(0.3712,0.4699,-0.0978), vec3(0.3714,-0.3039,-0.8773), vec2(0.6943,0.4199), vec2(0.707,0.4131), vec2(0.7168,0.4312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4447,0.4267,-0.0346), vec3(0.3953,0.4445,-0.0892), vec3(0.4084,0.4509,-0.0754), vec3(0.7336,-0.0452,-0.6781), vec2(0.6938,0.3955), vec2(0.7144,0.3921), vec2(0.707,0.4131), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4581,0.4774,-0.0636), vec3(0.3712,0.4699,-0.0978), vec3(0.424,0.5058,-0.0687), vec3(0.3377,0.241,-0.9099), vec2(0.6943,0.4199), vec2(0.7168,0.4312), vec2(0.6963,0.4434), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3865,0.5216,-0.1742), vec3(0.409,0.5869,-0.2991), vec3(0.465,0.5835,-0.1263), vec3(0.6867,-0.6876,-0.2359), vec2(0.8584,0.4111), vec2(0.8633,0.3774), vec2(0.876,0.4189), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4447,0.4267,-0.0346), vec3(0.4265,0.4329,-0.0144), vec3(0.3953,0.4445,-0.0892), vec3(-0.3303,-0.9438,-0.0085), vec2(0.6938,0.3955), vec2(0.6895,0.3877), vec2(0.7144,0.3921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4164,0.6455,0.3852), vec3(0.394,0.5822,0.2921), vec3(0.4596,0.607,0.2552), vec3(0.5114,-0.7626,0.3961), vec2(0.5479,0.3999), vec2(0.5879,0.3926), vec2(0.5903,0.4189), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4209,0.4831,0.0689), vec3(0.402,0.4579,0.0307), vec3(0.4471,0.4524,0.0261), vec3(-0.0439,-0.8238,0.5651), vec2(0.6597,0.3828), vec2(0.6753,0.3745), vec2(0.6748,0.3892), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4252,0.4445,0.018), vec3(0.4471,0.4524,0.0261), vec3(0.402,0.4579,0.0307), vec3(-0.013,-0.6978,0.7162), vec2(0.6797,0.3838), vec2(0.6748,0.3892), vec2(0.6753,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3865,0.5216,-0.1742), vec3(0.465,0.5835,-0.1263), vec3(0.424,0.5058,-0.0687), vec3(0.7019,-0.6243,-0.3429), vec2(0.7241,0.478), vec2(0.6948,0.4858), vec2(0.6963,0.4434), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4244,0.5355,0.1432), vec3(0.4596,0.607,0.2552), vec3(0.394,0.5822,0.2921), vec3(0.4974,-0.7936,0.3504), vec2(0.6328,0.4023), vec2(0.5903,0.4189), vec2(0.5879,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4252,0.4445,0.018), vec3(0.4265,0.4329,-0.0144), vec3(0.4453,0.3974,0.0206), vec3(-0.9165,-0.387,0.1013), vec2(0.0112,0.2886), vec2(0.0285,0.272), vec2(0.0463,0.3003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.462,0.5024,0.0448), vec3(0.4244,0.5355,0.1432), vec3(0.4209,0.4831,0.0689), vec3(0.5821,-0.6773,0.45), vec2(0.6606,0.4077), vec2(0.6328,0.4023), vec2(0.6597,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4265,0.4329,-0.0144), vec3(0.4447,0.4267,-0.0346), vec3(0.4428,0.3838,-0.0019), vec3(-0.7419,-0.3855,-0.5486), vec2(0.0108,0.3843), vec2(0.016,0.3662), vec2(0.0443,0.3823), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4428,0.3838,-0.0019), vec3(0.4453,0.3974,0.0206), vec3(0.4265,0.4329,-0.0144), vec3(-0.9352,-0.245,0.2556), vec2(0.0584,0.2881), vec2(0.0463,0.3003), vec2(0.0285,0.272), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4471,0.4524,0.0261), vec3(0.4252,0.4445,0.018), vec3(0.4453,0.3974,0.0206), vec3(-0.3186,-0.0855,0.944), vec2(0.0072,0.3042), vec2(0.0112,0.2886), vec2(0.0463,0.3003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4676,0.4359,-0.0277), vec3(0.4447,0.4267,-0.0346), vec3(0.4084,0.4509,-0.0754), vec3(0.4362,-0.5491,-0.7129), vec2(0.6885,0.4004), vec2(0.6938,0.3955), vec2(0.707,0.4131), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4209,0.4831,0.0689), vec3(0.4471,0.4524,0.0261), vec3(0.462,0.5024,0.0448), vec3(0.5983,-0.4309,0.6755), vec2(0.6597,0.3828), vec2(0.6748,0.3892), vec2(0.6606,0.4077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4676,0.4359,-0.0277), vec3(0.4084,0.4509,-0.0754), vec3(0.4581,0.4774,-0.0636), vec3(0.4513,-0.5226,-0.7234), vec2(0.6885,0.4004), vec2(0.707,0.4131), vec2(0.6943,0.4199), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4453,0.3974,0.0206), vec3(0.4428,0.3838,-0.0019), vec3(0.4537,0.3803,0.0202), vec3(-0.8374,-0.4196,0.3504), vec2(0.0463,0.3003), vec2(0.0584,0.2881), vec2(0.0586,0.3052), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.424,0.5058,-0.0687), vec3(0.4659,0.5352,-0.0049), vec3(0.4581,0.4774,-0.0636), vec3(0.5551,0.5541,-0.6203), vec2(0.6963,0.4434), vec2(0.6709,0.4399), vec2(0.6943,0.4199), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4517,0.3701,0.0033), vec3(0.4537,0.3803,0.0202), vec3(0.4428,0.3838,-0.0019), vec3(-0.8402,-0.4116,0.353), vec2(0.0678,0.2944), vec2(0.0586,0.3052), vec2(0.0584,0.2881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4614,0.3762,-0.0221), vec3(0.4428,0.3838,-0.0019), vec3(0.4447,0.4267,-0.0346), vec3(-0.7466,-0.3822,-0.5446), vec2(0.048,0.3647), vec2(0.0443,0.3823), vec2(0.016,0.3662), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4244,0.5355,0.1432), vec3(0.462,0.5024,0.0448), vec3(0.4632,0.5427,0.0673), vec3(0.8696,-0.2604,0.4196), vec2(0.6328,0.4023), vec2(0.6606,0.4077), vec2(0.6499,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4428,0.3838,-0.0019), vec3(0.4614,0.3762,-0.0221), vec3(0.4517,0.3701,0.0033), vec3(-0.6883,-0.5991,-0.4089), vec2(0.0443,0.3823), vec2(0.048,0.3647), vec2(0.0557,0.3804), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4652,0.4015,0.0258), vec3(0.4471,0.4524,0.0261), vec3(0.4453,0.3974,0.0206), vec3(-0.2348,-0.0905,0.9678), vec2(0.0417,0.3159), vec2(0.0072,0.3042), vec2(0.0463,0.3003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4537,0.3803,0.0202), vec3(0.4652,0.4015,0.0258), vec3(0.4453,0.3974,0.0206), vec3(-0.2257,-0.1314,0.9653), vec2(0.0586,0.3052), vec2(0.0417,0.3159), vec2(0.0463,0.3003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4447,0.4267,-0.0346), vec3(0.4676,0.4359,-0.0277), vec3(0.4614,0.3762,-0.0221), vec3(0.3318,-0.1228,-0.9353), vec2(0.016,0.3662), vec2(0.0156,0.3486), vec2(0.048,0.3647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4537,0.3803,0.0202), vec3(0.4517,0.3701,0.0033), vec3(0.4704,0.3408,0.0268), vec3(-0.8935,-0.3267,0.3081), vec2(0.0586,0.3052), vec2(0.0678,0.2944), vec2(0.0872,0.3154), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4661,0.3639,-0.0127), vec3(0.4517,0.3701,0.0033), vec3(0.4614,0.3762,-0.0221), vec3(-0.6996,-0.5853,-0.4099), vec2(0.0582,0.3647), vec2(0.0557,0.3804), vec2(0.048,0.3647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4704,0.4513,-0.0066), vec3(0.462,0.5024,0.0448), vec3(0.4471,0.4524,0.0261), vec3(0.7326,-0.419,0.5364), vec2(0.6812,0.3989), vec2(0.6606,0.4077), vec2(0.6748,0.3892), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4596,0.607,0.2552), vec3(0.4244,0.5355,0.1432), vec3(0.4971,0.6242,0.1068), vec3(0.7927,-0.5954,0.131), vec2(0.5903,0.4189), vec2(0.6328,0.4023), vec2(0.626,0.4536), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4652,0.4015,0.0258), vec3(0.4704,0.4513,-0.0066), vec3(0.4471,0.4524,0.0261), vec3(0.7869,0.2765,0.5516), vec2(0.0417,0.3159), vec2(0.0091,0.332), vec2(0.0072,0.3042), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4632,0.5427,0.0673), vec3(0.4971,0.6242,0.1068), vec3(0.4244,0.5355,0.1432), vec3(0.7894,-0.5002,0.3559), vec2(0.6499,0.4253), vec2(0.626,0.4536), vec2(0.6328,0.4023), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4687,0.3835,0.0247), vec3(0.4652,0.4015,0.0258), vec3(0.4537,0.3803,0.0202), vec3(-0.2656,-0.108,0.958), vec2(0.0552,0.3184), vec2(0.0417,0.3159), vec2(0.0586,0.3052), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4687,0.3835,0.0247), vec3(0.4537,0.3803,0.0202), vec3(0.4704,0.3408,0.0268), vec3(-0.295,0.0346,0.9549), vec2(0.0552,0.3184), vec2(0.0586,0.3052), vec2(0.0872,0.3154), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.465,0.5835,-0.1263), vec3(0.5062,0.6074,-0.0258), vec3(0.424,0.5058,-0.0687), vec3(0.8011,-0.5662,-0.1939), vec2(0.6948,0.4858), vec2(0.6626,0.4756), vec2(0.6963,0.4434), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5062,0.6074,-0.0258), vec3(0.4659,0.5352,-0.0049), vec3(0.424,0.5058,-0.0687), vec3(0.8006,-0.5287,-0.2818), vec2(0.6626,0.4756), vec2(0.6709,0.4399), vec2(0.6963,0.4434), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4649,0.3452,0.039), vec3(0.4681,0.3874,0.0516), vec3(0.4635,0.3473,0.0388), vec3(-0.4203,-0.232,0.8772), vec2(0.7095,0.9249), vec2(0.7217,0.9251), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4784,0.4972,-0.0247), vec3(0.4581,0.4774,-0.0636), vec3(0.4659,0.5352,-0.0049), vec3(0.6254,0.5124,-0.5885), vec2(0.6792,0.4209), vec2(0.6943,0.4199), vec2(0.6709,0.4399), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.462,0.5024,0.0448), vec3(0.4784,0.4972,-0.0247), vec3(0.4632,0.5427,0.0673), vec3(0.9579,-0.1613,0.2376), vec2(0.6606,0.4077), vec2(0.6792,0.4209), vec2(0.6499,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4581,0.4774,-0.0636), vec3(0.4784,0.4972,-0.0247), vec3(0.4676,0.4359,-0.0277), vec3(0.9051,-0.1392,-0.4018), vec2(0.6943,0.4199), vec2(0.6792,0.4209), vec2(0.6885,0.4004), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4681,0.3874,0.0516), vec3(0.4649,0.3452,0.039), vec3(0.4729,0.3698,0.0655), vec3(-0.9513,-0.0215,0.3075), vec2(0.7217,0.9251), vec2(0.7095,0.9249), vec2(0.7197,0.9203), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4659,0.5352,-0.0049), vec3(0.4632,0.5427,0.0673), vec3(0.4784,0.4972,-0.0247), vec3(0.9506,0.3104,0.0033), vec2(0.6709,0.4399), vec2(0.6499,0.4253), vec2(0.6792,0.4209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4775,0.3957,0.0334), vec3(0.4635,0.3473,0.0388), vec3(0.4681,0.3874,0.0516), vec3(-0.9022,0.2212,-0.3703), vec2(0.7227,0.9293), vec2(0.7104,0.9305), vec2(0.7217,0.9251), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4716,0.4165,0.0633), vec3(0.4681,0.3874,0.0516), vec3(0.47,0.3962,0.0823), vec3(-0.9935,0.1098,0.0304), vec2(0.7266,0.9252), vec2(0.7217,0.9251), vec2(0.7261,0.9222), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4704,0.4513,-0.0066), vec3(0.4784,0.4972,-0.0247), vec3(0.462,0.5024,0.0448), vec3(0.9693,-0.0761,0.2338), vec2(0.6812,0.3989), vec2(0.6792,0.4209), vec2(0.6606,0.4077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4729,0.3698,0.0655), vec3(0.47,0.3962,0.0823), vec3(0.4681,0.3874,0.0516), vec3(-0.9767,-0.1823,0.1135), vec2(0.7197,0.9203), vec2(0.7261,0.9222), vec2(0.7217,0.9251), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4837,0.3714,-0.0075), vec3(0.4661,0.3639,-0.0127), vec3(0.4614,0.3762,-0.0221), vec3(0.4185,-0.4463,-0.791), vec2(0.0585,0.3501), vec2(0.0582,0.3647), vec2(0.048,0.3647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4843,0.3858,-0.0154), vec3(0.4614,0.3762,-0.0221), vec3(0.4676,0.4359,-0.0277), vec3(0.3239,-0.1222,-0.9382), vec2(0.0473,0.3496), vec2(0.048,0.3647), vec2(0.0156,0.3486), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4676,0.4359,-0.0277), vec3(0.4784,0.4972,-0.0247), vec3(0.4704,0.4513,-0.0066), vec3(0.985,-0.1724,-0.0031), vec2(0.6885,0.4004), vec2(0.6792,0.4209), vec2(0.6812,0.3989), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4652,0.4015,0.0258), vec3(0.4687,0.3835,0.0247), vec3(0.4831,0.3977,0.0049), vec3(0.7647,0.1123,0.6346), vec2(0.0417,0.3159), vec2(0.0552,0.3184), vec2(0.0417,0.3345), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4704,0.4513,-0.0066), vec3(0.4652,0.4015,0.0258), vec3(0.4831,0.3977,0.0049), vec3(0.7503,0.3035,0.5874), vec2(0.0091,0.332), vec2(0.0417,0.3159), vec2(0.0417,0.3345), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4716,0.4165,0.0633), vec3(0.4803,0.4166,0.0483), vec3(0.4681,0.3874,0.0516), vec3(-0.8278,0.2931,-0.4784), vec2(0.7266,0.9252), vec2(0.7261,0.9275), vec2(0.7217,0.9251), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4704,0.4513,-0.0066), vec3(0.4831,0.3977,0.0049), vec3(0.4676,0.4359,-0.0277), vec3(0.9527,0.1724,-0.2501), vec2(0.0091,0.332), vec2(0.0417,0.3345), vec2(0.0156,0.3486), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4863,0.3452,0.028), vec3(0.4687,0.3835,0.0247), vec3(0.4704,0.3408,0.0268), vec3(-0.0892,0.045,0.995), vec2(0.085,0.3262), vec2(0.0552,0.3184), vec2(0.0872,0.3154), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4775,0.3957,0.0334), vec3(0.4681,0.3874,0.0516), vec3(0.4803,0.4166,0.0483), vec3(-0.8887,0.3377,-0.3101), vec2(0.7227,0.9293), vec2(0.7217,0.9251), vec2(0.7261,0.9275), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4632,0.5427,0.0673), vec3(0.4659,0.5352,-0.0049), vec3(0.4971,0.6242,0.1068), vec3(0.9071,-0.4139,0.0764), vec2(0.6499,0.4253), vec2(0.6709,0.4399), vec2(0.626,0.4536), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4843,0.3858,-0.0154), vec3(0.4837,0.3714,-0.0075), vec3(0.4614,0.3762,-0.0221), vec3(0.4181,-0.4474,-0.7906), vec2(0.0473,0.3496), vec2(0.0585,0.3501), vec2(0.048,0.3647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4707,0.3392,0.0438), vec3(0.4635,0.3473,0.0388), vec3(0.4955,0.3911,0.0341), vec3(0.2825,-0.3047,-0.9096), vec2(0.71,0.9376), vec2(0.7104,0.9305), vec2(0.7231,0.9333), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4707,0.3392,0.0438), vec3(0.4635,0.3473,0.0388), vec3(0.4955,0.3911,0.0341), vec3(0.2825,-0.3047,-0.9096), vec2(0.71,0.9376), vec2(0.7104,0.9305), vec2(0.7231,0.9333), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4729,0.3698,0.0655), vec3(0.4896,0.368,0.0662), vec3(0.47,0.3962,0.0823), vec3(-0.0912,-0.5421,0.8353), vec2(0.7197,0.9203), vec2(0.7212,0.9158), vec2(0.7261,0.9222), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4733,0.413,0.0537), vec3(0.4769,0.4242,0.0706), vec3(0.4842,0.4277,0.0593), vec3(-0.7187,0.6413,-0.2687), vec2(0.7939,0.0249), vec2(0.7939,0.0161), vec2(0.7983,0.019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4733,0.413,0.0537), vec3(0.4769,0.4242,0.0706), vec3(0.4842,0.4277,0.0593), vec3(-0.7187,0.6413,-0.2687), vec2(0.7939,0.0249), vec2(0.7939,0.0161), vec2(0.7983,0.019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4843,0.3858,-0.0154), vec3(0.4676,0.4359,-0.0277), vec3(0.4831,0.3977,0.0049), vec3(0.9509,0.2877,-0.1139), vec2(0.0473,0.3496), vec2(0.0156,0.3486), vec2(0.0417,0.3345), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4733,0.413,0.0537), vec3(0.4842,0.4277,0.0593), vec3(0.4786,0.4081,0.0405), vec3(-0.6027,0.6366,-0.4811), vec2(0.7939,0.0249), vec2(0.7983,0.019), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4733,0.413,0.0537), vec3(0.4842,0.4277,0.0593), vec3(0.4786,0.4081,0.0405), vec3(-0.6027,0.6366,-0.4811), vec2(0.7939,0.0249), vec2(0.7983,0.019), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4775,0.3957,0.0334), vec3(0.4955,0.3911,0.0341), vec3(0.4635,0.3473,0.0388), vec3(0.0073,-0.1124,-0.9936), vec2(0.7227,0.9293), vec2(0.7231,0.9333), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4775,0.3957,0.0334), vec3(0.4955,0.3911,0.0341), vec3(0.4635,0.3473,0.0388), vec3(0.0073,-0.1124,-0.9936), vec2(0.7227,0.9293), vec2(0.7231,0.9333), vec2(0.7104,0.9305), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4729,0.3698,0.0655), vec3(0.4744,0.3297,0.0462), vec3(0.4896,0.368,0.0662), vec3(-0.0824,-0.4356,0.8964), vec2(0.7197,0.9203), vec2(0.7061,0.9179), vec2(0.7212,0.9158), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.47,0.3962,0.0823), vec3(0.4956,0.3976,0.0784), vec3(0.4716,0.4165,0.0633), vec3(0.0749,0.6801,0.7293), vec2(0.7261,0.9222), vec2(0.73,0.9196), vec2(0.7266,0.9252), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.47,0.3962,0.0823), vec3(0.4956,0.3976,0.0784), vec3(0.4716,0.4165,0.0633), vec3(0.0749,0.6801,0.7293), vec2(0.7261,0.9222), vec2(0.73,0.9196), vec2(0.7266,0.9252), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4687,0.3835,0.0247), vec3(0.4855,0.3844,0.0085), vec3(0.4831,0.3977,0.0049), vec3(0.6488,0.3123,0.6939), vec2(0.0552,0.3184), vec2(0.054,0.3354), vec2(0.0417,0.3345), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4687,0.3835,0.0247), vec3(0.4863,0.3452,0.028), vec3(0.4855,0.3844,0.0085), vec3(0.6377,0.3529,0.6847), vec2(0.0552,0.3184), vec2(0.085,0.3262), vec2(0.054,0.3354), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4803,0.4166,0.0483), vec3(0.4716,0.4165,0.0633), vec3(0.4954,0.4129,0.0486), vec3(0.2325,0.9623,0.141), vec2(0.7261,0.9275), vec2(0.7266,0.9252), vec2(0.73,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4803,0.4166,0.0483), vec3(0.4716,0.4165,0.0633), vec3(0.4954,0.4129,0.0486), vec3(0.2325,0.9623,0.141), vec2(0.7261,0.9275), vec2(0.7266,0.9252), vec2(0.73,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4842,0.4277,0.0593), vec3(0.4769,0.4242,0.0706), vec3(0.4874,0.4308,0.0755), vec3(-0.5086,0.8586,-0.0644), vec2(0.7983,0.019), vec2(0.7939,0.0161), vec2(0.7988,0.0137), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4842,0.4277,0.0593), vec3(0.4769,0.4242,0.0706), vec3(0.4874,0.4308,0.0755), vec3(-0.5086,0.8586,-0.0644), vec2(0.7983,0.019), vec2(0.7939,0.0161), vec2(0.7988,0.0137), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4786,0.4081,0.0405), vec3(0.4968,0.4026,0.0394), vec3(0.4733,0.413,0.0537), vec3(-0.2707,-0.9329,0.2376), vec2(0.8062,0.0298), vec2(0.8101,0.0254), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4786,0.4081,0.0405), vec3(0.4968,0.4026,0.0394), vec3(0.4733,0.413,0.0537), vec3(-0.2707,-0.9329,0.2376), vec2(0.8062,0.0298), vec2(0.8101,0.0254), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.487,0.4281,0.0908), vec3(0.4874,0.4308,0.0755), vec3(0.4769,0.4242,0.0706), vec3(-0.5698,0.8119,0.1271), vec2(0.7983,0.0078), vec2(0.7988,0.0137), vec2(0.7939,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.487,0.4281,0.0908), vec3(0.4874,0.4308,0.0755), vec3(0.4769,0.4242,0.0706), vec3(-0.5698,0.8119,0.1271), vec2(0.7983,0.0078), vec2(0.7988,0.0137), vec2(0.7939,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4733,0.413,0.0537), vec3(0.5017,0.401,0.0528), vec3(0.4769,0.4242,0.0706), vec3(-0.3046,-0.7642,0.5685), vec2(0.7979,0.0298), vec2(0.8076,0.0161), vec2(0.7939,0.0249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4733,0.413,0.0537), vec3(0.5017,0.401,0.0528), vec3(0.4769,0.4242,0.0706), vec3(-0.3046,-0.7642,0.5685), vec2(0.7979,0.0298), vec2(0.8076,0.0161), vec2(0.7939,0.0249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4843,0.3858,-0.0154), vec3(0.4831,0.3977,0.0049), vec3(0.4855,0.3844,0.0085), vec3(0.9846,0.1695,-0.0425), vec2(0.0473,0.3496), vec2(0.0417,0.3345), vec2(0.054,0.3354), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4803,0.4166,0.0483), vec3(0.4954,0.4129,0.0486), vec3(0.4775,0.3957,0.0334), vec3(0.1549,0.5588,-0.8147), vec2(0.7261,0.9275), vec2(0.73,0.9303), vec2(0.7227,0.9293), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4803,0.4166,0.0483), vec3(0.4954,0.4129,0.0486), vec3(0.4775,0.3957,0.0334), vec3(0.1549,0.5588,-0.8147), vec2(0.7261,0.9275), vec2(0.73,0.9303), vec2(0.7227,0.9293), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4843,0.3858,-0.0154), vec3(0.4855,0.3844,0.0085), vec3(0.4837,0.3714,-0.0075), vec3(0.9961,-0.0674,-0.0566), vec2(0.0473,0.3496), vec2(0.054,0.3354), vec2(0.0585,0.3501), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4956,0.3976,0.0784), vec3(0.47,0.3962,0.0823), vec3(0.4896,0.368,0.0662), vec3(0.1587,-0.405,0.9004), vec2(0.73,0.9196), vec2(0.7261,0.9222), vec2(0.7212,0.9158), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4842,0.4277,0.0593), vec3(0.4982,0.4249,0.0601), vec3(0.4786,0.4081,0.0405), vec3(0.176,0.6556,-0.7343), vec2(0.7983,0.019), vec2(0.8032,0.0186), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4842,0.4277,0.0593), vec3(0.4982,0.4249,0.0601), vec3(0.4786,0.4081,0.0405), vec3(0.176,0.6556,-0.7343), vec2(0.7983,0.019), vec2(0.8032,0.0186), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4707,0.3392,0.0438), vec3(0.5024,0.3799,0.0503), vec3(0.4894,0.3301,0.0409), vec3(-0.0524,0.197,-0.979), vec2(0.71,0.9376), vec2(0.7246,0.9386), vec2(0.7085,0.9448), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.487,0.4281,0.0908), vec3(0.4769,0.4242,0.0706), vec3(0.5036,0.4166,0.0687), vec3(-0.2398,-0.9242,0.2974), vec2(0.7939,0.0161), vec2(0.7939,0.0249), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.487,0.4281,0.0908), vec3(0.4769,0.4242,0.0706), vec3(0.5036,0.4166,0.0687), vec3(-0.2398,-0.9242,0.2974), vec2(0.7939,0.0161), vec2(0.7939,0.0249), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4955,0.3911,0.0341), vec3(0.4775,0.3957,0.0334), vec3(0.4954,0.4129,0.0486), vec3(0.1683,0.5487,-0.8189), vec2(0.7231,0.9333), vec2(0.7227,0.9293), vec2(0.73,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4955,0.3911,0.0341), vec3(0.4775,0.3957,0.0334), vec3(0.4954,0.4129,0.0486), vec3(0.1683,0.5487,-0.8189), vec2(0.7231,0.9333), vec2(0.7227,0.9293), vec2(0.73,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4955,0.3911,0.0341), vec3(0.5024,0.3799,0.0503), vec3(0.4707,0.3392,0.0438), vec3(0.6797,-0.435,-0.5906), vec2(0.7231,0.9333), vec2(0.7246,0.9386), vec2(0.71,0.9376), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.487,0.4281,0.0908), vec3(0.4944,0.427,0.0912), vec3(0.4874,0.4308,0.0755), vec3(0.1267,0.9765,0.1745), vec2(0.7983,0.0078), vec2(0.8018,0.0073), vec2(0.7988,0.0137), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.487,0.4281,0.0908), vec3(0.4944,0.427,0.0912), vec3(0.4874,0.4308,0.0755), vec3(0.1267,0.9765,0.1745), vec2(0.7983,0.0078), vec2(0.8018,0.0073), vec2(0.7988,0.0137), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5062,0.6074,-0.0258), vec3(0.4971,0.6242,0.1068), vec3(0.4659,0.5352,-0.0049), vec3(0.8811,-0.4577,0.1187), vec2(0.6626,0.4756), vec2(0.626,0.4536), vec2(0.6709,0.4399), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4842,0.4277,0.0593), vec3(0.4874,0.4308,0.0755), vec3(0.4982,0.4249,0.0601), vec3(0.205,0.9533,-0.2216), vec2(0.7983,0.019), vec2(0.7988,0.0137), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4842,0.4277,0.0593), vec3(0.4874,0.4308,0.0755), vec3(0.4982,0.4249,0.0601), vec3(0.205,0.9533,-0.2216), vec2(0.7983,0.019), vec2(0.7988,0.0137), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4954,0.4129,0.0486), vec3(0.4716,0.4165,0.0633), vec3(0.5028,0.4082,0.0645), vec3(0.2472,0.9545,0.1669), vec2(0.73,0.9303), vec2(0.7266,0.9252), vec2(0.7344,0.9249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4954,0.4129,0.0486), vec3(0.4716,0.4165,0.0633), vec3(0.5028,0.4082,0.0645), vec3(0.2472,0.9545,0.1669), vec2(0.73,0.9303), vec2(0.7266,0.9252), vec2(0.7344,0.9249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5028,0.4082,0.0645), vec3(0.4716,0.4165,0.0633), vec3(0.4956,0.3976,0.0784), vec3(0.1705,0.7392,0.6515), vec2(0.7344,0.9249), vec2(0.7266,0.9252), vec2(0.73,0.9196), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5028,0.4082,0.0645), vec3(0.4716,0.4165,0.0633), vec3(0.4956,0.3976,0.0784), vec3(0.1705,0.7392,0.6515), vec2(0.7344,0.9249), vec2(0.7266,0.9252), vec2(0.73,0.9196), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4968,0.4026,0.0394), vec3(0.5017,0.401,0.0528), vec3(0.4733,0.413,0.0537), vec3(-0.3864,-0.9216,0.0377), vec2(0.8101,0.0254), vec2(0.8076,0.0161), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4968,0.4026,0.0394), vec3(0.5017,0.401,0.0528), vec3(0.4733,0.413,0.0537), vec3(-0.3864,-0.9216,0.0377), vec2(0.8101,0.0254), vec2(0.8076,0.0161), vec2(0.7979,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4968,0.4026,0.0394), vec3(0.4786,0.4081,0.0405), vec3(0.4982,0.4249,0.0601), vec3(0.1604,0.6665,-0.728), vec2(0.8062,0.0298), vec2(0.7979,0.0298), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4968,0.4026,0.0394), vec3(0.4786,0.4081,0.0405), vec3(0.4982,0.4249,0.0601), vec3(0.1604,0.6665,-0.728), vec2(0.8062,0.0298), vec2(0.7979,0.0298), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4855,0.3844,0.0085), vec3(0.505,0.3131,0.0197), vec3(0.4837,0.3714,-0.0075), vec3(0.9368,0.213,-0.2777), vec2(0.054,0.3354), vec2(0.1024,0.3428), vec2(0.0585,0.3501), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4974,0.4297,0.0758), vec3(0.4874,0.4308,0.0755), vec3(0.4944,0.427,0.0912), vec3(0.0984,0.9773,0.1875), vec2(0.8022,0.0132), vec2(0.7988,0.0137), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4974,0.4297,0.0758), vec3(0.4874,0.4308,0.0755), vec3(0.4944,0.427,0.0912), vec3(0.0984,0.9773,0.1875), vec2(0.8022,0.0132), vec2(0.7988,0.0137), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5024,0.3799,0.0503), vec3(0.4896,0.368,0.0662), vec3(0.4894,0.3301,0.0409), vec3(0.84,-0.3034,0.4498), vec2(0.7246,0.9386), vec2(0.7261,0.9458), vec2(0.7085,0.9448), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5036,0.4166,0.0687), vec3(0.4769,0.4242,0.0706), vec3(0.5017,0.401,0.0528), vec3(-0.1465,-0.6967,0.7022), vec2(0.8018,0.0073), vec2(0.7939,0.0249), vec2(0.8076,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5036,0.4166,0.0687), vec3(0.4769,0.4242,0.0706), vec3(0.5017,0.401,0.0528), vec3(-0.1465,-0.6967,0.7022), vec2(0.8018,0.0073), vec2(0.7939,0.0249), vec2(0.8076,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4974,0.4297,0.0758), vec3(0.4982,0.4249,0.0601), vec3(0.4874,0.4308,0.0755), vec3(0.107,0.9512,-0.2894), vec2(0.8022,0.0132), vec2(0.8032,0.0186), vec2(0.7988,0.0137), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4974,0.4297,0.0758), vec3(0.4982,0.4249,0.0601), vec3(0.4874,0.4308,0.0755), vec3(0.107,0.9512,-0.2894), vec2(0.8022,0.0132), vec2(0.8032,0.0186), vec2(0.7988,0.0137), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4944,0.427,0.0912), vec3(0.487,0.4281,0.0908), vec3(0.5036,0.4166,0.0687), vec3(-0.1431,-0.9191,0.3671), vec2(0.7983,0.0078), vec2(0.7939,0.0161), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4944,0.427,0.0912), vec3(0.487,0.4281,0.0908), vec3(0.5036,0.4166,0.0687), vec3(-0.1431,-0.9191,0.3671), vec2(0.7983,0.0078), vec2(0.7939,0.0161), vec2(0.8018,0.0073), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5024,0.3799,0.0503), vec3(0.4956,0.3976,0.0784), vec3(0.4896,0.368,0.0662), vec3(0.84,-0.3441,0.4195), vec2(0.7246,0.9386), vec2(0.7344,0.9394), vec2(0.7261,0.9458), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4955,0.3911,0.0341), vec3(0.4954,0.4129,0.0486), vec3(0.5024,0.3799,0.0503), vec3(0.944,0.1883,-0.2708), vec2(0.7231,0.9333), vec2(0.73,0.9303), vec2(0.7246,0.9386), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4944,0.427,0.0912), vec3(0.5036,0.4166,0.0687), vec3(0.4974,0.4297,0.0758), vec3(0.9218,0.312,0.2302), vec2(0.8018,0.0073), vec2(0.8076,0.0161), vec2(0.8022,0.0132), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4944,0.427,0.0912), vec3(0.5036,0.4166,0.0687), vec3(0.4974,0.4297,0.0758), vec3(0.9218,0.312,0.2302), vec2(0.8018,0.0073), vec2(0.8076,0.0161), vec2(0.8022,0.0132), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4982,0.4249,0.0601), vec3(0.5017,0.401,0.0528), vec3(0.4968,0.4026,0.0394), vec3(0.9197,0.2355,-0.3142), vec2(0.8032,0.0186), vec2(0.8101,0.0254), vec2(0.8062,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4982,0.4249,0.0601), vec3(0.5017,0.401,0.0528), vec3(0.4968,0.4026,0.0394), vec3(0.9197,0.2355,-0.3142), vec2(0.8032,0.0186), vec2(0.8101,0.0254), vec2(0.8062,0.0298), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4982,0.4249,0.0601), vec3(0.4974,0.4297,0.0758), vec3(0.5036,0.4166,0.0687), vec3(0.8758,0.4715,-0.1031), vec2(0.8032,0.0186), vec2(0.8022,0.0132), vec2(0.8076,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4982,0.4249,0.0601), vec3(0.4974,0.4297,0.0758), vec3(0.5036,0.4166,0.0687), vec3(0.8758,0.4715,-0.1031), vec2(0.8032,0.0186), vec2(0.8022,0.0132), vec2(0.8076,0.0161), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5028,0.4082,0.0645), vec3(0.5024,0.3799,0.0503), vec3(0.4954,0.4129,0.0486), vec3(0.9105,0.176,-0.3742), vec2(0.7329,0.9343), vec2(0.7246,0.9386), vec2(0.73,0.9303), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5028,0.4082,0.0645), vec3(0.4956,0.3976,0.0784), vec3(0.5024,0.3799,0.0503), vec3(0.9232,-0.1828,0.3382), vec2(0.7329,0.9343), vec2(0.7344,0.9394), vec2(0.7246,0.9386), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5036,0.4166,0.0687), vec3(0.5017,0.401,0.0528), vec3(0.4982,0.4249,0.0601), vec3(0.9068,0.2429,-0.3445), vec2(0.8076,0.0161), vec2(0.8101,0.0254), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5036,0.4166,0.0687), vec3(0.5017,0.401,0.0528), vec3(0.4982,0.4249,0.0601), vec3(0.9068,0.2429,-0.3445), vec2(0.8076,0.0161), vec2(0.8101,0.0254), vec2(0.8032,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4971,0.6242,0.1068), vec3(0.5621,0.8478,0.2026), vec3(0.4596,0.607,0.2552), vec3(0.9175,-0.3489,0.191), vec2(0.8994,0.4624), vec2(0.9355,0.4678), vec2(0.9048,0.4922), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5062,0.6074,-0.0258), vec3(0.465,0.5835,-0.1263), vec3(0.5817,0.7687,-0.1105), vec3(0.8334,-0.5065,-0.2213), vec2(0.8877,0.437), vec2(0.876,0.4189), vec2(0.9102,0.4072), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5062,0.6074,-0.0258), vec3(0.5875,0.8021,0.0289), vec3(0.4971,0.6242,0.1068), vec3(0.9048,-0.4101,0.1142), vec2(0.8877,0.437), vec2(0.9219,0.4341), vec2(0.8994,0.4624), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5621,0.8478,0.2026), vec3(0.4971,0.6242,0.1068), vec3(0.5875,0.8021,0.0289), vec3(0.9046,-0.3607,0.2271), vec2(0.9355,0.4678), vec2(0.8994,0.4624), vec2(0.9219,0.4341), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5875,0.8021,0.0289), vec3(0.5062,0.6074,-0.0258), vec3(0.5817,0.7687,-0.1105), vec3(0.9154,-0.3985,0.0574), vec2(0.9219,0.4341), vec2(0.8877,0.437), vec2(0.9102,0.4072), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6421,0.5536,-0.2143), vec3(0.7541,0.6227,-0.0195), vec3(0.6119,0.7612,-0.11), vec3(-0.7333,-0.3876,0.5586), vec2(0.6597,0.1782), vec2(0.6719,0.2217), vec2(0.7031,0.1914), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6514,0.8346,-0.0829), vec3(0.7842,0.6196,-0.0025), vec3(0.717,0.5541,-0.2672), vec3(0.8551,0.4092,-0.3184), vec2(0.2054,0.8118), vec2(0.2499,0.7439), vec2(0.177,0.7528), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8374,0.9354,0.1435), vec3(0.6119,0.7612,-0.11), vec3(0.7541,0.6227,-0.0195), vec3(-0.6585,-0.2025,0.7248), vec2(0.7188,0.2417), vec2(0.7031,0.1914), vec2(0.6719,0.2217), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8299,0.9754,0.1343), vec3(0.7842,0.6196,-0.0025), vec3(0.6514,0.8346,-0.0829), vec3(0.7018,0.1752,-0.6905), vec2(0.2583,0.8077), vec2(0.2499,0.7439), vec2(0.2054,0.8118), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7541,0.6227,-0.0195), vec3(0.9592,0.7218,0.3213), vec3(0.8374,0.9354,0.1435), vec3(-0.8496,-0.0475,0.5252), vec2(0.6719,0.2217), vec2(0.6855,0.2949), vec2(0.7188,0.2417), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7842,0.6196,-0.0025), vec3(0.8299,0.9754,0.1343), vec3(0.9609,0.7237,0.3181), vec3(0.8612,0.0821,-0.5016), vec2(0.2499,0.7439), vec2(0.2583,0.8077), vec2(0.3357,0.7244), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.5801,0.1869,0.0191), 0.1488, bestT)) {
        if (triHit(ro, rd, vec3(0.5968,0.1616,0.0216), vec3(0.6017,0.1672,0.0241), vec3(0.5989,0.1594,0.0396), vec3(0.7696,-0.6163,-0.1673), vec2(0.7817,0.0415), vec2(0.7793,0.041), vec2(0.7812,0.0352), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5968,0.1616,0.0216), vec3(0.6017,0.1672,0.0241), vec3(0.5989,0.1594,0.0396), vec3(0.7696,-0.6163,-0.1673), vec2(0.7817,0.0415), vec2(0.7793,0.041), vec2(0.7812,0.0352), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5989,0.1594,0.0396), vec3(0.5844,0.1676,0.0207), vec3(0.5968,0.1616,0.0216), vec3(-0.4268,-0.9024,-0.0592), vec2(0.7812,0.0352), vec2(0.7861,0.0435), vec2(0.7817,0.0415), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5989,0.1594,0.0396), vec3(0.5844,0.1676,0.0207), vec3(0.5968,0.1616,0.0216), vec3(-0.4268,-0.9024,-0.0592), vec2(0.7812,0.0352), vec2(0.7861,0.0435), vec2(0.7817,0.0415), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5989,0.1594,0.0396), vec3(0.6017,0.1672,0.0241), vec3(0.6019,0.1628,0.0408), vec3(0.7639,-0.6222,-0.1712), vec2(0.7812,0.0352), vec2(0.7793,0.041), vec2(0.7793,0.0347), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5989,0.1594,0.0396), vec3(0.6017,0.1672,0.0241), vec3(0.6019,0.1628,0.0408), vec3(0.7639,-0.6222,-0.1712), vec2(0.7812,0.0352), vec2(0.7793,0.041), vec2(0.7793,0.0347), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5968,0.1616,0.0216), vec3(0.5886,0.1702,0.009), vec3(0.6017,0.1672,0.0241), vec3(0.6843,-0.3157,-0.6573), vec2(0.7817,0.0415), vec2(0.7827,0.0469), vec2(0.7793,0.041), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5968,0.1616,0.0216), vec3(0.5886,0.1702,0.009), vec3(0.6017,0.1672,0.0241), vec3(0.6843,-0.3157,-0.6573), vec2(0.7817,0.0415), vec2(0.7827,0.0469), vec2(0.7793,0.041), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5886,0.1702,0.009), vec3(0.5968,0.1616,0.0216), vec3(0.5844,0.1676,0.0207), vec3(-0.387,-0.8609,-0.3304), vec2(0.7827,0.0469), vec2(0.7817,0.0415), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5886,0.1702,0.009), vec3(0.5968,0.1616,0.0216), vec3(0.5844,0.1676,0.0207), vec3(-0.387,-0.8609,-0.3304), vec2(0.7827,0.0469), vec2(0.7817,0.0415), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6019,0.1628,0.0408), vec3(0.6015,0.1811,0.0224), vec3(0.5989,0.1594,0.0396), vec3(-0.7278,0.4776,0.4922), vec2(0.7744,0.0439), vec2(0.7734,0.0503), vec2(0.7793,0.0347), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6019,0.1628,0.0408), vec3(0.6015,0.1811,0.0224), vec3(0.5989,0.1594,0.0396), vec3(-0.7278,0.4776,0.4922), vec2(0.7744,0.0439), vec2(0.7734,0.0503), vec2(0.7793,0.0347), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5989,0.1594,0.0396), vec3(0.6015,0.1811,0.0224), vec3(0.5844,0.1676,0.0207), vec3(-0.5156,0.5699,0.6399), vec2(0.7793,0.0347), vec2(0.7734,0.0503), vec2(0.7812,0.0352), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5989,0.1594,0.0396), vec3(0.6015,0.1811,0.0224), vec3(0.5844,0.1676,0.0207), vec3(-0.5156,0.5699,0.6399), vec2(0.7793,0.0347), vec2(0.7734,0.0503), vec2(0.7812,0.0352), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6019,0.1628,0.0408), vec3(0.6017,0.1672,0.0241), vec3(0.6015,0.1811,0.0224), vec3(0.9998,0.0163,-0.0072), vec2(0.7793,0.0347), vec2(0.7793,0.041), vec2(0.7744,0.0439), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6019,0.1628,0.0408), vec3(0.6017,0.1672,0.0241), vec3(0.6015,0.1811,0.0224), vec3(0.9998,0.0163,-0.0072), vec2(0.7793,0.0347), vec2(0.7793,0.041), vec2(0.7744,0.0439), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.598,0.1756,0.0129), vec3(0.6017,0.1672,0.0241), vec3(0.5886,0.1702,0.009), vec3(0.5738,-0.5488,-0.6079), vec2(0.7788,0.0459), vec2(0.7793,0.041), vec2(0.7827,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.598,0.1756,0.0129), vec3(0.6017,0.1672,0.0241), vec3(0.5886,0.1702,0.009), vec3(0.5738,-0.5488,-0.6079), vec2(0.7788,0.0459), vec2(0.7793,0.041), vec2(0.7827,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5844,0.1676,0.0207), vec3(0.5751,0.1759,0.012), vec3(0.5886,0.1702,0.009), vec3(-0.431,-0.8357,-0.3405), vec2(0.7861,0.0435), vec2(0.7876,0.0503), vec2(0.7827,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5844,0.1676,0.0207), vec3(0.5751,0.1759,0.012), vec3(0.5886,0.1702,0.009), vec3(-0.431,-0.8357,-0.3405), vec2(0.7861,0.0435), vec2(0.7876,0.0503), vec2(0.7827,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5849,0.1666,0.0161), vec3(0.5969,0.1829,0.0218), vec3(0.5832,0.1706,0.0264), vec3(0.6887,-0.6283,0.3619), vec2(0.6846,0.9939), vec2(0.6851,0.9881), vec2(0.6875,0.9914), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5849,0.1666,0.0161), vec3(0.5969,0.1829,0.0218), vec3(0.5832,0.1706,0.0264), vec3(0.6887,-0.6283,0.3619), vec2(0.6846,0.9939), vec2(0.6851,0.9881), vec2(0.6875,0.9914), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5849,0.1666,0.0161), vec3(0.5832,0.1706,0.0264), vec3(0.5657,0.1841,0.0128), vec3(-0.6785,-0.7169,0.1604), vec2(0.6846,0.9939), vec2(0.6807,0.9971), vec2(0.6772,0.9875), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.598,0.1756,0.0129), vec3(0.6015,0.1811,0.0224), vec3(0.6017,0.1672,0.0241), vec3(0.9417,-0.0242,-0.3356), vec2(0.7788,0.0459), vec2(0.7744,0.0439), vec2(0.7793,0.041), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.598,0.1756,0.0129), vec3(0.6015,0.1811,0.0224), vec3(0.6017,0.1672,0.0241), vec3(0.9417,-0.0242,-0.3356), vec2(0.7788,0.0459), vec2(0.7744,0.0439), vec2(0.7793,0.041), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5849,0.1666,0.0161), vec3(0.5882,0.1757,0.0084), vec3(0.5969,0.1829,0.0218), vec3(0.8216,-0.511,-0.2528), vec2(0.6846,0.9939), vec2(0.6826,0.9893), vec2(0.6851,0.9881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5849,0.1666,0.0161), vec3(0.5882,0.1757,0.0084), vec3(0.5969,0.1829,0.0218), vec3(0.8216,-0.511,-0.2528), vec2(0.6846,0.9939), vec2(0.6826,0.9893), vec2(0.6851,0.9881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5849,0.1666,0.0161), vec3(0.5657,0.1841,0.0128), vec3(0.5882,0.1757,0.0084), vec3(-0.3512,-0.5324,-0.7702), vec2(0.6846,0.9939), vec2(0.6772,0.9875), vec2(0.6826,0.9893), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5832,0.1706,0.0264), vec3(0.5969,0.1829,0.0218), vec3(0.5895,0.1775,0.031), vec3(0.6886,-0.7131,0.1318), vec2(0.6875,0.9914), vec2(0.6851,0.9881), vec2(0.687,0.9889), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5832,0.1706,0.0264), vec3(0.5969,0.1829,0.0218), vec3(0.5895,0.1775,0.031), vec3(0.6886,-0.7131,0.1318), vec2(0.6875,0.9914), vec2(0.6851,0.9881), vec2(0.687,0.9889), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.598,0.1756,0.0129), vec3(0.5886,0.1702,0.009), vec3(0.5758,0.188,0.0011), vec3(0.4304,-0.0866,-0.8985), vec2(0.7788,0.0459), vec2(0.7827,0.0469), vec2(0.7832,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.598,0.1756,0.0129), vec3(0.5886,0.1702,0.009), vec3(0.5758,0.188,0.0011), vec3(0.4304,-0.0866,-0.8985), vec2(0.7788,0.0459), vec2(0.7827,0.0469), vec2(0.7832,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5886,0.1702,0.009), vec3(0.5751,0.1759,0.012), vec3(0.5758,0.188,0.0011), vec3(-0.4078,-0.5961,-0.6916), vec2(0.7827,0.0469), vec2(0.7876,0.0503), vec2(0.7832,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5886,0.1702,0.009), vec3(0.5751,0.1759,0.012), vec3(0.5758,0.188,0.0011), vec3(-0.4078,-0.5961,-0.6916), vec2(0.7827,0.0469), vec2(0.7876,0.0503), vec2(0.7832,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5844,0.1676,0.0207), vec3(0.5941,0.1918,0.0167), vec3(0.5751,0.1759,0.012), vec3(-0.4739,0.3253,0.8183), vec2(0.7812,0.0352), vec2(0.7769,0.0562), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5844,0.1676,0.0207), vec3(0.5941,0.1918,0.0167), vec3(0.5751,0.1759,0.012), vec3(-0.4739,0.3253,0.8183), vec2(0.7812,0.0352), vec2(0.7769,0.0562), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5832,0.1706,0.0264), vec3(0.5895,0.1775,0.031), vec3(0.5624,0.1901,0.0282), vec3(-0.2552,-0.3549,0.8994), vec2(0.6875,0.9914), vec2(0.687,0.9889), vec2(0.6929,0.9872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5941,0.1918,0.0167), vec3(0.5844,0.1676,0.0207), vec3(0.6015,0.1811,0.0224), vec3(-0.3097,0.2742,0.9105), vec2(0.7769,0.0562), vec2(0.7812,0.0352), vec2(0.7734,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5941,0.1918,0.0167), vec3(0.5844,0.1676,0.0207), vec3(0.6015,0.1811,0.0224), vec3(-0.3097,0.2742,0.9105), vec2(0.7769,0.0562), vec2(0.7812,0.0352), vec2(0.7734,0.0503), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5945,0.1838,0.0128), vec3(0.5969,0.1829,0.0218), vec3(0.5882,0.1757,0.0084), vec3(0.8282,-0.4928,-0.2669), vec2(0.6841,0.9877), vec2(0.6851,0.9881), vec2(0.6826,0.9893), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5945,0.1838,0.0128), vec3(0.5969,0.1829,0.0218), vec3(0.5882,0.1757,0.0084), vec3(0.8282,-0.4928,-0.2669), vec2(0.6841,0.9877), vec2(0.6851,0.9881), vec2(0.6826,0.9893), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5624,0.1901,0.0282), vec3(0.5657,0.1841,0.0128), vec3(0.5832,0.1706,0.0264), vec3(-0.6718,-0.727,0.1418), vec2(0.6719,0.9874), vec2(0.6772,0.9875), vec2(0.6807,0.9971), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5941,0.1918,0.0167), vec3(0.6015,0.1811,0.0224), vec3(0.598,0.1756,0.0129), vec3(0.8219,0.3046,-0.4813), vec2(0.7734,0.0503), vec2(0.7744,0.0439), vec2(0.7788,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5941,0.1918,0.0167), vec3(0.6015,0.1811,0.0224), vec3(0.598,0.1756,0.0129), vec3(0.8219,0.3046,-0.4813), vec2(0.7734,0.0503), vec2(0.7744,0.0439), vec2(0.7788,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5945,0.1838,0.0128), vec3(0.5882,0.1757,0.0084), vec3(0.568,0.1949,0.0003), vec3(0.4629,0.1203,-0.8782), vec2(0.6841,0.9877), vec2(0.6826,0.9893), vec2(0.6797,0.9842), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5657,0.1841,0.0128), vec3(0.568,0.1949,0.0003), vec3(0.5882,0.1757,0.0084), vec3(-0.376,-0.6652,-0.6451), vec2(0.6772,0.9875), vec2(0.6797,0.9842), vec2(0.6826,0.9893), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.598,0.1756,0.0129), vec3(0.5758,0.188,0.0011), vec3(0.5851,0.1969,0.0058), vec3(0.4622,-0.0185,-0.8866), vec2(0.7788,0.0459), vec2(0.7832,0.0562), vec2(0.7769,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.598,0.1756,0.0129), vec3(0.5758,0.188,0.0011), vec3(0.5851,0.1969,0.0058), vec3(0.4622,-0.0185,-0.8866), vec2(0.7788,0.0459), vec2(0.7832,0.0562), vec2(0.7769,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5758,0.188,0.0011), vec3(0.5751,0.1759,0.012), vec3(0.5851,0.1969,0.0058), vec3(-0.7167,0.4888,0.4974), vec2(0.7876,0.0503), vec2(0.7861,0.0435), vec2(0.7832,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5758,0.188,0.0011), vec3(0.5751,0.1759,0.012), vec3(0.5851,0.1969,0.0058), vec3(-0.7167,0.4888,0.4974), vec2(0.7876,0.0503), vec2(0.7861,0.0435), vec2(0.7832,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5895,0.1775,0.031), vec3(0.5969,0.1829,0.0218), vec3(0.5716,0.2005,0.0348), vec3(0.6119,0.3579,0.7053), vec2(0.687,0.9889), vec2(0.6851,0.9881), vec2(0.6895,0.9845), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5941,0.1918,0.0167), vec3(0.598,0.1756,0.0129), vec3(0.5851,0.1969,0.0058), vec3(0.7969,0.3077,-0.5199), vec2(0.7734,0.0503), vec2(0.7788,0.0459), vec2(0.7769,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5941,0.1918,0.0167), vec3(0.598,0.1756,0.0129), vec3(0.5851,0.1969,0.0058), vec3(0.7969,0.3077,-0.5199), vec2(0.7734,0.0503), vec2(0.7788,0.0459), vec2(0.7769,0.0562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5941,0.1918,0.0167), vec3(0.5851,0.1969,0.0058), vec3(0.5751,0.1759,0.012), vec3(-0.5603,0.4691,0.6827), vec2(0.7769,0.0562), vec2(0.7832,0.0562), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5941,0.1918,0.0167), vec3(0.5851,0.1969,0.0058), vec3(0.5751,0.1759,0.012), vec3(-0.5603,0.4691,0.6827), vec2(0.7769,0.0562), vec2(0.7832,0.0562), vec2(0.7861,0.0435), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5716,0.2005,0.0348), vec3(0.5624,0.1901,0.0282), vec3(0.5895,0.1775,0.031), vec3(-0.2522,-0.3477,0.9031), vec2(0.6895,0.9845), vec2(0.6929,0.9872), vec2(0.687,0.9889), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5969,0.1829,0.0218), vec3(0.5945,0.1838,0.0128), vec3(0.5827,0.2081,0.0212), vec3(0.8576,0.48,-0.1847), vec2(0.6851,0.9881), vec2(0.6841,0.9877), vec2(0.6855,0.9836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5945,0.1838,0.0128), vec3(0.568,0.1949,0.0003), vec3(0.577,0.2069,0.0069), vec3(0.4654,0.1291,-0.8756), vec2(0.6841,0.9877), vec2(0.6797,0.9842), vec2(0.6826,0.9829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5827,0.2081,0.0212), vec3(0.5716,0.2005,0.0348), vec3(0.5969,0.1829,0.0218), vec3(0.6135,0.3632,0.7012), vec2(0.6855,0.9836), vec2(0.6895,0.9845), vec2(0.6851,0.9881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.577,0.2069,0.0069), vec3(0.5827,0.2081,0.0212), vec3(0.5945,0.1838,0.0128), vec3(0.7876,0.5047,-0.3535), vec2(0.6826,0.9829), vec2(0.6855,0.9836), vec2(0.6841,0.9877), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5657,0.1841,0.0128), vec3(0.5624,0.1901,0.0282), vec3(0.5141,0.2452,0.022), vec3(-0.7535,-0.6507,0.0945), vec2(0.6772,0.9875), vec2(0.6719,0.9874), vec2(0.6714,0.9616), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.568,0.1949,0.0003), vec3(0.5657,0.1841,0.0128), vec3(0.5141,0.2452,0.022), vec3(-0.6777,-0.4896,-0.5487), vec2(0.6797,0.9842), vec2(0.6772,0.9875), vec2(0.6714,0.9616), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5624,0.1901,0.0282), vec3(0.5716,0.2005,0.0348), vec3(0.5123,0.2535,0.0426), vec3(-0.2175,-0.3767,0.9004), vec2(0.6929,0.9872), vec2(0.6895,0.9845), vec2(0.6978,0.9676), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.577,0.2069,0.0069), vec3(0.568,0.1949,0.0003), vec3(0.5191,0.2571,0.0087), vec3(0.2454,0.3158,-0.9165), vec2(0.6826,0.9829), vec2(0.6797,0.9842), vec2(0.6777,0.96), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5716,0.2005,0.0348), vec3(0.5827,0.2081,0.0212), vec3(0.5214,0.2623,0.0443), vec3(0.6016,0.3815,0.7018), vec2(0.6895,0.9845), vec2(0.6855,0.9836), vec2(0.6948,0.9653), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5093,0.2169,0.0084), vec3(0.507,0.2494,0.016), vec3(0.497,0.2163,0.0246), vec3(0.7957,-0.0853,0.5996), vec2(0.6621,0.9518), vec2(0.6699,0.9569), vec2(0.6626,0.9553), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5827,0.2081,0.0212), vec3(0.577,0.2069,0.0069), vec3(0.5266,0.2677,0.016), vec3(0.7014,0.6319,-0.3298), vec2(0.6855,0.9836), vec2(0.6826,0.9829), vec2(0.6841,0.9601), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5093,0.2169,0.0084), vec3(0.4988,0.2178,-0.0088), vec3(0.507,0.2494,0.016), vec3(0.8459,0.1764,-0.5034), vec2(0.6621,0.9518), vec2(0.6611,0.947), vec2(0.6699,0.9569), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5123,0.2535,0.0426), vec3(0.5141,0.2452,0.022), vec3(0.5624,0.1901,0.0282), vec3(-0.7482,-0.6352,0.1914), vec2(0.667,0.9621), vec2(0.6714,0.9616), vec2(0.6719,0.9874), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5141,0.2452,0.022), vec3(0.5191,0.2571,0.0087), vec3(0.568,0.1949,0.0003), vec3(-0.6509,-0.4266,-0.628), vec2(0.6714,0.9616), vec2(0.6777,0.96), vec2(0.6797,0.9842), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5214,0.2623,0.0443), vec3(0.5123,0.2535,0.0426), vec3(0.5716,0.2005,0.0348), vec3(-0.021,-0.169,0.9854), vec2(0.6948,0.9653), vec2(0.6978,0.9676), vec2(0.6895,0.9845), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5191,0.2571,0.0087), vec3(0.5266,0.2677,0.016), vec3(0.577,0.2069,0.0069), vec3(0.3086,0.3871,-0.8689), vec2(0.6777,0.96), vec2(0.6841,0.9601), vec2(0.6826,0.9829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5308,0.2703,0.0328), vec3(0.5214,0.2623,0.0443), vec3(0.5827,0.2081,0.0212), vec3(0.5872,0.3541,0.7279), vec2(0.6904,0.9625), vec2(0.6948,0.9653), vec2(0.6855,0.9836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5266,0.2677,0.016), vec3(0.5308,0.2703,0.0328), vec3(0.5827,0.2081,0.0212), vec3(0.711,0.6453,-0.2793), vec2(0.6841,0.9601), vec2(0.6904,0.9625), vec2(0.6855,0.9836), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.4858,0.1407,-0.0102), 0.134, bestT)) {
        if (triHit(ro, rd, vec3(0.5093,0.2169,0.0084), vec3(0.497,0.2163,0.0246), vec3(0.4941,0.1246,0.0096), vec3(0.7932,-0.123,0.5964), vec2(0.6621,0.9518), vec2(0.6626,0.9553), vec2(0.6406,0.9556), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5011,0.1267,-0.0135), vec3(0.5093,0.2169,0.0084), vec3(0.4941,0.1246,0.0096), vec3(0.9497,-0.153,0.2733), vec2(0.6411,0.9505), vec2(0.6621,0.9518), vec2(0.6406,0.9556), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5011,0.1267,-0.0135), vec3(0.4941,0.1246,0.0096), vec3(0.4942,0.0824,-0.0007), vec3(0.9567,-0.0668,0.2833), vec2(0.6411,0.9505), vec2(0.6406,0.9556), vec2(0.624,0.9559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4988,0.2178,-0.0088), vec3(0.5093,0.2169,0.0084), vec3(0.5011,0.1267,-0.0135), vec3(0.8552,0.0475,-0.516), vec2(0.6611,0.947), vec2(0.6621,0.9518), vec2(0.6411,0.9505), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5064,0.082,-0.0185), vec3(0.5011,0.1267,-0.0135), vec3(0.4942,0.0824,-0.0007), vec3(0.8251,0.0353,0.5639), vec2(0.626,0.9495), vec2(0.6411,0.9505), vec2(0.624,0.9559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5064,0.082,-0.0185), vec3(0.498,0.0861,-0.0335), vec3(0.5011,0.1267,-0.0135), vec3(0.8791,0.1549,-0.4509), vec2(0.626,0.9495), vec2(0.6279,0.9452), vec2(0.6411,0.9505), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4977,0.1279,-0.0312), vec3(0.4988,0.2178,-0.0088), vec3(0.5011,0.1267,-0.0135), vec3(0.9825,0.0335,-0.1832), vec2(0.6421,0.946), vec2(0.6611,0.947), vec2(0.6411,0.9505), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4977,0.1279,-0.0312), vec3(0.5011,0.1267,-0.0135), vec3(0.498,0.0861,-0.0335), vec3(0.9827,0.0163,-0.1845), vec2(0.6421,0.946), vec2(0.6411,0.9505), vec2(0.6279,0.9452), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4755,0.1245,-0.0365), vec3(0.4977,0.1279,-0.0312), vec3(0.498,0.0861,-0.0335), vec3(0.2248,0.0549,-0.9729), vec2(0.6416,0.9413), vec2(0.6421,0.946), vec2(0.6279,0.9452), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.48,0.0833,-0.0378), vec3(0.4755,0.1245,-0.0365), vec3(0.498,0.0861,-0.0335), vec3(0.2248,0.0549,-0.9729), vec2(0.6279,0.9412), vec2(0.6416,0.9413), vec2(0.6279,0.9452), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4808,0.215,-0.0131), vec3(0.4988,0.2178,-0.0088), vec3(0.4977,0.1279,-0.0312), vec3(0.1922,0.2345,-0.9529), vec2(0.6602,0.9415), vec2(0.6611,0.947), vec2(0.6421,0.946), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4755,0.1245,-0.0365), vec3(0.4808,0.215,-0.0131), vec3(0.4977,0.1279,-0.0312), vec3(0.1925,0.2345,-0.9529), vec2(0.6416,0.9413), vec2(0.6602,0.9415), vec2(0.6421,0.946), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4749,0.2095,0.0026), vec3(0.4808,0.215,-0.0131), vec3(0.4755,0.1245,-0.0365), vec3(-0.9421,0.1344,-0.3071), vec2(0.6597,0.9368), vec2(0.6602,0.9415), vec2(0.6416,0.9413), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4623,0.1176,-0.0186), vec3(0.4749,0.2095,0.0026), vec3(0.4755,0.1245,-0.0365), vec3(-0.8224,0.2327,-0.5191), vec2(0.6396,0.9373), vec2(0.6597,0.9368), vec2(0.6416,0.9413), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4623,0.1176,-0.0186), vec3(0.4755,0.1245,-0.0365), vec3(0.48,0.0833,-0.0378), vec3(-0.7893,-0.0662,-0.6105), vec2(0.6396,0.9373), vec2(0.6416,0.9413), vec2(0.6279,0.9412), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4558,0.1269,-0.0008), vec3(0.4623,0.1176,-0.0186), vec3(0.4769,0.0812,-0.0053), vec3(-0.9053,-0.4079,-0.1184), vec2(0.6416,0.933), vec2(0.6396,0.9373), vec2(0.627,0.9333), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4769,0.0812,-0.0053), vec3(0.4942,0.0824,-0.0007), vec3(0.4558,0.1269,-0.0008), vec3(-0.2431,-0.2062,0.9478), vec2(0.627,0.9333), vec2(0.6255,0.9282), vec2(0.6416,0.933), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4623,0.1176,-0.0186), vec3(0.4558,0.1269,-0.0008), vec3(0.4749,0.2095,0.0026), vec3(-0.8733,0.2202,-0.4347), vec2(0.6396,0.9373), vec2(0.6416,0.933), vec2(0.6597,0.9368), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4941,0.1246,0.0096), vec3(0.4558,0.1269,-0.0008), vec3(0.4942,0.0824,-0.0007), vec3(-0.2688,-0.2284,0.9357), vec2(0.6411,0.9287), vec2(0.6416,0.933), vec2(0.6255,0.9282), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4701,0.2152,0.0201), vec3(0.4749,0.2095,0.0026), vec3(0.4558,0.1269,-0.0008), vec3(-0.9176,0.226,-0.3269), vec2(0.6616,0.9326), vec2(0.6597,0.9368), vec2(0.6416,0.933), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4558,0.1269,-0.0008), vec3(0.4941,0.1246,0.0096), vec3(0.4701,0.2152,0.0201), vec3(-0.2687,-0.1803,0.9462), vec2(0.6416,0.933), vec2(0.6411,0.9287), vec2(0.6616,0.9326), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.497,0.2163,0.0246), vec3(0.4701,0.2152,0.0201), vec3(0.4941,0.1246,0.0096), vec3(-0.1569,-0.1542,0.9755), vec2(0.6616,0.9293), vec2(0.6616,0.9326), vec2(0.6411,0.9287), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.4887,0.0497,-0.0227), 0.1229, bestT)) {
        if (triHit(ro, rd, vec3(0.49,0.0156,-0.0049), vec3(0.4946,0.0247,-0.0226), vec3(0.4953,0.0166,-0.0042), vec3(0.2152,-0.8904,-0.4011), vec2(0.7651,0.0112), vec2(0.7632,0.0186), vec2(0.7632,0.0112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.49,0.0156,-0.0049), vec3(0.4946,0.0247,-0.0226), vec3(0.4953,0.0166,-0.0042), vec3(0.2152,-0.8904,-0.4011), vec2(0.7651,0.0112), vec2(0.7632,0.0186), vec2(0.7632,0.0112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4946,0.0247,-0.0226), vec3(0.49,0.0156,-0.0049), vec3(0.4858,0.0233,-0.0243), vec3(0.2248,-0.8894,-0.398), vec2(0.7632,0.0186), vec2(0.7651,0.0112), vec2(0.7656,0.019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4946,0.0247,-0.0226), vec3(0.49,0.0156,-0.0049), vec3(0.4858,0.0233,-0.0243), vec3(0.2248,-0.8894,-0.398), vec2(0.7632,0.0186), vec2(0.7651,0.0112), vec2(0.7656,0.019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.49,0.0156,-0.0049), vec3(0.4953,0.0166,-0.0042), vec3(0.4781,0.037,-0.0211), vec3(-0.199,0.5214,0.8298), vec2(0.7632,0.0112), vec2(0.7578,0.0215), vec2(0.7651,0.0112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.49,0.0156,-0.0049), vec3(0.4953,0.0166,-0.0042), vec3(0.4781,0.037,-0.0211), vec3(-0.199,0.5214,0.8298), vec2(0.7632,0.0112), vec2(0.7578,0.0215), vec2(0.7651,0.0112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.49,0.0156,-0.0049), vec3(0.4781,0.037,-0.0211), vec3(0.4858,0.0233,-0.0243), vec3(-0.8735,-0.4868,-0.0013), vec2(0.7651,0.0112), vec2(0.771,0.0215), vec2(0.7656,0.019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.49,0.0156,-0.0049), vec3(0.4781,0.037,-0.0211), vec3(0.4858,0.0233,-0.0243), vec3(-0.8735,-0.4868,-0.0013), vec2(0.7651,0.0112), vec2(0.771,0.0215), vec2(0.7656,0.019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4953,0.0166,-0.0042), vec3(0.4946,0.0247,-0.0226), vec3(0.5034,0.0384,-0.0234), vec3(0.801,-0.5359,-0.2668), vec2(0.7632,0.0112), vec2(0.7632,0.0186), vec2(0.7578,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4953,0.0166,-0.0042), vec3(0.4946,0.0247,-0.0226), vec3(0.5034,0.0384,-0.0234), vec3(0.801,-0.5359,-0.2668), vec2(0.7632,0.0112), vec2(0.7632,0.0186), vec2(0.7578,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4958,0.0363,-0.0317), vec3(0.4946,0.0247,-0.0226), vec3(0.4858,0.0233,-0.0243), vec3(0.2471,-0.6175,-0.7468), vec2(0.7622,0.0229), vec2(0.7632,0.0186), vec2(0.7656,0.019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4958,0.0363,-0.0317), vec3(0.4946,0.0247,-0.0226), vec3(0.4858,0.0233,-0.0243), vec3(0.2471,-0.6175,-0.7468), vec2(0.7622,0.0229), vec2(0.7632,0.0186), vec2(0.7656,0.019), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4953,0.0166,-0.0042), vec3(0.5034,0.0384,-0.0234), vec3(0.4781,0.037,-0.0211), vec3(0.0327,0.6547,0.7552), vec2(0.7578,0.0215), vec2(0.7554,0.0327), vec2(0.7651,0.0112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4953,0.0166,-0.0042), vec3(0.5034,0.0384,-0.0234), vec3(0.4781,0.037,-0.0211), vec3(0.0327,0.6547,0.7552), vec2(0.7578,0.0215), vec2(0.7554,0.0327), vec2(0.7651,0.0112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4958,0.0363,-0.0317), vec3(0.4858,0.0233,-0.0243), vec3(0.4826,0.0381,-0.0337), vec3(0.0559,-0.5282,-0.8473), vec2(0.7622,0.0229), vec2(0.7656,0.019), vec2(0.7666,0.0239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4958,0.0363,-0.0317), vec3(0.4858,0.0233,-0.0243), vec3(0.4826,0.0381,-0.0337), vec3(0.0559,-0.5282,-0.8473), vec2(0.7622,0.0229), vec2(0.7656,0.019), vec2(0.7666,0.0239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4826,0.0381,-0.0337), vec3(0.4858,0.0233,-0.0243), vec3(0.4781,0.037,-0.0211), vec3(-0.853,-0.3977,-0.338), vec2(0.7666,0.0239), vec2(0.7656,0.019), vec2(0.771,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4826,0.0381,-0.0337), vec3(0.4858,0.0233,-0.0243), vec3(0.4781,0.037,-0.0211), vec3(-0.853,-0.3977,-0.338), vec2(0.7666,0.0239), vec2(0.7656,0.019), vec2(0.771,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4958,0.0363,-0.0317), vec3(0.5034,0.0384,-0.0234), vec3(0.4946,0.0247,-0.0226), vec3(0.7006,-0.4864,-0.5221), vec2(0.7622,0.0229), vec2(0.7578,0.0215), vec2(0.7632,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4958,0.0363,-0.0317), vec3(0.5034,0.0384,-0.0234), vec3(0.4946,0.0247,-0.0226), vec3(0.7006,-0.4864,-0.5221), vec2(0.7622,0.0229), vec2(0.7578,0.0215), vec2(0.7632,0.0186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4781,0.037,-0.0211), vec3(0.4741,0.063,-0.0251), vec3(0.4826,0.0381,-0.0337), vec3(-0.9187,-0.1945,-0.3436), vec2(0.771,0.0215), vec2(0.7725,0.0327), vec2(0.7666,0.0239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4781,0.037,-0.0211), vec3(0.4741,0.063,-0.0251), vec3(0.4826,0.0381,-0.0337), vec3(-0.9187,-0.1945,-0.3436), vec2(0.771,0.0215), vec2(0.7725,0.0327), vec2(0.7666,0.0239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5034,0.0647,-0.0244), vec3(0.5034,0.0384,-0.0234), vec3(0.4958,0.0363,-0.0317), vec3(0.7393,-0.027,-0.6729), vec2(0.7554,0.0327), vec2(0.7578,0.0215), vec2(0.7622,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5034,0.0647,-0.0244), vec3(0.5034,0.0384,-0.0234), vec3(0.4958,0.0363,-0.0317), vec3(0.7393,-0.027,-0.6729), vec2(0.7554,0.0327), vec2(0.7578,0.0215), vec2(0.7622,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5034,0.0647,-0.0244), vec3(0.4781,0.037,-0.0211), vec3(0.5034,0.0384,-0.0234), vec3(0.0884,0.0389,0.9953), vec2(0.7598,0.0396), vec2(0.7651,0.0112), vec2(0.7554,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5034,0.0647,-0.0244), vec3(0.4781,0.037,-0.0211), vec3(0.5034,0.0384,-0.0234), vec3(0.0884,0.0389,0.9953), vec2(0.7598,0.0396), vec2(0.7651,0.0112), vec2(0.7554,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4958,0.0363,-0.0317), vec3(0.4826,0.0381,-0.0337), vec3(0.4962,0.0778,-0.0336), vec3(0.1432,-0.046,-0.9886), vec2(0.7622,0.0229), vec2(0.7666,0.0239), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4958,0.0363,-0.0317), vec3(0.4826,0.0381,-0.0337), vec3(0.4962,0.0778,-0.0336), vec3(0.1432,-0.046,-0.9886), vec2(0.7622,0.0229), vec2(0.7666,0.0239), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4796,0.0518,-0.0097), vec3(0.4762,0.048,-0.0216), vec3(0.4914,0.0527,-0.0065), vec3(-0.0171,-0.9501,0.3114), vec2(0.6216,0.9368), vec2(0.6221,0.9387), vec2(0.6162,0.9355), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4796,0.0518,-0.0097), vec3(0.4762,0.048,-0.0216), vec3(0.4914,0.0527,-0.0065), vec3(-0.0171,-0.9501,0.3114), vec2(0.6216,0.9368), vec2(0.6221,0.9387), vec2(0.6162,0.9355), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4998,0.0524,-0.0188), vec3(0.4914,0.0527,-0.0065), vec3(0.4762,0.048,-0.0216), vec3(0.1652,-0.9769,0.1358), vec2(0.6167,0.9436), vec2(0.6162,0.9355), vec2(0.6221,0.9387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4998,0.0524,-0.0188), vec3(0.4914,0.0527,-0.0065), vec3(0.4762,0.048,-0.0216), vec3(0.1652,-0.9769,0.1358), vec2(0.6167,0.9436), vec2(0.6162,0.9355), vec2(0.6221,0.9387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4762,0.048,-0.0216), vec3(0.4842,0.0537,-0.0319), vec3(0.4998,0.0524,-0.0188), vec3(0.2111,-0.9155,-0.3424), vec2(0.6221,0.9387), vec2(0.623,0.9405), vec2(0.6167,0.9436), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4762,0.048,-0.0216), vec3(0.4842,0.0537,-0.0319), vec3(0.4998,0.0524,-0.0188), vec3(0.2111,-0.9155,-0.3424), vec2(0.6221,0.9387), vec2(0.623,0.9405), vec2(0.6167,0.9436), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4966,0.0556,-0.0289), vec3(0.4998,0.0524,-0.0188), vec3(0.4842,0.0537,-0.0319), vec3(0.2263,-0.9053,-0.3595), vec2(0.6216,0.9431), vec2(0.6167,0.9436), vec2(0.623,0.9405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4966,0.0556,-0.0289), vec3(0.4998,0.0524,-0.0188), vec3(0.4842,0.0537,-0.0319), vec3(0.2263,-0.9053,-0.3595), vec2(0.6216,0.9431), vec2(0.6167,0.9436), vec2(0.623,0.9405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4741,0.063,-0.0251), vec3(0.4781,0.037,-0.0211), vec3(0.5034,0.0647,-0.0244), vec3(-0.0295,0.1458,0.9889), vec2(0.771,0.0215), vec2(0.7651,0.0112), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4741,0.063,-0.0251), vec3(0.4781,0.037,-0.0211), vec3(0.5034,0.0647,-0.0244), vec3(-0.0295,0.1458,0.9889), vec2(0.771,0.0215), vec2(0.7651,0.0112), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4762,0.048,-0.0216), vec3(0.4796,0.0518,-0.0097), vec3(0.472,0.0756,-0.0226), vec3(-0.9418,-0.1306,0.3098), vec2(0.6221,0.9387), vec2(0.6216,0.9368), vec2(0.6265,0.9377), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4762,0.048,-0.0216), vec3(0.472,0.0756,-0.0226), vec3(0.4842,0.0537,-0.0319), vec3(-0.7459,-0.1369,-0.6519), vec2(0.6221,0.9387), vec2(0.6265,0.9377), vec2(0.623,0.9405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4826,0.0381,-0.0337), vec3(0.4741,0.063,-0.0251), vec3(0.4807,0.0764,-0.0366), vec3(-0.82,-0.0835,-0.5662), vec2(0.7666,0.0239), vec2(0.7725,0.0327), vec2(0.7671,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4826,0.0381,-0.0337), vec3(0.4741,0.063,-0.0251), vec3(0.4807,0.0764,-0.0366), vec3(-0.82,-0.0835,-0.5662), vec2(0.7666,0.0239), vec2(0.7725,0.0327), vec2(0.7671,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5034,0.0647,-0.0244), vec3(0.4958,0.0363,-0.0317), vec3(0.4962,0.0778,-0.0336), vec3(0.7573,-0.0372,-0.652), vec2(0.7554,0.0327), vec2(0.7622,0.0229), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5034,0.0647,-0.0244), vec3(0.4958,0.0363,-0.0317), vec3(0.4962,0.0778,-0.0336), vec3(0.7573,-0.0372,-0.652), vec2(0.7554,0.0327), vec2(0.7622,0.0229), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4796,0.0518,-0.0097), vec3(0.4914,0.0527,-0.0065), vec3(0.4769,0.0812,-0.0053), vec3(-0.2474,-0.164,0.9549), vec2(0.6216,0.9368), vec2(0.6162,0.9355), vec2(0.627,0.9333), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4998,0.0524,-0.0188), vec3(0.5064,0.082,-0.0185), vec3(0.4914,0.0527,-0.0065), vec3(0.8094,-0.1841,0.5576), vec2(0.6167,0.9436), vec2(0.626,0.9495), vec2(0.6138,0.9489), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4998,0.0524,-0.0188), vec3(0.4966,0.0556,-0.0289), vec3(0.5064,0.082,-0.0185), vec3(0.9137,-0.1999,-0.3537), vec2(0.6167,0.9436), vec2(0.6216,0.9431), vec2(0.626,0.9495), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4807,0.0764,-0.0366), vec3(0.4962,0.0778,-0.0336), vec3(0.4826,0.0381,-0.0337), vec3(0.1947,-0.0637,-0.9788), vec2(0.7671,0.0396), vec2(0.7598,0.0396), vec2(0.7666,0.0239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4807,0.0764,-0.0366), vec3(0.4962,0.0778,-0.0336), vec3(0.4826,0.0381,-0.0337), vec3(0.1947,-0.0637,-0.9788), vec2(0.7671,0.0396), vec2(0.7598,0.0396), vec2(0.7666,0.0239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4842,0.0537,-0.0319), vec3(0.48,0.0833,-0.0378), vec3(0.4966,0.0556,-0.0289), vec3(0.2529,-0.1537,-0.9552), vec2(0.623,0.9405), vec2(0.6279,0.9412), vec2(0.6216,0.9431), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4807,0.0764,-0.0366), vec3(0.4741,0.063,-0.0251), vec3(0.5034,0.0647,-0.0244), vec3(-0.0544,0.6652,0.7447), vec2(0.7725,0.0327), vec2(0.771,0.0215), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4807,0.0764,-0.0366), vec3(0.4741,0.063,-0.0251), vec3(0.5034,0.0647,-0.0244), vec3(-0.0544,0.6652,0.7447), vec2(0.7725,0.0327), vec2(0.771,0.0215), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4769,0.0812,-0.0053), vec3(0.472,0.0756,-0.0226), vec3(0.4796,0.0518,-0.0097), vec3(-0.9418,-0.1305,0.3099), vec2(0.627,0.9333), vec2(0.6265,0.9377), vec2(0.6216,0.9368), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.472,0.0756,-0.0226), vec3(0.48,0.0833,-0.0378), vec3(0.4842,0.0537,-0.0319), vec3(-0.8128,-0.222,-0.5385), vec2(0.6265,0.9377), vec2(0.6279,0.9412), vec2(0.623,0.9405), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4942,0.0824,-0.0007), vec3(0.4769,0.0812,-0.0053), vec3(0.4914,0.0527,-0.0065), vec3(-0.2479,-0.1642,0.9548), vec2(0.6255,0.9282), vec2(0.627,0.9333), vec2(0.6162,0.9355), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5064,0.082,-0.0185), vec3(0.4942,0.0824,-0.0007), vec3(0.4914,0.0527,-0.0065), vec3(0.8091,-0.1836,0.5583), vec2(0.626,0.9495), vec2(0.624,0.9559), vec2(0.6138,0.9489), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4962,0.0778,-0.0336), vec3(0.4807,0.0764,-0.0366), vec3(0.5034,0.0647,-0.0244), vec3(-0.207,0.4808,0.8521), vec2(0.7671,0.0396), vec2(0.7725,0.0327), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4962,0.0778,-0.0336), vec3(0.4807,0.0764,-0.0366), vec3(0.5034,0.0647,-0.0244), vec3(-0.207,0.4808,0.8521), vec2(0.7671,0.0396), vec2(0.7725,0.0327), vec2(0.7598,0.0396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.498,0.0861,-0.0335), vec3(0.5064,0.082,-0.0185), vec3(0.4966,0.0556,-0.0289), vec3(0.8526,-0.1155,-0.5097), vec2(0.6279,0.9452), vec2(0.626,0.9495), vec2(0.6216,0.9431), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.48,0.0833,-0.0378), vec3(0.498,0.0861,-0.0335), vec3(0.4966,0.0556,-0.0289), vec3(0.2525,-0.1539,-0.9553), vec2(0.6279,0.9412), vec2(0.6279,0.9452), vec2(0.6216,0.9431), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.472,0.0756,-0.0226), vec3(0.4769,0.0812,-0.0053), vec3(0.4623,0.1176,-0.0186), vec3(-0.9096,-0.243,0.3371), vec2(0.6265,0.9377), vec2(0.627,0.9333), vec2(0.6396,0.9373), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.472,0.0756,-0.0226), vec3(0.4623,0.1176,-0.0186), vec3(0.48,0.0833,-0.0378), vec3(-0.8436,-0.1467,-0.5166), vec2(0.6265,0.9377), vec2(0.6396,0.9373), vec2(0.6279,0.9412), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.8886,0.3336,-0.2312), 0.7289, bestT)) {
        if (triHit(ro, rd, vec3(0.9668,0.2819,-0.4759), vec3(1.3079,-0.1204,-0.3024), vec3(1.0477,0.2768,-0.6664), vec3(0.6748,0.6877,0.2679), vec2(0.1436,0.6477), vec2(0.2474,0.5112), vec2(0.0934,0.6282), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.3079,-0.1204,-0.3024), vec3(0.9668,0.2819,-0.4759), vec3(1.1996,-0.0465,-0.1315), vec3(0.7173,0.6778,0.1616), vec2(0.2474,0.5112), vec2(0.1436,0.6477), vec2(0.2808,0.553), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9668,0.2819,-0.4759), vec3(0.8709,0.3186,-0.3266), vec3(1.1996,-0.0465,-0.1315), vec3(0.6528,0.7175,0.243), vec2(0.1436,0.6477), vec2(0.1854,0.6741), vec2(0.2808,0.553), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9668,0.2819,-0.4759), vec3(0.8348,0.4686,-0.4785), vec3(0.8709,0.3186,-0.3266), vec3(0.7609,0.5429,0.3554), vec2(0.1436,0.6477), vec2(0.1287,0.7048), vec2(0.1854,0.6741), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0911,0.1191,0.0276), vec3(1.1996,-0.0465,-0.1315), vec3(0.8709,0.3186,-0.3266), vec3(0.7698,0.6256,-0.1263), vec2(0.3049,0.6011), vec2(0.2808,0.553), vec2(0.1854,0.6741), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8348,0.4686,-0.4785), vec3(0.7808,0.4873,-0.3644), vec3(0.8709,0.3186,-0.3266), vec3(0.811,0.5009,0.3021), vec2(0.1287,0.7048), vec2(0.1591,0.7239), vec2(0.1854,0.6741), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8709,0.3186,-0.3266), vec3(0.7901,0.3874,-0.184), vec3(1.0911,0.1191,0.0276), vec3(0.6606,0.7506,0.012), vec2(0.1854,0.6741), vec2(0.2158,0.7061), vec2(0.3049,0.6011), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7808,0.4873,-0.3644), vec3(0.7901,0.3874,-0.184), vec3(0.8709,0.3186,-0.3266), vec3(0.8353,0.4983,0.2325), vec2(0.1591,0.7239), vec2(0.2158,0.7061), vec2(0.1854,0.6741), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9638,0.3379,0.178), vec3(1.0911,0.1191,0.0276), vec3(0.7901,0.3874,-0.184), vec3(0.7396,0.6162,-0.2707), vec2(0.321,0.6643), vec2(0.3049,0.6011), vec2(0.2158,0.7061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.717,0.5541,-0.2672), vec3(0.7901,0.3874,-0.184), vec3(0.7808,0.4873,-0.3644), vec3(0.8465,0.4832,0.2236), vec2(0.177,0.7528), vec2(0.2158,0.7061), vec2(0.1591,0.7239), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.717,0.5541,-0.2672), vec3(0.7808,0.4873,-0.3644), vec3(0.7646,0.6244,-0.6263), vec3(0.841,0.4989,0.2092), vec2(0.177,0.7528), vec2(0.1591,0.7239), vec2(0.0676,0.7512), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7901,0.3874,-0.184), vec3(0.7842,0.6196,-0.0025), vec3(0.9638,0.3379,0.178), vec3(0.8716,0.3156,-0.3752), vec2(0.2158,0.7061), vec2(0.2499,0.7439), vec2(0.321,0.6643), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7901,0.3874,-0.184), vec3(0.717,0.5541,-0.2672), vec3(0.7842,0.6196,-0.0025), vec3(0.9201,0.2557,-0.2969), vec2(0.2158,0.7061), vec2(0.177,0.7528), vec2(0.2499,0.7439), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9609,0.7237,0.3181), vec3(0.9638,0.3379,0.178), vec3(0.7842,0.6196,-0.0025), vec3(0.8305,0.1956,-0.5215), vec2(0.3357,0.7244), vec2(0.321,0.6643), vec2(0.2499,0.7439), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0109,0.2297,-0.6658), vec3(1.2889,-0.1372,-0.302), vec3(0.9245,0.2358,-0.4731), vec3(-0.629,-0.7331,-0.2587), vec2(0.5166,0.0957), vec2(0.4917,0.2139), vec2(0.5532,0.1372), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.1877,-0.0593,-0.1295), vec3(0.9245,0.2358,-0.4731), vec3(1.2889,-0.1372,-0.302), vec3(-0.6933,-0.7158,-0.0837), vec2(0.5356,0.2417), vec2(0.5532,0.1372), vec2(0.4917,0.2139), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9245,0.2358,-0.4731), vec3(1.1877,-0.0593,-0.1295), vec3(0.8404,0.2884,-0.3218), vec3(-0.6696,-0.7335,-0.1171), vec2(0.5532,0.1372), vec2(0.5356,0.2417), vec2(0.5903,0.1714), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8404,0.2884,-0.3218), vec3(0.7601,0.4053,-0.463), vec3(0.9245,0.2358,-0.4731), vec3(-0.7135,-0.6822,-0.1594), vec2(0.5903,0.1714), vec2(0.5942,0.1309), vec2(0.5532,0.1372), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0846,0.1129,0.0282), vec3(0.8404,0.2884,-0.3218), vec3(1.1877,-0.0593,-0.1295), vec3(-0.7467,-0.6334,0.2033), vec2(0.5811,0.2627), vec2(0.5903,0.1714), vec2(0.5356,0.2417), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7084,0.4329,-0.3424), vec3(0.7601,0.4053,-0.463), vec3(0.8404,0.2884,-0.3218), vec3(-0.7186,-0.6783,-0.1533), vec2(0.6216,0.1567), vec2(0.5942,0.1309), vec2(0.5903,0.1714), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7084,0.4329,-0.3424), vec3(0.6973,0.5457,-0.5774), vec3(0.7601,0.4053,-0.463), vec3(-0.8089,-0.5441,-0.2228), vec2(0.6216,0.1567), vec2(0.6055,0.0903), vec2(0.5942,0.1309), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8404,0.2884,-0.3218), vec3(1.0846,0.1129,0.0282), vec3(0.7671,0.3779,-0.1778), vec3(-0.6774,-0.7277,0.1076), vec2(0.5903,0.1714), vec2(0.5811,0.2627), vec2(0.6265,0.1968), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7671,0.3779,-0.1778), vec3(0.7084,0.4329,-0.3424), vec3(0.8404,0.2884,-0.3218), vec3(-0.7405,-0.6708,0.04), vec2(0.6265,0.1968), vec2(0.6216,0.1567), vec2(0.5903,0.1714), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9709,0.286,0.1789), vec3(0.7671,0.3779,-0.1778), vec3(1.0846,0.1129,0.0282), vec3(-0.7078,-0.6671,0.2323), vec2(0.6348,0.2788), vec2(0.6265,0.1968), vec2(0.5811,0.2627), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7084,0.4329,-0.3424), vec3(0.7671,0.3779,-0.1778), vec3(0.6421,0.5536,-0.2143), vec3(-0.8207,-0.5616,0.1051), vec2(0.6216,0.1567), vec2(0.6265,0.1968), vec2(0.6597,0.1782), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6973,0.5457,-0.5774), vec3(0.7084,0.4329,-0.3424), vec3(0.6421,0.5536,-0.2143), vec3(-0.9214,-0.3657,-0.1319), vec2(0.6055,0.0903), vec2(0.6216,0.1567), vec2(0.6597,0.1782), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7671,0.3779,-0.1778), vec3(0.9709,0.286,0.1789), vec3(0.7541,0.6227,-0.0195), vec3(-0.8576,-0.3107,0.4099), vec2(0.6265,0.1968), vec2(0.6348,0.2788), vec2(0.6719,0.2217), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7541,0.6227,-0.0195), vec3(0.6421,0.5536,-0.2143), vec3(0.7671,0.3779,-0.1778), vec3(-0.7262,-0.4002,0.559), vec2(0.6719,0.2217), vec2(0.6597,0.1782), vec2(0.6265,0.1968), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9592,0.7218,0.3213), vec3(0.7541,0.6227,-0.0195), vec3(0.9709,0.286,0.1789), vec3(-0.8125,-0.2006,0.5474), vec2(0.6855,0.2949), vec2(0.6719,0.2217), vec2(0.6348,0.2788), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.8902,0.4178,-0.7476), 0.5898, bestT)) {
        if (triHit(ro, rd, vec3(1.0879,0.2351,-1.0228), vec3(0.9789,0.319,-0.9705), vec3(1.105,0.2455,-1.0224), vec3(-0.1851,0.3358,-0.9236), vec2(0.0116,0.5989), vec2(0.014,0.6331), vec2(0.0164,0.5957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9789,0.319,-0.9705), vec3(1.0061,0.3444,-0.9307), vec3(1.105,0.2455,-1.0224), vec3(0.1907,0.7637,-0.6168), vec2(0.014,0.6331), vec2(0.0258,0.6326), vec2(0.0164,0.5957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0879,0.2351,-1.0228), vec3(0.9697,0.3069,-0.8888), vec3(0.9789,0.319,-0.9705), vec3(-0.6532,-0.7349,-0.1823), vec2(0.4602,0.0317), vec2(0.4978,0.0459), vec2(0.4871,0.0322), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.105,0.2455,-1.0224), vec3(1.0061,0.3444,-0.9307), vec3(1.0922,0.2685,-0.8762), vec3(0.6796,0.7315,-0.0557), vec2(0.0164,0.5957), vec2(0.0258,0.6326), vec2(0.0489,0.6072), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0879,0.2351,-1.0228), vec3(1.0658,0.246,-0.8773), vec3(0.9697,0.3069,-0.8888), vec3(-0.534,-0.8453,-0.0182), vec2(0.4602,0.0317), vec2(0.4824,0.0566), vec2(0.4978,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9789,0.319,-0.9705), vec3(0.8527,0.4626,-0.8431), vec3(1.0061,0.3444,-0.9307), vec3(0.2192,0.7481,-0.6264), vec2(0.014,0.6331), vec2(0.0172,0.6948), vec2(0.0258,0.6326), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9789,0.319,-0.9705), vec3(0.9697,0.3069,-0.8888), vec3(0.8527,0.4626,-0.8431), vec3(-0.811,-0.5585,-0.1742), vec2(0.4871,0.0322), vec2(0.4978,0.0459), vec2(0.5356,0.0342), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9897,0.3565,-0.8578), vec3(1.0922,0.2685,-0.8762), vec3(1.0061,0.3444,-0.9307), vec3(0.6534,0.7567,0.0208), vec2(0.0381,0.6428), vec2(0.0489,0.6072), vec2(0.0258,0.6326), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0061,0.3444,-0.9307), vec3(0.889,0.4801,-0.8059), vec3(0.9897,0.3565,-0.8578), vec3(0.7881,0.6109,0.0755), vec2(0.0258,0.6326), vec2(0.0331,0.6912), vec2(0.0381,0.6428), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.889,0.4801,-0.8059), vec3(1.0061,0.3444,-0.9307), vec3(0.8527,0.4626,-0.8431), vec3(0.2467,0.7627,-0.5979), vec2(0.0331,0.6912), vec2(0.0258,0.6326), vec2(0.0172,0.6948), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9584,0.31,-0.8124), vec3(0.9697,0.3069,-0.8888), vec3(1.0658,0.246,-0.8773), vec3(-0.5314,-0.846,-0.0441), vec2(0.5098,0.0581), vec2(0.4978,0.0459), vec2(0.4824,0.0566), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8513,0.4423,-0.7959), vec3(0.8527,0.4626,-0.8431), vec3(0.9697,0.3069,-0.8888), vec3(-0.8075,-0.5327,-0.2532), vec2(0.54,0.0469), vec2(0.5356,0.0342), vec2(0.4978,0.0459), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9697,0.3069,-0.8888), vec3(0.9584,0.31,-0.8124), vec3(0.8513,0.4423,-0.7959), vec3(-0.7793,-0.6201,-0.0898), vec2(0.4978,0.0459), vec2(0.5098,0.0581), vec2(0.54,0.0469), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.889,0.4801,-0.8059), vec3(0.8527,0.4626,-0.8431), vec3(0.7121,0.5939,-0.7722), vec3(0.3246,0.6946,-0.642), vec2(0.0331,0.6912), vec2(0.0172,0.6948), vec2(0.0175,0.7574), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9093,0.4783,-0.7404), vec3(0.9897,0.3565,-0.8578), vec3(0.889,0.4801,-0.8059), vec3(0.7151,0.6687,-0.2037), vec2(0.0525,0.6885), vec2(0.0381,0.6428), vec2(0.0331,0.6912), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0922,0.2685,-0.8762), vec3(0.9897,0.3565,-0.8578), vec3(1.0477,0.2768,-0.6664), vec3(0.6587,0.7442,0.1106), vec2(0.0489,0.6072), vec2(0.0381,0.6428), vec2(0.0934,0.6282), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0658,0.246,-0.8773), vec3(1.0109,0.2297,-0.6658), vec3(0.9584,0.31,-0.8124), vec3(-0.5926,-0.7767,-0.2136), vec2(0.4824,0.0566), vec2(0.5166,0.0957), vec2(0.5098,0.0581), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8513,0.4423,-0.7959), vec3(0.6959,0.5716,-0.7158), vec3(0.8527,0.4626,-0.8431), vec3(-0.6969,-0.651,-0.3009), vec2(0.54,0.0469), vec2(0.5928,0.0532), vec2(0.5356,0.0342), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7121,0.5939,-0.7722), vec3(0.8527,0.4626,-0.8431), vec3(0.6959,0.5716,-0.7158), vec3(-0.7232,-0.5457,-0.4233), vec2(0.585,0.0381), vec2(0.5356,0.0342), vec2(0.5928,0.0532), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8511,0.4182,-0.7203), vec3(0.8513,0.4423,-0.7959), vec3(0.9584,0.31,-0.8124), vec3(-0.7739,-0.6027,-0.1946), vec2(0.5469,0.0659), vec2(0.54,0.0469), vec2(0.5098,0.0581), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9661,0.4079,-0.7177), vec3(0.9897,0.3565,-0.8578), vec3(0.9093,0.4783,-0.7404), vec3(0.7892,0.6076,-0.0896), vec2(0.0659,0.6641), vec2(0.0381,0.6428), vec2(0.0525,0.6885), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.889,0.4801,-0.8059), vec3(0.7121,0.5939,-0.7722), vec3(0.7466,0.6214,-0.7183), vec3(0.3517,0.7228,-0.5949), vec2(0.0331,0.6912), vec2(0.0175,0.7574), vec2(0.0387,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9093,0.4783,-0.7404), vec3(0.889,0.4801,-0.8059), vec3(0.7466,0.6214,-0.7183), vec3(0.6364,0.7507,-0.1771), vec2(0.0525,0.6885), vec2(0.0331,0.6912), vec2(0.0387,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9661,0.4079,-0.7177), vec3(1.0477,0.2768,-0.6664), vec3(0.9897,0.3565,-0.8578), vec3(0.8558,0.5153,-0.0444), vec2(0.0659,0.6641), vec2(0.0934,0.6282), vec2(0.0381,0.6428), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8511,0.4182,-0.7203), vec3(0.9584,0.31,-0.8124), vec3(0.9084,0.3451,-0.7002), vec3(-0.7599,-0.6347,-0.1406), vec2(0.5469,0.0659), vec2(0.5098,0.0581), vec2(0.5337,0.0767), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8513,0.4423,-0.7959), vec3(0.8511,0.4182,-0.7203), vec3(0.6959,0.5716,-0.7158), vec3(-0.6889,-0.69,-0.2223), vec2(0.54,0.0469), vec2(0.5469,0.0659), vec2(0.5928,0.0532), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9084,0.3451,-0.7002), vec3(0.9584,0.31,-0.8124), vec3(1.0109,0.2297,-0.6658), vec3(-0.7261,-0.6784,-0.1119), vec2(0.5337,0.0767), vec2(0.5098,0.0581), vec2(0.5166,0.0957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7121,0.5939,-0.7722), vec3(0.5211,0.7828,-0.6301), vec3(0.7466,0.6214,-0.7183), vec3(0.3097,0.7513,-0.5827), vec2(0.0175,0.7574), vec2(0.0175,0.8508), vec2(0.0387,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7121,0.5939,-0.7722), vec3(0.6959,0.5716,-0.7158), vec3(0.5211,0.7828,-0.6301), vec3(-0.777,-0.4763,-0.4115), vec2(0.585,0.0381), vec2(0.5928,0.0532), vec2(0.6582,0.0444), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9093,0.4783,-0.7404), vec3(0.7466,0.6214,-0.7183), vec3(0.7646,0.6244,-0.6263), vec3(0.6416,0.7523,-0.1497), vec2(0.0525,0.6885), vec2(0.0387,0.755), vec2(0.0676,0.7512), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9661,0.4079,-0.7177), vec3(0.9093,0.4783,-0.7404), vec3(0.9296,0.4304,-0.6132), vec3(0.7525,0.6469,0.1235), vec2(0.0659,0.6641), vec2(0.0525,0.6885), vec2(0.0903,0.6775), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8577,0.3648,-0.5957), vec3(0.8511,0.4182,-0.7203), vec3(0.9084,0.3451,-0.7002), vec3(-0.7323,-0.6392,-0.235), vec2(0.5562,0.0977), vec2(0.5469,0.0659), vec2(0.5337,0.0767), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6973,0.5457,-0.5774), vec3(0.6959,0.5716,-0.7158), vec3(0.8511,0.4182,-0.7203), vec3(-0.6995,-0.7036,-0.125), vec2(0.6055,0.0903), vec2(0.5928,0.0532), vec2(0.5469,0.0659), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9661,0.4079,-0.7177), vec3(0.9296,0.4304,-0.6132), vec3(1.0477,0.2768,-0.6664), vec3(0.8086,0.566,0.1604), vec2(0.0659,0.6641), vec2(0.0903,0.6775), vec2(0.0934,0.6282), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9093,0.4783,-0.7404), vec3(0.7646,0.6244,-0.6263), vec3(0.9296,0.4304,-0.6132), vec3(0.7517,0.6477,0.1239), vec2(0.0525,0.6885), vec2(0.0676,0.7512), vec2(0.0903,0.6775), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0109,0.2297,-0.6658), vec3(0.8577,0.3648,-0.5957), vec3(0.9084,0.3451,-0.7002), vec3(-0.6989,-0.6835,-0.2105), vec2(0.5166,0.0957), vec2(0.5562,0.0977), vec2(0.5337,0.0767), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7466,0.6214,-0.7183), vec3(0.579,0.7917,-0.6004), vec3(0.7646,0.6244,-0.6263), vec3(0.6502,0.7446,-0.1512), vec2(0.0387,0.755), vec2(0.041,0.8383), vec2(0.0676,0.7512), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8511,0.4182,-0.7203), vec3(0.8577,0.3648,-0.5957), vec3(0.6973,0.5457,-0.5774), vec3(-0.7394,-0.6322,-0.2317), vec2(0.5469,0.0659), vec2(0.5562,0.0977), vec2(0.6055,0.0903), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.6959,0.5716,-0.7158), vec3(0.6973,0.5457,-0.5774), vec3(0.4904,0.7376,-0.5767), vec3(-0.6745,-0.7268,-0.1296), vec2(0.5928,0.0532), vec2(0.6055,0.0903), vec2(0.6665,0.0669), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9296,0.4304,-0.6132), vec3(0.9668,0.2819,-0.4759), vec3(1.0477,0.2768,-0.6664), vec3(0.8007,0.5023,0.3264), vec2(0.0903,0.6775), vec2(0.1436,0.6477), vec2(0.0934,0.6282), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0109,0.2297,-0.6658), vec3(0.9245,0.2358,-0.4731), vec3(0.8577,0.3648,-0.5957), vec3(-0.7043,-0.6457,-0.2952), vec2(0.5166,0.0957), vec2(0.5532,0.1372), vec2(0.5562,0.0977), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8348,0.4686,-0.4785), vec3(0.9296,0.4304,-0.6132), vec3(0.7646,0.6244,-0.6263), vec3(0.7102,0.6259,0.3222), vec2(0.1287,0.7048), vec2(0.0903,0.6775), vec2(0.0676,0.7512), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7601,0.4053,-0.463), vec3(0.6973,0.5457,-0.5774), vec3(0.8577,0.3648,-0.5957), vec3(-0.7195,-0.6031,-0.3443), vec2(0.5942,0.1309), vec2(0.6055,0.0903), vec2(0.5562,0.0977), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.9668,0.2819,-0.4759), vec3(0.9296,0.4304,-0.6132), vec3(0.8348,0.4686,-0.4785), vec3(0.7536,0.538,0.3777), vec2(0.1436,0.6477), vec2(0.0903,0.6775), vec2(0.1287,0.7048), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.7601,0.4053,-0.463), vec3(0.8577,0.3648,-0.5957), vec3(0.9245,0.2358,-0.4731), vec3(-0.692,-0.6524,-0.309), vec2(0.5942,0.1309), vec2(0.5562,0.0977), vec2(0.5532,0.1372), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.8348,0.4686,-0.4785), vec3(0.7646,0.6244,-0.6263), vec3(0.7808,0.4873,-0.3644), vec3(0.761,0.5929,0.2634), vec2(0.1287,0.7048), vec2(0.0676,0.7512), vec2(0.1591,0.7239), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(1.3626,0.0307,-1.0197), 0.7908, bestT)) {
        if (triHit(ro, rd, vec3(1.105,0.2455,-1.0224), vec3(1.4503,0.0251,-1.3582), vec3(1.0879,0.2351,-1.0228), vec3(-0.3419,0.5846,-0.7357), vec2(0.0164,0.5957), vec2(0,0), vec2(0.4602,0.0317), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.4552,0.0357,-1.3566), vec3(1.4503,0.0251,-1.3582), vec3(1.105,0.2455,-1.0224), vec3(-0.5252,0.3549,-0.7734), vec2(0.0083,0.4624), vec2(0,0), vec2(0.0164,0.5957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.5413,-0.0409,-1.3261), vec3(1.5043,-0.0089,-1.353), vec3(1.5679,-0.0582,-1.2346), vec3(0.677,0.7337,-0.0581), vec2(0.0308,0.4351), vec2(0.0182,0.4458), vec2(0.0548,0.4341), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.5043,-0.0089,-1.353), vec3(1.4552,0.0357,-1.3566), vec3(1.5679,-0.0582,-1.2346), vec3(0.6739,0.7368,-0.0552), vec2(0.0182,0.4458), vec2(0.0083,0.4624), vec2(0.0548,0.4341), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.5679,-0.0582,-1.2346), vec3(1.4552,0.0357,-1.3566), vec3(1.5925,-0.1011,-1.054), vec3(0.5561,0.8225,0.1197), vec2(0.0548,0.4341), vec2(0.0083,0.4624), vec2(0.1003,0.436), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.105,0.2455,-1.0224), vec3(1.5925,-0.1011,-1.054), vec3(1.4552,0.0357,-1.3566), vec3(0.5809,0.8076,0.1017), vec2(0.0164,0.5957), vec2(0.1003,0.436), vec2(0.0083,0.4624), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0922,0.2685,-0.8762), vec3(1.5925,-0.1011,-1.054), vec3(1.105,0.2455,-1.0224), vec3(0.5744,0.8149,-0.0779), vec2(0.0489,0.6072), vec2(0.1003,0.436), vec2(0.0164,0.5957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.5925,-0.1011,-1.054), vec3(1.0922,0.2685,-0.8762), vec3(1.4192,-0.1774,-0.5316), vec3(0.6339,0.7071,0.3135), vec2(0.1003,0.436), vec2(0.0489,0.6072), vec2(0.1998,0.4692), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0477,0.2768,-0.6664), vec3(1.4192,-0.1774,-0.5316), vec3(1.0922,0.2685,-0.8762), vec3(0.7474,0.6509,0.1331), vec2(0.0934,0.6282), vec2(0.1998,0.4692), vec2(0.0489,0.6072), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.4192,-0.1774,-0.5316), vec3(1.0477,0.2768,-0.6664), vec3(1.3079,-0.1204,-0.3024), vec3(0.7309,0.6549,0.1921), vec2(0.1998,0.4692), vec2(0.0934,0.6282), vec2(0.2474,0.5112), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.536,-0.0523,-1.3278), vec3(1.5595,-0.0818,-1.241), vec3(1.4993,-0.0196,-1.3545), vec3(-0.6201,-0.7785,-0.0976), vec2(0.3462,0.0425), vec2(0.354,0.061), vec2(0.3486,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.4503,0.0251,-1.3582), vec3(1.4993,-0.0196,-1.3545), vec3(1.5595,-0.0818,-1.241), vec3(-0.671,-0.7398,-0.0494), vec2(0.3569,0.0249), vec2(0.3486,0.0327), vec2(0.354,0.061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.5831,-0.1219,-1.0606), vec3(1.4503,0.0251,-1.3582), vec3(1.5595,-0.0818,-1.241), vec3(-0.6504,-0.7551,-0.0825), vec2(0.375,0.0962), vec2(0.3569,0.0249), vec2(0.354,0.061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.5831,-0.1219,-1.0606), vec3(1.0879,0.2351,-1.0228), vec3(1.4503,0.0251,-1.3582), vec3(-0.5863,-0.7991,-0.1329), vec2(0.375,0.0962), vec2(0.4602,0.0317), vec2(0.3569,0.0249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0879,0.2351,-1.0228), vec3(1.5831,-0.1219,-1.0606), vec3(1.0658,0.246,-0.8773), vec3(-0.586,-0.8098,-0.0287), vec2(0.4602,0.0317), vec2(0.375,0.0962), vec2(0.4824,0.0566), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.5831,-0.1219,-1.0606), vec3(1.4036,-0.2,-0.5374), vec3(1.0658,0.246,-0.8773), vec3(-0.6217,-0.7149,-0.32), vec2(0.375,0.0962), vec2(0.4397,0.1743), vec2(0.4824,0.0566), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.0658,0.246,-0.8773), vec3(1.4036,-0.2,-0.5374), vec3(1.0109,0.2297,-0.6658), vec3(-0.683,-0.6931,-0.2306), vec2(0.4824,0.0566), vec2(0.4397,0.1743), vec2(0.5166,0.0957), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(1.2889,-0.1372,-0.302), vec3(1.0109,0.2297,-0.6658), vec3(1.4036,-0.2,-0.5374), vec3(-0.7047,-0.6915,-0.1588), vec2(0.4917,0.2139), vec2(0.5166,0.0957), vec2(0.4397,0.1743), bestT, bestN, bestUV)) hit = true;
}
    return hit ? 1.0 : 0.0;
}

float meshRayTestWalk(vec3 ro, vec3 rd, inout float bestT, inout vec3 bestN, inout vec2 bestUV) {
    bool hit = false;
    if (!raySphereNear(ro, rd, vec3(0.0,0.55,0.0), 1.5407)) return 0.0;
    if (clusterHit(ro, rd, vec3(-0.2477,0.5009,0.2212), 0.5863, bestT)) {
        if (triHit(ro, rd, vec3(-0.5326,0.1943,-0.0315), vec3(-0.4753,0.1414,0.1845), vec3(-0.5477,0.3679,0.03), vec3(-0.9631,-0.16,0.2163), vec2(0.6001,0.5044), vec2(0.5435,0.4731), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4737,0.2907,0.2474), vec3(-0.5477,0.3679,0.03), vec3(-0.4753,0.1414,0.1845), vec3(-0.9522,-0.1097,0.285), vec2(0.5156,0.5129), vec2(0.5757,0.5515), vec2(0.5435,0.4731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0065,0.3609,0.5105), vec3(0.1838,0.3542,0.5038), vec3(0.0073,0.5142,0.3487), vec3(0.0534,0.7247,0.6869), vec2(0.3103,0.5667), vec2(0.3718,0.5288), vec2(0.3613,0.6421), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1843,0.5053,0.3407), vec3(0.0073,0.5142,0.3487), vec3(0.1838,0.3542,0.5038), vec3(0.0677,0.7319,0.6781), vec2(0.4148,0.6013), vec2(0.3613,0.6421), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0073,0.5142,0.3487), vec3(0.1843,0.5053,0.3407), vec3(0.0085,0.6413,0.1778), vec3(0.0674,0.8004,0.5957), vec2(0.3613,0.6421), vec2(0.4148,0.6013), vec2(0.4136,0.707), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0065,0.3609,0.5105), vec3(0.0073,0.5142,0.3487), vec3(-0.1715,0.3543,0.5046), vec3(-0.0498,0.7251,0.6868), vec2(0.3103,0.5667), vec2(0.3613,0.6421), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1706,0.4944,0.3411), vec3(-0.1715,0.3543,0.5046), vec3(0.0073,0.5142,0.3487), vec3(-0.112,0.755,0.6461), vec2(0.4148,0.6013), vec2(0.3718,0.5288), vec2(0.3613,0.6421), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0073,0.5142,0.3487), vec3(0.0085,0.6413,0.1778), vec3(-0.1706,0.4944,0.3411), vec3(-0.1144,0.7975,0.5924), vec2(0.3613,0.6421), vec2(0.4136,0.707), vec2(0.4148,0.6013), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2484,0.3243,0.4818), vec3(-0.1715,0.3543,0.5046), vec3(-0.1706,0.4944,0.3411), vec3(-0.4395,0.6833,0.583), vec2(0.3997,0.5129), vec2(0.3718,0.5288), vec2(0.4148,0.6013), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1672,0.6273,0.1726), vec3(-0.1706,0.4944,0.3411), vec3(0.0085,0.6413,0.1778), vec3(-0.081,0.7834,0.6163), vec2(0.4646,0.6636), vec2(0.4148,0.6013), vec2(0.4136,0.707), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0085,0.6413,0.1778), vec3(0.0099,0.7442,0.002), vec3(-0.1672,0.6273,0.1726), vec3(-0.0838,0.8604,0.5026), vec2(0.4136,0.707), vec2(0.4724,0.7621), vec2(0.4646,0.6636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2632,0.4715,0.3232), vec3(-0.2484,0.3243,0.4818), vec3(-0.1706,0.4944,0.3411), vec3(-0.298,0.6857,0.6641), vec2(0.4431,0.5828), vec2(0.3997,0.5129), vec2(0.4148,0.6013), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1706,0.4944,0.3411), vec3(-0.1672,0.6273,0.1726), vec3(-0.2632,0.4715,0.3232), vec3(-0.2995,0.752,0.5871), vec2(0.4148,0.6013), vec2(0.4646,0.6636), vec2(0.4431,0.5828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2484,0.3243,0.4818), vec3(-0.3962,0.4145,0.2764), vec3(-0.3252,0.2848,0.4835), vec3(-0.3617,0.7295,0.5806), vec2(0.3997,0.5129), vec2(0.4844,0.5562), vec2(0.4255,0.4902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2632,0.4715,0.3232), vec3(-0.3962,0.4145,0.2764), vec3(-0.2484,0.3243,0.4818), vec3(-0.4831,0.6188,0.6194), vec2(0.4431,0.5828), vec2(0.4844,0.5562), vec2(0.3997,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3962,0.4145,0.2764), vec3(-0.4737,0.2907,0.2474), vec3(-0.3252,0.2848,0.4835), vec3(-0.7814,0.3722,0.5008), vec2(0.4844,0.5562), vec2(0.5156,0.5129), vec2(0.4255,0.4902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2575,0.613,0.1634), vec3(-0.2632,0.4715,0.3232), vec3(-0.1672,0.6273,0.1726), vec3(-0.1829,0.7392,0.6482), vec2(0.4873,0.6418), vec2(0.4431,0.5828), vec2(0.4646,0.6636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3962,0.4145,0.2764), vec3(-0.2632,0.4715,0.3232), vec3(-0.2575,0.613,0.1634), vec3(-0.4848,0.6632,0.5702), vec2(0.4844,0.5562), vec2(0.4431,0.5828), vec2(0.4873,0.6418), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4737,0.2907,0.2474), vec3(-0.3962,0.4145,0.2764), vec3(-0.5477,0.3679,0.03), vec3(-0.8099,0.4087,0.4208), vec2(0.5156,0.5129), vec2(0.4844,0.5562), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1553,0.7472,-0.0159), vec3(-0.1672,0.6273,0.1726), vec3(0.0099,0.7442,0.002), vec3(-0.0426,0.8442,0.5343), vec2(0.5176,0.7183), vec2(0.4646,0.6636), vec2(0.4724,0.7621), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2575,0.613,0.1634), vec3(-0.1672,0.6273,0.1726), vec3(-0.1553,0.7472,-0.0159), vec3(-0.1849,0.8345,0.5191), vec2(0.4873,0.6418), vec2(0.4646,0.6636), vec2(0.5176,0.7183), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2575,0.613,0.1634), vec3(-0.3706,0.5886,0.1147), vec3(-0.3962,0.4145,0.2764), vec3(-0.4144,0.6513,0.6356), vec2(0.4873,0.6418), vec2(0.522,0.6201), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2628,0.737,-0.0435), vec3(-0.2575,0.613,0.1634), vec3(-0.1553,0.7472,-0.0159), vec3(-0.2092,0.8364,0.5066), vec2(0.5479,0.6924), vec2(0.4873,0.6418), vec2(0.5176,0.7183), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3706,0.5886,0.1147), vec3(-0.2575,0.613,0.1634), vec3(-0.2628,0.737,-0.0435), vec3(-0.3785,0.7896,0.4829), vec2(0.522,0.6201), vec2(0.4873,0.6418), vec2(0.5479,0.6924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3706,0.5886,0.1147), vec3(-0.4276,0.5652,0.083), vec3(-0.3962,0.4145,0.2764), vec3(-0.5614,0.606,0.5636), vec2(0.522,0.6201), vec2(0.54,0.6082), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3574,0.7032,-0.0736), vec3(-0.3706,0.5886,0.1147), vec3(-0.2628,0.737,-0.0435), vec3(-0.4234,0.7866,0.4495), vec2(0.5713,0.667), vec2(0.522,0.6201), vec2(0.5479,0.6924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4276,0.5652,0.083), vec3(-0.3706,0.5886,0.1147), vec3(-0.3574,0.7032,-0.0736), vec3(-0.5325,0.739,0.4128), vec2(0.54,0.6082), vec2(0.522,0.6201), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4276,0.5652,0.083), vec3(-0.4922,0.5123,0.051), vec3(-0.3962,0.4145,0.2764), vec3(-0.6812,0.5196,0.5157), vec2(0.54,0.6082), vec2(0.5581,0.5881), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4922,0.5123,0.051), vec3(-0.5477,0.3679,0.03), vec3(-0.3962,0.4145,0.2764), vec3(-0.8442,0.2561,0.4708), vec2(0.5581,0.5881), vec2(0.5757,0.5515), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4276,0.5652,0.083), vec3(-0.4256,0.651,-0.1154), vec3(-0.4922,0.5123,0.051), vec3(-0.6876,0.6689,0.2825), vec2(0.54,0.6082), vec2(0.5923,0.6455), vec2(0.5581,0.5881), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.2078,0.043,0.4814), 0.5507, bestT)) {
        if (triHit(ro, rd, vec3(-0.2274,-0.0877,0.1159), vec3(-0.1098,-0.1015,0.1122), vec3(-0.1556,-0.0927,0.3385), vec3(-0.1161,-0.9931,0.0153), vec2(0.5928,0.3579), vec2(0.6079,0.3198), vec2(0.5347,0.3164), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2274,-0.0877,0.1159), vec3(-0.2481,-0.0742,0.3517), vec3(-0.3293,-0.0783,0.1059), vec3(-0.0969,-0.9941,0.0485), vec2(0.5928,0.3579), vec2(0.519,0.3477), vec2(0.5879,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.001,-0.1306,0.1348), vec3(-0.0809,-0.1119,0.3306), vec3(-0.1098,-0.1015,0.1122), vec3(-0.2559,-0.9666,-0.0121), vec2(0.623,0.2847), vec2(0.5474,0.2915), vec2(0.6079,0.3198), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4045,0.0536,0.2776), vec3(-0.4753,0.1414,0.1845), vec3(-0.4294,0.0359,0.1305), vec3(-0.8558,-0.4762,0.2021), vec2(0.5225,0.4321), vec2(0.5435,0.4731), vec2(0.5679,0.4419), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4045,0.0536,0.2776), vec3(-0.4294,0.0359,0.1305), vec3(-0.3687,-0.0482,0.2259), vec3(-0.8879,-0.4143,0.2001), vec2(0.5225,0.4321), vec2(0.5679,0.4419), vec2(0.5479,0.3999), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3293,-0.0783,0.1059), vec3(-0.2481,-0.0742,0.3517), vec3(-0.3687,-0.0482,0.2259), vec3(-0.3324,-0.9348,0.1253), vec2(0.5879,0.3926), vec2(0.519,0.3477), vec2(0.5479,0.3999), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0809,-0.1119,0.3306), vec3(-0.1556,-0.0927,0.3385), vec3(-0.1098,-0.1015,0.1122), vec3(-0.2507,-0.968,-0.0129), vec2(0.5474,0.2915), vec2(0.5347,0.3164), vec2(0.6079,0.3198), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0809,-0.1119,0.3306), vec3(-0.001,-0.1306,0.1348), vec3(0,-0.1194,0.3306), vec3(-0.0915,-0.9941,0.0576), vec2(0.5474,0.2915), vec2(0.623,0.2847), vec2(0.5581,0.2642), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2481,-0.0742,0.3517), vec3(-0.2274,-0.0877,0.1159), vec3(-0.1556,-0.0927,0.3385), vec3(-0.1904,-0.9809,0.0395), vec2(0.519,0.3477), vec2(0.5928,0.3579), vec2(0.5347,0.3164), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4753,0.1414,0.1845), vec3(-0.39,0.1061,0.3824), vec3(-0.4737,0.2907,0.2474), vec3(-0.9176,-0.1458,0.3698), vec2(0.5435,0.4731), vec2(0.4832,0.438), vec2(0.5156,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.39,0.1061,0.3824), vec3(-0.4753,0.1414,0.1845), vec3(-0.4045,0.0536,0.2776), vec3(-0.8732,-0.3765,0.3095), vec2(0.4832,0.438), vec2(0.5435,0.4731), vec2(0.5225,0.4321), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4045,0.0536,0.2776), vec3(-0.3687,-0.0482,0.2259), vec3(-0.3483,-0.0462,0.3777), vec3(-0.9135,-0.3863,0.1273), vec2(0.5225,0.4321), vec2(0.5479,0.3999), vec2(0.502,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3483,-0.0462,0.3777), vec3(-0.3687,-0.0482,0.2259), vec3(-0.2481,-0.0742,0.3517), vec3(-0.2575,-0.9651,0.0472), vec2(0.502,0.3828), vec2(0.5479,0.3999), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3483,-0.0462,0.3777), vec3(-0.39,0.1061,0.3824), vec3(-0.4045,0.0536,0.2776), vec3(-0.9293,-0.2622,0.26), vec2(0.502,0.3828), vec2(0.4832,0.438), vec2(0.5225,0.4321), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.39,0.1061,0.3824), vec3(-0.3691,0.1859,0.4749), vec3(-0.4737,0.2907,0.2474), vec3(-0.9227,-0.1631,0.3492), vec2(0.4832,0.438), vec2(0.4451,0.4561), vec2(0.5156,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0809,-0.1119,0.3306), vec3(0,-0.1194,0.3306), vec3(-0.06,-0.1172,0.4794), vec3(-0.0916,-0.9955,-0.0226), vec2(0.5474,0.2915), vec2(0.5581,0.2642), vec2(0.5029,0.2666), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.06,-0.1172,0.4794), vec3(-0.1556,-0.0927,0.3385), vec3(-0.0809,-0.1119,0.3306), vec3(-0.2494,-0.9684,0.0005), vec2(0.5029,0.2666), vec2(0.5347,0.3164), vec2(0.5474,0.2915), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1556,-0.0927,0.3385), vec3(-0.1014,-0.0868,0.4647), vec3(-0.2481,-0.0742,0.3517), vec3(-0.1777,-0.9765,0.1221), vec2(0.5347,0.3164), vec2(0.5,0.2856), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3691,0.1859,0.4749), vec3(-0.3252,0.2848,0.4835), vec3(-0.4737,0.2907,0.2474), vec3(-0.801,0.3109,0.5116), vec2(0.4451,0.4561), vec2(0.4255,0.4902), vec2(0.5156,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.39,0.1061,0.3824), vec3(-0.3483,-0.0462,0.3777), vec3(-0.3332,0.0599,0.5022), vec3(-0.9076,-0.2584,0.3307), vec2(0.4832,0.438), vec2(0.502,0.3828), vec2(0.4441,0.4043), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2481,-0.0742,0.3517), vec3(-0.2326,-0.0735,0.5369), vec3(-0.3483,-0.0462,0.3777), vec3(-0.263,-0.9645,0.0253), vec2(0.519,0.3477), vec2(0.4553,0.3228), vec2(0.502,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1556,-0.0927,0.3385), vec3(-0.06,-0.1172,0.4794), vec3(-0.1014,-0.0868,0.4647), vec3(-0.6327,-0.7118,0.305), vec2(0.5347,0.3164), vec2(0.5029,0.2666), vec2(0.5,0.2856), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0614,-0.1185,0.479), vec3(0.0006,-0.1338,0.4947), vec3(0,-0.1194,0.3306), vec3(0.2214,-0.9713,-0.0863), vec2(0.5029,0.2666), vec2(0.5068,0.2446), vec2(0.5581,0.2642), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0006,-0.1338,0.4947), vec3(-0.06,-0.1172,0.4794), vec3(0,-0.1194,0.3306), vec3(-0.2431,-0.9663,-0.0841), vec2(0.5068,0.2446), vec2(0.5029,0.2666), vec2(0.5581,0.2642), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1014,-0.0868,0.4647), vec3(-0.2326,-0.0735,0.5369), vec3(-0.2481,-0.0742,0.3517), vec3(-0.094,-0.9955,0.0113), vec2(0.5,0.2856), vec2(0.4553,0.3228), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3691,0.1859,0.4749), vec3(-0.39,0.1061,0.3824), vec3(-0.3359,0.1461,0.5129), vec3(-0.8505,-0.2876,0.4405), vec2(0.4451,0.4561), vec2(0.4832,0.438), vec2(0.4312,0.4365), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.39,0.1061,0.3824), vec3(-0.3332,0.0599,0.5022), vec3(-0.3359,0.1461,0.5129), vec3(-0.9122,-0.0791,0.402), vec2(0.4832,0.438), vec2(0.4441,0.4043), vec2(0.4312,0.4365), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3332,0.0599,0.5022), vec3(-0.3483,-0.0462,0.3777), vec3(-0.3029,-0.0628,0.5762), vec3(-0.9707,-0.1112,0.2129), vec2(0.4441,0.4043), vec2(0.502,0.3828), vec2(0.4319,0.3452), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2326,-0.0735,0.5369), vec3(-0.3029,-0.0628,0.5762), vec3(-0.3483,-0.0462,0.3777), vec3(-0.1739,-0.9838,-0.0427), vec2(0.4553,0.3228), vec2(0.4319,0.3452), vec2(0.502,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3691,0.1859,0.4749), vec3(-0.2986,0.2011,0.5535), vec3(-0.3252,0.2848,0.4835), vec3(-0.7417,0.2758,0.6114), vec2(0.4451,0.4561), vec2(0.4021,0.4541), vec2(0.4255,0.4902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2484,0.3243,0.4818), vec3(-0.3252,0.2848,0.4835), vec3(-0.226,0.2717,0.5469), vec3(-0.3319,0.675,0.659), vec2(0.3997,0.5129), vec2(0.4255,0.4902), vec2(0.3779,0.4863), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3359,0.1461,0.5129), vec3(-0.3214,0.1699,0.5322), vec3(-0.3691,0.1859,0.4749), vec3(-0.7737,-0.0402,0.6322), vec2(0.4312,0.4365), vec2(0.4197,0.4434), vec2(0.4451,0.4561), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0614,-0.1185,0.479), vec3(0.1034,-0.089,0.4639), vec3(0.0717,-0.1093,0.5787), vec3(0.5801,-0.8144,0.0161), vec2(0.5029,0.2666), vec2(0.5,0.2856), vec2(0.4705,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0693,-0.1077,0.5792), vec3(-0.1014,-0.0868,0.4647), vec3(-0.06,-0.1172,0.4794), vec3(-0.5974,-0.8017,0.0205), vec2(0.4705,0.2559), vec2(0.5,0.2856), vec2(0.5029,0.2666), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1715,0.3543,0.5046), vec3(-0.2484,0.3243,0.4818), vec3(-0.226,0.2717,0.5469), vec3(-0.4356,0.6213,0.6513), vec2(0.3718,0.5288), vec2(0.3997,0.5129), vec2(0.3779,0.4863), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0614,-0.1185,0.479), vec3(0.0717,-0.1093,0.5787), vec3(0.0006,-0.1338,0.4947), vec3(0.2582,-0.964,0.0631), vec2(0.5029,0.2666), vec2(0.4705,0.2559), vec2(0.5068,0.2446), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.06,-0.1172,0.4794), vec3(0.0006,-0.1338,0.4947), vec3(-0.0693,-0.1077,0.5792), vec3(-0.2786,-0.9582,0.0651), vec2(0.5029,0.2666), vec2(0.5068,0.2446), vec2(0.4705,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3214,0.1699,0.5322), vec3(-0.2986,0.2011,0.5535), vec3(-0.3691,0.1859,0.4749), vec3(-0.7506,0.1025,0.6528), vec2(0.4197,0.4434), vec2(0.4021,0.4541), vec2(0.4451,0.4561), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2326,-0.0735,0.5369), vec3(-0.1014,-0.0868,0.4647), vec3(-0.0693,-0.1077,0.5792), vec3(-0.1705,-0.9766,-0.1312), vec2(0.4553,0.3228), vec2(0.5,0.2856), vec2(0.4705,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3252,0.2848,0.4835), vec3(-0.2986,0.2011,0.5535), vec3(-0.226,0.2717,0.5469), vec3(-0.4179,0.501,0.7579), vec2(0.4255,0.4902), vec2(0.4021,0.4541), vec2(0.3779,0.4863), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3359,0.1461,0.5129), vec3(-0.3332,0.0599,0.5022), vec3(-0.2691,0.1527,0.6127), vec3(-0.824,-0.0958,0.5584), vec2(0.4312,0.4365), vec2(0.4441,0.4043), vec2(0.3818,0.4258), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3214,0.1699,0.5322), vec3(-0.3359,0.1461,0.5129), vec3(-0.2691,0.1527,0.6127), vec3(-0.8311,0.0592,0.5529), vec2(0.4197,0.4434), vec2(0.4312,0.4365), vec2(0.3818,0.4258), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.006,0.2364,0.6523), vec3(0.1838,0.3542,0.5038), vec3(0.0065,0.3609,0.5105), vec3(0.0533,0.7501,0.6592), vec2(0.2681,0.4941), vec2(0.3718,0.5288), vec2(0.3103,0.5667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0065,0.3609,0.5105), vec3(-0.1715,0.3543,0.5046), vec3(0.006,0.2364,0.6523), vec3(-0.0498,0.7504,0.6591), vec2(0.3103,0.5667), vec2(0.3718,0.5288), vec2(0.2681,0.4941), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0012,-0.113,0.6026), vec3(0.0006,-0.1338,0.4947), vec3(0.0717,-0.1093,0.5787), vec3(0.1157,-0.9755,0.1872), vec2(0.4744,0.23), vec2(0.5068,0.2446), vec2(0.4705,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0012,-0.113,0.6026), vec3(-0.0693,-0.1077,0.5792), vec3(0.0006,-0.1338,0.4947), vec3(-0.1352,-0.9728,0.1882), vec2(0.4744,0.23), vec2(0.4705,0.2559), vec2(0.5068,0.2446), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3332,0.0599,0.5022), vec3(-0.3029,-0.0628,0.5762), vec3(-0.3028,0.0059,0.602), vec3(-0.9654,-0.0909,0.2444), vec2(0.4441,0.4043), vec2(0.4319,0.3452), vec2(0.4148,0.3696), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2986,0.2011,0.5535), vec3(-0.3214,0.1699,0.5322), vec3(-0.2691,0.1527,0.6127), vec3(-0.8013,0.2003,0.5637), vec2(0.4021,0.4541), vec2(0.4197,0.4434), vec2(0.3818,0.4258), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1715,0.3543,0.5046), vec3(-0.226,0.2717,0.5469), vec3(-0.1654,0.2211,0.6565), vec3(-0.5136,0.6349,0.5772), vec2(0.3718,0.5288), vec2(0.3779,0.4863), vec2(0.3335,0.4575), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2691,0.1527,0.6127), vec3(-0.3332,0.0599,0.5022), vec3(-0.3028,0.0059,0.602), vec3(-0.9091,0.1817,0.3748), vec2(0.3818,0.4258), vec2(0.4441,0.4043), vec2(0.4148,0.3696), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.226,0.2717,0.5469), vec3(-0.2986,0.2011,0.5535), vec3(-0.1654,0.2211,0.6565), vec3(-0.54,0.6097,0.5802), vec2(0.3779,0.4863), vec2(0.4021,0.4541), vec2(0.3335,0.4575), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1754,0.2175,0.6552), vec3(0.1838,0.3542,0.5038), vec3(0.006,0.2364,0.6523), vec3(0.0707,0.7383,0.6707), vec2(0.3335,0.4575), vec2(0.3718,0.5288), vec2(0.2681,0.4941), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1654,0.2211,0.6565), vec3(0.006,0.2364,0.6523), vec3(-0.1715,0.3543,0.5046), vec3(-0.0504,0.75,0.6596), vec2(0.3335,0.4575), vec2(0.2681,0.4941), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2691,0.1527,0.6127), vec3(-0.1654,0.2211,0.6565), vec3(-0.2986,0.2011,0.5535), vec3(-0.5853,0.4595,0.668), vec2(0.3818,0.4258), vec2(0.3335,0.4575), vec2(0.4021,0.4541), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3029,-0.0628,0.5762), vec3(-0.2326,-0.0735,0.5369), vec3(-0.231,-0.0682,0.764), vec3(-0.1372,-0.9902,0.0245), vec2(0.4319,0.3452), vec2(0.4553,0.3228), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2326,-0.0735,0.5369), vec3(-0.0693,-0.1077,0.5792), vec3(-0.231,-0.0682,0.764), vec3(-0.211,-0.9772,0.0247), vec2(0.4553,0.3228), vec2(0.4705,0.2559), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3028,0.0059,0.602), vec3(-0.3029,-0.0628,0.5762), vec3(-0.256,-0.051,0.751), vec3(-0.9595,-0.0982,0.2639), vec2(0.4148,0.3696), vec2(0.4319,0.3452), vec2(0.3652,0.3052), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0693,-0.1077,0.5792), vec3(0.0012,-0.113,0.6026), vec3(-0.0884,-0.0756,0.7542), vec3(-0.1281,-0.9778,0.1657), vec2(0.4705,0.2559), vec2(0.4744,0.23), vec2(0.4097,0.2319), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2691,0.1527,0.6127), vec3(-0.3028,0.0059,0.602), vec3(-0.213,0.0413,0.7837), vec3(-0.8956,0.1761,0.4084), vec2(0.3831,0.9792), vec2(0.468,0.9855), vec2(0.4282,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1654,0.2211,0.6565), vec3(-0.2691,0.1527,0.6127), vec3(-0.1341,0.1254,0.8181), vec3(-0.615,0.6206,0.4865), vec2(0.3232,0.9353), vec2(0.3831,0.9792), vec2(0.3716,0.8473), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.256,-0.051,0.751), vec3(-0.3029,-0.0628,0.5762), vec3(-0.231,-0.0682,0.764), vec3(-0.625,-0.7495,0.2182), vec2(0.3652,0.3052), vec2(0.4319,0.3452), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1654,0.2211,0.6565), vec3(-0.1229,0.086,0.7875), vec3(0.006,0.2364,0.6523), vec3(-0.0434,0.6884,0.7241), vec2(0.3335,0.4575), vec2(0.2795,0.3838), vec2(0.2681,0.4941), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.231,-0.0682,0.764), vec3(-0.0693,-0.1077,0.5792), vec3(-0.0884,-0.0756,0.7542), vec3(-0.0391,-0.9835,0.1765), vec2(0.3655,0.2837), vec2(0.4705,0.2559), vec2(0.4097,0.2319), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.256,-0.051,0.751), vec3(-0.213,0.0413,0.7837), vec3(-0.3028,0.0059,0.602), vec3(-0.882,0.2755,0.3823), vec2(0.4939,0.896), vec2(0.4282,0.8768), vec2(0.468,0.9855), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1341,0.1254,0.8181), vec3(-0.2691,0.1527,0.6127), vec3(-0.213,0.0413,0.7837), vec3(-0.7156,0.4543,0.5306), vec2(0.3716,0.8473), vec2(0.3831,0.9792), vec2(0.4282,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1654,0.2211,0.6565), vec3(-0.1341,0.1254,0.8181), vec3(-0.1229,0.086,0.7875), vec3(0.9581,0.2861,-0.0158), vec2(0.3232,0.9353), vec2(0.3716,0.8473), vec2(0.3491,0.8347), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.4214,0.5672,-0.3398), 0.5465, bestT)) {
        if (triHit(ro, rd, vec3(-0.3016,0.7086,-0.6574), vec3(-0.323,0.605,-0.7095), vec3(-0.3662,0.6598,-0.5572), vec3(-0.8536,0.3639,-0.3729), vec2(0.7549,0.7261), vec2(0.7773,0.6902), vec2(0.7202,0.6946), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.391,0.5375,-0.6133), vec3(-0.3662,0.6598,-0.5572), vec3(-0.323,0.605,-0.7095), vec3(-0.8635,0.3443,-0.3686), vec2(0.7461,0.657), vec2(0.7202,0.6946), vec2(0.7773,0.6902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.444,0.5055,-0.5339), vec3(-0.391,0.5375,-0.6133), vec3(-0.4407,0.4017,-0.5628), vec3(-0.8472,0.1176,-0.5182), vec2(0.7202,0.6377), vec2(0.7461,0.657), vec2(0.7373,0.6094), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3894,0.6398,-0.5351), vec3(-0.3662,0.6598,-0.5572), vec3(-0.391,0.5375,-0.6133), vec3(-0.7888,0.3812,-0.4821), vec2(0.7139,0.6836), vec2(0.7202,0.6946), vec2(0.7461,0.657), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3016,0.7086,-0.6574), vec3(-0.3662,0.6598,-0.5572), vec3(-0.2982,0.7499,-0.4902), vec3(-0.7329,0.6638,-0.1489), vec2(0.7549,0.7261), vec2(0.7202,0.6946), vec2(0.6914,0.731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3894,0.6398,-0.5351), vec3(-0.391,0.5375,-0.6133), vec3(-0.4399,0.5741,-0.4977), vec3(-0.8114,0.3632,-0.458), vec2(0.7139,0.6836), vec2(0.7461,0.657), vec2(0.7051,0.6558), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4399,0.5741,-0.4977), vec3(-0.391,0.5375,-0.6133), vec3(-0.444,0.5055,-0.5339), vec3(-0.846,0.2877,-0.4488), vec2(0.7051,0.6558), vec2(0.7461,0.657), vec2(0.7202,0.6377), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3662,0.6598,-0.5572), vec3(-0.3894,0.6398,-0.5351), vec3(-0.2982,0.7499,-0.4902), vec3(-0.7275,0.6674,-0.1592), vec2(0.7202,0.6946), vec2(0.7139,0.6836), vec2(0.6914,0.731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4407,0.4017,-0.5628), vec3(-0.4954,0.3944,-0.4644), vec3(-0.444,0.5055,-0.5339), vec3(-0.8725,0.1053,-0.4771), vec2(0.7373,0.6094), vec2(0.7061,0.5986), vec2(0.7202,0.6377), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4399,0.5741,-0.4977), vec3(-0.444,0.5055,-0.5339), vec3(-0.4901,0.4942,-0.4414), vec3(-0.8754,0.2658,-0.4038), vec2(0.7051,0.6558), vec2(0.7202,0.6377), vec2(0.6948,0.6187), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4901,0.4942,-0.4414), vec3(-0.444,0.5055,-0.5339), vec3(-0.4954,0.3944,-0.4644), vec3(-0.8924,0.1459,-0.4269), vec2(0.6948,0.6187), vec2(0.7202,0.6377), vec2(0.7061,0.5986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3447,0.7258,-0.4), vec3(-0.2982,0.7499,-0.4902), vec3(-0.3894,0.6398,-0.5351), vec3(-0.7167,0.671,-0.1899), vec2(0.6636,0.7075), vec2(0.6914,0.731), vec2(0.7139,0.6836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4399,0.5741,-0.4977), vec3(-0.3807,0.6958,-0.382), vec3(-0.3894,0.6398,-0.5351), vec3(-0.8235,0.5463,-0.1528), vec2(0.7051,0.6558), vec2(0.6606,0.6909), vec2(0.7139,0.6836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4837,0.5545,-0.4047), vec3(-0.4399,0.5741,-0.4977), vec3(-0.4901,0.4942,-0.4414), vec3(-0.8841,0.3084,-0.3511), vec2(0.6782,0.6387), vec2(0.7051,0.6558), vec2(0.6948,0.6187), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4491,0.252,-0.5112), vec3(-0.5229,0.2412,-0.3511), vec3(-0.4954,0.3944,-0.4644), vec3(-0.8936,-0.1518,-0.4225), vec2(0.7329,0.563), vec2(0.6855,0.5481), vec2(0.7061,0.5986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3447,0.7258,-0.4), vec3(-0.3894,0.6398,-0.5351), vec3(-0.3807,0.6958,-0.382), vec3(-0.6867,0.6945,-0.2148), vec2(0.6636,0.7075), vec2(0.7139,0.6836), vec2(0.6606,0.6909), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4399,0.5741,-0.4977), vec3(-0.4837,0.5545,-0.4047), vec3(-0.3807,0.6958,-0.382), vec3(-0.7671,0.5969,-0.2349), vec2(0.7051,0.6558), vec2(0.6782,0.6387), vec2(0.6606,0.6909), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4901,0.4942,-0.4414), vec3(-0.4954,0.3944,-0.4644), vec3(-0.5276,0.4589,-0.3648), vec3(-0.9133,0.137,-0.3836), vec2(0.6948,0.6187), vec2(0.7061,0.5986), vec2(0.6768,0.592), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4837,0.5545,-0.4047), vec3(-0.4901,0.4942,-0.4414), vec3(-0.5276,0.4589,-0.3648), vec3(-0.9062,0.2864,-0.3111), vec2(0.6782,0.6387), vec2(0.6948,0.6187), vec2(0.6768,0.592), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5276,0.4589,-0.3648), vec3(-0.4954,0.3944,-0.4644), vec3(-0.5229,0.2412,-0.3511), vec3(-0.9579,-0.0383,-0.2845), vec2(0.6768,0.592), vec2(0.7061,0.5986), vec2(0.6855,0.5481), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4131,0.6636,-0.3253), vec3(-0.3807,0.6958,-0.382), vec3(-0.4837,0.5545,-0.4047), vec3(-0.7938,0.5971,-0.1153), vec2(0.6465,0.6724), vec2(0.6606,0.6909), vec2(0.6782,0.6387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3807,0.6958,-0.382), vec3(-0.3462,0.7307,-0.27), vec3(-0.3447,0.7258,-0.4), vec3(-0.6506,0.7586,-0.0361), vec2(0.6606,0.6909), vec2(0.6216,0.6965), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3462,0.7307,-0.27), vec3(-0.3807,0.6958,-0.382), vec3(-0.4131,0.6636,-0.3253), vec3(-0.7068,0.7075,-0.0028), vec2(0.6216,0.6965), vec2(0.6606,0.6909), vec2(0.6465,0.6724), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.257,0.7859,-0.2302), vec3(-0.2503,0.8017,-0.316), vec3(-0.3447,0.7258,-0.4), vec3(-0.6685,0.7389,0.0838), vec2(0.5986,0.7261), vec2(0.625,0.74), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4837,0.5545,-0.4047), vec3(-0.5276,0.4589,-0.3648), vec3(-0.5034,0.5635,-0.1513), vec3(-0.9184,0.3864,-0.0851), vec2(0.6782,0.6387), vec2(0.6768,0.592), vec2(0.6128,0.6121), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5276,0.4589,-0.3648), vec3(-0.5229,0.2412,-0.3511), vec3(-0.5546,0.4546,-0.1961), vec3(-0.9868,-0.0311,-0.1591), vec2(0.6768,0.592), vec2(0.6855,0.5481), vec2(0.6313,0.5754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5229,0.2412,-0.3511), vec3(-0.4447,0.1163,-0.3549), vec3(-0.5479,0.2292,-0.2054), vec3(-0.8354,-0.5175,-0.1853), vec2(0.6855,0.5481), vec2(0.7012,0.5083), vec2(0.647,0.5312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3462,0.7307,-0.27), vec3(-0.257,0.7859,-0.2302), vec3(-0.3447,0.7258,-0.4), vec3(-0.5133,0.8573,-0.0383), vec2(0.6216,0.6965), vec2(0.5986,0.7261), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4837,0.5545,-0.4047), vec3(-0.5034,0.5635,-0.1513), vec3(-0.4131,0.6636,-0.3253), vec3(-0.808,0.5832,-0.0836), vec2(0.6782,0.6387), vec2(0.6128,0.6121), vec2(0.6465,0.6724), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5479,0.2292,-0.2054), vec3(-0.5546,0.4546,-0.1961), vec3(-0.5229,0.2412,-0.3511), vec3(-0.9851,-0.0227,-0.1703), vec2(0.647,0.5312), vec2(0.6313,0.5754), vec2(0.6855,0.5481), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5546,0.4546,-0.1961), vec3(-0.5034,0.5635,-0.1513), vec3(-0.5276,0.4589,-0.3648), vec3(-0.8755,0.4657,-0.1288), vec2(0.6313,0.5754), vec2(0.6128,0.6121), vec2(0.6768,0.592), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3462,0.7307,-0.27), vec3(-0.4131,0.6636,-0.3253), vec3(-0.4256,0.651,-0.1154), vec3(-0.708,0.7063,0.0001), vec2(0.6216,0.6965), vec2(0.6465,0.6724), vec2(0.5923,0.6455), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4256,0.651,-0.1154), vec3(-0.4131,0.6636,-0.3253), vec3(-0.5034,0.5635,-0.1513), vec3(-0.7468,0.665,-0.0047), vec2(0.5923,0.6455), vec2(0.6465,0.6724), vec2(0.6128,0.6121), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3462,0.7307,-0.27), vec3(-0.3574,0.7032,-0.0736), vec3(-0.257,0.7859,-0.2302), vec3(-0.5513,0.83,0.0845), vec2(0.6216,0.6965), vec2(0.5713,0.667), vec2(0.5986,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.257,0.7859,-0.2302), vec3(-0.2628,0.737,-0.0435), vec3(-0.1501,0.8228,-0.2135), vec3(-0.3496,0.909,0.227), vec2(0.5986,0.7261), vec2(0.5479,0.6924), vec2(0.5781,0.7605), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4256,0.651,-0.1154), vec3(-0.3574,0.7032,-0.0736), vec3(-0.3462,0.7307,-0.27), vec3(-0.6335,0.7704,0.0714), vec2(0.5923,0.6455), vec2(0.5713,0.667), vec2(0.6216,0.6965), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5479,0.2292,-0.2054), vec3(-0.5477,0.3679,0.03), vec3(-0.5546,0.4546,-0.1961), vec3(-0.9993,-0.0309,0.019), vec2(0.647,0.5312), vec2(0.5757,0.5515), vec2(0.6313,0.5754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2628,0.737,-0.0435), vec3(-0.257,0.7859,-0.2302), vec3(-0.3574,0.7032,-0.0736), vec3(-0.3895,0.8939,0.2218), vec2(0.5479,0.6924), vec2(0.5986,0.7261), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5546,0.4546,-0.1961), vec3(-0.5477,0.3679,0.03), vec3(-0.5034,0.5635,-0.1513), vec3(-0.9166,0.363,0.1675), vec2(0.6313,0.5754), vec2(0.5757,0.5515), vec2(0.6128,0.6121), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1553,0.7472,-0.0159), vec3(-0.1501,0.8228,-0.2135), vec3(-0.2628,0.737,-0.0435), vec3(-0.1764,0.9208,0.3478), vec2(0.5176,0.7183), vec2(0.5781,0.7605), vec2(0.5479,0.6924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5034,0.5635,-0.1513), vec3(-0.4922,0.5123,0.051), vec3(-0.4256,0.651,-0.1154), vec3(-0.7718,0.6051,0.1957), vec2(0.6128,0.6121), vec2(0.5581,0.5881), vec2(0.5923,0.6455), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.5479,0.2292,-0.2054), vec3(-0.5326,0.1943,-0.0315), vec3(-0.5477,0.3679,0.03), vec3(-0.9919,-0.1089,0.0649), vec2(0.647,0.5312), vec2(0.6001,0.5044), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4256,0.651,-0.1154), vec3(-0.4276,0.5652,0.083), vec3(-0.3574,0.7032,-0.0736), vec3(-0.6863,0.67,0.283), vec2(0.5923,0.6455), vec2(0.54,0.6082), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4922,0.5123,0.051), vec3(-0.5034,0.5635,-0.1513), vec3(-0.5477,0.3679,0.03), vec3(-0.9311,0.3381,0.137), vec2(0.5581,0.5881), vec2(0.6128,0.6121), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.2511,0.2421,-0.6638), 0.5352, bestT)) {
        if (triHit(ro, rd, vec3(-0.235,0.0536,-0.5748), vec3(-0.1817,0.0468,-0.5974), vec3(-0.0024,-0.0982,-0.4563), vec3(-0.3044,-0.8304,-0.4666), vec2(0.7788,0.4385), vec2(0.811,0.4814), vec2(0.8193,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3463,0.1321,-0.5225), vec3(-0.235,0.0536,-0.5748), vec3(-0.1745,-0.0971,-0.3253), vec3(-0.6377,-0.718,-0.279), vec2(0.7417,0.4658), vec2(0.7788,0.4385), vec2(0.7344,0.4028), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1653,0.1053,-0.674), vec3(-0.002,-0.0138,-0.5929), vec3(-0.1817,0.0468,-0.5974), vec3(-0.2364,-0.7474,-0.6209), vec2(0.835,0.5125), vec2(0.8599,0.4399), vec2(0.811,0.4814), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.002,0.0631,-0.6816), vec3(-0.002,-0.0138,-0.5929), vec3(-0.1653,0.1053,-0.674), vec3(-0.2199,-0.737,-0.6391), vec2(0.8853,0.4771), vec2(0.8599,0.4399), vec2(0.835,0.5125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2712,0.0996,-0.567), vec3(-0.1817,0.0468,-0.5974), vec3(-0.235,0.0536,-0.5748), vec3(-0.4027,-0.1648,-0.9004), vec2(0.7827,0.4976), vec2(0.811,0.4814), vec2(0.7788,0.4385), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1817,0.0468,-0.5974), vec3(-0.2712,0.0996,-0.567), vec3(-0.1653,0.1053,-0.674), vec3(-0.5512,-0.6023,-0.5774), vec2(0.811,0.4814), vec2(0.7827,0.4976), vec2(0.835,0.5125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.235,0.0536,-0.5748), vec3(-0.3463,0.1321,-0.5225), vec3(-0.2712,0.0996,-0.567), vec3(-0.5837,-0.3346,-0.7399), vec2(0.7788,0.4385), vec2(0.7417,0.4658), vec2(0.7827,0.4976), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3463,0.1321,-0.5225), vec3(-0.3456,0.0375,-0.3839), vec3(-0.3671,0.1254,-0.4918), vec3(-0.4883,-0.7218,-0.4904), vec2(0.7417,0.4658), vec2(0.7241,0.478), vec2(0.7471,0.5186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0015,0.1359,-0.7461), vec3(-0.002,0.0631,-0.6816), vec3(-0.1653,0.1053,-0.674), vec3(-0.2015,-0.6491,-0.7336), vec2(0.9023,0.511), vec2(0.8853,0.4771), vec2(0.835,0.5125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2712,0.0996,-0.567), vec3(-0.3463,0.1321,-0.5225), vec3(-0.3038,0.0784,-0.5337), vec3(0.5793,0.2996,0.7581), vec2(0.7827,0.4976), vec2(0.7417,0.4658), vec2(0.77,0.5044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2712,0.0996,-0.567), vec3(-0.3038,0.0784,-0.5337), vec3(-0.2331,0.1408,-0.6501), vec3(0.2438,-0.9087,-0.3388), vec2(0.7827,0.4976), vec2(0.77,0.5044), vec2(0.8125,0.5249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3671,0.1254,-0.4918), vec3(-0.3038,0.0784,-0.5337), vec3(-0.3463,0.1321,-0.5225), vec3(0.6985,0.433,0.5698), vec2(0.7471,0.5186), vec2(0.77,0.5044), vec2(0.7417,0.4658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2331,0.1408,-0.6501), vec3(-0.1653,0.1053,-0.674), vec3(-0.2712,0.0996,-0.567), vec3(-0.5308,-0.6369,-0.5591), vec2(0.8125,0.5249), vec2(0.835,0.5125), vec2(0.7827,0.4976), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3018,0.1566,-0.6195), vec3(-0.2331,0.1408,-0.6501), vec3(-0.3038,0.0784,-0.5337), vec3(-0.427,-0.6631,-0.6147), vec2(0.79,0.5378), vec2(0.8125,0.5249), vec2(0.77,0.5044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3746,0.2003,-0.5669), vec3(-0.3038,0.0784,-0.5337), vec3(-0.3671,0.1254,-0.4918), vec3(-0.7051,-0.5359,-0.4644), vec2(0.7617,0.5498), vec2(0.77,0.5044), vec2(0.7471,0.5186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1653,0.1053,-0.674), vec3(-0.1537,0.1899,-0.7421), vec3(-0.0015,0.1359,-0.7461), vec3(-0.2297,-0.5912,-0.7731), vec2(0.835,0.5125), vec2(0.854,0.5461), vec2(0.9023,0.511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3746,0.2003,-0.5669), vec3(-0.3018,0.1566,-0.6195), vec3(-0.3038,0.0784,-0.5337), vec3(-0.6817,-0.5325,-0.5017), vec2(0.7617,0.5498), vec2(0.79,0.5378), vec2(0.77,0.5044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1537,0.1899,-0.7421), vec3(-0.1653,0.1053,-0.674), vec3(-0.2331,0.1408,-0.6501), vec3(-0.5083,-0.4968,-0.7035), vec2(0.854,0.5461), vec2(0.835,0.5125), vec2(0.8125,0.5249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3671,0.1254,-0.4918), vec3(-0.4447,0.1163,-0.3549), vec3(-0.4491,0.252,-0.5112), vec3(-0.7198,-0.5339,-0.4437), vec2(0.7471,0.5186), vec2(0.7012,0.5083), vec2(0.7329,0.563), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2331,0.1408,-0.6501), vec3(-0.3018,0.1566,-0.6195), vec3(-0.2046,0.2221,-0.7263), vec3(-0.4448,-0.5245,-0.726), vec2(0.8125,0.5249), vec2(0.79,0.5378), vec2(0.8364,0.5576), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1537,0.1899,-0.7421), vec3(-0.2331,0.1408,-0.6501), vec3(-0.2046,0.2221,-0.7263), vec3(-0.5224,-0.4784,-0.7058), vec2(0.854,0.5461), vec2(0.8125,0.5249), vec2(0.8364,0.5576), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3671,0.1254,-0.4918), vec3(-0.4491,0.252,-0.5112), vec3(-0.3746,0.2003,-0.5669), vec3(-0.7121,-0.5312,-0.459), vec2(0.7471,0.5186), vec2(0.7329,0.563), vec2(0.7617,0.5498), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4447,0.1163,-0.3549), vec3(-0.5229,0.2412,-0.3511), vec3(-0.4491,0.252,-0.5112), vec3(-0.7842,-0.4791,-0.3943), vec2(0.7012,0.5083), vec2(0.6855,0.5481), vec2(0.7329,0.563), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0004,0.3006,-0.8604), vec3(0.1518,0.1808,-0.7416), vec3(-0.0015,0.1359,-0.7461), vec3(0.1879,-0.5608,-0.8064), vec2(0.9282,0.5854), vec2(0.854,0.5461), vec2(0.9023,0.511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3746,0.2003,-0.5669), vec3(-0.3736,0.2667,-0.6142), vec3(-0.3018,0.1566,-0.6195), vec3(-0.683,-0.4168,-0.5998), vec2(0.7617,0.5498), vec2(0.77,0.5732), vec2(0.79,0.5378), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0015,0.1359,-0.7461), vec3(-0.1537,0.1899,-0.7421), vec3(-0.0004,0.3006,-0.8604), vec3(-0.2178,-0.5554,-0.8026), vec2(0.9023,0.511), vec2(0.854,0.5461), vec2(0.9282,0.5854), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2046,0.2221,-0.7263), vec3(-0.3018,0.1566,-0.6195), vec3(-0.2799,0.2574,-0.7033), vec3(-0.4606,-0.5062,-0.7291), vec2(0.8364,0.5576), vec2(0.79,0.5378), vec2(0.8105,0.5745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3736,0.2667,-0.6142), vec3(-0.2799,0.2574,-0.7033), vec3(-0.3018,0.1566,-0.6195), vec3(-0.6532,-0.3951,-0.6459), vec2(0.77,0.5732), vec2(0.8105,0.5745), vec2(0.79,0.5378), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3746,0.2003,-0.5669), vec3(-0.4491,0.252,-0.5112), vec3(-0.3736,0.2667,-0.6142), vec3(-0.7107,-0.4009,-0.5781), vec2(0.7617,0.5498), vec2(0.7329,0.563), vec2(0.77,0.5732), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1537,0.1899,-0.7421), vec3(-0.2046,0.2221,-0.7263), vec3(-0.1267,0.3364,-0.8576), vec3(-0.5188,-0.468,-0.7155), vec2(0.854,0.5461), vec2(0.8364,0.5576), vec2(0.8833,0.6074), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2046,0.2221,-0.7263), vec3(-0.2799,0.2574,-0.7033), vec3(-0.2017,0.3155,-0.7917), vec3(-0.4592,-0.4999,-0.7343), vec2(0.8364,0.5576), vec2(0.8105,0.5745), vec2(0.8491,0.5974), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1267,0.3364,-0.8576), vec3(-0.0004,0.3006,-0.8604), vec3(-0.1537,0.1899,-0.7421), vec3(-0.1839,-0.5871,-0.7884), vec2(0.8833,0.6074), vec2(0.9282,0.5854), vec2(0.854,0.5461), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2017,0.3155,-0.7917), vec3(-0.1267,0.3364,-0.8576), vec3(-0.2046,0.2221,-0.7263), vec3(-0.4951,-0.488,-0.7189), vec2(0.8491,0.5974), vec2(0.8833,0.6074), vec2(0.8364,0.5576), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3754,0.387,-0.6534), vec3(-0.2799,0.2574,-0.7033), vec3(-0.3736,0.2667,-0.6142), vec3(-0.6817,-0.236,-0.6926), vec2(0.772,0.6128), vec2(0.8105,0.5745), vec2(0.77,0.5732), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4491,0.252,-0.5112), vec3(-0.4407,0.4017,-0.5628), vec3(-0.3736,0.2667,-0.6142), vec3(-0.7847,-0.1624,-0.5983), vec2(0.7329,0.563), vec2(0.7373,0.6094), vec2(0.77,0.5732), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2382,0.4057,-0.8201), vec3(-0.2017,0.3155,-0.7917), vec3(-0.2799,0.2574,-0.7033), vec3(-0.5103,-0.4391,-0.7395), vec2(0.8418,0.6313), vec2(0.8491,0.5974), vec2(0.8105,0.5745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4407,0.4017,-0.5628), vec3(-0.4491,0.252,-0.5112), vec3(-0.4954,0.3944,-0.4644), vec3(-0.864,-0.1203,-0.489), vec2(0.7373,0.6094), vec2(0.7329,0.563), vec2(0.7061,0.5986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3754,0.387,-0.6534), vec3(-0.2382,0.4057,-0.8201), vec3(-0.2799,0.2574,-0.7033), vec3(-0.7224,-0.2911,-0.6273), vec2(0.772,0.6128), vec2(0.8418,0.6313), vec2(0.8105,0.5745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3754,0.387,-0.6534), vec3(-0.3736,0.2667,-0.6142), vec3(-0.4407,0.4017,-0.5628), vec3(-0.8105,-0.1924,-0.5532), vec2(0.772,0.6128), vec2(0.77,0.5732), vec2(0.7373,0.6094), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2382,0.4057,-0.8201), vec3(-0.1267,0.3364,-0.8576), vec3(-0.2017,0.3155,-0.7917), vec3(-0.5198,-0.4406,-0.7319), vec2(0.8418,0.6313), vec2(0.8833,0.6074), vec2(0.8491,0.5974), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0006,0.4419,-0.9374), vec3(-0.0004,0.3006,-0.8604), vec3(-0.1267,0.3364,-0.8576), vec3(-0.153,-0.472,-0.8682), vec2(0.939,0.6411), vec2(0.9282,0.5854), vec2(0.8833,0.6074), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1267,0.3364,-0.8576), vec3(-0.2382,0.4057,-0.8201), vec3(-0.1093,0.4582,-0.9144), vec3(-0.4729,-0.3162,-0.8224), vec2(0.8833,0.6074), vec2(0.8418,0.6313), vec2(0.897,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0006,0.4419,-0.9374), vec3(-0.1267,0.3364,-0.8576), vec3(-0.1093,0.4582,-0.9144), vec3(-0.2428,-0.3815,-0.8919), vec2(0.939,0.6411), vec2(0.8833,0.6074), vec2(0.897,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3011,0.4865,-0.7717), vec3(-0.2382,0.4057,-0.8201), vec3(-0.3754,0.387,-0.6534), vec3(-0.7455,-0.1995,-0.636), vec2(0.8096,0.6543), vec2(0.8418,0.6313), vec2(0.772,0.6128), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3754,0.387,-0.6534), vec3(-0.4407,0.4017,-0.5628), vec3(-0.391,0.5375,-0.6133), vec3(-0.8032,0.0744,-0.5911), vec2(0.772,0.6128), vec2(0.7373,0.6094), vec2(0.7461,0.657), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1779,0.5054,-0.8911), vec3(-0.1093,0.4582,-0.9144), vec3(-0.2382,0.4057,-0.8201), vec3(-0.4831,-0.2948,-0.8245), vec2(0.8691,0.6699), vec2(0.897,0.6543), vec2(0.8418,0.6313), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.391,0.5375,-0.6133), vec3(-0.3011,0.4865,-0.7717), vec3(-0.3754,0.387,-0.6534), vec3(-0.8625,0.045,-0.504), vec2(0.7461,0.657), vec2(0.8096,0.6543), vec2(0.772,0.6128), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3011,0.4865,-0.7717), vec3(-0.2739,0.5283,-0.8034), vec3(-0.2382,0.4057,-0.8201), vec3(-0.6848,-0.1008,-0.7217), vec2(0.8096,0.6543), vec2(0.8223,0.6716), vec2(0.8418,0.6313), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2382,0.4057,-0.8201), vec3(-0.2739,0.5283,-0.8034), vec3(-0.1779,0.5054,-0.8911), vec3(-0.6842,-0.1006,-0.7223), vec2(0.8418,0.6313), vec2(0.8223,0.6716), vec2(0.8691,0.6699), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3011,0.4865,-0.7717), vec3(-0.323,0.605,-0.7095), vec3(-0.2739,0.5283,-0.8034), vec3(-0.8306,0.1305,-0.5413), vec2(0.8096,0.6543), vec2(0.7773,0.6902), vec2(0.8223,0.6716), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.323,0.605,-0.7095), vec3(-0.3011,0.4865,-0.7717), vec3(-0.391,0.5375,-0.6133), vec3(-0.8475,0.1151,-0.5181), vec2(0.7773,0.6902), vec2(0.8096,0.6543), vec2(0.7461,0.657), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.2495,-0.0801,-0.1894), 0.5398, bestT)) {
        if (triHit(ro, rd, vec3(-0.0024,-0.0982,-0.4563), vec3(-0.0026,-0.1648,-0.2966), vec3(-0.235,0.0536,-0.5748), vec3(-0.3761,-0.8549,-0.3573), vec2(0.8193,0.3926), vec2(0.7695,0.3516), vec2(0.7788,0.4385), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3463,0.1321,-0.5225), vec3(-0.2702,-0.0558,-0.3317), vec3(-0.3456,0.0375,-0.3839), vec3(-0.5363,-0.6983,-0.4741), vec2(0.7417,0.4658), vec2(0.7168,0.4312), vec2(0.7241,0.478), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3456,0.0375,-0.3839), vec3(-0.4447,0.1163,-0.3549), vec3(-0.3671,0.1254,-0.4918), vec3(-0.6383,-0.6543,-0.4055), vec2(0.7241,0.478), vec2(0.7012,0.5083), vec2(0.7471,0.5186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0026,-0.1648,-0.2966), vec3(-0.1745,-0.0971,-0.3253), vec3(-0.235,0.0536,-0.5748), vec3(-0.2609,-0.853,-0.452), vec2(0.7695,0.3516), vec2(0.7344,0.4028), vec2(0.7788,0.4385), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1745,-0.0971,-0.3253), vec3(-0.2702,-0.0558,-0.3317), vec3(-0.3463,0.1321,-0.5225), vec3(-0.2766,-0.7374,-0.6162), vec2(0.7344,0.4028), vec2(0.7168,0.4312), vec2(0.7417,0.4658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4113,0.0729,-0.3191), vec3(-0.4447,0.1163,-0.3549), vec3(-0.3456,0.0375,-0.3839), vec3(-0.6461,-0.7162,-0.2639), vec2(0.6948,0.4858), vec2(0.7012,0.5083), vec2(0.7241,0.478), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.034,-0.2914), vec3(-0.3456,0.0375,-0.3839), vec3(-0.2702,-0.0558,-0.3317), vec3(-0.545,-0.6991,-0.4629), vec2(0.6963,0.4434), vec2(0.7241,0.478), vec2(0.7168,0.4312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.034,-0.2914), vec3(-0.4113,0.0729,-0.3191), vec3(-0.3456,0.0375,-0.3839), vec3(-0.6977,-0.6114,-0.3733), vec2(0.6963,0.4434), vec2(0.6948,0.4858), vec2(0.7241,0.478), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2702,-0.0558,-0.3317), vec3(-0.1745,-0.0971,-0.3253), vec3(-0.2519,-0.0924,-0.3177), vec3(-0.1138,-0.4047,-0.9074), vec2(0.7168,0.4312), vec2(0.7344,0.4028), vec2(0.707,0.4131), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1838,-0.0881,-0.3287), vec3(-0.2519,-0.0924,-0.3177), vec3(-0.1745,-0.0971,-0.3253), vec3(0.1144,0.4512,0.8851), vec2(0.7144,0.3921), vec2(0.707,0.4131), vec2(0.7344,0.4028), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2519,-0.0924,-0.3177), vec3(-0.2921,-0.0789,-0.3011), vec3(-0.2702,-0.0558,-0.3317), vec3(-0.4695,-0.5108,-0.7202), vec2(0.707,0.4131), vec2(0.6943,0.4199), vec2(0.7168,0.4312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2519,-0.0924,-0.3177), vec3(-0.1838,-0.0881,-0.3287), vec3(-0.2271,-0.1348,-0.2818), vec3(-0.0768,-0.6698,-0.7385), vec2(0.707,0.4131), vec2(0.7144,0.3921), vec2(0.6938,0.3955), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2921,-0.0789,-0.3011), vec3(-0.3324,-0.034,-0.2914), vec3(-0.2702,-0.0558,-0.3317), vec3(-0.593,-0.3799,-0.7099), vec2(0.6943,0.4199), vec2(0.6963,0.4434), vec2(0.7168,0.4312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1238,-0.1378,-0.2481), vec3(-0.1838,-0.0881,-0.3287), vec3(-0.1745,-0.0971,-0.3253), vec3(-0.7051,-0.7031,0.0923), vec2(0.7188,0.3711), vec2(0.7144,0.3921), vec2(0.7344,0.4028), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2921,-0.0789,-0.3011), vec3(-0.2519,-0.0924,-0.3177), vec3(-0.2537,-0.1332,-0.2749), vec3(-0.4683,-0.6296,-0.6199), vec2(0.6943,0.4199), vec2(0.707,0.4131), vec2(0.6885,0.4004), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4113,0.0729,-0.3191), vec3(-0.4688,0.0743,-0.2096), vec3(-0.4447,0.1163,-0.3549), vec3(-0.6106,-0.7281,-0.3114), vec2(0.6948,0.4858), vec2(0.6606,0.4844), vec2(0.7012,0.5083), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2271,-0.1348,-0.2818), vec3(-0.2537,-0.1332,-0.2749), vec3(-0.2519,-0.0924,-0.3177), vec3(-0.2191,-0.7018,-0.6779), vec2(0.6938,0.3955), vec2(0.6885,0.4004), vec2(0.707,0.4131), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0026,-0.1648,-0.2966), vec3(-0.1238,-0.1378,-0.2481), vec3(-0.1745,-0.0971,-0.3253), vec3(-0.3129,-0.9094,-0.2739), vec2(0.7695,0.3516), vec2(0.7188,0.3711), vec2(0.7344,0.4028), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2271,-0.1348,-0.2818), vec3(-0.1838,-0.0881,-0.3287), vec3(-0.2108,-0.1298,-0.2573), vec3(0.5864,-0.7761,-0.232), vec2(0.6938,0.3955), vec2(0.7144,0.3921), vec2(0.6895,0.3877), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2271,-0.1348,-0.2818), vec3(-0.2313,-0.1936,-0.2839), vec3(-0.2537,-0.1332,-0.2749), vec3(-0.2503,0.0517,-0.9668), vec2(0.016,0.3662), vec2(0.048,0.3647), vec2(0.0156,0.3486), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2579,-0.1916,-0.2771), vec3(-0.2537,-0.1332,-0.2749), vec3(-0.2313,-0.1936,-0.2839), vec3(-0.2428,0.0548,-0.9685), vec2(0.0473,0.3496), vec2(0.0156,0.3486), vec2(0.048,0.3647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2537,-0.1332,-0.2749), vec3(-0.3164,-0.0752,-0.257), vec3(-0.2921,-0.0789,-0.3011), vec3(-0.691,-0.645,-0.3264), vec2(0.6885,0.4004), vec2(0.6792,0.4209), vec2(0.6943,0.4199), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.034,-0.2914), vec3(-0.4477,0.0546,-0.2137), vec3(-0.4113,0.0729,-0.3191), vec3(-0.7075,-0.6131,-0.3516), vec2(0.6963,0.4434), vec2(0.6626,0.4756), vec2(0.6948,0.4858), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2313,-0.1936,-0.2839), vec3(-0.2271,-0.1348,-0.2818), vec3(-0.2148,-0.1869,-0.258), vec3(0.8472,-0.0419,-0.5297), vec2(0.048,0.3647), vec2(0.016,0.3662), vec2(0.0443,0.3823), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.034,-0.2914), vec3(-0.2921,-0.0789,-0.3011), vec3(-0.3642,-0.0339,-0.2216), vec3(-0.7357,-0.589,-0.3343), vec2(0.6963,0.4434), vec2(0.6943,0.4199), vec2(0.6709,0.4399), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2108,-0.1298,-0.2573), vec3(-0.1838,-0.0881,-0.3287), vec3(-0.1609,-0.1187,-0.2166), vec3(0.4471,-0.8355,-0.3194), vec2(0.6895,0.3877), vec2(0.7144,0.3921), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2108,-0.1298,-0.2573), vec3(-0.2148,-0.1869,-0.258), vec3(-0.2271,-0.1348,-0.2818), vec3(0.8368,-0.0514,-0.5451), vec2(0.0108,0.3843), vec2(0.0443,0.3823), vec2(0.016,0.3662), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2579,-0.1916,-0.2771), vec3(-0.2649,-0.185,-0.2448), vec3(-0.2537,-0.1332,-0.2749), vec3(-0.9713,0.0789,-0.2244), vec2(0.0473,0.3496), vec2(0.0417,0.3345), vec2(0.0156,0.3486), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1838,-0.0881,-0.3287), vec3(-0.1238,-0.1378,-0.2481), vec3(-0.1609,-0.1187,-0.2166), vec3(-0.5326,-0.8379,-0.1193), vec2(0.7144,0.3921), vec2(0.7188,0.3711), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2537,-0.1332,-0.2749), vec3(-0.2617,-0.1246,-0.2494), vec3(-0.3164,-0.0752,-0.257), vec3(-0.6731,-0.7385,0.04), vec2(0.6885,0.4004), vec2(0.6812,0.3989), vec2(0.6792,0.4209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3164,-0.0752,-0.257), vec3(-0.3642,-0.0339,-0.2216), vec3(-0.2921,-0.0789,-0.3011), vec3(-0.7482,-0.5537,-0.3655), vec2(0.6792,0.4209), vec2(0.6709,0.4399), vec2(0.6943,0.4199), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.26,-0.2,-0.2528), vec3(-0.2649,-0.185,-0.2448), vec3(-0.2579,-0.1916,-0.2771), vec3(-0.9605,-0.2281,-0.1596), vec2(0.054,0.3354), vec2(0.0417,0.3345), vec2(0.0473,0.3496), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4688,0.0743,-0.2096), vec3(-0.5479,0.2292,-0.2054), vec3(-0.4447,0.1163,-0.3549), vec3(-0.8612,-0.4322,-0.2675), vec2(0.6606,0.4844), vec2(0.647,0.5312), vec2(0.7012,0.5083), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2537,-0.1332,-0.2749), vec3(-0.2649,-0.185,-0.2448), vec3(-0.2617,-0.1246,-0.2494), vec3(-0.9511,0.0262,-0.3077), vec2(0.0156,0.3486), vec2(0.0417,0.3345), vec2(0.0091,0.332), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0026,-0.1648,-0.2966), vec3(-0.0025,-0.1771,-0.2215), vec3(-0.1238,-0.1378,-0.2481), vec3(-0.2741,-0.9492,-0.1549), vec2(0.7695,0.3516), vec2(0.7422,0.335), vec2(0.7188,0.3711), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2148,-0.1869,-0.258), vec3(-0.2108,-0.1298,-0.2573), vec3(-0.2223,-0.1803,-0.2324), vec3(0.952,-0.0693,0.2982), vec2(0.0584,0.2881), vec2(0.0285,0.272), vec2(0.0463,0.3003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4477,0.0546,-0.2137), vec3(-0.4688,0.0743,-0.2096), vec3(-0.4113,0.0729,-0.3191), vec3(-0.6769,-0.649,-0.3472), vec2(0.6626,0.4756), vec2(0.6606,0.4844), vec2(0.6948,0.4858), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2223,-0.1803,-0.2324), vec3(-0.2264,-0.1995,-0.2382), vec3(-0.2148,-0.1869,-0.258), vec3(0.8939,-0.2935,0.3388), vec2(0.0463,0.3003), vec2(0.0586,0.3052), vec2(0.0584,0.2881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3324,-0.034,-0.2914), vec3(-0.3642,-0.0339,-0.2216), vec3(-0.4477,0.0546,-0.2137), vec3(-0.703,-0.6355,-0.3193), vec2(0.6963,0.4434), vec2(0.6709,0.4399), vec2(0.6626,0.4756), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2649,-0.185,-0.2448), vec3(-0.2461,-0.1849,-0.2196), vec3(-0.2617,-0.1246,-0.2494), vec3(-0.8001,0.0864,0.5936), vec2(0.0417,0.3345), vec2(0.0417,0.3159), vec2(0.0091,0.332), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2141,-0.1274,-0.2208), vec3(-0.2223,-0.1803,-0.2324), vec3(-0.2108,-0.1298,-0.2573), vec3(0.9797,-0.1739,0.0993), vec2(0.0112,0.2886), vec2(0.0463,0.3003), vec2(0.0285,0.272), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2141,-0.1274,-0.2208), vec3(-0.2108,-0.1298,-0.2573), vec3(-0.1609,-0.1187,-0.2166), vec3(0.1552,-0.9847,0.0792), vec2(0.6797,0.3838), vec2(0.6895,0.3877), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2223,-0.1803,-0.2324), vec3(-0.2461,-0.1849,-0.2196), vec3(-0.2264,-0.1995,-0.2382), vec3(0.4963,-0.3473,0.7956), vec2(0.0463,0.3003), vec2(0.0417,0.3159), vec2(0.0586,0.3052), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3051,-0.0887,-0.1832), vec3(-0.3164,-0.0752,-0.257), vec3(-0.2617,-0.1246,-0.2494), vec3(-0.6675,-0.7438,-0.0344), vec2(0.6606,0.4077), vec2(0.6792,0.4209), vec2(0.6812,0.3989), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2393,-0.1272,-0.2127), vec3(-0.2617,-0.1246,-0.2494), vec3(-0.2461,-0.1849,-0.2196), vec3(-0.8513,0.0384,0.5232), vec2(0.0072,0.3042), vec2(0.0091,0.332), vec2(0.0417,0.3159), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2393,-0.1272,-0.2127), vec3(-0.2223,-0.1803,-0.2324), vec3(-0.2141,-0.1274,-0.2208), vec3(0.2933,-0.2475,0.9234), vec2(0.0072,0.3042), vec2(0.0463,0.3003), vec2(0.0112,0.2886), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2223,-0.1803,-0.2324), vec3(-0.2393,-0.1272,-0.2127), vec3(-0.2461,-0.1849,-0.2196), vec3(0.492,-0.159,0.856), vec2(0.0463,0.3003), vec2(0.0072,0.3042), vec2(0.0417,0.3159), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2617,-0.1246,-0.2494), vec3(-0.2393,-0.1272,-0.2127), vec3(-0.3051,-0.0887,-0.1832), vec3(-0.4269,-0.8823,0.1984), vec2(0.6812,0.3989), vec2(0.6748,0.3892), vec2(0.6606,0.4077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1942,-0.1122,-0.2014), vec3(-0.2141,-0.1274,-0.2208), vec3(-0.1609,-0.1187,-0.2166), vec3(0.0912,-0.8265,0.5555), vec2(0.6753,0.3745), vec2(0.6797,0.3838), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2141,-0.1274,-0.2208), vec3(-0.1942,-0.1122,-0.2014), vec3(-0.2393,-0.1272,-0.2127), vec3(0.154,-0.8476,0.5078), vec2(0.6797,0.3838), vec2(0.6753,0.3745), vec2(0.6748,0.3892), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0025,-0.1771,-0.2215), vec3(-0.0026,-0.1648,-0.2966), vec3(0.1265,-0.1703,-0.1156), vec3(0.1818,-0.9704,-0.1589), vec2(0.7422,0.335), vec2(0.7695,0.3516), vec2(0.7188,0.3711), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1238,-0.1378,-0.2481), vec3(-0.0025,-0.1771,-0.2215), vec3(-0.11,-0.1515,-0.1569), vec3(-0.2873,-0.9526,-0.0998), vec2(0.7188,0.3711), vec2(0.7422,0.335), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1785,-0.1439,-0.2136), vec3(0.1265,-0.1703,-0.1156), vec3(-0.0026,-0.1648,-0.2966), vec3(0.1866,-0.969,-0.1622), vec2(0.7344,0.4028), vec2(0.7188,0.3711), vec2(0.7695,0.3516), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3642,-0.0339,-0.2216), vec3(-0.3164,-0.0752,-0.257), vec3(-0.3539,-0.0526,-0.1463), vec3(-0.6866,-0.722,-0.0857), vec2(0.6709,0.4399), vec2(0.6792,0.4209), vec2(0.6499,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.11,-0.1515,-0.1569), vec3(-0.1609,-0.1187,-0.2166), vec3(-0.1238,-0.1378,-0.2481), vec3(-0.4939,-0.8677,-0.0557), vec2(0.6943,0.3525), vec2(0.6885,0.3687), vec2(0.7188,0.3711), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3051,-0.0887,-0.1832), vec3(-0.3539,-0.0526,-0.1463), vec3(-0.3164,-0.0752,-0.257), vec3(-0.6177,-0.7849,-0.0495), vec2(0.6606,0.4077), vec2(0.6499,0.4253), vec2(0.6792,0.4209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2376,-0.1058,-0.1589), vec3(-0.2393,-0.1272,-0.2127), vec3(-0.1942,-0.1122,-0.2014), vec3(0.2131,-0.9101,0.3553), vec2(0.6597,0.3828), vec2(0.6748,0.3892), vec2(0.6753,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2376,-0.1058,-0.1589), vec3(-0.3051,-0.0887,-0.1832), vec3(-0.2393,-0.1272,-0.2127), vec3(-0.3476,-0.8675,0.3557), vec2(0.6597,0.3828), vec2(0.6606,0.4077), vec2(0.6748,0.3892), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1698,-0.1054,-0.097), vec3(-0.1942,-0.1122,-0.2014), vec3(-0.1609,-0.1187,-0.2166), vec3(-0.1475,-0.9841,0.0985), vec2(0.6538,0.3569), vec2(0.6753,0.3745), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4477,0.0546,-0.2137), vec3(-0.3642,-0.0339,-0.2216), vec3(-0.4348,0.0213,-0.0744), vec3(-0.7279,-0.6792,-0.0945), vec2(0.6626,0.4756), vec2(0.6709,0.4399), vec2(0.626,0.4536), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0023,-0.1835,-0.1247), vec3(-0.11,-0.1515,-0.1569), vec3(-0.0025,-0.1771,-0.2215), vec3(-0.2675,-0.9615,-0.0634), vec2(0.7104,0.3188), vec2(0.6943,0.3525), vec2(0.7422,0.335), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4688,0.0743,-0.2096), vec3(-0.4477,0.0546,-0.2137), vec3(-0.457,0.0425,-0.0546), vec3(-0.6908,-0.7168,-0.0946), vec2(0.6606,0.4844), vec2(0.6626,0.4756), vec2(0.6196,0.4609), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.11,-0.1515,-0.1569), vec3(-0.1698,-0.1054,-0.097), vec3(-0.1609,-0.1187,-0.2166), vec3(-0.5796,-0.8135,0.0472), vec2(0.6943,0.3525), vec2(0.6538,0.3569), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1942,-0.1122,-0.2014), vec3(-0.1698,-0.1054,-0.097), vec3(-0.2376,-0.1058,-0.1589), vec3(-0.0679,-0.9944,0.0806), vec2(0.6753,0.3745), vec2(0.6538,0.3569), vec2(0.6597,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4688,0.0743,-0.2096), vec3(-0.5326,0.1943,-0.0315), vec3(-0.5479,0.2292,-0.2054), vec3(-0.8908,-0.4542,-0.0132), vec2(0.6606,0.4844), vec2(0.6001,0.5044), vec2(0.647,0.5312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3539,-0.0526,-0.1463), vec3(-0.4348,0.0213,-0.0744), vec3(-0.3642,-0.0339,-0.2216), vec3(-0.7091,-0.7008,-0.0774), vec2(0.6499,0.4253), vec2(0.626,0.4536), vec2(0.6709,0.4399), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2376,-0.1058,-0.1589), vec3(-0.3147,-0.0802,-0.0679), vec3(-0.3051,-0.0887,-0.1832), vec3(-0.2619,-0.9638,0.0494), vec2(0.6597,0.3828), vec2(0.6328,0.4023), vec2(0.6606,0.4077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3539,-0.0526,-0.1463), vec3(-0.3051,-0.0887,-0.1832), vec3(-0.3147,-0.0802,-0.0679), vec3(-0.5891,-0.808,0.0109), vec2(0.6499,0.4253), vec2(0.6606,0.4077), vec2(0.6328,0.4023), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0023,-0.1835,-0.1247), vec3(-0.0025,-0.1771,-0.2215), vec3(0.1094,-0.1629,-0.0349), vec3(0.2311,-0.9707,-0.065), vec2(0.7104,0.3188), vec2(0.7422,0.335), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1265,-0.1703,-0.1156), vec3(0.1094,-0.1629,-0.0349), vec3(-0.0025,-0.1771,-0.2215), vec3(-0.0184,-0.9961,0.0866), vec2(0.7188,0.3711), vec2(0.6943,0.3525), vec2(0.7422,0.335), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4348,0.0213,-0.0744), vec3(-0.457,0.0425,-0.0546), vec3(-0.4477,0.0546,-0.2137), vec3(-0.7301,-0.6769,-0.0938), vec2(0.626,0.4536), vec2(0.6196,0.4609), vec2(0.6626,0.4756), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2376,-0.1058,-0.1589), vec3(-0.1698,-0.1054,-0.097), vec3(-0.2346,-0.097,-0.069), vec3(-0.0855,-0.9913,0.0998), vec2(0.6597,0.3828), vec2(0.6538,0.3569), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2346,-0.097,-0.069), vec3(-0.3147,-0.0802,-0.0679), vec3(-0.2376,-0.1058,-0.1589), vec3(-0.203,-0.9738,0.1021), vec2(0.6387,0.3745), vec2(0.6328,0.4023), vec2(0.6597,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4688,0.0743,-0.2096), vec3(-0.457,0.0425,-0.0546), vec3(-0.5326,0.1943,-0.0315), vec3(-0.8962,-0.4431,-0.0225), vec2(0.6606,0.4844), vec2(0.6196,0.4609), vec2(0.6001,0.5044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1698,-0.1054,-0.097), vec3(-0.11,-0.1515,-0.1569), vec3(-0.1112,-0.1342,-0.0409), vec3(-0.5283,-0.8406,0.1193), vec2(0.6538,0.3569), vec2(0.6943,0.3525), vec2(0.6577,0.3379), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0023,-0.1835,-0.1247), vec3(-0.0019,-0.162,-0.0109), vec3(-0.11,-0.1515,-0.1569), vec3(-0.3292,-0.9275,0.1771), vec2(0.7104,0.3188), vec2(0.6729,0.3022), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3539,-0.0526,-0.1463), vec3(-0.3147,-0.0802,-0.0679), vec3(-0.4348,0.0213,-0.0744), vec3(-0.646,-0.7613,0.0558), vec2(0.6499,0.4253), vec2(0.6328,0.4023), vec2(0.626,0.4536), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1112,-0.1342,-0.0409), vec3(-0.11,-0.1515,-0.1569), vec3(-0.0019,-0.162,-0.0109), vec3(-0.2792,-0.9502,0.1384), vec2(0.6577,0.3379), vec2(0.6943,0.3525), vec2(0.6729,0.3022), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0023,-0.1835,-0.1247), vec3(0.1094,-0.1629,-0.0349), vec3(-0.0019,-0.162,-0.0109), vec3(0.0315,-0.9821,0.186), vec2(0.7104,0.3188), vec2(0.6943,0.3525), vec2(0.6729,0.3022), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3994,-0.0459,0.0731), vec3(-0.4348,0.0213,-0.0744), vec3(-0.3147,-0.0802,-0.0679), vec3(-0.627,-0.7547,-0.1933), vec2(0.5903,0.4189), vec2(0.626,0.4536), vec2(0.6328,0.4023), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3994,-0.0459,0.0731), vec3(-0.457,0.0425,-0.0546), vec3(-0.4348,0.0213,-0.0744), vec3(-0.7406,-0.6605,-0.1231), vec2(0.5903,0.4189), vec2(0.6196,0.4609), vec2(0.626,0.4536), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1698,-0.1054,-0.097), vec3(-0.1098,-0.1015,0.1122), vec3(-0.2346,-0.097,-0.069), vec3(-0.1075,-0.993,0.0491), vec2(0.6538,0.3569), vec2(0.6079,0.3198), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2346,-0.097,-0.069), vec3(-0.3293,-0.0783,0.1059), vec3(-0.3147,-0.0802,-0.0679), vec3(-0.2055,-0.9786,-0.0066), vec2(0.6387,0.3745), vec2(0.5879,0.3926), vec2(0.6328,0.4023), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1098,-0.1015,0.1122), vec3(-0.1698,-0.1054,-0.097), vec3(-0.1112,-0.1342,-0.0409), vec3(-0.5661,-0.805,0.1771), vec2(0.6079,0.3198), vec2(0.6538,0.3569), vec2(0.6577,0.3379), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.457,0.0425,-0.0546), vec3(-0.4294,0.0359,0.1305), vec3(-0.5326,0.1943,-0.0315), vec3(-0.882,-0.457,0.1151), vec2(0.6196,0.4609), vec2(0.5679,0.4419), vec2(0.6001,0.5044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0019,-0.162,-0.0109), vec3(-0.001,-0.1306,0.1348), vec3(-0.1112,-0.1342,-0.0409), vec3(-0.2929,-0.9344,0.2029), vec2(0.6729,0.3022), vec2(0.623,0.2847), vec2(0.6577,0.3379), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3293,-0.0783,0.1059), vec3(-0.3994,-0.0459,0.0731), vec3(-0.3147,-0.0802,-0.0679), vec3(-0.4099,-0.9118,-0.0246), vec2(0.5879,0.3926), vec2(0.5903,0.4189), vec2(0.6328,0.4023), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.457,0.0425,-0.0546), vec3(-0.3994,-0.0459,0.0731), vec3(-0.4294,0.0359,0.1305), vec3(-0.902,-0.4148,0.1196), vec2(0.6196,0.4609), vec2(0.5903,0.4189), vec2(0.5679,0.4419), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2346,-0.097,-0.069), vec3(-0.2274,-0.0877,0.1159), vec3(-0.3293,-0.0783,0.1059), vec3(-0.0974,-0.9938,0.0536), vec2(0.6387,0.3745), vec2(0.5928,0.3579), vec2(0.5879,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2346,-0.097,-0.069), vec3(-0.1098,-0.1015,0.1122), vec3(-0.2274,-0.0877,0.1159), vec3(-0.1148,-0.9919,0.0542), vec2(0.6387,0.3745), vec2(0.6079,0.3198), vec2(0.5928,0.3579), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1098,-0.1015,0.1122), vec3(-0.1112,-0.1342,-0.0409), vec3(-0.001,-0.1306,0.1348), vec3(-0.292,-0.9348,0.2023), vec2(0.6079,0.3198), vec2(0.6577,0.3379), vec2(0.623,0.2847), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.4294,0.0359,0.1305), vec3(-0.4753,0.1414,0.1845), vec3(-0.5326,0.1943,-0.0315), vec3(-0.8847,-0.4492,0.1246), vec2(0.5679,0.4419), vec2(0.5435,0.4731), vec2(0.6001,0.5044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3994,-0.0459,0.0731), vec3(-0.3293,-0.0783,0.1059), vec3(-0.3687,-0.0482,0.2259), vec3(-0.4476,-0.8909,0.0766), vec2(0.5903,0.4189), vec2(0.5879,0.3926), vec2(0.5479,0.3999), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3994,-0.0459,0.0731), vec3(-0.3687,-0.0482,0.2259), vec3(-0.4294,0.0359,0.1305), vec3(-0.8804,-0.4426,0.1704), vec2(0.5903,0.4189), vec2(0.5479,0.3999), vec2(0.5679,0.4419), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.1185,0.7532,-0.9338), 0.426, bestT)) {
        if (triHit(ro, rd, vec3(0.0006,0.4419,-0.9374), vec3(0.0019,0.6256,-1.0594), vec3(0.111,0.456,-0.9155), vec3(0.2296,-0.5398,-0.8099), vec2(0.939,0.6411), vec2(0.9434,0.6992), vec2(0.897,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0006,0.4419,-0.9374), vec3(-0.1093,0.4582,-0.9144), vec3(0.0019,0.6256,-1.0594), vec3(-0.248,-0.5351,-0.8076), vec2(0.939,0.6411), vec2(0.897,0.6543), vec2(0.9434,0.6992), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0925,0.6468,-1.0361), vec3(-0.1093,0.4582,-0.9144), vec3(-0.1779,0.5054,-0.8911), vec3(-0.5385,-0.4227,-0.7289), vec2(0.9053,0.7095), vec2(0.897,0.6543), vec2(0.8691,0.6699), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2353,0.5862,-0.8505), vec3(-0.1779,0.5054,-0.8911), vec3(-0.2739,0.5283,-0.8034), vec3(-0.6855,-0.1263,-0.717), vec2(0.8394,0.6953), vec2(0.8691,0.6699), vec2(0.8223,0.6716), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0968,0.6448,-1.037), vec3(0.111,0.456,-0.9155), vec3(0.0019,0.6256,-1.0594), vec3(0.2937,-0.5017,-0.8136), vec2(0.9053,0.7095), vec2(0.897,0.6543), vec2(0.9434,0.6992), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0925,0.6468,-1.0361), vec3(0.0019,0.6256,-1.0594), vec3(-0.1093,0.4582,-0.9144), vec3(-0.3115,-0.4956,-0.8107), vec2(0.9053,0.7095), vec2(0.9434,0.6992), vec2(0.897,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2353,0.5862,-0.8505), vec3(-0.0925,0.6468,-1.0361), vec3(-0.1779,0.5054,-0.8911), vec3(-0.742,-0.2062,-0.6379), vec2(0.8394,0.6953), vec2(0.9053,0.7095), vec2(0.8691,0.6699), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2739,0.5283,-0.8034), vec3(-0.2933,0.6399,-0.7515), vec3(-0.2353,0.5862,-0.8505), vec3(-0.8305,0.1095,-0.5461), vec2(0.8223,0.6716), vec2(0.7944,0.7068), vec2(0.8394,0.6953), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2933,0.6399,-0.7515), vec3(-0.2739,0.5283,-0.8034), vec3(-0.323,0.605,-0.7095), vec3(-0.848,0.0949,-0.5214), vec2(0.7944,0.7068), vec2(0.8223,0.6716), vec2(0.7773,0.6902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.261,0.6771,-0.8018), vec3(-0.2353,0.5862,-0.8505), vec3(-0.2933,0.6399,-0.7515), vec3(-0.8532,0.037,-0.5202), vec2(0.813,0.7246), vec2(0.8394,0.6953), vec2(0.7944,0.7068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0925,0.6468,-1.0361), vec3(-0.2353,0.5862,-0.8505), vec3(-0.1684,0.7051,-0.9867), vec3(-0.6849,-0.348,-0.6402), vec2(0.9053,0.7095), vec2(0.8394,0.6953), vec2(0.8701,0.7329), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.323,0.605,-0.7095), vec3(-0.3016,0.7086,-0.6574), vec3(-0.2933,0.6399,-0.7515), vec3(-0.8768,0.348,-0.3318), vec2(0.7773,0.6902), vec2(0.7549,0.7261), vec2(0.7944,0.7068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2353,0.5862,-0.8505), vec3(-0.261,0.6771,-0.8018), vec3(-0.1684,0.7051,-0.9867), vec3(-0.8933,-0.0122,-0.4493), vec2(0.8394,0.6953), vec2(0.813,0.7246), vec2(0.8701,0.7329), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.261,0.6771,-0.8018), vec3(-0.2933,0.6399,-0.7515), vec3(-0.2579,0.7642,-0.7416), vec3(-0.8886,0.2816,-0.362), vec2(0.813,0.7246), vec2(0.7944,0.7068), vec2(0.7852,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0019,0.6256,-1.0594), vec3(0.0037,0.8345,-1.1038), vec3(0.0968,0.6448,-1.037), vec3(0.2636,-0.2026,-0.9431), vec2(0.9434,0.6992), vec2(0.9473,0.7694), vec2(0.9053,0.7095), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0019,0.6256,-1.0594), vec3(-0.0925,0.6468,-1.0361), vec3(0.0037,0.8345,-1.1038), vec3(-0.2765,-0.1972,-0.9405), vec2(0.9434,0.6992), vec2(0.9053,0.7095), vec2(0.9473,0.7694), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3016,0.7086,-0.6574), vec3(-0.2579,0.7642,-0.7416), vec3(-0.2933,0.6399,-0.7515), vec3(-0.9149,0.2832,-0.2878), vec2(0.7549,0.7261), vec2(0.7852,0.755), vec2(0.7944,0.7068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.203,0.7761,-0.9163), vec3(-0.1684,0.7051,-0.9867), vec3(-0.261,0.6771,-0.8018), vec3(-0.8945,0.0075,-0.4469), vec2(0.8408,0.7628), vec2(0.8701,0.7329), vec2(0.813,0.7246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0914,0.833,-1.0714), vec3(0.1743,0.7017,-0.9883), vec3(0.0968,0.6448,-1.037), vec3(0.5936,-0.1278,-0.7946), vec2(0.9111,0.7754), vec2(0.8701,0.7329), vec2(0.9053,0.7095), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0925,0.6468,-1.0361), vec3(-0.1684,0.7051,-0.9867), vec3(-0.0836,0.8347,-1.0705), vec3(-0.6034,-0.1159,-0.789), vec2(0.9053,0.7095), vec2(0.8701,0.7329), vec2(0.9111,0.7754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.261,0.6771,-0.8018), vec3(-0.2579,0.7642,-0.7416), vec3(-0.203,0.7761,-0.9163), vec3(-0.9337,0.2253,-0.2782), vec2(0.813,0.7246), vec2(0.7852,0.755), vec2(0.8408,0.7628), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1743,0.7017,-0.9883), vec3(0.0914,0.833,-1.0714), vec3(0.211,0.772,-0.9182), vec3(0.8071,0.1483,-0.5715), vec2(0.8701,0.7329), vec2(0.9111,0.7754), vec2(0.8408,0.7628), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0914,0.833,-1.0714), vec3(0.0968,0.6448,-1.037), vec3(0.0037,0.8345,-1.1038), vec3(0.3401,-0.1593,-0.9268), vec2(0.9111,0.7754), vec2(0.9053,0.7095), vec2(0.9473,0.7694), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1684,0.7051,-0.9867), vec3(-0.203,0.7761,-0.9163), vec3(-0.0836,0.8347,-1.0705), vec3(-0.8094,0.1646,-0.5637), vec2(0.8701,0.7329), vec2(0.8408,0.7628), vec2(0.9111,0.7754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0836,0.8347,-1.0705), vec3(0.0037,0.8345,-1.1038), vec3(-0.0925,0.6468,-1.0361), vec3(-0.352,-0.1524,-0.9235), vec2(0.9111,0.7754), vec2(0.9473,0.7694), vec2(0.9053,0.7095), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2115,0.8522,-0.6831), vec3(-0.2579,0.7642,-0.7416), vec3(-0.3016,0.7086,-0.6574), vec3(-0.8508,0.5157,-0.1013), vec2(0.7583,0.7926), vec2(0.7852,0.755), vec2(0.7549,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2017,0.8842,-0.8568), vec3(-0.203,0.7761,-0.9163), vec3(-0.2579,0.7642,-0.7416), vec3(-0.9436,0.1678,-0.2853), vec2(0.8188,0.809), vec2(0.8408,0.7628), vec2(0.7852,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1823,0.8486,-0.9594), vec3(0.211,0.772,-0.9182), vec3(0.0914,0.833,-1.0714), vec3(0.7785,-0.045,-0.6261), vec2(0.8579,0.7921), vec2(0.8408,0.7628), vec2(0.9111,0.7754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1732,0.8522,-0.9577), vec3(-0.0836,0.8347,-1.0705), vec3(-0.203,0.7761,-0.9163), vec3(-0.7851,-0.0294,-0.6186), vec2(0.8579,0.7921), vec2(0.9111,0.7754), vec2(0.8408,0.7628), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2115,0.8522,-0.6831), vec3(-0.2017,0.8842,-0.8568), vec3(-0.2579,0.7642,-0.7416), vec3(-0.8929,0.449,0.0326), vec2(0.7583,0.7926), vec2(0.8188,0.809), vec2(0.7852,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2017,0.8842,-0.8568), vec3(-0.1732,0.8522,-0.9577), vec3(-0.203,0.7761,-0.9163), vec3(-0.9278,0.188,-0.3222), vec2(0.8188,0.809), vec2(0.8579,0.7921), vec2(0.8408,0.7628), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0046,0.9224,-1.1114), vec3(0.0914,0.833,-1.0714), vec3(0.0037,0.8345,-1.1038), vec3(0.3445,-0.0842,-0.935), vec2(0.9512,0.7986), vec2(0.9111,0.7754), vec2(0.9473,0.7694), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0037,0.8345,-1.1038), vec3(-0.0836,0.8347,-1.0705), vec3(0.0046,0.9224,-1.1114), vec3(-0.355,-0.0771,-0.9317), vec2(0.9473,0.7694), vec2(0.9111,0.7754), vec2(0.9512,0.7986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0914,0.833,-1.0714), vec3(0.0926,0.9199,-1.0777), vec3(0.1823,0.8486,-0.9594), vec3(0.7788,-0.0568,-0.6247), vec2(0.9111,0.7754), vec2(0.9146,0.807), vec2(0.8579,0.7921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1732,0.8522,-0.9577), vec3(-0.0832,0.9217,-1.0768), vec3(-0.0836,0.8347,-1.0705), vec3(-0.7857,-0.0413,-0.6172), vec2(0.8579,0.7921), vec2(0.9146,0.807), vec2(0.9111,0.7754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2017,0.8842,-0.8568), vec3(-0.1583,0.9366,-0.9762), vec3(-0.1732,0.8522,-0.9577), vec3(-0.9483,0.1017,-0.3006), vec2(0.8188,0.809), vec2(0.8682,0.8246), vec2(0.8579,0.7921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0836,0.8347,-1.0705), vec3(-0.0832,0.9217,-1.0768), vec3(0.0046,0.9224,-1.1114), vec3(-0.3649,-0.0658,-0.9287), vec2(0.9111,0.7754), vec2(0.9146,0.807), vec2(0.9512,0.7986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1817,0.9496,-0.7816), vec3(-0.2017,0.8842,-0.8568), vec3(-0.2115,0.8522,-0.6831), vec3(-0.9563,0.2923,0.0001), vec2(0.793,0.8396), vec2(0.8188,0.809), vec2(0.7583,0.7926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1732,0.8522,-0.9577), vec3(-0.1583,0.9366,-0.9762), vec3(-0.0832,0.9217,-1.0768), vec3(-0.8009,0.0102,-0.5987), vec2(0.8579,0.7921), vec2(0.8682,0.8246), vec2(0.9146,0.807), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2017,0.8842,-0.8568), vec3(-0.1679,1.0255,-0.8955), vec3(-0.1583,0.9366,-0.9762), vec3(-0.9484,0.1504,-0.2793), vec2(0.8188,0.809), vec2(0.8413,0.8647), vec2(0.8682,0.8246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0832,0.9217,-1.0768), vec3(-0.1583,0.9366,-0.9762), vec3(-0.0855,0.9973,-1.0776), vec3(-0.8035,-0.0301,-0.5946), vec2(0.9146,0.807), vec2(0.8682,0.8246), vec2(0.9175,0.8345), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1817,0.9496,-0.7816), vec3(-0.1679,1.0255,-0.8955), vec3(-0.2017,0.8842,-0.8568), vec3(-0.9687,0.2442,0.0453), vec2(0.793,0.8396), vec2(0.8413,0.8647), vec2(0.8188,0.809), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1472,0.9941,-0.9954), vec3(-0.0855,0.9973,-1.0776), vec3(-0.1583,0.9366,-0.9762), vec3(-0.7979,-0.0472,-0.6009), vec2(0.8789,0.8451), vec2(0.9175,0.8345), vec2(0.8682,0.8246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1679,1.0255,-0.8955), vec3(-0.1472,0.9941,-0.9954), vec3(-0.1583,0.9366,-0.9762), vec3(-0.9662,0.1075,-0.2343), vec2(0.8413,0.8647), vec2(0.8789,0.8451), vec2(0.8682,0.8246), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.0508,0.8701,-0.4819), 0.5431, bestT)) {
        if (triHit(ro, rd, vec3(-0.1073,1.0143,-0.7065), vec3(-0.1817,0.9496,-0.7816), vec3(-0.1294,0.9313,-0.6193), vec3(-0.783,0.5374,0.3133), vec2(0.7632,0.8768), vec2(0.793,0.8396), vec2(0.7261,0.8356), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2115,0.8522,-0.6831), vec3(-0.1294,0.9313,-0.6193), vec3(-0.1817,0.9496,-0.7816), vec3(-0.7736,0.5515,0.3119), vec2(0.7583,0.7926), vec2(0.7261,0.8356), vec2(0.793,0.8396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0688,1.0267,-0.687), vec3(-0.1073,1.0143,-0.7065), vec3(-0.1294,0.9313,-0.6193), vec3(-0.4915,0.6895,0.532), vec2(0.752,0.8905), vec2(0.7632,0.8768), vec2(0.7261,0.8356), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2115,0.8522,-0.6831), vec3(-0.3016,0.7086,-0.6574), vec3(-0.2498,0.8054,-0.5986), vec3(-0.8508,0.5159,-0.1004), vec2(0.7583,0.7926), vec2(0.7549,0.7261), vec2(0.7285,0.7654), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1294,0.9313,-0.6193), vec3(-0.067,0.9514,-0.5948), vec3(-0.0688,1.0267,-0.687), vec3(-0.4464,0.6887,0.5713), vec2(0.7261,0.8356), vec2(0.708,0.8591), vec2(0.752,0.8905), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2115,0.8522,-0.6831), vec3(-0.2498,0.8054,-0.5986), vec3(-0.1294,0.9313,-0.6193), vec3(-0.7163,0.6952,0.0599), vec2(0.7583,0.7926), vec2(0.7285,0.7654), vec2(0.7261,0.8356), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0074,0.9571,-0.5782), vec3(0.0816,0.9499,-0.5955), vec3(0.0078,1.0353,-0.67), vec3(0.2199,0.7423,0.633), vec2(0.689,0.8833), vec2(0.708,0.8591), vec2(0.7329,0.9139), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0074,0.9571,-0.5782), vec3(0.0078,1.0353,-0.67), vec3(-0.067,0.9514,-0.5948), vec3(-0.1988,0.7465,0.6349), vec2(0.689,0.8833), vec2(0.7329,0.9139), vec2(0.708,0.8591), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2615,0.8003,-0.601), vec3(0.1434,0.9286,-0.6207), vec3(0.1806,0.8686,-0.5424), vec3(0.7088,0.6808,0.1847), vec2(0.7285,0.7654), vec2(0.7261,0.8356), vec2(0.6973,0.8024), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1434,0.9286,-0.6207), vec3(0.0816,0.9499,-0.5955), vec3(0.1806,0.8686,-0.5424), vec3(0.4412,0.8012,0.4043), vec2(0.7261,0.8356), vec2(0.708,0.8591), vec2(0.6973,0.8024), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1671,0.872,-0.5407), vec3(-0.1294,0.9313,-0.6193), vec3(-0.2498,0.8054,-0.5986), vec3(-0.6932,0.6948,0.1915), vec2(0.6973,0.8024), vec2(0.7261,0.8356), vec2(0.7285,0.7654), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1294,0.9313,-0.6193), vec3(-0.1671,0.872,-0.5407), vec3(-0.067,0.9514,-0.5948), vec3(-0.4213,0.8097,0.4085), vec2(0.7261,0.8356), vec2(0.6973,0.8024), vec2(0.708,0.8591), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.3016,0.7086,-0.6574), vec3(-0.2982,0.7499,-0.4902), vec3(-0.2498,0.8054,-0.5986), vec3(-0.8467,0.5203,-0.1112), vec2(0.7549,0.7261), vec2(0.6914,0.731), vec2(0.7285,0.7654), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0816,0.9499,-0.5955), vec3(0.0074,0.9571,-0.5782), vec3(0.0984,0.9007,-0.5015), vec3(0.1864,0.8838,0.4291), vec2(0.708,0.8591), vec2(0.689,0.8833), vec2(0.6719,0.8322), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.067,0.9514,-0.5948), vec3(-0.0839,0.9025,-0.5006), vec3(0.0074,0.9571,-0.5782), vec3(-0.1644,0.8873,0.4309), vec2(0.708,0.8591), vec2(0.6719,0.8322), vec2(0.689,0.8833), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0984,0.9007,-0.5015), vec3(0.1806,0.8686,-0.5424), vec3(0.0816,0.9499,-0.5955), vec3(0.4834,0.8082,0.3363), vec2(0.6719,0.8322), vec2(0.6973,0.8024), vec2(0.708,0.8591), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0839,0.9025,-0.5006), vec3(-0.067,0.9514,-0.5948), vec3(-0.1671,0.872,-0.5407), vec3(-0.4641,0.8176,0.3408), vec2(0.6719,0.8322), vec2(0.708,0.8591), vec2(0.6973,0.8024), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2498,0.8054,-0.5986), vec3(-0.2982,0.7499,-0.4902), vec3(-0.1671,0.872,-0.5407), vec3(-0.6609,0.7454,0.0871), vec2(0.7285,0.7654), vec2(0.6914,0.731), vec2(0.6973,0.8024), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0074,0.9064,-0.4804), vec3(0.0984,0.9007,-0.5015), vec3(0.0074,0.9571,-0.5782), vec3(0.1607,0.8764,0.454), vec2(0.6499,0.8623), vec2(0.6719,0.8322), vec2(0.689,0.8833), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0074,0.9571,-0.5782), vec3(-0.0839,0.9025,-0.5006), vec3(0.0074,0.9064,-0.4804), vec3(-0.1387,0.8794,0.4555), vec2(0.689,0.8833), vec2(0.6719,0.8322), vec2(0.6499,0.8623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.229,0.815,-0.436), vec3(0.1806,0.8686,-0.5424), vec3(0.0984,0.9007,-0.5015), vec3(0.4513,0.8625,0.2289), vec2(0.6626,0.7659), vec2(0.6973,0.8024), vec2(0.6719,0.8322), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0839,0.9025,-0.5006), vec3(-0.1671,0.872,-0.5407), vec3(-0.2155,0.8195,-0.4339), vec3(-0.4318,0.8714,0.2329), vec2(0.6719,0.8322), vec2(0.6973,0.8024), vec2(0.6626,0.7659), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.229,0.815,-0.436), vec3(0.3097,0.7438,-0.4931), vec3(0.1806,0.8686,-0.5424), vec3(0.6825,0.7287,0.0564), vec2(0.6626,0.7659), vec2(0.6914,0.731), vec2(0.6973,0.8024), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2155,0.8195,-0.4339), vec3(-0.1671,0.872,-0.5407), vec3(-0.2982,0.7499,-0.4902), vec3(-0.6673,0.7421,0.0626), vec2(0.6626,0.7659), vec2(0.6973,0.8024), vec2(0.6914,0.731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0074,0.9064,-0.4804), vec3(0.1301,0.8596,-0.3827), vec3(0.0984,0.9007,-0.5015), vec3(0.1279,0.9474,0.2934), vec2(0.6499,0.8623), vec2(0.6309,0.8002), vec2(0.6719,0.8322), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0839,0.9025,-0.5006), vec3(-0.1153,0.8621,-0.3815), vec3(0.0074,0.9064,-0.4804), vec3(-0.1061,0.9497,0.2947), vec2(0.6719,0.8322), vec2(0.6309,0.8002), vec2(0.6499,0.8623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2982,0.7499,-0.4902), vec3(-0.3447,0.7258,-0.4), vec3(-0.2155,0.8195,-0.4339), vec3(-0.6012,0.7931,-0.0978), vec2(0.6914,0.731), vec2(0.6636,0.7075), vec2(0.6626,0.7659), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1301,0.8596,-0.3827), vec3(0.229,0.815,-0.436), vec3(0.0984,0.9007,-0.5015), vec3(0.4798,0.8608,0.1697), vec2(0.6309,0.8002), vec2(0.6626,0.7659), vec2(0.6719,0.8322), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0839,0.9025,-0.5006), vec3(-0.2155,0.8195,-0.4339), vec3(-0.1153,0.8621,-0.3815), vec3(-0.4608,0.8702,0.1742), vec2(0.6719,0.8322), vec2(0.6626,0.7659), vec2(0.6309,0.8002), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0074,0.9064,-0.4804), vec3(0.0075,0.8653,-0.3644), vec3(0.1301,0.8596,-0.3827), vec3(0.0927,0.9383,0.3332), vec2(0.6499,0.8623), vec2(0.605,0.8419), vec2(0.6309,0.8002), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1153,0.8621,-0.3815), vec3(0.0075,0.8653,-0.3644), vec3(0.0074,0.9064,-0.4804), vec3(-0.0709,0.9399,0.3339), vec2(0.6309,0.8002), vec2(0.605,0.8419), vec2(0.6499,0.8623), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2503,0.8017,-0.316), vec3(-0.2155,0.8195,-0.4339), vec3(-0.3447,0.7258,-0.4), vec3(-0.5957,0.8013,-0.0545), vec2(0.625,0.74), vec2(0.6626,0.7659), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.229,0.815,-0.436), vec3(0.1301,0.8596,-0.3827), vec3(0.2645,0.7965,-0.3185), vec3(0.4185,0.9081,0.0165), vec2(0.6626,0.7659), vec2(0.6309,0.8002), vec2(0.625,0.74), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2155,0.8195,-0.4339), vec3(-0.2503,0.8017,-0.316), vec3(-0.1153,0.8621,-0.3815), vec3(-0.4,0.9163,0.0205), vec2(0.6626,0.7659), vec2(0.625,0.74), vec2(0.6309,0.8002), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0075,0.8653,-0.3644), vec3(0.1663,0.8177,-0.2173), vec3(0.1301,0.8596,-0.3827), vec3(0.0787,0.9703,0.2288), vec2(0.605,0.8419), vec2(0.5781,0.7605), vec2(0.6309,0.8002), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1153,0.8621,-0.3815), vec3(-0.1501,0.8228,-0.2135), vec3(0.0075,0.8653,-0.3644), vec3(-0.0555,0.9747,0.2163), vec2(0.6309,0.8002), vec2(0.5781,0.7605), vec2(0.605,0.8419), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1663,0.8177,-0.2173), vec3(0.2645,0.7965,-0.3185), vec3(0.1301,0.8596,-0.3827), vec3(0.3582,0.9207,0.1551), vec2(0.5781,0.7605), vec2(0.625,0.74), vec2(0.6309,0.8002), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1501,0.8228,-0.2135), vec3(-0.1153,0.8621,-0.3815), vec3(-0.2503,0.8017,-0.316), vec3(-0.3445,0.9275,0.1454), vec2(0.5781,0.7605), vec2(0.6309,0.8002), vec2(0.625,0.74), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0075,0.8653,-0.3644), vec3(0.008,0.8263,-0.192), vec3(0.1663,0.8177,-0.2173), vec3(0.088,0.9717,0.2192), vec2(0.605,0.8419), vec2(0.541,0.8092), vec2(0.5781,0.7605), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1501,0.8228,-0.2135), vec3(0.008,0.8263,-0.192), vec3(0.0075,0.8653,-0.3644), vec3(-0.0517,0.9741,0.2201), vec2(0.5781,0.7605), vec2(0.541,0.8092), vec2(0.605,0.8419), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.257,0.7859,-0.2302), vec3(-0.1501,0.8228,-0.2135), vec3(-0.2503,0.8017,-0.316), vec3(-0.3433,0.9281,0.1441), vec2(0.5986,0.7261), vec2(0.5781,0.7605), vec2(0.625,0.74), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1501,0.8228,-0.2135), vec3(-0.1553,0.7472,-0.0159), vec3(0.008,0.8263,-0.192), vec3(-0.0691,0.9323,0.355), vec2(0.5781,0.7605), vec2(0.5176,0.7183), vec2(0.541,0.8092), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.074,1.0365,-0.8116), 0.4178, bestT)) {
        if (triHit(ro, rd, vec3(0.1689,0.9333,-0.9778), vec3(0.0964,0.9955,-1.0785), vec3(0.1588,0.991,-0.9969), vec3(0.7911,-0.0631,-0.6084), vec2(0.8682,0.8246), vec2(0.9175,0.8345), vec2(0.8789,0.8451), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0926,0.9199,-1.0777), vec3(0.1689,0.9333,-0.9778), vec3(0.1823,0.8486,-0.9594), vec3(0.7952,-0.0057,-0.6063), vec2(0.9146,0.807), vec2(0.8682,0.8246), vec2(0.8579,0.7921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1422,1.0619,-1.0333), vec3(0.1604,1.101,-0.9777), vec3(0.1588,0.991,-0.9969), vec3(0.9392,0.0456,-0.3402), vec2(0.8975,0.8658), vec2(0.8779,0.8866), vec2(0.8789,0.8451), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1689,0.9333,-0.9778), vec3(0.1588,0.991,-0.9969), vec3(0.1811,1.022,-0.8972), vec3(0.9658,0.0883,-0.2437), vec2(0.8682,0.8246), vec2(0.8789,0.8451), vec2(0.8413,0.8647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1811,1.022,-0.8972), vec3(0.1588,0.991,-0.9969), vec3(0.1604,1.101,-0.9777), vec3(0.9738,0.0252,-0.2258), vec2(0.8413,0.8647), vec2(0.8789,0.8451), vec2(0.8779,0.8866), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1604,1.101,-0.9777), vec3(0.1563,1.1393,-0.9339), vec3(0.1811,1.022,-0.8972), vec3(0.9801,0.1857,-0.0701), vec2(0.8779,0.8866), vec2(0.8638,0.9044), vec2(0.8413,0.8647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1823,0.8486,-0.9594), vec3(0.1689,0.9333,-0.9778), vec3(0.2125,0.8801,-0.8587), vec3(0.9473,0.0828,-0.3096), vec2(0.8579,0.7921), vec2(0.8682,0.8246), vec2(0.8188,0.809), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.211,0.772,-0.9182), vec3(0.1823,0.8486,-0.9594), vec3(0.2125,0.8801,-0.8587), vec3(0.9282,0.1696,-0.331), vec2(0.8408,0.7628), vec2(0.8579,0.7921), vec2(0.8188,0.809), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1689,0.9333,-0.9778), vec3(0.1811,1.022,-0.8972), vec3(0.2125,0.8801,-0.8587), vec3(0.9485,0.1313,-0.2883), vec2(0.8682,0.8246), vec2(0.8413,0.8647), vec2(0.8188,0.809), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,1.1393,-0.9339), vec3(0.1314,1.1786,-0.8977), vec3(0.1572,1.0796,-0.8368), vec3(0.9031,0.3696,0.2187), vec2(0.8638,0.9044), vec2(0.8535,0.9227), vec2(0.8232,0.8921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1572,1.0796,-0.8368), vec3(0.1811,1.022,-0.8972), vec3(0.1563,1.1393,-0.9339), vec3(0.9581,0.2479,0.1433), vec2(0.8232,0.8921), vec2(0.8413,0.8647), vec2(0.8638,0.9044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1423,1.0826,-0.8354), vec3(-0.1411,1.1423,-0.9325), vec3(-0.1679,1.0255,-0.8955), vec3(-0.9516,0.2668,0.1524), vec2(0.8232,0.8921), vec2(0.8638,0.9044), vec2(0.8413,0.8647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1945,0.9459,-0.7834), vec3(0.2125,0.8801,-0.8587), vec3(0.1811,1.022,-0.8972), vec3(0.9737,0.2248,0.0363), vec2(0.793,0.8396), vec2(0.8188,0.809), vec2(0.8413,0.8647), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0655,1.223,-0.8567), vec3(0.0903,1.1274,-0.7764), vec3(0.1314,1.1786,-0.8977), vec3(0.6748,0.5693,0.4697), vec2(0.8408,0.9507), vec2(0.8032,0.9231), vec2(0.8535,0.9227), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0479,1.2241,-0.8561), vec3(-0.1151,1.1811,-0.8965), vec3(-0.0738,1.129,-0.7757), vec3(-0.6589,0.5824,0.476), vec2(0.8408,0.9507), vec2(0.8535,0.9227), vec2(0.8032,0.9231), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1811,1.022,-0.8972), vec3(0.1572,1.0796,-0.8368), vec3(0.1945,0.9459,-0.7834), vec3(0.9495,0.3005,0.0898), vec2(0.8413,0.8647), vec2(0.8232,0.8921), vec2(0.793,0.8396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1423,1.0826,-0.8354), vec3(-0.1679,1.0255,-0.8955), vec3(-0.1817,0.9496,-0.7816), vec3(-0.9425,0.3194,0.0986), vec2(0.8232,0.8921), vec2(0.8413,0.8647), vec2(0.793,0.8396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1572,1.0796,-0.8368), vec3(0.1314,1.1786,-0.8977), vec3(0.0903,1.1274,-0.7764), vec3(0.7516,0.4762,0.4565), vec2(0.8232,0.8921), vec2(0.8535,0.9227), vec2(0.8032,0.9231), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1423,1.0826,-0.8354), vec3(-0.0738,1.129,-0.7757), vec3(-0.1151,1.1811,-0.8965), vec3(-0.7374,0.4913,0.4636), vec2(0.8232,0.8921), vec2(0.8032,0.9231), vec2(0.8535,0.9227), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0655,1.223,-0.8567), vec3(0.0089,1.2317,-0.8504), vec3(0.0903,1.1274,-0.7764), vec3(0.182,0.6596,0.7292), vec2(0.8408,0.9507), vec2(0.8354,0.9704), vec2(0.8032,0.9231), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0479,1.2241,-0.8561), vec3(-0.0738,1.129,-0.7757), vec3(0.0089,1.2317,-0.8504), vec3(-0.1618,0.6629,0.731), vec2(0.8408,0.9507), vec2(0.8032,0.9231), vec2(0.8354,0.9704), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0083,1.1286,-0.7569), vec3(0.0903,1.1274,-0.7764), vec3(0.0089,1.2317,-0.8504), vec3(0.1837,0.6602,0.7282), vec2(0.7847,0.9484), vec2(0.8032,0.9231), vec2(0.8354,0.9704), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0083,1.1286,-0.7569), vec3(0.0089,1.2317,-0.8504), vec3(-0.0738,1.129,-0.7757), vec3(-0.1637,0.6637,0.7299), vec2(0.7847,0.9484), vec2(0.8354,0.9704), vec2(0.8032,0.9231), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1945,0.9459,-0.7834), vec3(0.1572,1.0796,-0.8368), vec3(0.1221,1.012,-0.7076), vec3(0.8114,0.3974,0.4285), vec2(0.793,0.8396), vec2(0.8232,0.8921), vec2(0.7632,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2125,0.8801,-0.8587), vec3(0.1945,0.9459,-0.7834), vec3(0.2233,0.8479,-0.6852), vec3(0.9618,0.2734,-0.009), vec2(0.8188,0.809), vec2(0.793,0.8396), vec2(0.7583,0.7926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1817,0.9496,-0.7816), vec3(-0.1073,1.0143,-0.7065), vec3(-0.1423,1.0826,-0.8354), vec3(-0.7992,0.4135,0.4362), vec2(0.793,0.8396), vec2(0.7632,0.8768), vec2(0.8232,0.8921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0903,1.1274,-0.7764), vec3(0.1221,1.012,-0.7076), vec3(0.1572,1.0796,-0.8368), vec3(0.7514,0.4784,0.4546), vec2(0.8032,0.9231), vec2(0.7632,0.8768), vec2(0.8232,0.8921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0738,1.129,-0.7757), vec3(-0.1423,1.0826,-0.8354), vec3(-0.1073,1.0143,-0.7065), vec3(-0.7371,0.4934,0.4617), vec2(0.8032,0.9231), vec2(0.8232,0.8921), vec2(0.7632,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0903,1.1274,-0.7764), vec3(0.0083,1.1286,-0.7569), vec3(0.084,1.0252,-0.6877), vec3(0.1879,0.6372,0.7474), vec2(0.8032,0.9231), vec2(0.7847,0.9484), vec2(0.752,0.8905), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0738,1.129,-0.7757), vec3(-0.0688,1.0267,-0.687), vec3(0.0083,1.1286,-0.7569), vec3(-0.1682,0.6408,0.7491), vec2(0.8032,0.9231), vec2(0.752,0.8905), vec2(0.7847,0.9484), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1221,1.012,-0.7076), vec3(0.0903,1.1274,-0.7764), vec3(0.084,1.0252,-0.6877), vec3(0.529,0.5375,0.6567), vec2(0.7632,0.8768), vec2(0.8032,0.9231), vec2(0.752,0.8905), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0688,1.0267,-0.687), vec3(-0.0738,1.129,-0.7757), vec3(-0.1073,1.0143,-0.7065), vec3(-0.5116,0.5481,0.6617), vec2(0.752,0.8905), vec2(0.8032,0.9231), vec2(0.7632,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.0353,-0.67), vec3(0.084,1.0252,-0.6877), vec3(0.0083,1.1286,-0.7569), vec3(0.252,0.6585,0.7092), vec2(0.7329,0.9139), vec2(0.752,0.8905), vec2(0.7847,0.9484), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.0353,-0.67), vec3(0.0083,1.1286,-0.7569), vec3(-0.0688,1.0267,-0.687), vec3(-0.232,0.6633,0.7115), vec2(0.7329,0.9139), vec2(0.7847,0.9484), vec2(0.752,0.8905), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1221,1.012,-0.7076), vec3(0.1434,0.9286,-0.6207), vec3(0.1945,0.9459,-0.7834), vec3(0.7965,0.5217,0.3058), vec2(0.7632,0.8768), vec2(0.7261,0.8356), vec2(0.793,0.8396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2233,0.8479,-0.6852), vec3(0.1945,0.9459,-0.7834), vec3(0.1434,0.9286,-0.6207), vec3(0.7873,0.5361,0.3044), vec2(0.7583,0.7926), vec2(0.793,0.8396), vec2(0.7261,0.8356), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.084,1.0252,-0.6877), vec3(0.1434,0.9286,-0.6207), vec3(0.1221,1.012,-0.7076), vec3(0.5105,0.6794,0.5271), vec2(0.752,0.8905), vec2(0.7261,0.8356), vec2(0.7632,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.084,1.0252,-0.6877), vec3(0.0078,1.0353,-0.67), vec3(0.0816,0.9499,-0.5955), vec3(0.2425,0.7483,0.6175), vec2(0.752,0.8905), vec2(0.7329,0.9139), vec2(0.708,0.8591), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0688,1.0267,-0.687), vec3(-0.067,0.9514,-0.5948), vec3(0.0078,1.0353,-0.67), vec3(-0.2216,0.753,0.6195), vec2(0.752,0.8905), vec2(0.708,0.8591), vec2(0.7329,0.9139), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1434,0.9286,-0.6207), vec3(0.2615,0.8003,-0.601), vec3(0.2233,0.8479,-0.6852), vec3(0.7306,0.6808,0.0532), vec2(0.7261,0.8356), vec2(0.7285,0.7654), vec2(0.7583,0.7926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.084,1.0252,-0.6877), vec3(0.0816,0.9499,-0.5955), vec3(0.1434,0.9286,-0.6207), vec3(0.4655,0.6795,0.5671), vec2(0.752,0.8905), vec2(0.708,0.8591), vec2(0.7261,0.8356), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.0101,1.1086,-1.183), 0.3632, bestT)) {
        if (triHit(ro, rd, vec3(0.0046,0.9224,-1.1114), vec3(0.0926,0.9199,-1.0777), vec3(0.0914,0.833,-1.0714), vec3(0.3546,-0.073,-0.9322), vec2(0.9512,0.7986), vec2(0.9146,0.807), vec2(0.9111,0.7754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0046,0.9224,-1.1114), vec3(0.047,0.9988,-1.1098), vec3(0.0926,0.9199,-1.0777), vec3(0.3476,-0.1741,-0.9213), vec2(0.9512,0.7986), vec2(0.9409,0.829), vec2(0.9146,0.807), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0046,0.9224,-1.1114), vec3(-0.0832,0.9217,-1.0768), vec3(-0.0363,0.9996,-1.1094), vec3(-0.3598,-0.1672,-0.9179), vec2(0.9512,0.7986), vec2(0.9146,0.807), vec2(0.9409,0.829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0926,0.9199,-1.0777), vec3(0.0964,0.9955,-1.0785), vec3(0.1689,0.9333,-0.9778), vec3(0.797,-0.0462,-0.6022), vec2(0.9146,0.807), vec2(0.9175,0.8345), vec2(0.8682,0.8246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0964,0.9955,-1.0785), vec3(0.0926,0.9199,-1.0777), vec3(0.047,0.9988,-1.1098), vec3(0.533,-0.0357,-0.8454), vec2(0.9175,0.8345), vec2(0.9146,0.807), vec2(0.9409,0.829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0855,0.9973,-1.0776), vec3(-0.0363,0.9996,-1.1094), vec3(-0.0832,0.9217,-1.0768), vec3(-0.542,-0.0249,-0.84), vec2(0.9175,0.8345), vec2(0.9409,0.829), vec2(0.9146,0.807), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0055,1.022,-1.1207), vec3(0.047,0.9988,-1.1098), vec3(0.0046,0.9224,-1.1114), vec3(0.203,-0.0927,-0.9748), vec2(0.959,0.832), vec2(0.9409,0.829), vec2(0.9512,0.7986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0046,0.9224,-1.1114), vec3(-0.0363,0.9996,-1.1094), vec3(0.0055,1.022,-1.1207), vec3(-0.2138,-0.0885,-0.9729), vec2(0.9512,0.7986), vec2(0.9409,0.829), vec2(0.959,0.832), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0964,0.9955,-1.0785), vec3(0.047,0.9988,-1.1098), vec3(0.1023,1.0406,-1.0872), vec3(0.5104,-0.2259,-0.8297), vec2(0.9175,0.8345), vec2(0.9409,0.829), vec2(0.9214,0.851), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0855,0.9973,-1.0776), vec3(-0.0905,1.0425,-1.0863), vec3(-0.0363,0.9996,-1.1094), vec3(-0.5231,-0.2158,-0.8245), vec2(0.9175,0.8345), vec2(0.9214,0.851), vec2(0.9409,0.829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0964,0.9955,-1.0785), vec3(0.1422,1.0619,-1.0333), vec3(0.1588,0.991,-0.9969), vec3(0.7845,-0.1276,-0.6069), vec2(0.9175,0.8345), vec2(0.8975,0.8658), vec2(0.8789,0.8451), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0055,1.022,-1.1207), vec3(0.0537,1.0335,-1.1164), vec3(0.047,0.9988,-1.1098), vec3(0.1359,-0.2094,-0.9683), vec2(0.959,0.832), vec2(0.9424,0.8424), vec2(0.9409,0.829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1472,0.9941,-0.9954), vec3(-0.1295,1.0646,-1.032), vec3(-0.0855,0.9973,-1.0776), vec3(-0.7926,-0.1119,-0.5994), vec2(0.8789,0.8451), vec2(0.8975,0.8658), vec2(0.9175,0.8345), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0363,0.9996,-1.1094), vec3(-0.0424,1.0345,-1.1159), vec3(0.0055,1.022,-1.1207), vec3(-0.1492,-0.2061,-0.9671), vec2(0.9409,0.829), vec2(0.9424,0.8424), vec2(0.959,0.832), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0537,1.0335,-1.1164), vec3(0.1023,1.0406,-1.0872), vec3(0.047,0.9988,-1.1098), vec3(0.5255,-0.2557,-0.8115), vec2(0.9424,0.8424), vec2(0.9214,0.851), vec2(0.9409,0.829), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0424,1.0345,-1.1159), vec3(-0.0363,0.9996,-1.1094), vec3(-0.0905,1.0425,-1.0863), vec3(-0.5381,-0.2445,-0.8066), vec2(0.9424,0.8424), vec2(0.9409,0.829), vec2(0.9214,0.851), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0964,0.9955,-1.0785), vec3(0.1023,1.0406,-1.0872), vec3(0.1422,1.0619,-1.0333), vec3(0.8235,-0.2083,-0.5277), vec2(0.9175,0.8345), vec2(0.9214,0.851), vec2(0.8975,0.8658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0905,1.0425,-1.0863), vec3(-0.0855,0.9973,-1.0776), vec3(-0.1295,1.0646,-1.032), vec3(-0.8325,-0.1922,-0.5196), vec2(0.9214,0.851), vec2(0.9175,0.8345), vec2(0.8975,0.8658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0055,1.022,-1.1207), vec3(0.0059,1.0688,-1.136), vec3(0.0537,1.0335,-1.1164), vec3(0.157,-0.3088,-0.9381), vec2(0.959,0.832), vec2(0.9663,0.8491), vec2(0.9424,0.8424), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0055,1.022,-1.1207), vec3(-0.0424,1.0345,-1.1159), vec3(0.0059,1.0688,-1.136), vec3(-0.1721,-0.3056,-0.9365), vec2(0.959,0.832), vec2(0.9424,0.8424), vec2(0.9663,0.8491), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1032,1.1043,-1.1002), vec3(0.1023,1.0406,-1.0872), vec3(0.0537,1.0335,-1.1164), vec3(0.5263,-0.1776,-0.8316), vec2(0.9282,0.8737), vec2(0.9214,0.851), vec2(0.9424,0.8424), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0524,1.0779,-1.1331), vec3(0.0537,1.0335,-1.1164), vec3(0.0059,1.0688,-1.136), vec3(0.1265,-0.3456,-0.9298), vec2(0.9502,0.8593), vec2(0.9424,0.8424), vec2(0.9663,0.8491), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0404,1.0788,-1.1326), vec3(0.0059,1.0688,-1.136), vec3(-0.0424,1.0345,-1.1159), vec3(-0.1422,-0.3431,-0.9285), vec2(0.9502,0.8593), vec2(0.9663,0.8491), vec2(0.9424,0.8424), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0903,1.1062,-1.0993), vec3(-0.0424,1.0345,-1.1159), vec3(-0.0905,1.0425,-1.0863), vec3(-0.5375,-0.1669,-0.8266), vec2(0.9282,0.8737), vec2(0.9424,0.8424), vec2(0.9214,0.851), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1032,1.1043,-1.1002), vec3(0.1422,1.0619,-1.0333), vec3(0.1023,1.0406,-1.0872), vec3(0.8202,-0.1258,-0.558), vec2(0.9282,0.8737), vec2(0.8975,0.8658), vec2(0.9214,0.851), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0905,1.0425,-1.0863), vec3(-0.1295,1.0646,-1.032), vec3(-0.0903,1.1062,-1.0993), vec3(-0.8279,-0.1092,-0.5501), vec2(0.9214,0.851), vec2(0.8975,0.8658), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0537,1.0335,-1.1164), vec3(0.0524,1.0779,-1.1331), vec3(0.1032,1.1043,-1.1002), vec3(0.6164,-0.2609,-0.7429), vec2(0.9424,0.8424), vec2(0.9502,0.8593), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0404,1.0788,-1.1326), vec3(-0.0424,1.0345,-1.1159), vec3(-0.0903,1.1062,-1.0993), vec3(-0.6287,-0.2486,-0.7369), vec2(0.9502,0.8593), vec2(0.9424,0.8424), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0524,1.0779,-1.1331), vec3(0.0059,1.0688,-1.136), vec3(0.0434,1.1065,-1.1548), vec3(0.1614,-0.5641,-0.8098), vec2(0.9502,0.8593), vec2(0.9663,0.8491), vec2(0.9595,0.8706), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0404,1.0788,-1.1326), vec3(-0.031,1.1072,-1.1544), vec3(0.0059,1.0688,-1.136), vec3(-0.1803,-0.5604,-0.8084), vec2(0.9502,0.8593), vec2(0.9595,0.8706), vec2(0.9663,0.8491), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0061,1.0959,-1.162), vec3(0.0434,1.1065,-1.1548), vec3(0.0059,1.0688,-1.136), vec3(0.3202,-0.658,-0.6815), vec2(0.9727,0.8625), vec2(0.9595,0.8706), vec2(0.9663,0.8491), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0061,1.0959,-1.162), vec3(0.0059,1.0688,-1.136), vec3(-0.031,1.1072,-1.1544), vec3(-0.3398,-0.6513,-0.6785), vec2(0.9727,0.8625), vec2(0.9663,0.8491), vec2(0.9595,0.8706), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0524,1.0779,-1.1331), vec3(0.0434,1.1065,-1.1548), vec3(0.1032,1.1043,-1.1002), vec3(0.6284,-0.3344,-0.7023), vec2(0.9502,0.8593), vec2(0.9595,0.8706), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.031,1.1072,-1.1544), vec3(-0.0404,1.0788,-1.1326), vec3(-0.0903,1.1062,-1.0993), vec3(-0.6416,-0.3215,-0.6964), vec2(0.9595,0.8706), vec2(0.9502,0.8593), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1032,1.1043,-1.1002), vec3(0.1183,1.1309,-1.0732), vec3(0.1422,1.0619,-1.0333), vec3(0.8671,0.0122,-0.498), vec2(0.9282,0.8737), vec2(0.918,0.8853), vec2(0.8975,0.8658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0076,1.0986,-1.2709), vec3(0.0142,1.1023,-1.2642), vec3(0.0078,1.1003,-1.2433), vec3(0.4479,-0.8926,0.0521), vec2(0.6035,0.02), vec2(0.6064,0.0181), vec2(0.6133,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.1003,-1.2433), vec3(0.0013,1.1024,-1.2642), vec3(0.0076,1.0986,-1.2709), vec3(-0.4696,-0.8811,0.0557), vec2(0.6133,0.0229), vec2(0.6064,0.0181), vec2(0.6035,0.02), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0221,1.1057,-1.2489), vec3(0.0078,1.1003,-1.2433), vec3(0.0142,1.1023,-1.2642), vec3(0.3596,-0.9329,0.0213), vec2(0.6128,0.0171), vec2(0.6133,0.0229), vec2(0.6064,0.0181), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0013,1.1024,-1.2642), vec3(0.0078,1.1003,-1.2433), vec3(-0.0064,1.106,-1.2488), vec3(-0.3792,-0.925,0.0231), vec2(0.6064,0.0181), vec2(0.6133,0.0229), vec2(0.6128,0.0171), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0142,1.1023,-1.2642), vec3(0.0076,1.0986,-1.2709), vec3(0.0161,1.1098,-1.2736), vec3(0.7039,-0.6179,-0.3502), vec2(0.6064,0.0181), vec2(0.6035,0.02), vec2(0.6035,0.0146), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0013,1.1024,-1.2642), vec3(-0.0006,1.11,-1.2736), vec3(0.0076,1.0986,-1.2709), vec3(-0.721,-0.6016,-0.3439), vec2(0.6064,0.0181), vec2(0.6035,0.0146), vec2(0.6035,0.02), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.008,1.1012,-1.1855), vec3(0.0396,1.1149,-1.1745), vec3(0.0061,1.0959,-1.162), vec3(0.4402,-0.8827,-0.1645), vec2(0.6338,0.0288), vec2(0.6416,0.0176), vec2(0.6411,0.0327), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0161,1.1098,-1.2736), vec3(0.0076,1.0986,-1.2709), vec3(0.0077,1.1039,-1.2829), vec3(0.7334,-0.6219,-0.2747), vec2(0.6035,0.0146), vec2(0.6035,0.02), vec2(0.5996,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0076,1.0986,-1.2709), vec3(-0.0006,1.11,-1.2736), vec3(0.0077,1.1039,-1.2829), vec3(-0.7493,-0.6047,-0.2702), vec2(0.6035,0.02), vec2(0.6035,0.0146), vec2(0.5996,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.008,1.1012,-1.1855), vec3(0.0061,1.0959,-1.162), vec3(-0.0233,1.1156,-1.1743), vec3(-0.475,-0.8488,-0.2322), vec2(0.6338,0.0288), vec2(0.6411,0.0327), vec2(0.6416,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.1003,-1.2433), vec3(0.0315,1.112,-1.2128), vec3(0.0079,1.1015,-1.2162), vec3(0.4016,-0.915,0.0384), vec2(0.6133,0.0229), vec2(0.627,0.0166), vec2(0.623,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.1015,-1.2162), vec3(-0.0155,1.1125,-1.2126), vec3(0.0078,1.1003,-1.2433), vec3(-0.4213,-0.906,0.0411), vec2(0.623,0.0254), vec2(0.627,0.0166), vec2(0.6133,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.1015,-1.2162), vec3(0.0315,1.112,-1.2128), vec3(0.008,1.1012,-1.1855), vec3(0.4077,-0.9131,-0.0098), vec2(0.623,0.0254), vec2(0.627,0.0166), vec2(0.6338,0.0288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.1015,-1.2162), vec3(0.008,1.1012,-1.1855), vec3(-0.0155,1.1125,-1.2126), vec3(-0.4276,-0.9039,-0.0069), vec2(0.623,0.0254), vec2(0.6338,0.0288), vec2(0.627,0.0166), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0434,1.1065,-1.1548), vec3(0.0061,1.0959,-1.162), vec3(0.0396,1.1149,-1.1745), vec3(0.3236,-0.8464,-0.423), vec2(0.6494,0.0205), vec2(0.6411,0.0327), vec2(0.6416,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0221,1.1057,-1.2489), vec3(0.0315,1.112,-1.2128), vec3(0.0078,1.1003,-1.2433), vec3(0.3735,-0.9254,0.0642), vec2(0.6128,0.0171), vec2(0.627,0.0166), vec2(0.6133,0.0229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0233,1.1156,-1.1743), vec3(0.0061,1.0959,-1.162), vec3(-0.031,1.1072,-1.1544), vec3(-0.3464,-0.8089,-0.4751), vec2(0.6416,0.0176), vec2(0.6411,0.0327), vec2(0.6494,0.0205), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.1003,-1.2433), vec3(-0.0155,1.1125,-1.2126), vec3(-0.0064,1.106,-1.2488), vec3(-0.3929,-0.9171,0.067), vec2(0.6133,0.0229), vec2(0.627,0.0166), vec2(0.6128,0.0171), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.1055,-1.2569), vec3(0.0161,1.1098,-1.2736), vec3(0.0077,1.1039,-1.2829), vec3(-0.534,0.8441,-0.0489), vec2(0.6738,0.0146), vec2(0.6675,0.0195), vec2(0.6631,0.0156), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0077,1.1039,-1.2829), vec3(-0.0006,1.11,-1.2736), vec3(0.0078,1.1055,-1.2569), vec3(0.5525,0.8319,-0.0524), vec2(0.6631,0.0156), vec2(0.6675,0.0195), vec2(0.6738,0.0146), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0142,1.1023,-1.2642), vec3(0.0234,1.1146,-1.2613), vec3(0.0221,1.1057,-1.2489), vec3(0.7959,-0.5303,-0.292), vec2(0.6064,0.0181), vec2(0.6089,0.0132), vec2(0.6128,0.0171), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0077,1.1149,-1.2612), vec3(0.0013,1.1024,-1.2642), vec3(-0.0064,1.106,-1.2488), vec3(-0.8087,-0.514,-0.2861), vec2(0.6089,0.0132), vec2(0.6064,0.0181), vec2(0.6128,0.0171), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0188,1.1111,-1.2735), vec3(0.0076,1.098,-1.2896), vec3(0.0152,1.117,-1.2768), vec3(0.771,0.1113,-0.6271), vec2(0.1805,0.4194), vec2(0.1897,0.4253), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0004,1.1171,-1.2768), vec3(0.0076,1.098,-1.2896), vec3(-0.0032,1.1113,-1.2734), vec3(-0.7726,0.1277,-0.6219), vec2(0.1788,0.4224), vec2(0.1897,0.4253), vec2(0.1805,0.4194), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0076,1.098,-1.2896), vec3(0.0188,1.1111,-1.2735), vec3(0.0079,1.1175,-1.2639), vec3(0.063,-0.7955,0.6027), vec2(0.1727,0.0288), vec2(0.1566,0.0337), vec2(0.1493,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0234,1.1146,-1.2613), vec3(0.0142,1.1023,-1.2642), vec3(0.0161,1.1098,-1.2736), vec3(0.7992,-0.5389,-0.2663), vec2(0.6089,0.0132), vec2(0.6064,0.0181), vec2(0.6035,0.0146), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.1175,-1.2639), vec3(-0.0032,1.1113,-1.2734), vec3(0.0076,1.098,-1.2896), vec3(-0.0756,-0.794,0.6031), vec2(0.1493,0.0254), vec2(0.1566,0.0337), vec2(0.1727,0.0288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0006,1.11,-1.2736), vec3(0.0013,1.1024,-1.2642), vec3(-0.0077,1.1149,-1.2612), vec3(-0.8118,-0.5223,-0.2612), vec2(0.6035,0.0146), vec2(0.6064,0.0181), vec2(0.6089,0.0132), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0396,1.1149,-1.1745), vec3(0.008,1.1012,-1.1855), vec3(0.0315,1.112,-1.2128), vec3(0.4025,-0.9153,-0.0151), vec2(0.6416,0.0176), vec2(0.6338,0.0288), vec2(0.627,0.0166), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0233,1.1156,-1.1743), vec3(-0.0155,1.1125,-1.2126), vec3(0.008,1.1012,-1.1855), vec3(-0.4227,-0.9062,-0.0121), vec2(0.6416,0.0176), vec2(0.627,0.0166), vec2(0.6338,0.0288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.1055,-1.2569), vec3(0.0234,1.1146,-1.2613), vec3(0.0161,1.1098,-1.2736), vec3(-0.5061,0.8619,-0.0303), vec2(0.6738,0.0146), vec2(0.6729,0.0225), vec2(0.6675,0.0195), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0006,1.11,-1.2736), vec3(-0.0077,1.1149,-1.2612), vec3(0.0078,1.1055,-1.2569), vec3(0.525,0.8505,-0.0336), vec2(0.6675,0.0195), vec2(0.6729,0.0225), vec2(0.6738,0.0146), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0076,1.098,-1.2896), vec3(0.0079,1.118,-1.2779), vec3(0.0152,1.117,-1.2768), vec3(0.1884,0.4949,-0.8483), vec2(0.1897,0.4253), vec2(0.1787,0.4258), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0004,1.1171,-1.2768), vec3(0.0079,1.118,-1.2779), vec3(0.0076,1.098,-1.2896), vec3(-0.1836,0.499,-0.8469), vec2(0.1788,0.4224), vec2(0.1787,0.4258), vec2(0.1897,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.1055,-1.2569), vec3(0.0079,1.1072,-1.2197), vec3(0.0417,1.1234,-1.2166), vec3(-0.4297,0.9021,-0.0388), vec2(0.6738,0.0146), vec2(0.6895,0.0127), vec2(0.6929,0.0283), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.1072,-1.2197), vec3(0.0081,1.106,-1.1773), vec3(0.0417,1.1234,-1.2166), vec3(-0.4347,0.9002,0.0265), vec2(0.6895,0.0127), vec2(0.7075,0.0103), vec2(0.6929,0.0283), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0255,1.1241,-1.2164), vec3(0.0079,1.1072,-1.2197), vec3(0.0078,1.1055,-1.2569), vec3(0.4487,0.8927,-0.042), vec2(0.6929,0.0283), vec2(0.6895,0.0127), vec2(0.6738,0.0146), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.1072,-1.2197), vec3(-0.0255,1.1241,-1.2164), vec3(0.0081,1.106,-1.1773), vec3(0.4542,0.8906,0.0235), vec2(0.6895,0.0127), vec2(0.6929,0.0283), vec2(0.7075,0.0103), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0081,1.106,-1.1773), vec3(0.0082,1.1037,-1.128), vec3(0.0652,1.1284,-1.1467), vec3(-0.3857,0.9215,0.0444), vec2(0.7075,0.0103), vec2(0.728,0.0068), vec2(0.7241,0.0342), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0652,1.1284,-1.1467), vec3(0.1032,1.1043,-1.1002), vec3(0.0434,1.1065,-1.1548), vec3(0.621,-0.3619,-0.6953), vec2(0.9521,0.8813), vec2(0.9282,0.8737), vec2(0.9595,0.8706), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0081,1.106,-1.1773), vec3(-0.0483,1.1297,-1.1463), vec3(0.0082,1.1037,-1.128), vec3(0.406,0.9129,0.0416), vec2(0.7075,0.0103), vec2(0.7241,0.0342), vec2(0.728,0.0068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0315,1.112,-1.2128), vec3(0.0221,1.1057,-1.2489), vec3(0.0417,1.1234,-1.2166), vec3(0.7313,-0.6782,-0.0724), vec2(0.627,0.0166), vec2(0.6128,0.0171), vec2(0.627,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0255,1.1241,-1.2164), vec3(-0.0064,1.106,-1.2488), vec3(-0.0155,1.1125,-1.2126), vec3(-0.7462,-0.6623,-0.0672), vec2(0.627,0.0107), vec2(0.6128,0.0171), vec2(0.627,0.0166), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.031,1.1072,-1.1544), vec3(-0.0903,1.1062,-1.0993), vec3(-0.0483,1.1297,-1.1463), vec3(-0.6565,-0.2517,-0.711), vec2(0.9595,0.8706), vec2(0.9282,0.8737), vec2(0.9521,0.8813), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.1055,-1.2569), vec3(0.0417,1.1234,-1.2166), vec3(0.0234,1.1146,-1.2613), vec3(-0.4935,0.8692,0.0296), vec2(0.6738,0.0146), vec2(0.6929,0.0283), vec2(0.6729,0.0225), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0249,1.1156,-1.2621), vec3(0.0188,1.1111,-1.2735), vec3(0.0152,1.117,-1.2768), vec3(0.8267,0.2024,-0.525), vec2(0.1758,0.4146), vec2(0.1805,0.4194), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0221,1.1057,-1.2489), vec3(0.0234,1.1146,-1.2613), vec3(0.0417,1.1234,-1.2166), vec3(0.842,-0.4782,-0.2497), vec2(0.6128,0.0171), vec2(0.6089,0.0132), vec2(0.627,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.1175,-1.2639), vec3(0.0188,1.1111,-1.2735), vec3(0.0249,1.1156,-1.2621), vec3(-0.1428,-0.8904,0.4321), vec2(0.1493,0.0254), vec2(0.1566,0.0337), vec2(0.1471,0.0366), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0032,1.1113,-1.2734), vec3(-0.0092,1.116,-1.262), vec3(0.0004,1.1171,-1.2768), vec3(-0.8253,0.2192,-0.5204), vec2(0.1805,0.4194), vec2(0.1758,0.4146), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.1055,-1.2569), vec3(-0.0077,1.1149,-1.2612), vec3(-0.0255,1.1241,-1.2164), vec3(0.5129,0.858,0.0265), vec2(0.6738,0.0146), vec2(0.6729,0.0225), vec2(0.6929,0.0283), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0092,1.116,-1.262), vec3(-0.0032,1.1113,-1.2734), vec3(0.0079,1.1175,-1.2639), vec3(0.1259,-0.8928,0.4325), vec2(0.1471,0.0366), vec2(0.1566,0.0337), vec2(0.1493,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0064,1.106,-1.2488), vec3(-0.0255,1.1241,-1.2164), vec3(-0.0077,1.1149,-1.2612), vec3(-0.8535,-0.4608,-0.2432), vec2(0.6128,0.0171), vec2(0.627,0.0107), vec2(0.6089,0.0132), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0396,1.1149,-1.1745), vec3(0.0545,1.1273,-1.1727), vec3(0.0434,1.1065,-1.1548), vec3(0.6128,-0.6779,-0.4062), vec2(0.6416,0.0176), vec2(0.644,0.0107), vec2(0.6494,0.0205), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0315,1.112,-1.2128), vec3(0.0417,1.1234,-1.2166), vec3(0.0396,1.1149,-1.1745), vec3(0.7245,-0.6818,-0.1013), vec2(0.627,0.0166), vec2(0.627,0.0107), vec2(0.6416,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0233,1.1156,-1.1743), vec3(-0.031,1.1072,-1.1544), vec3(-0.0379,1.1283,-1.1724), vec3(-0.6053,-0.6218,-0.497), vec2(0.6416,0.0176), vec2(0.6494,0.0205), vec2(0.644,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0255,1.1241,-1.2164), vec3(-0.0155,1.1125,-1.2126), vec3(-0.0233,1.1156,-1.1743), vec3(-0.7397,-0.666,-0.096), vec2(0.627,0.0107), vec2(0.627,0.0166), vec2(0.6416,0.0176), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0545,1.1273,-1.1727), vec3(0.0417,1.1234,-1.2166), vec3(0.0081,1.106,-1.1773), vec3(-0.4196,0.9067,0.0423), vec2(0.7124,0.0312), vec2(0.6929,0.0283), vec2(0.7075,0.0103), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0379,1.1283,-1.1724), vec3(0.0081,1.106,-1.1773), vec3(-0.0255,1.1241,-1.2164), vec3(0.4396,0.8973,0.0392), vec2(0.7124,0.0312), vec2(0.7075,0.0103), vec2(0.6929,0.0283), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0086,1.1276,-1.0928), vec3(0.0652,1.1284,-1.1467), vec3(0.0082,1.1037,-1.128), vec3(-0.4782,0.7288,-0.4901), vec2(0.7461,0.0093), vec2(0.7241,0.0342), vec2(0.728,0.0068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0249,1.1156,-1.2621), vec3(0.0152,1.117,-1.2768), vec3(0.0221,1.128,-1.2623), vec3(0.8294,0.1795,-0.529), vec2(0.1758,0.4146), vec2(0.1788,0.4224), vec2(0.1709,0.4185), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0082,1.1037,-1.128), vec3(-0.0483,1.1297,-1.1463), vec3(0.0086,1.1276,-1.0928), vec3(0.4905,0.7186,-0.493), vec2(0.728,0.0068), vec2(0.7241,0.0342), vec2(0.7461,0.0093), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0092,1.116,-1.262), vec3(-0.0061,1.1283,-1.2622), vec3(0.0004,1.1171,-1.2768), vec3(-0.8283,0.1985,-0.5239), vec2(0.1758,0.4146), vec2(0.1709,0.4185), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0652,1.1284,-1.1467), vec3(0.0545,1.1273,-1.1727), vec3(0.0081,1.106,-1.1773), vec3(-0.4238,0.8957,0.1345), vec2(0.7241,0.0342), vec2(0.7124,0.0312), vec2(0.7075,0.0103), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0545,1.1273,-1.1727), vec3(0.0652,1.1284,-1.1467), vec3(0.0434,1.1065,-1.1548), vec3(0.7305,-0.626,-0.2728), vec2(0.644,0.0107), vec2(0.6543,0.0088), vec2(0.6494,0.0205), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0379,1.1283,-1.1724), vec3(-0.0483,1.1297,-1.1463), vec3(0.0081,1.106,-1.1773), vec3(0.4442,0.8862,0.1315), vec2(0.7124,0.0312), vec2(0.7241,0.0342), vec2(0.7075,0.0103), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.031,1.1072,-1.1544), vec3(-0.0483,1.1297,-1.1463), vec3(-0.0379,1.1283,-1.1724), vec3(-0.8041,-0.5155,-0.2962), vec2(0.6494,0.0205), vec2(0.6543,0.0088), vec2(0.644,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0396,1.1149,-1.1745), vec3(0.0417,1.1234,-1.2166), vec3(0.0545,1.1273,-1.1727), vec3(0.6429,-0.7564,-0.1204), vec2(0.6416,0.0176), vec2(0.627,0.0107), vec2(0.644,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0233,1.1156,-1.1743), vec3(-0.0379,1.1283,-1.1724), vec3(-0.0255,1.1241,-1.2164), vec3(-0.6597,-0.7426,-0.1157), vec2(0.6416,0.0176), vec2(0.644,0.0107), vec2(0.627,0.0107), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0249,1.1156,-1.2621), vec3(0.0221,1.128,-1.2623), vec3(0.0435,1.1256,-1.2185), vec3(0.8853,0.194,-0.4225), vec2(0.1758,0.4146), vec2(0.1709,0.4185), vec2(0.1602,0.3975), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.118,-1.2779), vec3(0.0081,1.1342,-1.2631), vec3(0.0152,1.117,-1.2768), vec3(0.1934,0.6594,-0.7265), vec2(0.1787,0.4258), vec2(0.1682,0.4253), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.118,-1.2779), vec3(0.0004,1.1171,-1.2768), vec3(0.0081,1.1342,-1.2631), vec3(-0.1843,0.6632,-0.7254), vec2(0.1787,0.4258), vec2(0.1788,0.4224), vec2(0.1682,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0061,1.1283,-1.2622), vec3(-0.0092,1.116,-1.262), vec3(-0.0272,1.1264,-1.2183), vec3(-0.8835,0.2144,-0.4164), vec2(0.1709,0.4185), vec2(0.1758,0.4146), vec2(0.1602,0.3975), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.1175,-1.2639), vec3(0.0249,1.1156,-1.2621), vec3(0.0082,1.1384,-1.2277), vec3(-0.1455,-0.8564,0.4954), vec2(0.1493,0.0254), vec2(0.1471,0.0366), vec2(0.1191,0.02), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0079,1.1175,-1.2639), vec3(0.0082,1.1384,-1.2277), vec3(-0.0092,1.116,-1.262), vec3(0.1298,-0.8595,0.4945), vec2(0.1493,0.0254), vec2(0.1191,0.02), vec2(0.1471,0.0366), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0221,1.128,-1.2623), vec3(0.0152,1.117,-1.2768), vec3(0.0081,1.1342,-1.2631), vec3(0.3323,0.6686,-0.6653), vec2(0.1709,0.4185), vec2(0.1788,0.4224), vec2(0.1682,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0061,1.1283,-1.2622), vec3(0.0081,1.1342,-1.2631), vec3(0.0004,1.1171,-1.2768), vec3(-0.3228,0.6753,-0.6632), vec2(0.1709,0.4185), vec2(0.1682,0.4253), vec2(0.1788,0.4224), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0249,1.1156,-1.2621), vec3(0.0435,1.1256,-1.2185), vec3(0.0082,1.1384,-1.2277), vec3(-0.399,-0.8419,0.3633), vec2(0.1471,0.0366), vec2(0.1133,0.0479), vec2(0.1191,0.02), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0082,1.1384,-1.2277), vec3(-0.0272,1.1264,-1.2183), vec3(-0.0092,1.116,-1.262), vec3(0.3828,-0.8506,0.3604), vec2(0.1191,0.02), vec2(0.1133,0.0479), vec2(0.1471,0.0366), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1032,1.1043,-1.1002), vec3(0.0652,1.1284,-1.1467), vec3(0.0949,1.1546,-1.1048), vec3(0.7908,0.0734,-0.6077), vec2(0.9282,0.8737), vec2(0.9521,0.8813), vec2(0.9331,0.8916), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0949,1.1546,-1.1048), vec3(0.1183,1.1309,-1.0732), vec3(0.1032,1.1043,-1.1002), vec3(0.8309,0.0853,-0.5498), vec2(0.9331,0.8916), vec2(0.918,0.8853), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0903,1.1062,-1.0993), vec3(-0.0811,1.1563,-1.104), vec3(-0.0483,1.1297,-1.1463), vec3(-0.7634,0.0793,-0.6411), vec2(0.9282,0.8737), vec2(0.9331,0.8916), vec2(0.9521,0.8813), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0435,1.1256,-1.2185), vec3(0.0221,1.128,-1.2623), vec3(0.0358,1.1459,-1.2295), vec3(0.8952,0.1095,-0.4319), vec2(0.1602,0.3975), vec2(0.1709,0.4185), vec2(0.1553,0.4082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0086,1.1276,-1.0928), vec3(0.0086,1.1437,-1.1443), vec3(0.0652,1.1284,-1.1467), vec3(-0.2611,-0.921,-0.289), vec2(0.0181,0.0254), vec2(0.0575,0.0215), vec2(0.0604,0.0635), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0586,1.1296,-1.1729), vec3(0.0085,1.1451,-1.1731), vec3(0.0435,1.1256,-1.2185), vec3(-0.2912,-0.9397,0.1791), vec2(0.0795,0.0581), vec2(0.0786,0.0205), vec2(0.1133,0.0479), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0483,1.1297,-1.1463), vec3(0.0086,1.1437,-1.1443), vec3(0.0086,1.1276,-1.0928), vec3(0.2391,-0.9264,-0.2907), vec2(0.0604,0.0635), vec2(0.0575,0.0215), vec2(0.0181,0.0254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0191,1.1465,-1.2293), vec3(-0.0061,1.1283,-1.2622), vec3(-0.0272,1.1264,-1.2183), vec3(-0.8955,0.1294,-0.4259), vec2(0.1553,0.4082), vec2(0.1709,0.4185), vec2(0.1602,0.3975), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0652,1.1284,-1.1467), vec3(0.0086,1.1437,-1.1443), vec3(0.0586,1.1296,-1.1729), vec3(-0.2596,-0.9655,0.0212), vec2(0.0604,0.0635), vec2(0.0575,0.0215), vec2(0.0795,0.0581), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0272,1.1264,-1.2183), vec3(0.0085,1.1451,-1.1731), vec3(-0.042,1.1307,-1.1726), vec3(0.2721,-0.9459,0.177), vec2(0.1133,0.0479), vec2(0.0786,0.0205), vec2(0.0795,0.0581), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0586,1.1296,-1.1729), vec3(0.0435,1.1256,-1.2185), vec3(0.0586,1.1489,-1.1725), vec3(0.9491,0.0076,-0.3149), vec2(0.1456,0.3794), vec2(0.1602,0.3975), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.042,1.1307,-1.1726), vec3(0.0086,1.1437,-1.1443), vec3(-0.0483,1.1297,-1.1463), vec3(0.2387,-0.9709,0.0198), vec2(0.0795,0.0581), vec2(0.0575,0.0215), vec2(0.0604,0.0635), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0586,1.1296,-1.1729), vec3(0.0586,1.1489,-1.1725), vec3(0.0652,1.1284,-1.1467), vec3(0.9702,0.0061,-0.2423), vec2(0.1456,0.3794), vec2(0.1375,0.3843), vec2(0.1392,0.3677), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.042,1.1307,-1.1726), vec3(-0.0415,1.15,-1.1722), vec3(-0.0272,1.1264,-1.2183), vec3(-0.9507,0.029,-0.3088), vec2(0.1456,0.3794), vec2(0.1375,0.3843), vec2(0.1602,0.3975), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0221,1.128,-1.2623), vec3(0.0081,1.1342,-1.2631), vec3(0.0358,1.1459,-1.2295), vec3(0.3615,0.7473,-0.5576), vec2(0.1709,0.4185), vec2(0.1682,0.4253), vec2(0.1553,0.4082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0061,1.1283,-1.2622), vec3(-0.0191,1.1465,-1.2293), vec3(0.0081,1.1342,-1.2631), vec3(-0.3496,0.7548,-0.555), vec2(0.1709,0.4185), vec2(0.1553,0.4082), vec2(0.1682,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0082,1.1384,-1.2277), vec3(0.0435,1.1256,-1.2185), vec3(0.0085,1.1451,-1.1731), vec3(-0.3645,-0.924,0.1159), vec2(0.1191,0.02), vec2(0.1133,0.0479), vec2(0.0786,0.0205), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0082,1.1384,-1.2277), vec3(0.0085,1.1451,-1.1731), vec3(-0.0272,1.1264,-1.2183), vec3(0.345,-0.9317,0.1135), vec2(0.1191,0.02), vec2(0.0786,0.0205), vec2(0.1133,0.0479), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.042,1.1307,-1.1726), vec3(-0.0483,1.1297,-1.1463), vec3(-0.0415,1.15,-1.1722), vec3(-0.9717,0.028,-0.2347), vec2(0.1456,0.3794), vec2(0.1392,0.3677), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0085,1.1451,-1.1731), vec3(0.0586,1.1296,-1.1729), vec3(0.0086,1.1437,-1.1443), vec3(-0.2949,-0.9544,-0.0461), vec2(0.0786,0.0205), vec2(0.0795,0.0581), vec2(0.0575,0.0215), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0085,1.1451,-1.1731), vec3(0.0086,1.1437,-1.1443), vec3(-0.042,1.1307,-1.1726), vec3(0.274,-0.9605,-0.0479), vec2(0.0786,0.0205), vec2(0.0575,0.0215), vec2(0.0795,0.0581), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0358,1.1459,-1.2295), vec3(0.0586,1.1489,-1.1725), vec3(0.0435,1.1256,-1.2185), vec3(0.9152,0.1479,-0.3748), vec2(0.1553,0.4082), vec2(0.1375,0.3843), vec2(0.1602,0.3975), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0191,1.1465,-1.2293), vec3(-0.0272,1.1264,-1.2183), vec3(-0.0415,1.15,-1.1722), vec3(-0.9142,0.1681,-0.3687), vec2(0.1553,0.4082), vec2(0.1602,0.3975), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0084,1.1538,-1.2367), vec3(0.0358,1.1459,-1.2295), vec3(0.0081,1.1342,-1.2631), vec3(0.3627,0.7462,-0.5582), vec2(0.1527,0.4214), vec2(0.1553,0.4082), vec2(0.1682,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0687,1.1568,-1.1415), vec3(0.0652,1.1284,-1.1467), vec3(0.0586,1.1489,-1.1725), vec3(0.9539,-0.0634,-0.2934), vec2(0.1272,0.3721), vec2(0.1392,0.3677), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0084,1.1538,-1.2367), vec3(0.0081,1.1342,-1.2631), vec3(-0.0191,1.1465,-1.2293), vec3(-0.3508,0.7538,-0.5556), vec2(0.1527,0.4214), vec2(0.1682,0.4253), vec2(0.1553,0.4082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0552,1.158,-1.1409), vec3(-0.0415,1.15,-1.1722), vec3(-0.0483,1.1297,-1.1463), vec3(-0.9197,-0.1515,-0.3623), vec2(0.1272,0.3721), vec2(0.1375,0.3843), vec2(0.1392,0.3677), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0687,1.1568,-1.1415), vec3(0.0949,1.1546,-1.1048), vec3(0.0652,1.1284,-1.1467), vec3(0.813,0.0075,-0.5823), vec2(0.9507,0.8915), vec2(0.9331,0.8916), vec2(0.9521,0.8813), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0552,1.158,-1.1409), vec3(-0.0483,1.1297,-1.1463), vec3(-0.0811,1.1563,-1.104), vec3(-0.813,-0.0847,-0.5761), vec2(0.9507,0.8915), vec2(0.9521,0.8813), vec2(0.9331,0.8916), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0586,1.1489,-1.1725), vec3(0.0358,1.1459,-1.2295), vec3(0.049,1.168,-1.1718), vec3(0.829,0.4318,-0.3553), vec2(0.1375,0.3843), vec2(0.1553,0.4082), vec2(0.1293,0.3911), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0315,1.1688,-1.1715), vec3(-0.0191,1.1465,-1.2293), vec3(-0.0415,1.15,-1.1722), vec3(-0.8211,0.451,-0.3497), vec2(0.1293,0.3911), vec2(0.1553,0.4082), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0586,1.1489,-1.1725), vec3(0.049,1.168,-1.1718), vec3(0.0687,1.1568,-1.1415), vec3(0.8215,0.4288,-0.3758), vec2(0.1375,0.3843), vec2(0.1293,0.3911), vec2(0.1272,0.3721), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0552,1.158,-1.1409), vec3(-0.0315,1.1688,-1.1715), vec3(-0.0415,1.15,-1.1722), vec3(-0.7802,0.4329,-0.4515), vec2(0.1272,0.3721), vec2(0.1293,0.3911), vec2(0.1375,0.3843), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0084,1.1538,-1.2367), vec3(0.0088,1.1787,-1.1856), vec3(0.0358,1.1459,-1.2295), vec3(0.3514,0.8404,-0.4126), vec2(0.1527,0.4214), vec2(0.1267,0.4126), vec2(0.1553,0.4082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0084,1.1538,-1.2367), vec3(-0.0191,1.1465,-1.2293), vec3(0.0088,1.1787,-1.1856), vec3(-0.3364,0.8478,-0.41), vec2(0.1527,0.4214), vec2(0.1553,0.4082), vec2(0.1267,0.4126), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0687,1.1568,-1.1415), vec3(0.0694,1.1793,-1.1346), vec3(0.0949,1.1546,-1.1048), vec3(0.8081,0.1482,-0.5702), vec2(0.9507,0.8915), vec2(0.9487,0.9006), vec2(0.9331,0.8916), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.049,1.168,-1.1718), vec3(0.0358,1.1459,-1.2295), vec3(0.0088,1.1787,-1.1856), vec3(0.3635,0.8393,-0.4043), vec2(0.1293,0.3911), vec2(0.1553,0.4082), vec2(0.1267,0.4126), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0315,1.1688,-1.1715), vec3(0.0088,1.1787,-1.1856), vec3(-0.0191,1.1465,-1.2293), vec3(-0.348,0.847,-0.4019), vec2(0.1293,0.3911), vec2(0.1267,0.4126), vec2(0.1553,0.4082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0552,1.158,-1.1409), vec3(-0.0811,1.1563,-1.104), vec3(-0.0554,1.1805,-1.134), vec3(-0.81,0.1653,-0.5626), vec2(0.9507,0.8915), vec2(0.9331,0.8916), vec2(0.9487,0.9006), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.049,1.168,-1.1718), vec3(0.0566,1.1851,-1.1571), vec3(0.0687,1.1568,-1.1415), vec3(0.8482,0.0709,-0.5249), vec2(0.1293,0.3911), vec2(0.1183,0.3872), vec2(0.1272,0.3721), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0315,1.1688,-1.1715), vec3(-0.0552,1.158,-1.1409), vec3(-0.0387,1.1862,-1.1568), vec3(-0.8066,0.1505,-0.5716), vec2(0.1293,0.3911), vec2(0.1272,0.3721), vec2(0.1183,0.3872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0694,1.1793,-1.1346), vec3(0.0687,1.1568,-1.1415), vec3(0.0566,1.1851,-1.1571), vec3(0.8765,0.1145,-0.4677), vec2(0.1159,0.375), vec2(0.1272,0.3721), vec2(0.1183,0.3872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0387,1.1862,-1.1568), vec3(-0.0552,1.158,-1.1409), vec3(-0.0554,1.1805,-1.134), vec3(-0.8144,0.1635,-0.5568), vec2(0.1183,0.3872), vec2(0.1272,0.3721), vec2(0.1159,0.375), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0088,1.1787,-1.1856), vec3(0.0091,1.2002,-1.167), vec3(0.049,1.168,-1.1718), vec3(0.3992,0.5958,-0.6969), vec2(0.1267,0.4126), vec2(0.1132,0.4111), vec2(0.1293,0.3911), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0088,1.1787,-1.1856), vec3(-0.0315,1.1688,-1.1715), vec3(0.0091,1.2002,-1.167), vec3(-0.391,0.6041,-0.6944), vec2(0.1267,0.4126), vec2(0.1293,0.3911), vec2(0.1132,0.4111), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0566,1.1851,-1.1571), vec3(0.049,1.168,-1.1718), vec3(0.0091,1.2002,-1.167), vec3(0.3305,0.5238,-0.7851), vec2(0.1183,0.3872), vec2(0.1293,0.3911), vec2(0.1132,0.4111), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0387,1.1862,-1.1568), vec3(0.0091,1.2002,-1.167), vec3(-0.0315,1.1688,-1.1715), vec3(-0.3242,0.5303,-0.7834), vec2(0.1183,0.3872), vec2(0.1132,0.4111), vec2(0.1293,0.3911), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0608,1.1979,-1.1299), vec3(0.0694,1.1793,-1.1346), vec3(0.0566,1.1851,-1.1571), vec3(0.8166,0.4644,-0.3428), vec2(0.1071,0.3804), vec2(0.1159,0.375), vec2(0.1183,0.3872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0387,1.1862,-1.1568), vec3(-0.0554,1.1805,-1.134), vec3(-0.0463,1.1989,-1.1294), vec3(-0.7596,0.4809,-0.438), vec2(0.1183,0.3872), vec2(0.1159,0.375), vec2(0.1071,0.3804), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0608,1.1979,-1.1299), vec3(0.0566,1.1851,-1.1571), vec3(0.0299,1.2111,-1.1343), vec3(0.4068,0.8017,-0.4379), vec2(0.1071,0.3804), vec2(0.1183,0.3872), vec2(0.1012,0.396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0091,1.2002,-1.167), vec3(0.0299,1.2111,-1.1343), vec3(0.0566,1.1851,-1.1571), vec3(0.3552,0.7953,-0.4912), vec2(0.1132,0.4111), vec2(0.1012,0.396), vec2(0.1183,0.3872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0091,1.2002,-1.167), vec3(-0.0387,1.1862,-1.1568), vec3(-0.0152,1.2116,-1.1341), vec3(-0.342,0.7812,-0.5223), vec2(0.1132,0.4111), vec2(0.1183,0.3872), vec2(0.1012,0.396), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(-0.0018,1.2162,-1.0429), 0.3427, bestT)) {
        if (triHit(ro, rd, vec3(0.0091,1.2002,-1.167), vec3(0.0074,1.2149,-1.1346), vec3(0.0299,1.2111,-1.1343), vec3(0.1552,0.9032,-0.4001), vec2(0.1132,0.4111), vec2(0.0977,0.4062), vec2(0.1012,0.396), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0152,1.2116,-1.1341), vec3(0.0074,1.2149,-1.1346), vec3(0.0091,1.2002,-1.167), vec3(-0.141,0.8991,-0.4143), vec2(0.1012,0.396), vec2(0.0977,0.4062), vec2(0.1132,0.4111), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0463,1.1989,-1.1294), vec3(-0.0152,1.2116,-1.1341), vec3(-0.0387,1.1862,-1.1568), vec3(-0.3917,0.7867,-0.4772), vec2(0.1071,0.3804), vec2(0.1012,0.396), vec2(0.1183,0.3872), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0299,1.2111,-1.1343), vec3(0.0074,1.2149,-1.1346), vec3(0.0327,1.2418,-1.1176), vec3(0.0901,0.4708,-0.8776), vec2(0.959,0.9182), vec2(0.9653,0.924), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0172,1.2422,-1.1174), vec3(0.0074,1.2149,-1.1346), vec3(-0.0152,1.2116,-1.1341), vec3(-0.0898,0.4721,-0.877), vec2(0.9502,0.9297), vec2(0.9653,0.924), vec2(0.959,0.9182), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0608,1.1979,-1.1299), vec3(0.0299,1.2111,-1.1343), vec3(0.0754,1.2295,-1.1139), vec3(0.2711,0.3316,-0.9036), vec2(0.9492,0.9088), vec2(0.959,0.9182), vec2(0.939,0.9193), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0152,1.2116,-1.1341), vec3(-0.0463,1.1989,-1.1294), vec3(-0.0602,1.2308,-1.1133), vec3(-0.2728,0.3371,-0.9011), vec2(0.959,0.9182), vec2(0.9492,0.9088), vec2(0.939,0.9193), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.2448,-1.117), vec3(0.0327,1.2418,-1.1176), vec3(0.0074,1.2149,-1.1346), vec3(0.0408,0.5068,-0.8611), vec2(0.9575,0.9365), vec2(0.9502,0.9297), vec2(0.9653,0.924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0078,1.2448,-1.117), vec3(0.0074,1.2149,-1.1346), vec3(-0.0172,1.2422,-1.1174), vec3(-0.0389,0.5076,-0.8607), vec2(0.9575,0.9365), vec2(0.9653,0.924), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0694,1.1793,-1.1346), vec3(0.0608,1.1979,-1.1299), vec3(0.0948,1.1856,-1.1017), vec3(0.6604,0.4557,-0.5968), vec2(0.9487,0.9006), vec2(0.9492,0.9088), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0754,1.2295,-1.1139), vec3(0.0299,1.2111,-1.1343), vec3(0.0327,1.2418,-1.1176), vec3(0.2051,0.4545,-0.8668), vec2(0.939,0.9193), vec2(0.959,0.9182), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0172,1.2422,-1.1174), vec3(-0.0152,1.2116,-1.1341), vec3(-0.0602,1.2308,-1.1133), vec3(-0.2043,0.4582,-0.8651), vec2(0.9502,0.9297), vec2(0.959,0.9182), vec2(0.939,0.9193), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0554,1.1805,-1.134), vec3(-0.0803,1.1873,-1.1008), vec3(-0.0463,1.1989,-1.1294), vec3(-0.6571,0.4686,-0.5904), vec2(0.9487,0.9006), vec2(0.9326,0.9033), vec2(0.9492,0.9088), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0608,1.1979,-1.1299), vec3(0.0754,1.2295,-1.1139), vec3(0.0948,1.1856,-1.1017), vec3(0.6537,0.0782,-0.7527), vec2(0.9492,0.9088), vec2(0.939,0.9193), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0602,1.2308,-1.1133), vec3(-0.0463,1.1989,-1.1294), vec3(-0.0803,1.1873,-1.1008), vec3(-0.6592,0.0909,-0.7464), vec2(0.939,0.9193), vec2(0.9492,0.9088), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0948,1.1856,-1.1017), vec3(0.0949,1.1546,-1.1048), vec3(0.0694,1.1793,-1.1346), vec3(0.7838,0.0663,-0.6174), vec2(0.9326,0.9033), vec2(0.9331,0.8916), vec2(0.9487,0.9006), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0803,1.1873,-1.1008), vec3(-0.0554,1.1805,-1.134), vec3(-0.0811,1.1563,-1.104), vec3(-0.7881,0.0832,-0.6099), vec2(0.9326,0.9033), vec2(0.9487,0.9006), vec2(0.9331,0.8916), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0327,1.2418,-1.1176), vec3(0.0078,1.2448,-1.117), vec3(0.0376,1.2752,-1.089), vec3(0.0597,0.644,-0.7627), vec2(0.9502,0.9297), vec2(0.9575,0.9365), vec2(0.9385,0.9414), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0212,1.2757,-1.0887), vec3(0.0078,1.2448,-1.117), vec3(-0.0172,1.2422,-1.1174), vec3(-0.0542,0.6451,-0.7622), vec2(0.9385,0.9414), vec2(0.9575,0.9365), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0754,1.2295,-1.1139), vec3(0.0327,1.2418,-1.1176), vec3(0.086,1.2574,-1.0827), vec3(0.2539,0.6772,-0.6906), vec2(0.939,0.9193), vec2(0.9502,0.9297), vec2(0.9277,0.9287), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0602,1.2308,-1.1133), vec3(-0.0698,1.2589,-1.082), vec3(-0.0172,1.2422,-1.1174), vec3(-0.247,0.682,-0.6884), vec2(0.939,0.9193), vec2(0.9277,0.9287), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1052,1.2139,-1.0853), vec3(0.0948,1.1856,-1.1017), vec3(0.0754,1.2295,-1.1139), vec3(0.721,0.1279,-0.681), vec2(0.9258,0.9136), vec2(0.9326,0.9033), vec2(0.939,0.9193), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.09,1.2158,-1.0844), vec3(-0.0602,1.2308,-1.1133), vec3(-0.0803,1.1873,-1.1008), vec3(-0.7247,0.1419,-0.6743), vec2(0.9258,0.9136), vec2(0.939,0.9193), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0082,1.2774,-1.0864), vec3(0.0376,1.2752,-1.089), vec3(0.0078,1.2448,-1.117), vec3(-0.013,0.6843,-0.729), vec2(0.9448,0.9506), vec2(0.9385,0.9414), vec2(0.9575,0.9365), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0082,1.2774,-1.0864), vec3(0.0078,1.2448,-1.117), vec3(-0.0212,1.2757,-1.0887), vec3(0.0198,0.684,-0.7292), vec2(0.9448,0.9506), vec2(0.9575,0.9365), vec2(0.9385,0.9414), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0376,1.2752,-1.089), vec3(0.086,1.2574,-1.0827), vec3(0.0327,1.2418,-1.1176), vec3(0.3142,0.5902,-0.7436), vec2(0.9385,0.9414), vec2(0.9277,0.9287), vec2(0.9502,0.9297), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0212,1.2757,-1.0887), vec3(-0.0172,1.2422,-1.1174), vec3(-0.0698,1.2589,-1.082), vec3(-0.3093,0.5965,-0.7407), vec2(0.9385,0.9414), vec2(0.9502,0.9297), vec2(0.9277,0.9287), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0754,1.2295,-1.1139), vec3(0.086,1.2574,-1.0827), vec3(0.1052,1.2139,-1.0853), vec3(0.7373,0.3611,-0.5709), vec2(0.939,0.9193), vec2(0.9277,0.9287), vec2(0.9258,0.9136), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0949,1.1546,-1.1048), vec3(0.0948,1.1856,-1.1017), vec3(0.1183,1.1309,-1.0732), vec3(0.8241,0.0609,-0.5631), vec2(0.9331,0.8916), vec2(0.9326,0.9033), vec2(0.918,0.8853), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0602,1.2308,-1.1133), vec3(-0.09,1.2158,-1.0844), vec3(-0.0698,1.2589,-1.082), vec3(-0.7353,0.376,-0.5638), vec2(0.939,0.9193), vec2(0.9258,0.9136), vec2(0.9277,0.9287), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0811,1.1563,-1.104), vec3(-0.1046,1.1331,-1.0721), vec3(-0.0803,1.1873,-1.1008), vec3(-0.8288,0.0785,-0.554), vec2(0.9331,0.8916), vec2(0.918,0.8853), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0903,1.1062,-1.0993), vec3(-0.1046,1.1331,-1.0721), vec3(-0.0811,1.1563,-1.104), vec3(-0.8346,0.1017,-0.5414), vec2(0.9282,0.8737), vec2(0.918,0.8853), vec2(0.9331,0.8916), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1123,1.2488,-1.0556), vec3(0.1052,1.2139,-1.0853), vec3(0.086,1.2574,-1.0827), vec3(0.7233,0.3561,-0.5916), vec2(0.916,0.9254), vec2(0.9258,0.9136), vec2(0.9277,0.9287), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1052,1.2139,-1.0853), vec3(0.1321,1.1768,-1.0342), vec3(0.0948,1.1856,-1.1017), vec3(0.872,-0.0395,-0.4879), vec2(0.9258,0.9136), vec2(0.9058,0.9043), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0961,1.2508,-1.0546), vec3(-0.0698,1.2589,-1.082), vec3(-0.09,1.2158,-1.0844), vec3(-0.7215,0.3708,-0.5847), vec2(0.916,0.9254), vec2(0.9277,0.9287), vec2(0.9258,0.9136), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0803,1.1873,-1.1008), vec3(-0.1172,1.1793,-1.033), vec3(-0.09,1.2158,-1.0844), vec3(-0.8771,-0.0222,-0.4798), vec2(0.9326,0.9033), vec2(0.9058,0.9043), vec2(0.9258,0.9136), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.086,1.2574,-1.0827), vec3(0.0376,1.2752,-1.089), vec3(0.0971,1.2702,-1.0412), vec3(0.3631,0.8582,-0.3629), vec2(0.9277,0.9287), vec2(0.9385,0.9414), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0376,1.2752,-1.089), vec3(0.0082,1.2774,-1.0864), vec3(0.0431,1.2973,-1.0372), vec3(0.0345,0.9173,-0.3967), vec2(0.9385,0.9414), vec2(0.9448,0.9506), vec2(0.9199,0.9523), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0258,1.298,-1.0369), vec3(0.0082,1.2774,-1.0864), vec3(-0.0212,1.2757,-1.0887), vec3(-0.0198,0.9179,-0.3964), vec2(0.9199,0.9523), vec2(0.9448,0.9506), vec2(0.9385,0.9414), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0698,1.2589,-1.082), vec3(-0.0804,1.2719,-1.0404), vec3(-0.0212,1.2757,-1.0887), vec3(-0.3492,0.8656,-0.3589), vec2(0.9277,0.9287), vec2(0.9136,0.9346), vec2(0.9385,0.9414), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1321,1.1768,-1.0342), vec3(0.1183,1.1309,-1.0732), vec3(0.0948,1.1856,-1.1017), vec3(0.8744,0.1325,-0.4668), vec2(0.9058,0.9043), vec2(0.918,0.8853), vec2(0.9326,0.9033), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1172,1.1793,-1.033), vec3(-0.0803,1.1873,-1.1008), vec3(-0.1046,1.1331,-1.0721), vec3(-0.8758,0.1499,-0.4587), vec2(0.9058,0.9043), vec2(0.9326,0.9033), vec2(0.918,0.8853), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1295,1.0646,-1.032), vec3(-0.1046,1.1331,-1.0721), vec3(-0.0903,1.1062,-1.0993), vec3(-0.8714,0.0298,-0.4896), vec2(0.8975,0.8658), vec2(0.918,0.8853), vec2(0.9282,0.8737), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1123,1.2488,-1.0556), vec3(0.086,1.2574,-1.0827), vec3(0.0971,1.2702,-1.0412), vec3(0.6146,0.6918,-0.3792), vec2(0.916,0.9254), vec2(0.9277,0.9287), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0804,1.2719,-1.0404), vec3(-0.0698,1.2589,-1.082), vec3(-0.0961,1.2508,-1.0546), vec3(-0.604,0.7043,-0.373), vec2(0.9136,0.9346), vec2(0.9277,0.9287), vec2(0.916,0.9254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1052,1.2139,-1.0853), vec3(0.1123,1.2488,-1.0556), vec3(0.1321,1.1768,-1.0342), vec3(0.9141,0.1382,-0.3812), vec2(0.9258,0.9136), vec2(0.916,0.9254), vec2(0.9058,0.9043), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.09,1.2158,-1.0844), vec3(-0.1172,1.1793,-1.033), vec3(-0.0961,1.2508,-1.0546), vec3(-0.9147,0.1566,-0.3725), vec2(0.9258,0.9136), vec2(0.9058,0.9043), vec2(0.916,0.9254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0431,1.2973,-1.0372), vec3(0.0971,1.2702,-1.0412), vec3(0.0376,1.2752,-1.089), vec3(0.3885,0.8314,-0.3973), vec2(0.9199,0.9523), vec2(0.9136,0.9346), vec2(0.9385,0.9414), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0258,1.298,-1.0369), vec3(-0.0212,1.2757,-1.0887), vec3(-0.0804,1.2719,-1.0404), vec3(-0.3761,0.8387,-0.3939), vec2(0.9199,0.9523), vec2(0.9385,0.9414), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0087,1.3,-1.0345), vec3(0.0431,1.2973,-1.0372), vec3(0.0082,1.2774,-1.0864), vec3(0.039,0.916,-0.3993), vec2(0.9238,0.9641), vec2(0.9199,0.9523), vec2(0.9448,0.9506), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0087,1.3,-1.0345), vec3(0.0082,1.2774,-1.0864), vec3(-0.0258,1.298,-1.0369), vec3(-0.0243,0.9166,-0.399), vec2(0.9238,0.9641), vec2(0.9448,0.9506), vec2(0.9199,0.9523), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1123,1.2488,-1.0556), vec3(0.0971,1.2702,-1.0412), vec3(0.1318,1.2206,-0.9931), vec3(0.8169,0.5767,0.0054), vec2(0.916,0.9254), vec2(0.9136,0.9346), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0961,1.2508,-1.0546), vec3(-0.1156,1.223,-0.9919), vec3(-0.0804,1.2719,-1.0404), vec3(-0.8048,0.5934,0.0133), vec2(0.916,0.9254), vec2(0.8936,0.9229), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1321,1.1768,-1.0342), vec3(0.1604,1.101,-0.9777), vec3(0.1183,1.1309,-1.0732), vec3(0.9196,0.053,-0.3892), vec2(0.9058,0.9043), vec2(0.8779,0.8866), vec2(0.918,0.8853), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1422,1.0619,-1.0333), vec3(0.1183,1.1309,-1.0732), vec3(0.1604,1.101,-0.9777), vec3(0.9215,0.1026,-0.3745), vec2(0.8975,0.8658), vec2(0.918,0.8853), vec2(0.8779,0.8866), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1318,1.2206,-0.9931), vec3(0.1321,1.1768,-1.0342), vec3(0.1123,1.2488,-1.0556), vec3(0.9572,0.2018,-0.2074), vec2(0.8936,0.9229), vec2(0.9058,0.9043), vec2(0.916,0.9254), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1172,1.1793,-1.033), vec3(-0.1046,1.1331,-1.0721), vec3(-0.1464,1.1041,-0.9763), vec3(-0.922,0.0713,-0.3806), vec2(0.9058,0.9043), vec2(0.918,0.8853), vec2(0.8779,0.8866), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1295,1.0646,-1.032), vec3(-0.1464,1.1041,-0.9763), vec3(-0.1046,1.1331,-1.0721), vec3(-0.9228,0.1211,-0.3659), vec2(0.8975,0.8658), vec2(0.8779,0.8866), vec2(0.918,0.8853), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0961,1.2508,-1.0546), vec3(-0.1172,1.1793,-1.033), vec3(-0.1156,1.223,-0.9919), vec3(-0.9549,0.2209,-0.1985), vec2(0.916,0.9254), vec2(0.9058,0.9043), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.064,1.2746,-0.9521), vec3(0.0971,1.2702,-1.0412), vec3(0.0431,1.2973,-1.0372), vec3(0.4529,0.8829,0.1242), vec2(0.8848,0.9547), vec2(0.9136,0.9346), vec2(0.9199,0.9523), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0258,1.298,-1.0369), vec3(-0.0804,1.2719,-1.0404), vec3(-0.0463,1.2757,-0.9515), vec3(-0.4346,0.8914,0.1284), vec2(0.9199,0.9523), vec2(0.9136,0.9346), vec2(0.8848,0.9547), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0087,1.3,-1.0345), vec3(0.064,1.2746,-0.9521), vec3(0.0431,1.2973,-1.0372), vec3(0.0933,0.9674,0.2353), vec2(0.9238,0.9641), vec2(0.8848,0.9547), vec2(0.9199,0.9523), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0258,1.298,-1.0369), vec3(-0.0463,1.2757,-0.9515), vec3(0.0087,1.3,-1.0345), vec3(-0.0714,0.9691,0.2362), vec2(0.9199,0.9523), vec2(0.8848,0.9547), vec2(0.9238,0.9641), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1318,1.2206,-0.9931), vec3(0.1604,1.101,-0.9777), vec3(0.1321,1.1768,-1.0342), vec3(0.9571,0.2021,-0.2078), vec2(0.8936,0.9229), vec2(0.8779,0.8866), vec2(0.9058,0.9043), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1295,1.0646,-1.032), vec3(-0.1472,0.9941,-0.9954), vec3(-0.1464,1.1041,-0.9763), vec3(-0.9413,0.0643,-0.3313), vec2(0.8975,0.8658), vec2(0.8789,0.8451), vec2(0.8779,0.8866), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1139,1.2455,-0.9676), vec3(0.1318,1.2206,-0.9931), vec3(0.0971,1.2702,-1.0412), vec3(0.8154,0.5788,0.0087), vec2(0.8867,0.9351), vec2(0.8936,0.9229), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1172,1.1793,-1.033), vec3(-0.1464,1.1041,-0.9763), vec3(-0.1156,1.223,-0.9919), vec3(-0.9547,0.2212,-0.1989), vec2(0.9058,0.9043), vec2(0.8779,0.8866), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0969,1.2475,-0.9666), vec3(-0.0804,1.2719,-1.0404), vec3(-0.1156,1.223,-0.9919), vec3(-0.8032,0.5954,0.0165), vec2(0.8867,0.9351), vec2(0.9136,0.9346), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.064,1.2746,-0.9521), vec3(0.1139,1.2455,-0.9676), vec3(0.0971,1.2702,-1.0412), vec3(0.5345,0.8304,0.1571), vec2(0.8848,0.9547), vec2(0.8867,0.9351), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0969,1.2475,-0.9666), vec3(-0.0463,1.2757,-0.9515), vec3(-0.0804,1.2719,-1.0404), vec3(-0.5166,0.8408,0.162), vec2(0.8867,0.9351), vec2(0.8848,0.9547), vec2(0.9136,0.9346), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.064,1.2746,-0.9521), vec3(0.0087,1.3,-1.0345), vec3(0.0089,1.2771,-0.9422), vec3(0.0862,0.9669,0.24), vec2(0.8848,0.9547), vec2(0.9238,0.9641), vec2(0.8823,0.9742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0463,1.2757,-0.9515), vec3(0.0089,1.2771,-0.9422), vec3(0.0087,1.3,-1.0345), vec3(-0.0644,0.9685,0.2407), vec2(0.8848,0.9547), vec2(0.8823,0.9742), vec2(0.9238,0.9641), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1563,1.1393,-0.9339), vec3(0.1604,1.101,-0.9777), vec3(0.1318,1.2206,-0.9931), vec3(0.9705,0.2191,-0.1002), vec2(0.8638,0.9044), vec2(0.8779,0.8866), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1464,1.1041,-0.9763), vec3(-0.1411,1.1423,-0.9325), vec3(-0.1156,1.223,-0.9919), vec3(-0.9669,0.2385,-0.091), vec2(0.8779,0.8866), vec2(0.8638,0.9044), vec2(0.8936,0.9229), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1318,1.2206,-0.9931), vec3(0.1139,1.2455,-0.9676), vec3(0.1563,1.1393,-0.9339), vec3(0.8827,0.4197,0.2113), vec2(0.8936,0.9229), vec2(0.8867,0.9351), vec2(0.8638,0.9044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1156,1.223,-0.9919), vec3(-0.1411,1.1423,-0.9325), vec3(-0.0969,1.2475,-0.9666), vec3(-0.8719,0.4375,0.22), vec2(0.8936,0.9229), vec2(0.8638,0.9044), vec2(0.8867,0.9351), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1679,1.0255,-0.8955), vec3(-0.1464,1.1041,-0.9763), vec3(-0.1472,0.9941,-0.9954), vec3(-0.9753,0.0445,-0.2163), vec2(0.8413,0.8647), vec2(0.8779,0.8866), vec2(0.8789,0.8451), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1139,1.2455,-0.9676), vec3(0.064,1.2746,-0.9521), vec3(0.1314,1.1786,-0.8977), vec3(0.5477,0.6692,0.5022), vec2(0.8867,0.9351), vec2(0.8848,0.9547), vec2(0.8535,0.9227), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0969,1.2475,-0.9666), vec3(-0.1151,1.1811,-0.8965), vec3(-0.0463,1.2757,-0.9515), vec3(-0.5297,0.6798,0.5072), vec2(0.8867,0.9351), vec2(0.8535,0.9227), vec2(0.8848,0.9547), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1679,1.0255,-0.8955), vec3(-0.1411,1.1423,-0.9325), vec3(-0.1464,1.1041,-0.9763), vec3(-0.9769,0.2051,-0.0606), vec2(0.8413,0.8647), vec2(0.8638,0.9044), vec2(0.8779,0.8866), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1314,1.1786,-0.8977), vec3(0.1563,1.1393,-0.9339), vec3(0.1139,1.2455,-0.9676), vec3(0.8958,0.4113,0.1684), vec2(0.8535,0.9227), vec2(0.8638,0.9044), vec2(0.8867,0.9351), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1151,1.1811,-0.8965), vec3(-0.0969,1.2475,-0.9666), vec3(-0.1411,1.1423,-0.9325), vec3(-0.8856,0.4294,0.1772), vec2(0.8535,0.9227), vec2(0.8867,0.9351), vec2(0.8638,0.9044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0089,1.2771,-0.9422), vec3(0.0655,1.223,-0.8567), vec3(0.064,1.2746,-0.9521), vec3(0.1232,0.8734,0.4711), vec2(0.8823,0.9742), vec2(0.8408,0.9507), vec2(0.8848,0.9547), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0463,1.2757,-0.9515), vec3(-0.0479,1.2241,-0.8561), vec3(0.0089,1.2771,-0.9422), vec3(-0.1011,0.8756,0.4723), vec2(0.8848,0.9547), vec2(0.8408,0.9507), vec2(0.8823,0.9742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0655,1.223,-0.8567), vec3(0.1314,1.1786,-0.8977), vec3(0.064,1.2746,-0.9521), vec3(0.6625,0.6629,0.3488), vec2(0.8408,0.9507), vec2(0.8535,0.9227), vec2(0.8848,0.9547), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0463,1.2757,-0.9515), vec3(-0.1151,1.1811,-0.8965), vec3(-0.0479,1.2241,-0.8561), vec3(-0.6459,0.6758,0.355), vec2(0.8848,0.9547), vec2(0.8535,0.9227), vec2(0.8408,0.9507), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1151,1.1811,-0.8965), vec3(-0.1411,1.1423,-0.9325), vec3(-0.1423,1.0826,-0.8354), vec3(-0.8932,0.3878,0.2276), vec2(0.8535,0.9227), vec2(0.8638,0.9044), vec2(0.8232,0.8921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0655,1.223,-0.8567), vec3(0.0089,1.2771,-0.9422), vec3(0.0089,1.2317,-0.8504), vec3(0.1836,0.881,0.436), vec2(0.8408,0.9507), vec2(0.8823,0.9742), vec2(0.8354,0.9704), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0479,1.2241,-0.8561), vec3(0.0089,1.2317,-0.8504), vec3(0.0089,1.2771,-0.9422), vec3(-0.1618,0.8845,0.4376), vec2(0.8408,0.9507), vec2(0.8354,0.9704), vec2(0.8823,0.9742), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.2507,0.0436,-0.4755), 0.4992, bestT)) {
        if (triHit(ro, rd, vec3(0.1518,0.1808,-0.7416), vec3(0.1624,0.0928,-0.6711), vec3(-0.0015,0.1359,-0.7461), vec3(0.198,-0.5985,-0.7763), vec2(0.854,0.5461), vec2(0.835,0.5125), vec2(0.9023,0.511), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1518,0.1808,-0.7416), vec3(0.2036,0.2082,-0.7252), vec3(0.2312,0.1191,-0.6443), vec3(0.4901,-0.4981,-0.7154), vec2(0.854,0.5461), vec2(0.8364,0.5576), vec2(0.8125,0.5249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0015,0.1359,-0.7461), vec3(0.1624,0.0928,-0.6711), vec3(-0.002,0.0631,-0.6816), vec3(0.1654,-0.6548,-0.7375), vec2(0.9023,0.511), vec2(0.835,0.5125), vec2(0.8853,0.4771), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2312,0.1191,-0.6443), vec3(0.1624,0.0928,-0.6711), vec3(0.1518,0.1808,-0.7416), vec3(0.4747,-0.5151,-0.7136), vec2(0.8125,0.5249), vec2(0.835,0.5125), vec2(0.854,0.5461), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2036,0.2082,-0.7252), vec3(0.2808,0.2513,-0.7053), vec3(0.3011,0.1501,-0.6216), vec3(0.4688,-0.5049,-0.7248), vec2(0.8364,0.5576), vec2(0.8105,0.5745), vec2(0.79,0.5378), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3011,0.1501,-0.6216), vec3(0.2312,0.1191,-0.6443), vec3(0.2036,0.2082,-0.7252), vec3(0.4617,-0.5138,-0.7231), vec2(0.79,0.5378), vec2(0.8125,0.5249), vec2(0.8364,0.5576), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.002,-0.0138,-0.5929), vec3(-0.002,0.0631,-0.6816), vec3(0.1624,0.0928,-0.6711), vec3(0.1756,-0.7439,-0.6448), vec2(0.8599,0.4399), vec2(0.8853,0.4771), vec2(0.835,0.5125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3011,0.1501,-0.6216), vec3(0.2808,0.2513,-0.7053), vec3(0.3754,0.2586,-0.6169), vec3(0.6399,-0.4092,-0.6505), vec2(0.79,0.5378), vec2(0.8105,0.5745), vec2(0.77,0.5732), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2312,0.1191,-0.6443), vec3(0.2696,0.0425,-0.5352), vec3(0.1624,0.0928,-0.6711), vec3(0.4789,-0.6302,-0.6112), vec2(0.8125,0.5249), vec2(0.7827,0.4976), vec2(0.835,0.5125), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1624,0.0928,-0.6711), vec3(0.1755,0.0126,-0.5818), vec3(-0.002,-0.0138,-0.5929), vec3(0.1496,-0.7243,-0.673), vec2(0.835,0.5125), vec2(0.811,0.4814), vec2(0.8599,0.4399), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3011,0.1501,-0.6216), vec3(0.3754,0.2586,-0.6169), vec3(0.3752,0.1922,-0.5696), vec3(0.6694,-0.4314,-0.6048), vec2(0.79,0.5378), vec2(0.77,0.5732), vec2(0.7617,0.5498), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1755,0.0126,-0.5818), vec3(0.1624,0.0928,-0.6711), vec3(0.2696,0.0425,-0.5352), vec3(0.4994,-0.6066,-0.6186), vec2(0.811,0.4814), vec2(0.835,0.5125), vec2(0.7827,0.4976), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3011,0.1501,-0.6216), vec3(0.304,0.0556,-0.5216), vec3(0.2312,0.1191,-0.6443), vec3(0.4775,-0.6317,-0.6107), vec2(0.79,0.5378), vec2(0.77,0.5044), vec2(0.8125,0.5249), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3011,0.1501,-0.6216), vec3(0.3752,0.1922,-0.5696), vec3(0.304,0.0556,-0.5216), vec3(0.6677,-0.5314,-0.5214), vec2(0.79,0.5378), vec2(0.7617,0.5498), vec2(0.77,0.5044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2696,0.0425,-0.5352), vec3(0.2312,0.1191,-0.6443), vec3(0.304,0.0556,-0.5216), vec3(0.4801,-0.6294,-0.6111), vec2(0.7827,0.4976), vec2(0.8125,0.5249), vec2(0.77,0.5044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.002,-0.0138,-0.5929), vec3(-0.0024,-0.0982,-0.4563), vec3(-0.1817,0.0468,-0.5974), vec3(-0.2638,-0.8202,-0.5077), vec2(0.8599,0.4399), vec2(0.8193,0.3926), vec2(0.811,0.4814), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.002,-0.0138,-0.5929), vec3(0.1755,0.0126,-0.5818), vec3(-0.0024,-0.0982,-0.4563), vec3(0.1571,-0.8403,-0.5188), vec2(0.8599,0.4399), vec2(0.811,0.4814), vec2(0.8193,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3683,0.101,-0.4802), vec3(0.304,0.0556,-0.5216), vec3(0.3752,0.1922,-0.5696), vec3(0.6911,-0.5323,-0.489), vec2(0.7471,0.5186), vec2(0.77,0.5044), vec2(0.7617,0.5498), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3752,0.1922,-0.5696), vec3(0.4512,0.2423,-0.5145), vec3(0.3683,0.101,-0.4802), vec3(0.6987,-0.5274,-0.4835), vec2(0.7617,0.5498), vec2(0.7329,0.563), vec2(0.7471,0.5186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2696,0.0425,-0.5352), vec3(0.17,-0.0817,-0.428), vec3(0.1755,0.0126,-0.5818), vec3(0.4655,-0.7619,-0.4504), vec2(0.7827,0.4976), vec2(0.7788,0.4385), vec2(0.811,0.4814), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.17,-0.0817,-0.428), vec3(-0.0024,-0.0982,-0.4563), vec3(0.1755,0.0126,-0.5818), vec3(0.1645,-0.8436,-0.5112), vec2(0.7788,0.4385), vec2(0.8193,0.3926), vec2(0.811,0.4814), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.304,0.0556,-0.5216), vec3(0.2923,-0.0302,-0.3743), vec3(0.2696,0.0425,-0.5352), vec3(0.4622,-0.7819,-0.4184), vec2(0.77,0.5044), vec2(0.7417,0.4658), vec2(0.7827,0.4976), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.304,0.0556,-0.5216), vec3(0.3683,0.101,-0.4802), vec3(0.2923,-0.0302,-0.3743), vec3(0.677,-0.6581,-0.3294), vec2(0.77,0.5044), vec2(0.7471,0.5186), vec2(0.7417,0.4658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2696,0.0425,-0.5352), vec3(0.2923,-0.0302,-0.3743), vec3(0.17,-0.0817,-0.428), vec3(0.5018,-0.7595,-0.4139), vec2(0.7827,0.4976), vec2(0.7417,0.4658), vec2(0.7788,0.4385), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4512,0.2423,-0.5145), vec3(0.4452,0.0862,-0.3316), vec3(0.3683,0.101,-0.4802), vec3(0.729,-0.5323,-0.4305), vec2(0.7329,0.563), vec2(0.7012,0.5083), vec2(0.7471,0.5186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3476,-0.0013,-0.338), vec3(0.2923,-0.0302,-0.3743), vec3(0.3683,0.101,-0.4802), vec3(0.6161,-0.6791,-0.3991), vec2(0.7241,0.478), vec2(0.7417,0.4658), vec2(0.7471,0.5186), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.17,-0.0817,-0.428), vec3(-0.0026,-0.1648,-0.2966), vec3(-0.0024,-0.0982,-0.4563), vec3(0.1497,-0.9125,-0.3808), vec2(0.7788,0.4385), vec2(0.7695,0.3516), vec2(0.8193,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3683,0.101,-0.4802), vec3(0.4452,0.0862,-0.3316), vec3(0.3476,-0.0013,-0.338), vec3(0.6282,-0.672,-0.3923), vec2(0.7471,0.5186), vec2(0.7012,0.5083), vec2(0.7241,0.478), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2923,-0.0302,-0.3743), vec3(0.1785,-0.1439,-0.2136), vec3(0.17,-0.0817,-0.428), vec3(0.4704,-0.8424,-0.2629), vec2(0.7417,0.4658), vec2(0.7344,0.4028), vec2(0.7788,0.4385), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.17,-0.0817,-0.428), vec3(0.1785,-0.1439,-0.2136), vec3(-0.0026,-0.1648,-0.2966), vec3(0.2358,-0.9308,-0.2792), vec2(0.7788,0.4385), vec2(0.7344,0.4028), vec2(0.7695,0.3516), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3476,-0.0013,-0.338), vec3(0.4452,0.0862,-0.3316), vec3(0.4121,0.0275,-0.2533), vec3(0.6546,-0.7113,-0.256), vec2(0.7241,0.478), vec2(0.7012,0.5083), vec2(0.6948,0.4858), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2923,-0.0302,-0.3743), vec3(0.3476,-0.0013,-0.338), vec3(0.2761,-0.1137,-0.1929), vec3(0.5868,-0.7542,-0.2948), vec2(0.7417,0.4658), vec2(0.7241,0.478), vec2(0.7168,0.4312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2761,-0.1137,-0.1929), vec3(0.1785,-0.1439,-0.2136), vec3(0.2923,-0.0302,-0.3743), vec3(0.3449,-0.8639,-0.367), vec2(0.7168,0.4312), vec2(0.7344,0.4028), vec2(0.7417,0.4658), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3476,-0.0013,-0.338), vec3(0.4121,0.0275,-0.2533), vec3(0.3363,-0.0808,-0.1616), vec3(0.6661,-0.6952,-0.2703), vec2(0.7241,0.478), vec2(0.6948,0.4858), vec2(0.6963,0.4434), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4121,0.0275,-0.2533), vec3(0.4452,0.0862,-0.3316), vec3(0.464,0.043,-0.1643), vec3(0.6532,-0.7122,-0.2573), vec2(0.6948,0.4858), vec2(0.7012,0.5083), vec2(0.6606,0.4844), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3363,-0.0808,-0.1616), vec3(0.2761,-0.1137,-0.1929), vec3(0.3476,-0.0013,-0.338), vec3(0.5741,-0.7597,-0.3053), vec2(0.6963,0.4434), vec2(0.7168,0.4312), vec2(0.7241,0.478), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.464,0.043,-0.1643), vec3(0.444,0.0225,-0.1403), vec3(0.4121,0.0275,-0.2533), vec3(0.5748,-0.7941,-0.1973), vec2(0.6606,0.4844), vec2(0.6626,0.4756), vec2(0.6948,0.4858), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4121,0.0275,-0.2533), vec3(0.444,0.0225,-0.1403), vec3(0.3363,-0.0808,-0.1616), vec3(0.6972,-0.6801,-0.2268), vec2(0.6948,0.4858), vec2(0.6626,0.4756), vec2(0.6963,0.4434), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2761,-0.1137,-0.1929), vec3(0.2615,-0.1579,-0.0845), vec3(0.1785,-0.1439,-0.2136), vec3(0.3407,-0.8858,-0.3152), vec2(0.7168,0.4312), vec2(0.707,0.4131), vec2(0.7344,0.4028), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.251,0.5632,-0.7519), 0.4545, bestT)) {
        if (triHit(ro, rd, vec3(0.1518,0.1808,-0.7416), vec3(0.1265,0.3339,-0.8588), vec3(0.2036,0.2082,-0.7252), vec3(0.4853,-0.4795,-0.7312), vec2(0.854,0.5461), vec2(0.8833,0.6074), vec2(0.8364,0.5576), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2036,0.2082,-0.7252), vec3(0.2017,0.3115,-0.7936), vec3(0.2808,0.2513,-0.7053), vec3(0.4619,-0.4841,-0.7432), vec2(0.8364,0.5576), vec2(0.8491,0.5974), vec2(0.8105,0.5745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1265,0.3339,-0.8588), vec3(0.1518,0.1808,-0.7416), vec3(-0.0004,0.3006,-0.8604), vec3(0.1627,-0.5827,-0.7962), vec2(0.8833,0.6074), vec2(0.854,0.5461), vec2(0.9282,0.5854), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2017,0.3115,-0.7936), vec3(0.2036,0.2082,-0.7252), vec3(0.1265,0.3339,-0.8588), vec3(0.491,-0.475,-0.7303), vec2(0.8491,0.5974), vec2(0.8364,0.5576), vec2(0.8833,0.6074), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2397,0.4009,-0.8224), vec3(0.2808,0.2513,-0.7053), vec3(0.2017,0.3115,-0.7936), vec3(0.4921,-0.4486,-0.7461), vec2(0.8418,0.6313), vec2(0.8105,0.5745), vec2(0.8491,0.5974), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3794,0.3789,-0.6561), vec3(0.2808,0.2513,-0.7053), vec3(0.2397,0.4009,-0.8224), vec3(0.7092,-0.3032,-0.6365), vec2(0.772,0.6128), vec2(0.8105,0.5745), vec2(0.8418,0.6313), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2017,0.3115,-0.7936), vec3(0.1265,0.3339,-0.8588), vec3(0.2397,0.4009,-0.8224), vec3(0.504,-0.4507,-0.7368), vec2(0.8491,0.5974), vec2(0.8833,0.6074), vec2(0.8418,0.6313), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1265,0.3339,-0.8588), vec3(-0.0004,0.3006,-0.8604), vec3(0.0006,0.4419,-0.9374), vec3(0.1353,-0.4749,-0.8696), vec2(0.8833,0.6074), vec2(0.9282,0.5854), vec2(0.939,0.6411), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1265,0.3339,-0.8588), vec3(0.111,0.456,-0.9155), vec3(0.2397,0.4009,-0.8224), vec3(0.4588,-0.3256,-0.8267), vec2(0.8833,0.6074), vec2(0.897,0.6543), vec2(0.8418,0.6313), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.111,0.456,-0.9155), vec3(0.1265,0.3339,-0.8588), vec3(0.0006,0.4419,-0.9374), vec3(0.2267,-0.3863,-0.8941), vec2(0.897,0.6543), vec2(0.8833,0.6074), vec2(0.939,0.6411), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2397,0.4009,-0.8224), vec3(0.3064,0.4799,-0.7739), vec3(0.3794,0.3789,-0.6561), vec3(0.7314,-0.2227,-0.6445), vec2(0.8418,0.6313), vec2(0.8096,0.6543), vec2(0.772,0.6128), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1808,0.5019,-0.8928), vec3(0.2397,0.4009,-0.8224), vec3(0.111,0.456,-0.9155), vec3(0.4694,-0.3044,-0.8289), vec2(0.8691,0.6699), vec2(0.8418,0.6313), vec2(0.897,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3794,0.3789,-0.6561), vec3(0.3064,0.4799,-0.7739), vec3(0.3986,0.529,-0.6161), vec3(0.8596,0.0264,-0.5102), vec2(0.772,0.6128), vec2(0.8096,0.6543), vec2(0.7461,0.657), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2397,0.4009,-0.8224), vec3(0.278,0.5228,-0.806), vec3(0.3064,0.4799,-0.7739), vec3(0.6661,-0.1103,-0.7376), vec2(0.8418,0.6313), vec2(0.8223,0.6716), vec2(0.8096,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2397,0.4009,-0.8224), vec3(0.1808,0.5019,-0.8928), vec3(0.278,0.5228,-0.806), vec3(0.6753,-0.1144,-0.7286), vec2(0.8418,0.6313), vec2(0.8691,0.6699), vec2(0.8223,0.6716), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3064,0.4799,-0.7739), vec3(0.278,0.5228,-0.806), vec3(0.3314,0.5979,-0.7118), vec3(0.8183,0.1223,-0.5616), vec2(0.8096,0.6543), vec2(0.8223,0.6716), vec2(0.7773,0.6902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1808,0.5019,-0.8928), vec3(0.111,0.456,-0.9155), vec3(0.0968,0.6448,-1.037), vec3(0.5231,-0.4333,-0.734), vec2(0.8691,0.6699), vec2(0.897,0.6543), vec2(0.9053,0.7095), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2401,0.5814,-0.8527), vec3(0.278,0.5228,-0.806), vec3(0.1808,0.5019,-0.8928), vec3(0.6761,-0.1398,-0.7234), vec2(0.8394,0.6953), vec2(0.8223,0.6716), vec2(0.8691,0.6699), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3314,0.5979,-0.7118), vec3(0.3986,0.529,-0.6161), vec3(0.3064,0.4799,-0.7739), vec3(0.8461,0.0967,-0.5242), vec2(0.7773,0.6902), vec2(0.7461,0.657), vec2(0.8096,0.6543), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1808,0.5019,-0.8928), vec3(0.0968,0.6448,-1.037), vec3(0.2401,0.5814,-0.8527), vec3(0.7317,-0.2209,-0.6449), vec2(0.8691,0.6699), vec2(0.9053,0.7095), vec2(0.8394,0.6953), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.278,0.5228,-0.806), vec3(0.2401,0.5814,-0.8527), vec3(0.3002,0.6339,-0.7543), vec3(0.8273,0.0929,-0.554), vec2(0.8223,0.6716), vec2(0.8394,0.6953), vec2(0.7944,0.7068), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3002,0.6339,-0.7543), vec3(0.3314,0.5979,-0.7118), vec3(0.278,0.5228,-0.806), vec3(0.8357,0.0859,-0.5424), vec2(0.7944,0.7068), vec2(0.7773,0.6902), vec2(0.8223,0.6716), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3986,0.529,-0.6161), vec3(0.3314,0.5979,-0.7118), vec3(0.3753,0.6524,-0.5607), vec3(0.8678,0.3308,-0.3708), vec2(0.7461,0.657), vec2(0.7773,0.6902), vec2(0.7202,0.6946), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3986,0.529,-0.6161), vec3(0.3753,0.6524,-0.5607), vec3(0.3982,0.6319,-0.5387), vec3(0.7923,0.3684,-0.4863), vec2(0.7461,0.657), vec2(0.7202,0.6946), vec2(0.7139,0.6836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2681,0.6718,-0.8043), vec3(0.3002,0.6339,-0.7543), vec3(0.2401,0.5814,-0.8527), vec3(0.8488,0.0201,-0.5283), vec2(0.813,0.7246), vec2(0.7944,0.7068), vec2(0.8394,0.6953), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1743,0.7017,-0.9883), vec3(0.2401,0.5814,-0.8527), vec3(0.0968,0.6448,-1.037), vec3(0.6718,-0.3613,-0.6466), vec2(0.8701,0.7329), vec2(0.8394,0.6953), vec2(0.9053,0.7095), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3002,0.6339,-0.7543), vec3(0.3107,0.7025,-0.6602), vec3(0.3314,0.5979,-0.7118), vec3(0.8713,0.3447,-0.3493), vec2(0.7944,0.7068), vec2(0.7549,0.7261), vec2(0.7773,0.6902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3107,0.7025,-0.6602), vec3(0.3753,0.6524,-0.5607), vec3(0.3314,0.5979,-0.7118), vec3(0.8559,0.3549,-0.3761), vec2(0.7549,0.7261), vec2(0.7202,0.6946), vec2(0.7773,0.6902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2401,0.5814,-0.8527), vec3(0.1743,0.7017,-0.9883), vec3(0.2681,0.6718,-0.8043), vec3(0.8885,-0.0299,-0.4579), vec2(0.8394,0.6953), vec2(0.8701,0.7329), vec2(0.813,0.7246), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3753,0.6524,-0.5607), vec3(0.3097,0.7438,-0.4931), vec3(0.3982,0.6319,-0.5387), vec3(0.7395,0.6525,-0.1655), vec2(0.7202,0.6946), vec2(0.6914,0.731), vec2(0.7139,0.6836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3002,0.6339,-0.7543), vec3(0.2681,0.6718,-0.8043), vec3(0.2673,0.7589,-0.7441), vec3(0.8906,0.264,-0.3703), vec2(0.7944,0.7068), vec2(0.813,0.7246), vec2(0.7852,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3566,0.7187,-0.4033), vec3(0.3982,0.6319,-0.5387), vec3(0.3097,0.7438,-0.4931), vec3(0.7283,0.6564,-0.1967), vec2(0.6636,0.7075), vec2(0.7139,0.6836), vec2(0.6914,0.731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3002,0.6339,-0.7543), vec3(0.2673,0.7589,-0.7441), vec3(0.3107,0.7025,-0.6602), vec3(0.9175,0.2651,-0.2964), vec2(0.7944,0.7068), vec2(0.7852,0.755), vec2(0.7549,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3097,0.7438,-0.4931), vec3(0.3753,0.6524,-0.5607), vec3(0.3107,0.7025,-0.6602), vec3(0.7446,0.6491,-0.1559), vec2(0.6914,0.731), vec2(0.7202,0.6946), vec2(0.7549,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.211,0.772,-0.9182), vec3(0.2681,0.6718,-0.8043), vec3(0.1743,0.7017,-0.9883), vec3(0.8901,-0.0106,-0.4556), vec2(0.8408,0.7628), vec2(0.813,0.7246), vec2(0.8701,0.7329), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2681,0.6718,-0.8043), vec3(0.211,0.772,-0.9182), vec3(0.2673,0.7589,-0.7441), vec3(0.9353,0.2069,-0.287), vec2(0.813,0.7246), vec2(0.8408,0.7628), vec2(0.7852,0.755), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2615,0.8003,-0.601), vec3(0.3097,0.7438,-0.4931), vec3(0.3107,0.7025,-0.6602), vec3(0.8559,0.5033,-0.1193), vec2(0.7285,0.7654), vec2(0.6914,0.731), vec2(0.7549,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3097,0.7438,-0.4931), vec3(0.229,0.815,-0.436), vec3(0.3566,0.7187,-0.4033), vec3(0.6159,0.781,-0.1033), vec2(0.6914,0.731), vec2(0.6626,0.7659), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2673,0.7589,-0.7441), vec3(0.2233,0.8479,-0.6852), vec3(0.3107,0.7025,-0.6602), vec3(0.8599,0.4985,-0.1095), vec2(0.7852,0.755), vec2(0.7583,0.7926), vec2(0.7549,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2615,0.8003,-0.601), vec3(0.3107,0.7025,-0.6602), vec3(0.2233,0.8479,-0.6852), vec3(0.86,0.4987,-0.1084), vec2(0.7285,0.7654), vec2(0.7549,0.7261), vec2(0.7583,0.7926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2125,0.8801,-0.8587), vec3(0.2673,0.7589,-0.7441), vec3(0.211,0.772,-0.9182), vec3(0.9441,0.1491,-0.2942), vec2(0.8188,0.809), vec2(0.7852,0.755), vec2(0.8408,0.7628), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1806,0.8686,-0.5424), vec3(0.3097,0.7438,-0.4931), vec3(0.2615,0.8003,-0.601), vec3(0.6765,0.732,0.0807), vec2(0.6973,0.8024), vec2(0.6914,0.731), vec2(0.7285,0.7654), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2233,0.8479,-0.6852), vec3(0.2673,0.7589,-0.7441), vec3(0.2125,0.8801,-0.8587), vec3(0.9021,0.431,0.024), vec2(0.7583,0.7926), vec2(0.7852,0.755), vec2(0.8188,0.809), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.0309,-0.0556,0.9238), 0.4993, bestT)) {
        if (triHit(ro, rd, vec3(0.2388,-0.0725,0.7609), vec3(0.2353,-0.0786,0.5352), vec3(0.3061,-0.0694,0.574), vec3(0.115,-0.9931,0.025), vec2(0.3655,0.2837), vec2(0.4553,0.3228), vec2(0.4319,0.3452), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2353,-0.0786,0.5352), vec3(0.2388,-0.0725,0.7609), vec3(0.0717,-0.1093,0.5787), vec3(0.1902,-0.9815,0.0235), vec2(0.4553,0.3228), vec2(0.3655,0.2837), vec2(0.4705,0.2559), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.264,-0.0559,0.7477), vec3(0.3061,-0.0694,0.574), vec3(0.3091,0.002,0.6005), vec3(0.9611,-0.1307,0.2433), vec2(0.3652,0.3052), vec2(0.4319,0.3452), vec2(0.4148,0.3696), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0717,-0.1093,0.5787), vec3(0.0931,-0.0775,0.7534), vec3(0.0012,-0.113,0.6026), vec3(0.1084,-0.9803,0.165), vec2(0.4705,0.2559), vec2(0.4097,0.2319), vec2(0.4744,0.23), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.279,0.1476,0.6091), vec3(0.22,0.0366,0.7821), vec3(0.3091,0.002,0.6005), vec3(0.8979,0.161,0.4098), vec2(0.3831,0.9792), vec2(0.4282,0.8768), vec2(0.468,0.9855), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.279,0.1476,0.6091), vec3(0.1754,0.2175,0.6552), vec3(0.1432,0.1224,0.8171), vec3(0.6267,0.6112,0.4835), vec2(0.3831,0.9792), vec2(0.3232,0.9353), vec2(0.3716,0.8473), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2388,-0.0725,0.7609), vec3(0.3061,-0.0694,0.574), vec3(0.264,-0.0559,0.7477), vec3(0.6129,-0.7623,0.208), vec2(0.3655,0.2837), vec2(0.4319,0.3452), vec2(0.3652,0.3052), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0931,-0.0775,0.7534), vec3(0.0717,-0.1093,0.5787), vec3(0.2388,-0.0725,0.7609), vec3(0.0245,-0.9841,0.1759), vec2(0.4097,0.2319), vec2(0.4705,0.2559), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1309,0.0832,0.7866), vec3(0.1754,0.2175,0.6552), vec3(0.006,0.2364,0.6523), vec3(0.064,0.6871,0.7237), vec2(0.2795,0.3838), vec2(0.3335,0.4575), vec2(0.2681,0.4941), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0012,-0.113,0.6026), vec3(0.0931,-0.0775,0.7534), vec3(0.0023,-0.0847,0.7533), vec3(0.0781,-0.9799,0.1833), vec2(0.4744,0.23), vec2(0.4097,0.2319), vec2(0.4326,0.2061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0023,-0.0847,0.7533), vec3(-0.0884,-0.0756,0.7542), vec3(0.0012,-0.113,0.6026), vec3(-0.0971,-0.9781,0.1841), vec2(0.4326,0.2061), vec2(0.4097,0.2319), vec2(0.4744,0.23), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.264,-0.0559,0.7477), vec3(0.3091,0.002,0.6005), vec3(0.22,0.0366,0.7821), vec3(0.8823,0.2779,0.3798), vec2(0.4939,0.896), vec2(0.468,0.9855), vec2(0.4282,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1432,0.1224,0.8171), vec3(0.22,0.0366,0.7821), vec3(0.279,0.1476,0.6091), vec3(0.7281,0.4365,0.5285), vec2(0.3716,0.8473), vec2(0.4282,0.8768), vec2(0.3831,0.9792), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1309,0.0832,0.7866), vec3(0.006,0.2364,0.6523), vec3(0.0058,0.1082,0.8034), vec3(0.2329,0.7417,0.629), vec2(0.2795,0.3838), vec2(0.2681,0.4941), vec2(0.2196,0.418), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0058,0.1082,0.8034), vec3(0.006,0.2364,0.6523), vec3(-0.1229,0.086,0.7875), vec3(-0.2073,0.7464,0.6324), vec2(0.2196,0.418), vec2(0.2681,0.4941), vec2(0.2795,0.3838), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1309,0.0832,0.7866), vec3(0.1432,0.1224,0.8171), vec3(0.1754,0.2175,0.6552), vec3(-0.9518,0.3067,-0.009), vec2(0.3491,0.8347), vec2(0.3716,0.8473), vec2(0.3232,0.9353), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2388,-0.0725,0.7609), vec3(0.264,-0.0559,0.7477), vec3(0.2091,-0.0811,0.8513), vec3(0.5896,-0.7991,0.1176), vec2(0.3655,0.2837), vec2(0.3652,0.3052), vec2(0.2981,0.2656), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2037,-0.0768,0.853), vec3(-0.256,-0.051,0.751), vec3(-0.231,-0.0682,0.764), vec3(-0.5978,-0.7946,0.1059), vec2(0.2981,0.2656), vec2(0.3652,0.3052), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0931,-0.0775,0.7534), vec3(0.1065,-0.1045,0.8936), vec3(0.0023,-0.0847,0.7533), vec3(0.0784,-0.9774,-0.1962), vec2(0.4097,0.2319), vec2(0.3682,0.1938), vec2(0.4326,0.2061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0884,-0.0756,0.7542), vec3(0.0023,-0.0847,0.7533), vec3(-0.1008,-0.1024,0.8946), vec3(-0.1006,-0.9756,-0.1953), vec2(0.4097,0.2319), vec2(0.4326,0.2061), vec2(0.3682,0.1938), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0931,-0.0775,0.7534), vec3(0.2388,-0.0725,0.7609), vec3(0.1065,-0.1045,0.8936), vec3(0.0434,-0.9802,-0.1934), vec2(0.4097,0.2319), vec2(0.3655,0.2837), vec2(0.3682,0.1938), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1008,-0.1024,0.8946), vec3(-0.231,-0.0682,0.764), vec3(-0.0884,-0.0756,0.7542), vec3(-0.0641,-0.9791,-0.1928), vec2(0.3682,0.1938), vec2(0.3655,0.2837), vec2(0.4097,0.2319), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.22,0.0366,0.7821), vec3(0.1813,-0.1017,0.9688), vec3(0.264,-0.0559,0.7477), vec3(0.8806,0.2747,0.3862), vec2(0.4282,0.8768), vec2(0.4639,0.782), vec2(0.4939,0.896), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.256,-0.051,0.751), vec3(-0.1759,-0.0979,0.9701), vec3(-0.213,0.0413,0.7837), vec3(-0.8823,0.276,0.3814), vec2(0.4939,0.896), vec2(0.4639,0.782), vec2(0.4282,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0023,-0.0847,0.7533), vec3(0.1065,-0.1045,0.8936), vec3(0.003,-0.1055,0.9185), vec3(-0.0206,-0.992,-0.1247), vec2(0.4326,0.2061), vec2(0.3682,0.1938), vec2(0.3975,0.1587), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.003,-0.1055,0.9185), vec3(-0.1008,-0.1024,0.8946), vec3(0.0023,-0.0847,0.7533), vec3(-0.001,-0.9922,-0.1248), vec2(0.3975,0.1587), vec2(0.3682,0.1938), vec2(0.4326,0.2061), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2091,-0.0811,0.8513), vec3(0.264,-0.0559,0.7477), vec3(0.1813,-0.1017,0.9688), vec3(0.2256,-0.9673,-0.1161), vec2(0.4875,0.8381), vec2(0.4939,0.896), vec2(0.4639,0.782), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2037,-0.0768,0.853), vec3(-0.1759,-0.0979,0.9701), vec3(-0.256,-0.051,0.751), vec3(-0.2524,-0.961,-0.1132), vec2(0.4875,0.8381), vec2(0.4639,0.782), vec2(0.4939,0.896), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1432,0.1224,0.8171), vec3(0.1208,0.0201,0.9958), vec3(0.22,0.0366,0.7821), vec3(0.7589,0.5195,0.3926), vec2(0.3716,0.8473), vec2(0.4146,0.7875), vec2(0.4282,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1341,0.1254,0.8181), vec3(-0.213,0.0413,0.7837), vec3(-0.1127,0.0226,0.9966), vec3(-0.7447,0.5357,0.3981), vec2(0.3716,0.8473), vec2(0.4282,0.8768), vec2(0.4146,0.7875), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1432,0.1224,0.8171), vec3(0.1309,0.0832,0.7866), vec3(0.1208,0.0201,0.9958), vec3(-0.961,0.2741,0.0366), vec2(0.3716,0.8473), vec2(0.3491,0.8347), vec2(0.4146,0.7875), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1341,0.1254,0.8181), vec3(-0.1127,0.0226,0.9966), vec3(-0.1229,0.086,0.7875), vec3(0.9669,0.2534,0.0298), vec2(0.3716,0.8473), vec2(0.4146,0.7875), vec2(0.3491,0.8347), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1309,0.0832,0.7866), vec3(0.2091,-0.0811,0.8513), vec3(0.1084,-0.021,0.9954), vec3(-0.7905,-0.5098,-0.3395), vec2(0.3491,0.8347), vec2(0.3521,0.7383), vec2(0.4136,0.7742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1229,0.086,0.7875), vec3(-0.1011,-0.0187,0.9962), vec3(-0.2037,-0.0768,0.853), vec3(0.7781,-0.5253,-0.3445), vec2(0.3491,0.8347), vec2(0.4136,0.7742), vec2(0.3521,0.7383), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1621,-0.0524,0.9835), vec3(0.1813,-0.1017,0.9688), vec3(0.22,0.0366,0.7821), vec3(0.8995,0.2405,0.3648), vec2(0.4417,0.7867), vec2(0.4639,0.782), vec2(0.4282,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1556,-0.049,0.9846), vec3(-0.213,0.0413,0.7837), vec3(-0.1759,-0.0979,0.9701), vec3(-0.8913,0.2601,0.3714), vec2(0.4417,0.7867), vec2(0.4282,0.8768), vec2(0.4639,0.782), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1621,-0.0524,0.9835), vec3(0.22,0.0366,0.7821), vec3(0.1208,0.0201,0.9958), vec3(0.82,0.3978,0.4115), vec2(0.4417,0.7867), vec2(0.4282,0.8768), vec2(0.4146,0.7875), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1556,-0.049,0.9846), vec3(-0.1127,0.0226,0.9966), vec3(-0.213,0.0413,0.7837), vec3(-0.8082,0.4154,0.4174), vec2(0.4417,0.7867), vec2(0.4146,0.7875), vec2(0.4282,0.8768), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2037,-0.0768,0.853), vec3(-0.231,-0.0682,0.764), vec3(-0.2484,-0.1895,1.1528), vec3(-0.5082,0.8284,0.2357), vec2(0.2981,0.2656), vec2(0.3655,0.2837), vec2(0.1605,0.1201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1693,-0.0954,0.9499), vec3(0.2091,-0.0811,0.8513), vec3(0.1813,-0.1017,0.9688), vec3(-0.176,-0.9617,-0.2102), vec2(0.4736,0.7832), vec2(0.4875,0.8381), vec2(0.4639,0.782), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2091,-0.0811,0.8513), vec3(0.256,-0.1857,1.158), vec3(0.2388,-0.0725,0.7609), vec3(0.4419,0.8676,0.2281), vec2(0.2981,0.2656), vec2(0.1605,0.1201), vec2(0.3655,0.2837), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1639,-0.0918,0.9511), vec3(-0.1759,-0.0979,0.9701), vec3(-0.2037,-0.0768,0.853), vec3(0.1549,-0.9652,-0.2106), vec2(0.4736,0.7832), vec2(0.4639,0.782), vec2(0.4875,0.8381), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1208,0.0201,0.9958), vec3(0.1309,0.0832,0.7866), vec3(0.1084,-0.021,0.9954), vec3(-0.9562,0.2896,0.0415), vec2(0.4146,0.7875), vec2(0.3491,0.8347), vec2(0.4136,0.7742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1229,0.086,0.7875), vec3(-0.121,-0.1573,1.1871), vec3(0.0058,0.1082,0.8034), vec3(-0.2075,0.8352,0.5094), vec2(0.2795,0.3838), vec2(0.0988,0.1636), vec2(0.2196,0.418), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1127,0.0226,0.9966), vec3(-0.1011,-0.0187,0.9962), vec3(-0.1229,0.086,0.7875), vec3(0.9626,0.2687,0.0346), vec2(0.4146,0.7875), vec2(0.4136,0.7742), vec2(0.3491,0.8347), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1309,0.0832,0.7866), vec3(0.0058,0.1082,0.8034), vec3(0.1305,-0.1534,1.1912), vec3(0.2338,0.8392,0.491), vec2(0.2795,0.3838), vec2(0.2196,0.418), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1693,-0.0954,0.9499), vec3(0.1084,-0.021,0.9954), vec3(0.2091,-0.0811,0.8513), vec3(-0.815,-0.4277,-0.391), vec2(0.3992,0.7432), vec2(0.4136,0.7742), vec2(0.3521,0.7383), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1639,-0.0918,0.9511), vec3(-0.2037,-0.0768,0.853), vec3(-0.1011,-0.0187,0.9962), vec3(0.803,-0.4469,-0.3941), vec2(0.3992,0.7432), vec2(0.3521,0.7383), vec2(0.4136,0.7742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.2037,-0.0768,0.853), vec3(-0.121,-0.1573,1.1871), vec3(-0.1229,0.086,0.7875), vec3(-0.7901,0.522,0.3214), vec2(0.2981,0.2656), vec2(0.0988,0.1636), vec2(0.2795,0.3838), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2091,-0.0811,0.8513), vec3(0.1309,0.0832,0.7866), vec3(0.1305,-0.1534,1.1912), vec3(0.8126,0.5028,0.2948), vec2(0.2981,0.2656), vec2(0.2795,0.3838), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1813,-0.1017,0.9688), vec3(0.1389,-0.109,1.0351), vec3(0.1693,-0.0954,0.9499), vec3(-0.1699,-0.9619,-0.2142), vec2(0.4639,0.782), vec2(0.4468,0.7572), vec2(0.4736,0.7832), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1759,-0.0979,0.9701), vec3(-0.1639,-0.0918,0.9511), vec3(-0.1333,-0.1061,1.0361), vec3(0.1476,-0.9653,-0.2152), vec2(0.4639,0.782), vec2(0.4736,0.7832), vec2(0.4468,0.7572), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1084,-0.021,0.9954), vec3(0.1693,-0.0954,0.9499), vec3(0.1246,-0.0879,1.0441), vec3(-0.8184,-0.454,-0.3524), vec2(0.4136,0.7742), vec2(0.3992,0.7432), vec2(0.4353,0.7614), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1011,-0.0187,0.9962), vec3(-0.1184,-0.0853,1.045), vec3(-0.1639,-0.0918,0.9511), vec3(0.8058,-0.4716,-0.358), vec2(0.4136,0.7742), vec2(0.4353,0.7614), vec2(0.3992,0.7432), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1813,-0.1017,0.9688), vec3(0.1621,-0.0524,0.9835), vec3(0.1509,-0.1154,1.0541), vec3(0.9011,0.2428,0.3592), vec2(0.4639,0.782), vec2(0.4417,0.7867), vec2(0.4436,0.7645), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1759,-0.0979,0.9701), vec3(-0.1453,-0.1122,1.0551), vec3(-0.1556,-0.049,0.9846), vec3(-0.8929,0.2623,0.366), vec2(0.4639,0.782), vec2(0.4436,0.7645), vec2(0.4417,0.7867), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1389,-0.109,1.0351), vec3(0.1246,-0.0879,1.0441), vec3(0.1693,-0.0954,0.9499), vec3(-0.8345,-0.4143,-0.3632), vec2(0.4355,0.752), vec2(0.4353,0.7614), vec2(0.3992,0.7432), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1333,-0.1061,1.0361), vec3(-0.1639,-0.0918,0.9511), vec3(-0.1184,-0.0853,1.045), vec3(0.8227,-0.4325,-0.3689), vec2(0.4355,0.752), vec2(0.3992,0.7432), vec2(0.4353,0.7614), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1366,-0.0943,1.0631), vec3(0.1621,-0.0524,0.9835), vec3(0.1208,0.0201,0.9958), vec3(0.8033,0.3804,0.4583), vec2(0.4399,0.764), vec2(0.4417,0.7867), vec2(0.4146,0.7875), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1127,0.0226,0.9966), vec3(-0.1556,-0.049,0.9846), vec3(-0.1304,-0.0914,1.064), vec3(-0.7915,0.3976,0.4641), vec2(0.4146,0.7875), vec2(0.4417,0.7867), vec2(0.4399,0.764), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1084,-0.021,0.9954), vec3(0.1366,-0.0943,1.0631), vec3(0.1208,0.0201,0.9958), vec3(-0.7824,0.2325,0.5778), vec2(0.4136,0.7742), vec2(0.4399,0.764), vec2(0.4146,0.7875), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1011,-0.0187,0.9962), vec3(-0.1127,0.0226,0.9966), vec3(-0.1304,-0.0914,1.064), vec3(0.7916,0.2152,0.5718), vec2(0.4136,0.7742), vec2(0.4146,0.7875), vec2(0.4399,0.764), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1389,-0.109,1.0351), vec3(0.1813,-0.1017,0.9688), vec3(0.1509,-0.1154,1.0541), vec3(-0.1697,-0.962,-0.2141), vec2(0.4468,0.7572), vec2(0.4639,0.782), vec2(0.4436,0.7645), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1453,-0.1122,1.0551), vec3(-0.1759,-0.0979,0.9701), vec3(-0.1333,-0.1061,1.0361), vec3(0.1488,-0.965,-0.2159), vec2(0.4436,0.7645), vec2(0.4639,0.782), vec2(0.4468,0.7572), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1065,-0.1045,0.8936), vec3(0.1273,-0.1945,1.2693), vec3(0.003,-0.1055,0.9185), vec3(-0.0462,-0.9721,-0.2301), vec2(0.3682,0.1938), vec2(0.2598,0.0532), vec2(0.3975,0.1587), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1008,-0.1024,0.8946), vec3(0.003,-0.1055,0.9185), vec3(-0.119,-0.192,1.2706), vec3(0.0239,-0.9728,-0.2305), vec2(0.3682,0.1938), vec2(0.3975,0.1587), vec2(0.2598,0.0532), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1366,-0.0943,1.0631), vec3(0.1509,-0.1154,1.0541), vec3(0.1621,-0.0524,0.9835), vec3(0.8144,0.363,0.4527), vec2(0.4399,0.764), vec2(0.4436,0.7645), vec2(0.4417,0.7867), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1246,-0.0879,1.0441), vec3(0.1366,-0.0943,1.0631), vec3(0.1084,-0.021,0.9954), vec3(-0.7863,0.2278,0.5743), vec2(0.4353,0.7614), vec2(0.4399,0.764), vec2(0.4136,0.7742), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1304,-0.0914,1.064), vec3(-0.1556,-0.049,0.9846), vec3(-0.1453,-0.1122,1.0551), vec3(-0.8032,0.3802,0.4586), vec2(0.4399,0.764), vec2(0.4417,0.7867), vec2(0.4436,0.7645), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1184,-0.0853,1.045), vec3(-0.1011,-0.0187,0.9962), vec3(-0.1304,-0.0914,1.064), vec3(0.7957,0.21,0.5681), vec2(0.4353,0.7614), vec2(0.4136,0.7742), vec2(0.4399,0.764), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1246,-0.0879,1.0441), vec3(0.1389,-0.109,1.0351), vec3(0.1509,-0.1154,1.0541), vec3(-0.7414,-0.6174,0.2631), vec2(0.4353,0.7614), vec2(0.4468,0.7572), vec2(0.4436,0.7645), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1453,-0.1122,1.0551), vec3(-0.1333,-0.1061,1.0361), vec3(-0.1184,-0.0853,1.045), vec3(0.7301,-0.6334,0.2563), vec2(0.4436,0.7645), vec2(0.4468,0.7572), vec2(0.4353,0.7614), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1246,-0.0879,1.0441), vec3(0.1509,-0.1154,1.0541), vec3(0.1366,-0.0943,1.0631), vec3(-0.7414,-0.6177,0.2621), vec2(0.4353,0.7614), vec2(0.4436,0.7645), vec2(0.4399,0.764), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1304,-0.0914,1.064), vec3(-0.1453,-0.1122,1.0551), vec3(-0.1184,-0.0853,1.045), vec3(0.7301,-0.6334,0.2563), vec2(0.4399,0.764), vec2(0.4436,0.7645), vec2(0.4353,0.7614), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.121,-0.1573,1.1871), vec3(-0.2037,-0.0768,0.853), vec3(-0.2484,-0.1895,1.1528), vec3(-0.3079,0.9048,0.2943), vec2(0.0988,0.1636), vec2(0.2981,0.2656), vec2(0.1605,0.1201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.256,-0.1857,1.158), vec3(0.2091,-0.0811,0.8513), vec3(0.1305,-0.1534,1.1912), vec3(0.3052,0.9146,0.2651), vec2(0.1605,0.1201), vec2(0.2981,0.2656), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0075,-0.1377,1.218), vec3(0.0058,0.1082,0.8034), vec3(-0.121,-0.1573,1.1871), vec3(-0.2463,0.8332,0.4952), vec2(0.0361,0.2051), vec2(0.2196,0.418), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0075,-0.1377,1.218), vec3(0.1305,-0.1534,1.1912), vec3(0.0058,0.1082,0.8034), vec3(0.2158,0.8402,0.4975), vec2(0.0361,0.2051), vec2(0.0988,0.1636), vec2(0.2196,0.418), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1273,-0.1945,1.2693), vec3(0.0042,-0.1977,1.2896), vec3(0.003,-0.1055,0.9185), vec3(-0.014,-0.9704,-0.2411), vec2(0.2598,0.0532), vec2(0.3057,0.0132), vec2(0.3975,0.1587), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0042,-0.1977,1.2896), vec3(-0.119,-0.192,1.2706), vec3(0.003,-0.1055,0.9185), vec3(-0.0083,-0.9705,-0.2411), vec2(0.3057,0.0132), vec2(0.2598,0.0532), vec2(0.3975,0.1587), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.121,-0.1573,1.1871), vec3(-0.2484,-0.1895,1.1528), vec3(-0.119,-0.192,1.2706), vec3(-0.32,0.8722,0.3699), vec2(0.0988,0.1636), vec2(0.1605,0.1201), vec2(0.0641,0.1128), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1273,-0.1945,1.2693), vec3(0.256,-0.1857,1.158), vec3(0.1305,-0.1534,1.1912), vec3(0.3322,0.8292,0.4495), vec2(0.0641,0.1128), vec2(0.1605,0.1201), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0075,-0.1377,1.218), vec3(-0.121,-0.1573,1.1871), vec3(0.0042,-0.1977,1.2896), vec3(-0.2613,0.7453,0.6134), vec2(0.0361,0.2051), vec2(0.0988,0.1636), vec2(-0.0063,0.1499), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0042,-0.1977,1.2896), vec3(0.1305,-0.1534,1.1912), vec3(0.0075,-0.1377,1.218), vec3(0.2321,0.74,0.6313), vec2(-0.0063,0.1499), vec2(0.0988,0.1636), vec2(0.0361,0.2051), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.119,-0.192,1.2706), vec3(0.0042,-0.1977,1.2896), vec3(-0.121,-0.1573,1.1871), vec3(-0.0158,0.9234,0.3835), vec2(0.0641,0.1128), vec2(-0.0063,0.1499), vec2(0.0988,0.1636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1273,-0.1945,1.2693), vec3(0.1305,-0.1534,1.1912), vec3(0.0042,-0.1977,1.2896), vec3(0.0534,0.883,0.4663), vec2(0.0641,0.1128), vec2(0.0988,0.1636), vec2(-0.0063,0.1499), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.2805,-0.0005,0.2096), 0.5813, bestT)) {
        if (triHit(ro, rd, vec3(0.3008,-0.1385,-0.0459), vec3(0.2761,-0.1137,-0.1929), vec3(0.3363,-0.0808,-0.1616), vec3(0.5559,-0.7992,-0.2287), vec2(0.6943,0.4199), vec2(0.7168,0.4312), vec2(0.6963,0.4434), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.444,0.0225,-0.1403), vec3(0.3639,-0.065,-0.0736), vec3(0.3363,-0.0808,-0.1616), vec3(0.6987,-0.7095,-0.0919), vec2(0.6626,0.4756), vec2(0.6709,0.4399), vec2(0.6963,0.4434), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1785,-0.1439,-0.2136), vec3(0.1971,-0.1697,-0.0176), vec3(0.1265,-0.1703,-0.1156), vec3(0.2123,-0.966,-0.1478), vec2(0.7344,0.4028), vec2(0.7144,0.3921), vec2(0.7188,0.3711), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3008,-0.1385,-0.0459), vec3(0.2615,-0.1579,-0.0845), vec3(0.2761,-0.1137,-0.1929), vec3(0.6019,-0.7645,-0.2306), vec2(0.6943,0.4199), vec2(0.707,0.4131), vec2(0.7168,0.4312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1971,-0.1697,-0.0176), vec3(0.1785,-0.1439,-0.2136), vec3(0.2615,-0.1579,-0.0845), vec3(0.0425,-0.99,-0.1348), vec2(0.7144,0.3921), vec2(0.7344,0.4028), vec2(0.707,0.4131), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.464,0.043,-0.1643), vec3(0.4487,0.0283,0.0012), vec3(0.444,0.0225,-0.1403), vec3(0.7173,-0.6968,0.0044), vec2(0.6606,0.4844), vec2(0.6196,0.4609), vec2(0.6626,0.4756), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3363,-0.0808,-0.1616), vec3(0.3639,-0.065,-0.0736), vec3(0.3008,-0.1385,-0.0459), vec3(0.7338,-0.6704,-0.1099), vec2(0.6963,0.4434), vec2(0.6709,0.4399), vec2(0.6943,0.4199), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.444,0.0225,-0.1403), vec3(0.428,0.015,0.0041), vec3(0.3639,-0.065,-0.0736), vec3(0.7554,-0.6534,0.0499), vec2(0.6626,0.4756), vec2(0.626,0.4536), vec2(0.6709,0.4399), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4487,0.0283,0.0012), vec3(0.464,0.043,-0.1643), vec3(0.5254,0.1619,0.0118), vec3(0.8655,-0.4996,0.0356), vec2(0.6196,0.4609), vec2(0.6606,0.4844), vec2(0.6001,0.5044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.428,0.015,0.0041), vec3(0.444,0.0225,-0.1403), vec3(0.4487,0.0283,0.0012), vec3(0.5397,-0.8417,0.0162), vec2(0.626,0.4536), vec2(0.6626,0.4756), vec2(0.6196,0.4609), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3217,-0.1141,-0.0041), vec3(0.3008,-0.1385,-0.0459), vec3(0.3639,-0.065,-0.0736), vec3(0.7596,-0.6504,0.0017), vec2(0.6792,0.4209), vec2(0.6943,0.4199), vec2(0.6709,0.4399), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1094,-0.1629,-0.0349), vec3(0.1265,-0.1703,-0.1156), vec3(0.1648,-0.1417,0.0602), vec3(0.1635,-0.9788,0.1235), vec2(0.6943,0.3525), vec2(0.7188,0.3711), vec2(0.6885,0.3687), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1971,-0.1697,-0.0176), vec3(0.1648,-0.1417,0.0602), vec3(0.1265,-0.1703,-0.1156), vec3(-0.2909,-0.9323,0.215), vec2(0.7144,0.3921), vec2(0.6885,0.3687), vec2(0.7188,0.3711), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2633,-0.1723,0.0648), vec3(0.2615,-0.1579,-0.0845), vec3(0.3008,-0.1385,-0.0459), vec3(0.5083,-0.8565,-0.0892), vec2(0.6885,0.4004), vec2(0.707,0.4131), vec2(0.6943,0.4199), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3639,-0.065,-0.0736), vec3(0.3504,-0.0587,0.0148), vec3(0.3217,-0.1141,-0.0041), vec3(0.8512,-0.4983,0.165), vec2(0.6709,0.4399), vec2(0.6499,0.4253), vec2(0.6792,0.4209), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3504,-0.0587,0.0148), vec3(0.3639,-0.065,-0.0736), vec3(0.428,0.015,0.0041), vec3(0.692,-0.705,0.1553), vec2(0.6499,0.4253), vec2(0.6709,0.4399), vec2(0.626,0.4536), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2376,-0.1797,0.0582), vec3(0.1971,-0.1697,-0.0176), vec3(0.2615,-0.1579,-0.0845), vec3(0.0309,-0.9888,-0.1457), vec2(0.6938,0.3955), vec2(0.7144,0.3921), vec2(0.707,0.4131), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3008,-0.1385,-0.0459), vec3(0.3217,-0.1141,-0.0041), vec3(0.2633,-0.1723,0.0648), vec3(0.7279,-0.6847,0.0376), vec2(0.6943,0.4199), vec2(0.6792,0.4209), vec2(0.6885,0.4004), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.107,-0.1245,0.062), vec3(-0.0019,-0.162,-0.0109), vec3(0.1094,-0.1629,-0.0349), vec3(0.0716,-0.9263,0.37), vec2(0.6577,0.3379), vec2(0.6729,0.3022), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2633,-0.1723,0.0648), vec3(0.2376,-0.1797,0.0582), vec3(0.2615,-0.1579,-0.0845), vec3(0.2954,-0.9506,-0.0957), vec2(0.6885,0.4004), vec2(0.6938,0.3955), vec2(0.707,0.4131), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3051,-0.0943,0.0609), vec3(0.3217,-0.1141,-0.0041), vec3(0.3504,-0.0587,0.0148), vec3(0.7737,-0.5237,0.3566), vec2(0.6606,0.4077), vec2(0.6792,0.4209), vec2(0.6499,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3504,-0.0587,0.0148), vec3(0.428,0.015,0.0041), vec3(0.3085,-0.0605,0.0904), vec3(0.6694,-0.6522,0.3557), vec2(0.6499,0.4253), vec2(0.626,0.4536), vec2(0.6328,0.4023), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2376,-0.1797,0.0582), vec3(0.2188,-0.1635,0.075), vec3(0.1971,-0.1697,-0.0176), vec3(-0.5428,-0.8198,0.1824), vec2(0.6938,0.3955), vec2(0.6895,0.3877), vec2(0.7144,0.3921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2188,-0.1635,0.075), vec3(0.1648,-0.1417,0.0602), vec3(0.1971,-0.1697,-0.0176), vec3(-0.406,-0.9005,0.1557), vec2(0.6895,0.3877), vec2(0.6885,0.3687), vec2(0.7144,0.3921), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2685,-0.1505,0.0818), vec3(0.3217,-0.1141,-0.0041), vec3(0.3051,-0.0943,0.0609), vec3(0.8407,-0.4197,0.3421), vec2(0.6812,0.3989), vec2(0.6792,0.4209), vec2(0.6606,0.4077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2633,-0.1723,0.0648), vec3(0.3217,-0.1141,-0.0041), vec3(0.2685,-0.1505,0.0818), vec3(0.8321,-0.4503,0.3238), vec2(0.6885,0.4004), vec2(0.6792,0.4209), vec2(0.6812,0.3989), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1648,-0.1417,0.0602), vec3(0.1645,-0.0842,0.1205), vec3(0.1094,-0.1629,-0.0349), vec3(-0.6706,-0.538,0.5107), vec2(0.6885,0.3687), vec2(0.6538,0.3569), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1645,-0.0842,0.1205), vec3(0.107,-0.1245,0.062), vec3(0.1094,-0.1629,-0.0349), vec3(0.2588,-0.8954,0.3624), vec2(0.6538,0.3569), vec2(0.6577,0.3379), vec2(0.6943,0.3525), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.428,0.015,0.0041), vec3(0.4487,0.0283,0.0012), vec3(0.3908,-0.0265,0.146), vec3(0.5238,-0.8446,-0.1104), vec2(0.626,0.4536), vec2(0.6196,0.4609), vec2(0.5903,0.4189), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3085,-0.0605,0.0904), vec3(0.3051,-0.0943,0.0609), vec3(0.3504,-0.0587,0.0148), vec3(0.7854,-0.4502,0.4249), vec2(0.6328,0.4023), vec2(0.6606,0.4077), vec2(0.6499,0.4253), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5254,0.1619,0.0118), vec3(0.4229,0.0397,0.1692), vec3(0.4487,0.0283,0.0012), vec3(0.8498,-0.5008,0.1644), vec2(0.6001,0.5044), vec2(0.5679,0.4419), vec2(0.6196,0.4609), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.0019,-0.162,-0.0109), vec3(0.107,-0.1245,0.062), vec3(-0.001,-0.1306,0.1348), vec3(0.1932,-0.9594,0.2054), vec2(0.6729,0.3022), vec2(0.6577,0.3379), vec2(0.623,0.2847), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1648,-0.1417,0.0602), vec3(0.2188,-0.1635,0.075), vec3(0.2184,-0.1412,0.1043), vec3(-0.4377,-0.7185,0.5405), vec2(0.6885,0.3687), vec2(0.6895,0.3877), vec2(0.6797,0.3838), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3908,-0.0265,0.146), vec3(0.3085,-0.0605,0.0904), vec3(0.428,0.015,0.0041), vec3(0.4563,-0.879,-0.1382), vec2(0.5903,0.4189), vec2(0.6328,0.4023), vec2(0.626,0.4536), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2685,-0.1505,0.0818), vec3(0.3051,-0.0943,0.0609), vec3(0.2428,-0.1346,0.1124), vec3(0.6973,-0.1972,0.6891), vec2(0.6812,0.3989), vec2(0.6606,0.4077), vec2(0.6748,0.3892), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5254,0.1619,0.0118), vec3(0.5546,0.351,0.0323), vec3(0.4724,0.1356,0.2125), vec3(0.9576,-0.1731,0.2303), vec2(0.6001,0.5044), vec2(0.5757,0.5515), vec2(0.5435,0.4731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3051,-0.0943,0.0609), vec3(0.3085,-0.0605,0.0904), vec3(0.2357,-0.0946,0.1195), vec3(0.5227,-0.5903,0.6151), vec2(0.6606,0.4077), vec2(0.6328,0.4023), vec2(0.6597,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1648,-0.1417,0.0602), vec3(0.2184,-0.1412,0.1043), vec3(0.1962,-0.1196,0.1108), vec3(-0.4732,-0.6604,0.5831), vec2(0.6885,0.3687), vec2(0.6797,0.3838), vec2(0.6753,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1648,-0.1417,0.0602), vec3(0.1962,-0.1196,0.1108), vec3(0.1645,-0.0842,0.1205), vec3(-0.5138,-0.6216,0.5913), vec2(0.6885,0.3687), vec2(0.6753,0.3745), vec2(0.6538,0.3569), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2357,-0.0946,0.1195), vec3(0.2428,-0.1346,0.1124), vec3(0.3051,-0.0943,0.0609), vec3(0.6454,-0.0218,0.7635), vec2(0.6597,0.3828), vec2(0.6748,0.3892), vec2(0.6606,0.4077), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2184,-0.1412,0.1043), vec3(0.2188,-0.1635,0.075), vec3(0.2297,-0.1911,0.124), vec3(-0.9777,-0.1736,0.1183), vec2(0.0112,0.2886), vec2(0.0285,0.272), vec2(0.0463,0.3003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4229,0.0397,0.1692), vec3(0.3908,-0.0265,0.146), vec3(0.4487,0.0283,0.0012), vec3(0.8636,-0.4764,0.1649), vec2(0.5679,0.4419), vec2(0.5903,0.4189), vec2(0.6196,0.4609), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2184,-0.1412,0.1043), vec3(0.2428,-0.1346,0.1124), vec3(0.1962,-0.1196,0.1108), vec3(-0.1733,-0.4428,0.8797), vec2(0.6797,0.3838), vec2(0.6748,0.3892), vec2(0.6753,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2541,-0.1898,0.1355), vec3(0.2685,-0.1505,0.0818), vec3(0.2428,-0.1346,0.1124), vec3(0.7974,0.3643,0.481), vec2(0.0417,0.3159), vec2(0.0091,0.332), vec2(0.0072,0.3042), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2428,-0.1346,0.1124), vec3(0.2184,-0.1412,0.1043), vec3(0.2297,-0.1911,0.124), vec3(-0.3707,0.2687,0.889), vec2(0.0072,0.3042), vec2(0.0112,0.2886), vec2(0.0463,0.3003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2357,-0.0946,0.1195), vec3(0.3085,-0.0605,0.0904), vec3(0.2275,-0.0665,0.1309), vec3(0.4494,-0.2198,0.8659), vec2(0.6597,0.3828), vec2(0.6328,0.4023), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2357,-0.0946,0.1195), vec3(0.1962,-0.1196,0.1108), vec3(0.2428,-0.1346,0.1124), vec3(-0.0949,-0.1898,0.9772), vec2(0.6597,0.3828), vec2(0.6753,0.3745), vec2(0.6748,0.3892), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2357,-0.0946,0.1195), vec3(0.1645,-0.0842,0.1205), vec3(0.1962,-0.1196,0.1108), vec3(-0.0291,-0.2872,0.9574), vec2(0.6597,0.3828), vec2(0.6538,0.3569), vec2(0.6753,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.107,-0.1245,0.062), vec3(0.1645,-0.0842,0.1205), vec3(0.1023,-0.0708,0.1865), vec3(0.2253,-0.8916,0.3928), vec2(0.6577,0.3379), vec2(0.6538,0.3569), vec2(0.6079,0.3198), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2275,-0.0665,0.1309), vec3(0.1645,-0.0842,0.1205), vec3(0.2357,-0.0946,0.1195), vec3(-0.0442,-0.3863,0.9213), vec2(0.6387,0.3745), vec2(0.6538,0.3569), vec2(0.6597,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2541,-0.1898,0.1355), vec3(0.2428,-0.1346,0.1124), vec3(0.2297,-0.1911,0.124), vec3(-0.4205,0.2752,0.8646), vec2(0.0417,0.3159), vec2(0.0072,0.3042), vec2(0.0463,0.3003), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1023,-0.0708,0.1865), vec3(-0.001,-0.1306,0.1348), vec3(0.107,-0.1245,0.062), vec3(0.3099,-0.8688,0.3862), vec2(0.6079,0.3198), vec2(0.623,0.2847), vec2(0.6577,0.3379), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4724,0.1356,0.2125), vec3(0.4229,0.0397,0.1692), vec3(0.5254,0.1619,0.0118), vec3(0.8471,-0.5077,0.1573), vec2(0.5435,0.4731), vec2(0.5679,0.4419), vec2(0.6001,0.5044), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3085,-0.0605,0.0904), vec3(0.3218,-0.0483,0.1804), vec3(0.2275,-0.0665,0.1309), vec3(0.1296,-0.9849,0.1144), vec2(0.6328,0.4023), vec2(0.5879,0.3926), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3085,-0.0605,0.0904), vec3(0.3908,-0.0265,0.146), vec3(0.3218,-0.0483,0.1804), vec3(0.3351,-0.9389,0.0778), vec2(0.6328,0.4023), vec2(0.5903,0.4189), vec2(0.5879,0.3926), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2275,-0.0665,0.1309), vec3(0.1023,-0.0708,0.1865), vec3(0.1645,-0.0842,0.1205), vec3(0.1942,-0.9096,0.3672), vec2(0.6387,0.3745), vec2(0.6079,0.3198), vec2(0.6538,0.3569), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4804,0.2836,0.2512), vec3(0.4724,0.1356,0.2125), vec3(0.5546,0.351,0.0323), vec3(0.9506,-0.1257,0.2838), vec2(0.5156,0.5129), vec2(0.5435,0.4731), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3218,-0.0483,0.1804), vec3(0.2189,-0.0509,0.1983), vec3(0.2275,-0.0665,0.1309), vec3(0.0646,-0.9703,0.233), vec2(0.5879,0.3926), vec2(0.5928,0.3579), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2189,-0.0509,0.1983), vec3(0.1023,-0.0708,0.1865), vec3(0.2275,-0.0665,0.1309), vec3(0.1397,-0.9606,0.2404), vec2(0.5928,0.3579), vec2(0.6079,0.3198), vec2(0.6387,0.3745), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4804,0.2836,0.2512), vec3(0.5546,0.351,0.0323), vec3(0.3987,0.4357,0.2894), vec3(0.8465,0.3552,0.3965), vec2(0.5156,0.5129), vec2(0.5757,0.5515), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3908,-0.0265,0.146), vec3(0.4229,0.0397,0.1692), vec3(0.3626,-0.0235,0.2672), vec3(0.849,-0.485,0.2096), vec2(0.5903,0.4189), vec2(0.5679,0.4419), vec2(0.5479,0.3999), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3626,-0.0235,0.2672), vec3(0.3218,-0.0483,0.1804), vec3(0.3908,-0.0265,0.146), vec3(0.3461,-0.9324,0.104), vec2(0.5479,0.3999), vec2(0.5879,0.3926), vec2(0.5903,0.4189), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1023,-0.0708,0.1865), vec3(0.0792,-0.1003,0.3446), vec3(-0.001,-0.1306,0.1348), vec3(0.5292,-0.8447,-0.0804), vec2(0.6079,0.3198), vec2(0.5474,0.2915), vec2(0.623,0.2847), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4229,0.0397,0.1692), vec3(0.4724,0.1356,0.2125), vec3(0.4029,0.0591,0.2954), vec3(0.8266,-0.5216,0.2113), vec2(0.5679,0.4419), vec2(0.5435,0.4731), vec2(0.5225,0.4321), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4029,0.0591,0.2954), vec3(0.3626,-0.0235,0.2672), vec3(0.4229,0.0397,0.1692), vec3(0.8489,-0.4854,0.2092), vec2(0.5225,0.4321), vec2(0.5479,0.3999), vec2(0.5679,0.4419), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2189,-0.0509,0.1983), vec3(0.1535,-0.0783,0.3554), vec3(0.1023,-0.0708,0.1865), vec3(0.177,-0.9794,-0.0974), vec2(0.5928,0.3579), vec2(0.5347,0.3164), vec2(0.6079,0.3198), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3218,-0.0483,0.1804), vec3(0.2449,-0.0526,0.375), vec3(0.2189,-0.0509,0.1983), vec3(0.0225,-0.9997,-0.0131), vec2(0.5879,0.3926), vec2(0.519,0.3477), vec2(0.5928,0.3579), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0,-0.1194,0.3306), vec3(-0.001,-0.1306,0.1348), vec3(0.0792,-0.1003,0.3446), vec3(0.2241,-0.973,0.0548), vec2(0.5581,0.2642), vec2(0.623,0.2847), vec2(0.5474,0.2915), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3218,-0.0483,0.1804), vec3(0.3626,-0.0235,0.2672), vec3(0.2449,-0.0526,0.375), vec3(0.3334,-0.9362,0.1111), vec2(0.5879,0.3926), vec2(0.5479,0.3999), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4804,0.2836,0.2512), vec3(0.3933,0.103,0.3883), vec3(0.4724,0.1356,0.2125), vec3(0.9118,-0.1493,0.3825), vec2(0.5156,0.5129), vec2(0.4832,0.438), vec2(0.5435,0.4731), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0792,-0.1003,0.3446), vec3(0.1023,-0.0708,0.1865), vec3(0.1535,-0.0783,0.3554), vec3(0.2986,-0.9451,-0.1328), vec2(0.5474,0.2915), vec2(0.6079,0.3198), vec2(0.5347,0.3164), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4029,0.0591,0.2954), vec3(0.4724,0.1356,0.2125), vec3(0.3933,0.103,0.3883), vec3(0.8448,-0.4447,0.2975), vec2(0.5225,0.4321), vec2(0.5435,0.4731), vec2(0.4832,0.438), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1535,-0.0783,0.3554), vec3(0.2189,-0.0509,0.1983), vec3(0.2449,-0.0526,0.375), vec3(0.2807,-0.9585,-0.0507), vec2(0.5347,0.3164), vec2(0.5928,0.3579), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3483,-0.0408,0.386), vec3(0.3626,-0.0235,0.2672), vec3(0.4029,0.0591,0.2954), vec3(0.8923,-0.4495,0.0421), vec2(0.502,0.3828), vec2(0.5479,0.3999), vec2(0.5225,0.4321), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3987,0.4357,0.2894), vec3(0.3352,0.2777,0.4812), vec3(0.4804,0.2836,0.2512), vec3(0.8026,0.3021,0.5143), vec2(0.4844,0.5562), vec2(0.4255,0.4902), vec2(0.5156,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3483,-0.0408,0.386), vec3(0.2449,-0.0526,0.375), vec3(0.3626,-0.0235,0.2672), vec3(0.1256,-0.9837,-0.1286), vec2(0.502,0.3828), vec2(0.519,0.3477), vec2(0.5479,0.3999), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4029,0.0591,0.2954), vec3(0.3933,0.103,0.3883), vec3(0.3483,-0.0408,0.386), vec3(0.9266,-0.2937,0.2347), vec2(0.5225,0.4321), vec2(0.4832,0.438), vec2(0.502,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2594,0.3254,0.4817), vec3(0.3987,0.4357,0.2894), vec3(0.2753,0.4902,0.325), vec3(0.4535,0.5909,0.6672), vec2(0.3997,0.5129), vec2(0.4844,0.5562), vec2(0.4431,0.5828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3769,0.1779,0.4722), vec3(0.3933,0.103,0.3883), vec3(0.4804,0.2836,0.2512), vec3(0.9211,-0.1834,0.3434), vec2(0.4451,0.4561), vec2(0.4832,0.438), vec2(0.5156,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1843,0.5053,0.3407), vec3(0.2594,0.3254,0.4817), vec3(0.2753,0.4902,0.325), vec3(0.2326,0.6584,0.7158), vec2(0.4148,0.6013), vec2(0.3997,0.5129), vec2(0.4431,0.5828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0614,-0.1185,0.479), vec3(0,-0.1194,0.3306), vec3(0.0792,-0.1003,0.3446), vec3(0.2489,-0.9636,-0.0977), vec2(0.5029,0.2666), vec2(0.5581,0.2642), vec2(0.5474,0.2915), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0792,-0.1003,0.3446), vec3(0.1535,-0.0783,0.3554), vec3(0.0614,-0.1185,0.479), vec3(0.2943,-0.9514,-0.0901), vec2(0.5474,0.2915), vec2(0.5347,0.3164), vec2(0.5029,0.2666), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2449,-0.0526,0.375), vec3(0.1034,-0.089,0.4639), vec3(0.1535,-0.0783,0.3554), vec3(0.2652,-0.9638,0.0282), vec2(0.519,0.3477), vec2(0.5,0.2856), vec2(0.5347,0.3164), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3769,0.1779,0.4722), vec3(0.4804,0.2836,0.2512), vec3(0.3352,0.2777,0.4812), vec3(0.8059,0.29,0.5161), vec2(0.4451,0.4561), vec2(0.5156,0.5129), vec2(0.4255,0.4902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3352,0.2777,0.4812), vec3(0.3987,0.4357,0.2894), vec3(0.2594,0.3254,0.4817), vec3(0.4048,0.6355,0.6575), vec2(0.4255,0.4902), vec2(0.4844,0.5562), vec2(0.3997,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3385,0.0527,0.4997), vec3(0.3483,-0.0408,0.386), vec3(0.3933,0.103,0.3883), vec3(0.9045,-0.2881,0.3145), vec2(0.4441,0.4043), vec2(0.502,0.3828), vec2(0.4832,0.438), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3483,-0.0408,0.386), vec3(0.2353,-0.0786,0.5352), vec3(0.2449,-0.0526,0.375), vec3(0.1276,-0.9802,-0.1514), vec2(0.502,0.3828), vec2(0.4553,0.3228), vec2(0.519,0.3477), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1034,-0.089,0.4639), vec3(0.0614,-0.1185,0.479), vec3(0.1535,-0.0783,0.3554), vec3(0.6126,-0.7624,0.2086), vec2(0.5,0.2856), vec2(0.5029,0.2666), vec2(0.5347,0.3164), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2594,0.3254,0.4817), vec3(0.1843,0.5053,0.3407), vec3(0.1838,0.3542,0.5038), vec3(0.4311,0.6613,0.6139), vec2(0.3997,0.5129), vec2(0.4148,0.6013), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3432,0.1388,0.5105), vec3(0.3933,0.103,0.3883), vec3(0.3769,0.1779,0.4722), vec3(0.8471,-0.3035,0.4363), vec2(0.4312,0.4365), vec2(0.4832,0.438), vec2(0.4451,0.4561), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2449,-0.0526,0.375), vec3(0.2353,-0.0786,0.5352), vec3(0.1034,-0.089,0.4639), vec3(0.1572,-0.9763,-0.1489), vec2(0.519,0.3477), vec2(0.4553,0.3228), vec2(0.5,0.2856), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3432,0.1388,0.5105), vec3(0.3385,0.0527,0.4997), vec3(0.3933,0.103,0.3883), vec3(0.91,-0.0997,0.4023), vec2(0.4312,0.4365), vec2(0.4441,0.4043), vec2(0.4832,0.438), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-0.0694,0.574), vec3(0.3483,-0.0408,0.386), vec3(0.3385,0.0527,0.4997), vec3(0.9707,-0.138,0.1969), vec2(0.4319,0.3452), vec2(0.502,0.3828), vec2(0.4441,0.4043), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3061,-0.0694,0.574), vec3(0.2353,-0.0786,0.5352), vec3(0.3483,-0.0408,0.386), vec3(0.1852,-0.9769,-0.1069), vec2(0.4319,0.3452), vec2(0.4553,0.3228), vec2(0.502,0.3828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3769,0.1779,0.4722), vec3(0.3293,0.1629,0.5299), vec3(0.3432,0.1388,0.5105), vec3(0.7775,-0.057,0.6263), vec2(0.4451,0.4561), vec2(0.4197,0.4434), vec2(0.4312,0.4365), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3352,0.2777,0.4812), vec3(0.3078,0.2002,0.5599), vec3(0.3769,0.1779,0.4722), vec3(0.7877,0.2794,0.549), vec2(0.4255,0.4902), vec2(0.4021,0.4541), vec2(0.4451,0.4561), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2367,0.2723,0.5587), vec3(0.3352,0.2777,0.4812), vec3(0.2594,0.3254,0.4817), vec3(0.4311,0.6781,0.5952), vec2(0.3779,0.4863), vec2(0.4255,0.4902), vec2(0.3997,0.5129), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2367,0.2723,0.5587), vec3(0.2594,0.3254,0.4817), vec3(0.1838,0.3542,0.5038), vec3(0.4318,0.6777,0.5951), vec2(0.3779,0.4863), vec2(0.3997,0.5129), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3293,0.1629,0.5299), vec3(0.3769,0.1779,0.4722), vec3(0.3078,0.2002,0.5599), vec3(0.7774,-0.0564,0.6265), vec2(0.4197,0.4434), vec2(0.4451,0.4561), vec2(0.4021,0.4541), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0717,-0.1093,0.5787), vec3(0.1034,-0.089,0.4639), vec3(0.2353,-0.0786,0.5352), vec3(0.1485,-0.98,-0.1323), vec2(0.4705,0.2559), vec2(0.5,0.2856), vec2(0.4553,0.3228), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2367,0.2723,0.5587), vec3(0.3078,0.2002,0.5599), vec3(0.3352,0.2777,0.4812), vec3(0.5117,0.5168,0.6863), vec2(0.3779,0.4863), vec2(0.4021,0.4541), vec2(0.4255,0.4902), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3385,0.0527,0.4997), vec3(0.3432,0.1388,0.5105), vec3(0.279,0.1476,0.6091), vec3(0.8282,-0.1135,0.5488), vec2(0.4441,0.4043), vec2(0.4312,0.4365), vec2(0.3818,0.4258), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.279,0.1476,0.6091), vec3(0.3432,0.1388,0.5105), vec3(0.3293,0.1629,0.5299), vec3(0.8393,0.0467,0.5416), vec2(0.3818,0.4258), vec2(0.4312,0.4365), vec2(0.4197,0.4434), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3091,0.002,0.6005), vec3(0.3061,-0.0694,0.574), vec3(0.3385,0.0527,0.4997), vec3(0.9676,-0.1226,0.2208), vec2(0.4148,0.3696), vec2(0.4319,0.3452), vec2(0.4441,0.4043), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.279,0.1476,0.6091), vec3(0.3293,0.1629,0.5299), vec3(0.3078,0.2002,0.5599), vec3(0.8392,0.0475,0.5417), vec2(0.3818,0.4258), vec2(0.4197,0.4434), vec2(0.4021,0.4541), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3091,0.002,0.6005), vec3(0.3385,0.0527,0.4997), vec3(0.279,0.1476,0.6091), vec3(0.92,0.1689,0.3536), vec2(0.4148,0.3696), vec2(0.4441,0.4043), vec2(0.3818,0.4258), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1754,0.2175,0.6552), vec3(0.2367,0.2723,0.5587), vec3(0.1838,0.3542,0.5038), vec3(0.3889,0.6729,0.6293), vec2(0.3335,0.4575), vec2(0.3779,0.4863), vec2(0.3718,0.5288), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2367,0.2723,0.5587), vec3(0.1754,0.2175,0.6552), vec3(0.3078,0.2002,0.5599), vec3(0.5365,0.5406,0.648), vec2(0.3779,0.4863), vec2(0.3335,0.4575), vec2(0.4021,0.4541), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.279,0.1476,0.6091), vec3(0.3078,0.2002,0.5599), vec3(0.1754,0.2175,0.6552), vec3(0.5739,0.3696,0.7308), vec2(0.3818,0.4258), vec2(0.4021,0.4541), vec2(0.3335,0.4575), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.3014,0.6501,-0.0496), 0.5181, bestT)) {
        if (triHit(ro, rd, vec3(0.2645,0.7965,-0.3185), vec3(0.3566,0.7187,-0.4033), vec3(0.229,0.815,-0.436), vec3(0.6111,0.7892,-0.0604), vec2(0.625,0.74), vec2(0.6636,0.7075), vec2(0.6626,0.7659), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3921,0.6881,-0.3856), vec3(0.3566,0.7187,-0.4033), vec3(0.3596,0.7218,-0.2744), vec3(0.663,0.7478,-0.0334), vec2(0.6606,0.6909), vec2(0.6636,0.7075), vec2(0.6216,0.6965), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4245,0.6541,-0.3296), vec3(0.3921,0.6881,-0.3856), vec3(0.3596,0.7218,-0.2744), vec3(0.7223,0.6916,0.001), vec2(0.6465,0.6724), vec2(0.6606,0.6909), vec2(0.6216,0.6965), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3566,0.7187,-0.4033), vec3(0.2645,0.7965,-0.3185), vec3(0.2721,0.7786,-0.2344), vec3(0.6899,0.7182,0.0903), vec2(0.6636,0.7075), vec2(0.625,0.74), vec2(0.5986,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3596,0.7218,-0.2744), vec3(0.3566,0.7187,-0.4033), vec3(0.2721,0.7786,-0.2344), vec3(0.5338,0.845,-0.0327), vec2(0.6216,0.6965), vec2(0.6636,0.7075), vec2(0.5986,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2645,0.7965,-0.3185), vec3(0.1663,0.8177,-0.2173), vec3(0.2721,0.7786,-0.2344), vec3(0.3644,0.917,0.1619), vec2(0.625,0.74), vec2(0.5781,0.7605), vec2(0.5986,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3596,0.7218,-0.2744), vec3(0.4361,0.6186,-0.1318), vec3(0.4245,0.6541,-0.3296), vec3(0.7495,0.6578,0.0743), vec2(0.6216,0.6965), vec2(0.5923,0.6455), vec2(0.6465,0.6724), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4361,0.6186,-0.1318), vec3(0.5069,0.5162,-0.1564), vec3(0.4245,0.6541,-0.3296), vec3(0.827,0.5598,0.0522), vec2(0.5923,0.6455), vec2(0.6128,0.6121), vec2(0.6465,0.6724), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3596,0.7218,-0.2744), vec3(0.2721,0.7786,-0.2344), vec3(0.3724,0.6771,-0.0953), vec3(0.5872,0.7942,0.1561), vec2(0.6216,0.6965), vec2(0.5986,0.7261), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2721,0.7786,-0.2344), vec3(0.1663,0.8177,-0.2173), vec3(0.2813,0.719,-0.066), vec3(0.3721,0.8811,0.2919), vec2(0.5986,0.7261), vec2(0.5781,0.7605), vec2(0.5479,0.6924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3724,0.6771,-0.0953), vec3(0.4361,0.6186,-0.1318), vec3(0.3596,0.7218,-0.2744), vec3(0.7092,0.6943,0.1224), vec2(0.5713,0.667), vec2(0.5923,0.6455), vec2(0.6216,0.6965), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.008,0.8263,-0.192), vec3(0.1753,0.7388,-0.0299), vec3(0.1663,0.8177,-0.2173), vec3(0.1109,0.9179,0.3809), vec2(0.541,0.8092), vec2(0.5176,0.7183), vec2(0.5781,0.7605), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2813,0.719,-0.066), vec3(0.3724,0.6771,-0.0953), vec3(0.2721,0.7786,-0.2344), vec3(0.4723,0.8386,0.2714), vec2(0.5479,0.6924), vec2(0.5713,0.667), vec2(0.5986,0.7261), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1753,0.7388,-0.0299), vec3(0.2813,0.719,-0.066), vec3(0.1663,0.8177,-0.2173), vec3(0.2886,0.8874,0.3595), vec2(0.5176,0.7183), vec2(0.5479,0.6924), vec2(0.5781,0.7605), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5069,0.5162,-0.1564), vec3(0.4361,0.6186,-0.1318), vec3(0.4943,0.492,0.053), vec3(0.8295,0.5469,0.1133), vec2(0.6128,0.6121), vec2(0.5923,0.6455), vec2(0.5581,0.5881), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.008,0.8263,-0.192), vec3(0.0099,0.7442,0.002), vec3(0.1753,0.7388,-0.0299), vec3(0.1043,0.9162,0.3869), vec2(0.541,0.8092), vec2(0.4724,0.7621), vec2(0.5176,0.7183), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(-0.1553,0.7472,-0.0159), vec3(0.0099,0.7442,0.002), vec3(0.008,0.8263,-0.192), vec3(-0.0257,0.9205,0.39), vec2(0.5176,0.7183), vec2(0.4724,0.7621), vec2(0.541,0.8092), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3724,0.6771,-0.0953), vec3(0.4369,0.5511,0.0738), vec3(0.4361,0.6186,-0.1318), vec3(0.7249,0.6554,0.2121), vec2(0.5713,0.667), vec2(0.54,0.6082), vec2(0.5923,0.6455), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4943,0.492,0.053), vec3(0.5546,0.351,0.0323), vec3(0.5069,0.5162,-0.1564), vec3(0.92,0.3792,0.0993), vec2(0.5581,0.5881), vec2(0.5757,0.5515), vec2(0.6128,0.6121), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2813,0.719,-0.066), vec3(0.3843,0.5802,0.1017), vec3(0.3724,0.6771,-0.0953), vec3(0.4826,0.7971,0.363), vec2(0.5479,0.6924), vec2(0.522,0.6201), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4369,0.5511,0.0738), vec3(0.4943,0.492,0.053), vec3(0.4361,0.6186,-0.1318), vec3(0.7375,0.6425,0.2078), vec2(0.54,0.6082), vec2(0.5581,0.5881), vec2(0.5923,0.6455), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1753,0.7388,-0.0299), vec3(0.2754,0.6177,0.1466), vec3(0.2813,0.719,-0.066), vec3(0.3025,0.8573,0.4167), vec2(0.5176,0.7183), vec2(0.4873,0.6418), vec2(0.5479,0.6924), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3843,0.5802,0.1017), vec3(0.4369,0.5511,0.0738), vec3(0.3724,0.6771,-0.0953), vec3(0.5849,0.7412,0.3294), vec2(0.522,0.6201), vec2(0.54,0.6082), vec2(0.5713,0.667), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1753,0.7388,-0.0299), vec3(0.0099,0.7442,0.002), vec3(0.1869,0.6378,0.1547), vec3(0.1191,0.8741,0.4708), vec2(0.5176,0.7183), vec2(0.4724,0.7621), vec2(0.4646,0.6636), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2813,0.719,-0.066), vec3(0.2754,0.6177,0.1466), vec3(0.3843,0.5802,0.1017), vec3(0.4406,0.8057,0.3959), vec2(0.5479,0.6924), vec2(0.4873,0.6418), vec2(0.522,0.6201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1753,0.7388,-0.0299), vec3(0.1869,0.6378,0.1547), vec3(0.2754,0.6177,0.1466), vec3(0.2365,0.8585,0.4549), vec2(0.5176,0.7183), vec2(0.4646,0.6636), vec2(0.4873,0.6418), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.0085,0.6413,0.1778), vec3(0.1869,0.6378,0.1547), vec3(0.0099,0.7442,0.002), vec3(0.0822,0.86,0.5037), vec2(0.4136,0.707), vec2(0.4646,0.6636), vec2(0.4724,0.7621), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4943,0.492,0.053), vec3(0.3987,0.4357,0.2894), vec3(0.5546,0.351,0.0323), vec3(0.8555,0.3047,0.4186), vec2(0.5581,0.5881), vec2(0.4844,0.5562), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3987,0.4357,0.2894), vec3(0.4943,0.492,0.053), vec3(0.4369,0.5511,0.0738), vec3(0.7203,0.5502,0.4224), vec2(0.4844,0.5562), vec2(0.5581,0.5881), vec2(0.54,0.6082), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3987,0.4357,0.2894), vec3(0.4369,0.5511,0.0738), vec3(0.3843,0.5802,0.1017), vec3(0.6038,0.6532,0.4568), vec2(0.4844,0.5562), vec2(0.54,0.6082), vec2(0.522,0.6201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2754,0.6177,0.1466), vec3(0.3987,0.4357,0.2894), vec3(0.3843,0.5802,0.1017), vec3(0.4616,0.7196,0.5188), vec2(0.4873,0.6418), vec2(0.4844,0.5562), vec2(0.522,0.6201), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2754,0.6177,0.1466), vec3(0.1869,0.6378,0.1547), vec3(0.2753,0.4902,0.325), vec3(0.2314,0.7914,0.5659), vec2(0.4873,0.6418), vec2(0.4646,0.6636), vec2(0.4431,0.5828), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1869,0.6378,0.1547), vec3(0.0085,0.6413,0.1778), vec3(0.1843,0.5053,0.3407), vec3(0.0909,0.8104,0.5788), vec2(0.4646,0.6636), vec2(0.4136,0.707), vec2(0.4148,0.6013), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.2754,0.6177,0.1466), vec3(0.2753,0.4902,0.325), vec3(0.3987,0.4357,0.2894), vec3(0.4663,0.7195,0.5146), vec2(0.4873,0.6418), vec2(0.4431,0.5828), vec2(0.4844,0.5562), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.1843,0.5053,0.3407), vec3(0.2753,0.4902,0.325), vec3(0.1869,0.6378,0.1547), vec3(0.229,0.7913,0.567), vec2(0.4148,0.6013), vec2(0.4431,0.5828), vec2(0.4646,0.6636), bestT, bestN, bestUV)) hit = true;
}
    if (clusterHit(ro, rd, vec3(0.4702,0.3961,-0.4002), 0.527, bestT)) {
        if (triHit(ro, rd, vec3(0.3754,0.2586,-0.6169), vec3(0.2808,0.2513,-0.7053), vec3(0.3794,0.3789,-0.6561), vec3(0.6715,-0.2506,-0.6974), vec2(0.77,0.5732), vec2(0.8105,0.5745), vec2(0.772,0.6128), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3794,0.3789,-0.6561), vec3(0.4457,0.3921,-0.566), vec3(0.3754,0.2586,-0.6169), vec3(0.8023,-0.2098,-0.5589), vec2(0.772,0.6128), vec2(0.7373,0.6094), vec2(0.77,0.5732), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3794,0.3789,-0.6561), vec3(0.3986,0.529,-0.6161), vec3(0.4457,0.3921,-0.566), vec3(0.8004,0.0571,-0.5968), vec2(0.772,0.6128), vec2(0.7461,0.657), vec2(0.7373,0.6094), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4515,0.4958,-0.5371), vec3(0.4457,0.3921,-0.566), vec3(0.3986,0.529,-0.6161), vec3(0.8456,0.0991,-0.5245), vec2(0.7202,0.6377), vec2(0.7373,0.6094), vec2(0.7461,0.657), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3754,0.2586,-0.6169), vec3(0.4512,0.2423,-0.5145), vec3(0.3752,0.1922,-0.5696), vec3(0.6977,-0.4161,-0.5832), vec2(0.77,0.5732), vec2(0.7329,0.563), vec2(0.7617,0.5498), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4512,0.2423,-0.5145), vec3(0.3754,0.2586,-0.6169), vec3(0.4457,0.3921,-0.566), vec3(0.7767,-0.1792,-0.6039), vec2(0.7329,0.563), vec2(0.77,0.5732), vec2(0.7373,0.6094), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4478,0.5653,-0.5018), vec3(0.3986,0.529,-0.6161), vec3(0.3982,0.6319,-0.5387), vec3(0.8149,0.3501,-0.4619), vec2(0.7051,0.6558), vec2(0.7461,0.657), vec2(0.7139,0.6836), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4515,0.4958,-0.5371), vec3(0.3986,0.529,-0.6161), vec3(0.4478,0.5653,-0.5018), vec3(0.8483,0.2751,-0.4524), vec2(0.7202,0.6377), vec2(0.7461,0.657), vec2(0.7051,0.6558), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4457,0.3921,-0.566), vec3(0.4515,0.4958,-0.5371), vec3(0.501,0.3837,-0.468), vec3(0.871,0.0863,-0.4836), vec2(0.7373,0.6094), vec2(0.7202,0.6377), vec2(0.7061,0.5986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.501,0.3837,-0.468), vec3(0.4512,0.2423,-0.5145), vec3(0.4457,0.3921,-0.566), vec3(0.8575,-0.1389,-0.4954), vec2(0.7061,0.5986), vec2(0.7329,0.563), vec2(0.7373,0.6094), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4961,0.4588,-0.4445), vec3(0.4515,0.4958,-0.5371), vec3(0.4478,0.5653,-0.5018), vec3(0.9098,0.2255,-0.3485), vec2(0.6948,0.6187), vec2(0.7202,0.6377), vec2(0.7051,0.6558), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4961,0.4588,-0.4445), vec3(0.501,0.3837,-0.468), vec3(0.4515,0.4958,-0.5371), vec3(0.9125,0.1746,-0.3701), vec2(0.6948,0.6187), vec2(0.7061,0.5986), vec2(0.7202,0.6377), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4478,0.5653,-0.5018), vec3(0.3982,0.6319,-0.5387), vec3(0.3921,0.6881,-0.3856), vec3(0.8326,0.53,-0.1608), vec2(0.7051,0.6558), vec2(0.7139,0.6836), vec2(0.6606,0.6909), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4961,0.4588,-0.4445), vec3(0.4478,0.5653,-0.5018), vec3(0.4921,0.5407,-0.4096), vec3(0.9024,0.206,-0.3784), vec2(0.6948,0.6187), vec2(0.7051,0.6558), vec2(0.6782,0.6387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4512,0.2423,-0.5145), vec3(0.501,0.3837,-0.468), vec3(0.5249,0.2224,-0.3509), vec3(0.8896,-0.1744,-0.4221), vec2(0.7329,0.563), vec2(0.7061,0.5986), vec2(0.6855,0.5481), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.3921,0.6881,-0.3856), vec3(0.3982,0.6319,-0.5387), vec3(0.3566,0.7187,-0.4033), vec3(0.6985,0.6805,-0.2213), vec2(0.6606,0.6909), vec2(0.7139,0.6836), vec2(0.6636,0.7075), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4478,0.5653,-0.5018), vec3(0.3921,0.6881,-0.3856), vec3(0.4921,0.5407,-0.4096), vec3(0.7884,0.572,-0.2263), vec2(0.7051,0.6558), vec2(0.6606,0.6909), vec2(0.6782,0.6387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5301,0.3856,-0.3541), vec3(0.501,0.3837,-0.468), vec3(0.4961,0.4588,-0.4445), vec3(0.9589,0.1393,-0.2474), vec2(0.6768,0.592), vec2(0.7061,0.5986), vec2(0.6948,0.6187), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4961,0.4588,-0.4445), vec3(0.4921,0.5407,-0.4096), vec3(0.5301,0.3856,-0.3541), vec3(0.9594,0.1495,-0.2394), vec2(0.6948,0.6187), vec2(0.6782,0.6387), vec2(0.6768,0.592), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4512,0.2423,-0.5145), vec3(0.5249,0.2224,-0.3509), vec3(0.4452,0.0862,-0.3316), vec3(0.7629,-0.5038,-0.4051), vec2(0.7329,0.563), vec2(0.6855,0.5481), vec2(0.7012,0.5083), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5301,0.3856,-0.3541), vec3(0.5249,0.2224,-0.3509), vec3(0.501,0.3837,-0.468), vec3(0.9684,-0.0354,-0.2468), vec2(0.6768,0.592), vec2(0.6855,0.5481), vec2(0.7061,0.5986), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4245,0.6541,-0.3296), vec3(0.4921,0.5407,-0.4096), vec3(0.3921,0.6881,-0.3856), vec3(0.8115,0.571,-0.1238), vec2(0.6465,0.6724), vec2(0.6782,0.6387), vec2(0.6606,0.6909), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5069,0.5162,-0.1564), vec3(0.5301,0.3856,-0.3541), vec3(0.4921,0.5407,-0.4096), vec3(0.9735,0.226,-0.0351), vec2(0.6128,0.6121), vec2(0.6768,0.592), vec2(0.6782,0.6387), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.4921,0.5407,-0.4096), vec3(0.4245,0.6541,-0.3296), vec3(0.5069,0.5162,-0.1564), vec3(0.8588,0.5124,-0.0007), vec2(0.6782,0.6387), vec2(0.6465,0.6724), vec2(0.6128,0.6121), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5249,0.2224,-0.3509), vec3(0.5476,0.1979,-0.1932), vec3(0.4452,0.0862,-0.3316), vec3(0.833,-0.5159,-0.2001), vec2(0.6855,0.5481), vec2(0.647,0.5312), vec2(0.7012,0.5083), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5301,0.3856,-0.3541), vec3(0.5504,0.3819,-0.1701), vec3(0.5249,0.2224,-0.3509), vec3(0.9933,-0.0335,-0.1102), vec2(0.6768,0.592), vec2(0.6313,0.5754), vec2(0.6855,0.5481), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5249,0.2224,-0.3509), vec3(0.5504,0.3819,-0.1701), vec3(0.5476,0.1979,-0.1932), vec3(0.9898,0.0032,-0.1421), vec2(0.6855,0.5481), vec2(0.6313,0.5754), vec2(0.647,0.5312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.464,0.043,-0.1643), vec3(0.4452,0.0862,-0.3316), vec3(0.5476,0.1979,-0.1932), vec3(0.84,-0.495,-0.2222), vec2(0.6606,0.4844), vec2(0.7012,0.5083), vec2(0.647,0.5312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5301,0.3856,-0.3541), vec3(0.5069,0.5162,-0.1564), vec3(0.5504,0.3819,-0.1701), vec3(0.9439,0.3154,-0.0977), vec2(0.6768,0.592), vec2(0.6128,0.6121), vec2(0.6313,0.5754), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5476,0.1979,-0.1932), vec3(0.5254,0.1619,0.0118), vec3(0.464,0.043,-0.1643), vec3(0.8808,-0.4733,0.0125), vec2(0.647,0.5312), vec2(0.6001,0.5044), vec2(0.6606,0.4844), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5504,0.3819,-0.1701), vec3(0.5546,0.351,0.0323), vec3(0.5476,0.1979,-0.1932), vec3(0.9997,-0.012,-0.0229), vec2(0.6313,0.5754), vec2(0.5757,0.5515), vec2(0.647,0.5312), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5504,0.3819,-0.1701), vec3(0.5069,0.5162,-0.1564), vec3(0.5546,0.351,0.0323), vec3(0.9519,0.3053,0.0265), vec2(0.6313,0.5754), vec2(0.6128,0.6121), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
        if (triHit(ro, rd, vec3(0.5254,0.1619,0.0118), vec3(0.5476,0.1979,-0.1932), vec3(0.5546,0.351,0.0323), vec3(0.9839,-0.1607,0.0786), vec2(0.6001,0.5044), vec2(0.647,0.5312), vec2(0.5757,0.5515), bestT, bestN, bestUV)) hit = true;
}
    return hit ? 1.0 : 0.0;
}


// ===== COLOR =====
// No per-part IDs from a raw mesh (unlike the SDF build's partId), so parts are classified by real
// hit-point position instead -- same idea as before, just against actual mesh coordinates now.

vec3 iridescentColor(vec3 p, float turb, float spd) {
    float t = 0.0;
    t += sin(p.x * turb + TIME * spd) * 0.5;
    t += sin(p.y * turb * 1.3 + TIME * spd * 0.7) * 0.3;
    t += sin(p.z * turb * 0.8 + TIME * spd * 1.2) * 0.4;
    t += syn_HighPresence * 0.05;
    t = fract(t * 0.5 + 0.5);
    vec3 green = vec3(0.14, 0.38, 0.32);
    vec3 teal = vec3(0.12, 0.35, 0.38);
    vec3 blue = vec3(0.22, 0.28, 0.42);
    vec3 purple = vec3(0.34, 0.27, 0.44);
    vec3 magenta = vec3(0.30, 0.22, 0.36);
    float seg = t * 4.0;
    if (seg < 1.0) return mix(green, teal, seg);
    if (seg < 2.0) return mix(teal, blue, seg - 1.0);
    if (seg < 3.0) return mix(blue, purple, seg - 2.0);
    return mix(purple, magenta, seg - 3.0);
}

// Shared neck/head sheen turbulence -- was only ever inlined inside neonAccentColor, factored out
// so Iridescent Realism's sheen (iridescentColorA/B, added alongside Neon's own hardcoded blue/red
// below) can reuse the exact same moving pattern instead of drifting out of sync with a duplicate.
float neckSheenT(vec3 p, float turb, float spd) {
    float t = 0.0;
    t += sin(p.x * turb + TIME * spd) * 0.5;
    t += sin(p.z * turb * 0.8 + TIME * spd * 1.2) * 0.4;
    t += syn_HighPresence * 0.05;
    return fract(t * 0.5 + 0.5);
}

vec3 neonAccentColor(vec3 p, float turb, float spd) {
    vec3 blue = vec3(0.10, 0.40, 1.0);
    vec3 red = vec3(1.0, 0.10, 0.15);
    return mix(blue, red, neckSheenT(p, turb, spd));
}

// approximate head/neck position, used for the neck/head tint falloff (a real per-part ID isn't
// available from raw triangles). This whole constant was WRONG for the entire "neck tint on the
// tail" saga -- every vertex-density heuristic tried this session (and the sessions before it)
// concluded +Z=beak, and each recheck "confirmed" that same wrong answer because the real signal
// (wingtips also cluster near -Z, close to the actual head) kept getting misread as "the tail
// needs lots of vertices." Sam settled it by placing real named landmarks by hand on the actual
// mesh data (via an interactive point-mapping tool) instead of trusting another vertex-count pass:
// Beak (0.024, 0.958, -1.273), Eyes (0.024, 1.124, -1.199), Top of head (0.024, 1.278, -1.114),
// Bottom of skull (0.024, 1.073, -1.005), neck-at-chest (0.024, 0.639, -0.725), neck-at-spine
// (0.024, 1.215, -0.628), neck-at-shoulders (+-0.23, 0.924, -0.59) -- the beak is at NEGATIVE Z,
// tail runs +0.66 to +1.34. This value is the centroid of those 8 head/neck/shoulder points, radius
// widened to actually span beak-to-shoulder (was 0.12-0.32, now 0.18-0.42 at the neckT call site)
// instead of the old ~beak-tip-only radius.
const vec3 HEAD_APPROX = vec3(0.032, 1.017, -0.890);

// same idea, computed from the walk-pose mesh's own transform -- fly and walk normalize to the same
// overall height but have very different proportions (extended flight posture vs standing/folded),
// so a single HEAD_APPROX doesn't work for both. Like HEAD_APPROX above, the old value here was
// wrong for the same reason: it came from the same vertex-density method (confirmed +Z=beak, which
// the Fly-pose ground-truth pass proved backwards) and landed at Y=-0.13, Z=+1.05 -- low to the
// ground AND in the tail's +Z region, nowhere near a walking bird's head. Sam placed 11 real
// landmarks on the actual Walk mesh (Tip/base of beak, top of head, base of skull, neck at spine/
// chest, breast, top of back, feet, tail start/tip) confirming beak is at -Z here too (same axis
// convention as Fly, just different proportions) -- this value is the centroid of the 6 head/neck
// landmarks (excludes breast/back/feet/tail).
const vec3 HEAD_APPROX_WALK = vec3(0.004, 0.988, -0.979);

vec3 shadeHit(vec3 p, vec3 n, vec2 uv, float style, float neckTurb, float neckSpd) {
    // Dove: soft pale white/cream plumage, procedural (no texture asset for this style -- checked
    // before the Iridescent branch below since it's also style >= 0.5).
    if (style >= 1.5) {
        vec3 col = vec3(0.80, 0.78, 0.75);
        vec3 headRef = (pigeonPose >= 0.5) ? HEAD_APPROX_WALK : HEAD_APPROX;
        float neckT = 1.0 - smoothstep(0.18, 0.42, length(p - headRef));
        col = mix(col, vec3(0.92, 0.85, 0.74), neckT * 0.6);
        if (abs(p.x) > 0.30) col *= 0.92;
        if (p.z < -0.55) col *= 0.9;
        return col;
    }

    // Iridescent Realism: sample the real reference texture directly at the hit point's actual UV
    // (from the OBJ's own vt data via triHit's barycentric interpolation) instead of guessing color
    // by position. No more position-based classification bugs -- the exact real pixel, every time.
    if (style >= 0.5) {
        return texture(pigeonTex, uv).rgb;
    }

    // Neon Blue/Red -- procedural, deliberately not photoreal
    vec3 col = vec3(0.03, 0.035, 0.05);

    // real bug found here: this always used HEAD_APPROX (the fly-pose head) regardless of which pose
    // was actually selected. Viewing Walk pose in Neon style, the tint was anchored to where fly
    // pose's head would be -- nowhere near walk's very differently-shaped body -- and could land
    // anywhere, including looking like it was on the tail. Branch on pigeonPose like the geometry
    // itself already does. Also tightened the radius (0.15-0.38 -> 0.12-0.32) as extra insurance
    // against bleeding onto the shoulder/wing-root given the real anatomy sits close there.
    vec3 headRef = (pigeonPose >= 0.5) ? HEAD_APPROX_WALK : HEAD_APPROX;
    float neckT = 1.0 - smoothstep(0.18, 0.42, length(p - headRef));
    // Magenta debug override removed -- Sam settled the real bug by hand-placing landmark points
    // on the actual mesh (see HEAD_APPROX's comment): the beak is at -Z, not +Z, which every
    // vertex-density heuristic this saga tried (including twice this session) got backwards.
    // HEAD_APPROX is now the real measured head/neck centroid. Back to the real color cycle.
    if (neckT > 0.001) {
        col = mix(col, neonAccentColor(p, neckTurb, neckSpd), neckT);
    }

    if (abs(p.x) > 0.30) col *= 0.85;
    if (p.z < -0.55) col *= 0.8;

    return col;
}

// ===== BACKGROUND =====

vec3 pigeonBackground(vec3 rd, float style, float sat, float bright, float intensity, float mediaAmt) {
    vec3 col;
    if (style >= 1.5) {
        // Dove: soft pale gradient sky with a warm glow near the horizon -- same sat/bright/
        // intensity controls as the other two styles so it can be dialed in live from Synesthesia
        // rather than baked to one fixed look. Original palette (low ~(0.30,0.27,0.26), high
        // ~(0.55,0.60,0.66), glow ~(0.55,0.42,0.30)) read as "blinding white" per Sam's report --
        // real cause: high + glow summed above 1.0 near the horizon (clipping to flat white), and
        // both base tones were too close to gray to read as colorful even before that. Replaced
        // with an actual dusk gradient -- dusty rose near the horizon deepening to indigo overhead,
        // warm amber glow kept under 1.0 across backgroundIntensity's full 0-2 range, not just at
        // its default of 1 -- checked the worst case (glow=1.0, intensity=2, the slider's own MAX,
        // before backgroundColors' separate sat/bright even touches it): R peaks at 0.25+2*0.35=
        // 0.95, comfortably under 1.0, vs. the glow's R coefficient needing to stay below ~0.375 to
        // avoid clipping there at all.
        float horizon = smoothstep(-0.3, 0.4, rd.y);
        vec3 low = vec3(0.40, 0.22, 0.26);
        vec3 high = vec3(0.10, 0.10, 0.26);
        col = mix(low, high, horizon);
        float glow = pow(max(1.0 - abs(rd.y - 0.05) * 2.0, 0.0), 3.0);
        col += vec3(0.35, 0.20, 0.12) * glow * intensity;
    } else if (style < 0.5) {
        float horizon = smoothstep(-0.3, 0.4, rd.y);
        vec3 low = vec3(0.05, 0.02, 0.03);
        vec3 high = vec3(0.01, 0.02, 0.05);
        col = mix(low, high, horizon);
        float glow = pow(max(1.0 - abs(rd.y - 0.05) * 2.0, 0.0), 3.0);
        col += vec3(0.05, 0.15, 0.4) * glow * intensity;
    } else {
        // Iridescent Realism's bokeh-haze background -- dark/warm were hardcoded until now;
        // iridescentColorA/B expose them as color pickers (defaults unchanged) per Sam's request.
        float n = 0.0;
        n += sin(rd.x * 6.0 + TIME * 0.15) * 0.5;
        n += sin(rd.y * 5.0 + TIME * 0.11) * 0.3;
        n += sin((rd.x + rd.y) * 4.0 + TIME * 0.08) * 0.2;
        n = fract(n * 0.5 + 0.5);
        vec3 dark = iridescentColorA;
        vec3 warm = iridescentColorB;
        col = mix(dark, warm, smoothstep(0.6, 1.0, n) * intensity);
        col += vec3(0.06, 0.05, 0.08) * smoothstep(0.3, -0.4, rd.y);
    }
    col = enhanceColor(col, bright, sat);

    // media (video/image plugged into this layer) replaces/blends with the procedural background,
    // same _isMediaActive()/_textureMedia() pattern as Motion Amplification. Uses the plain screen
    // UV (_uv), not the per-RGB-split-channel ray offset, so a flat background layer doesn't itself
    // fracture into misaligned copies when the RGB split corruption effect is active.
    if (mediaAmt > 0.001 && _isMediaActive()) {
        col = mix(col, _textureMedia(_uv).rgb, mediaAmt);
    }
    return col;
}

// Lightweight hit-test-only probe for edgeDetectAmount's real fix (see below). Applies the same
// idle spin/bob/wobble object transform as renderChannel, so the probe ray lines up with the
// actual rendered bird, but skips corruption (meshGlitch/meshTwist/etc.) and all shading -- edge
// detection only needs hit/miss + depth, and running it through the same random per-cell corruption
// jitter as the real render would make the edge signal itself glitchy, ironically recreating the
// bug it exists to fix. Some duplication from renderChannel's transform block is accepted here
// rather than restructuring that function to share it -- this is meant to be the cheap path.
// baseYaw/pitchTotal/bob are the idle spin/bob/wobble transform angles -- identical
// for every call in a given frame (they depend only on TIME and the controls, never on cuv), so
// they're computed ONCE in renderMain and passed in here rather than recomputed per call. This
// function alone can run up to 5x per pixel (edge detect's 4 neighbor probes + center), and
// renderChannel below up to 3x (RGB split) -- recomputing this shared block from scratch in each of
// up to 8 total calls per pixel was pure waste for values that never differ between them.
float silhouetteProbe(vec2 cuv, vec3 ro, vec3 forward, vec3 right, vec3 up,
                       float baseYaw, float pitchTotal, float bob, out float tOut) {
    vec3 rd = normalize(forward + cuv.x * right + cuv.y * up);
    vec3 basePivot = vec3(0.0, 0.55, 0.0);

    vec3 bro = ro - basePivot - vec3(0.0, bob, 0.0);
    vec3 brd = rd;
    bro.xz = rot(-baseYaw) * bro.xz; brd.xz = rot(-baseYaw) * brd.xz;
    bro.yz = rot(-pitchTotal) * bro.yz; brd.yz = rot(-pitchTotal) * brd.yz;
    bro += basePivot;

    float bestT = 1e6;
    vec3 bestN = vec3(0.0);
    vec2 bestUV = vec2(0.0);
    float hitFlag = (pigeonPose < 0.5) ? meshRayTest(bro, brd, bestT, bestN, bestUV) : meshRayTestWalk(bro, brd, bestT, bestN, bestUV);
    tOut = bestT;
    return hitFlag;
}

vec3 renderChannel(vec2 cuv, vec3 ro, vec3 forward, vec3 right, vec3 up,
                    float style, float pigSat, float pigBright, float bgSat, float bgBright, float bgIntensity,
                    float neckTurb, float neckSpd, float mediaAmt, float meshGlitchAmt, float meshGlitchRes,
                    float meshTwistAmt, float meshWarpAmt, float meshDistortAmt, float meshFoldAmt,
                    float lowPolyAmt, float baseYaw, float pitchTotal, float bob,
                    out float hitOut) {
    // meshWarp/meshDistort/meshFold are real per-vertex distortions (see warpVertex(), applied
    // inside triHit() for every triangle test) rather than a ray-origin offset -- set once here as
    // plain globals since triHit() is called ~2000+ times per bird from deeply nested unrolled call
    // sites that were never going to be threaded extra parameters each. lowPolyAmt is set here too
    // so its vertex-snap half (see snapVertex) runs in the same pass as the others.
    gMeshWarpAmt = meshWarpAmt;
    gMeshDistortAmt = meshDistortAmt;
    gMeshFoldAmt = meshFoldAmt;
    gLowPolyAmt = lowPolyAmt;

    vec3 rd = normalize(forward + cuv.x * right + cuv.y * up);

    // object transform: idle spin/bob + wobble, applied as the inverse to the
    // ray rather than the geometry, since the geometry is a fixed set of literal triangle calls,
    // not something that can be moved directly. The angles themselves (baseYaw/pitchTotal/
    // bob) are computed once in renderMain and passed in -- see silhouetteProbe's comment for why.
    vec3 basePivot = vec3(0.0, 0.55, 0.0);

    vec3 bro = ro - basePivot - vec3(0.0, bob, 0.0);
    vec3 brd = rd;
    bro.xz = rot(-baseYaw) * bro.xz; brd.xz = rot(-baseYaw) * brd.xz;
    bro.yz = rot(-pitchTotal) * bro.yz; brd.yz = rot(-pitchTotal) * brd.yz;
    bro += basePivot;

    // model corruption: coarse screen-space cells randomly displace the ray before it ever
    // reaches the mesh test, so chunks of the rendered bird appear to shatter/jump rather than
    // the whole object wobbling uniformly. Genuinely different from the screen-space CORRUPTION
    // bank below, which only ever shuffles the final pixel's color/position after the 3D render
    // is already done -- this one actually corrupts the 3D geometry itself.
    if (meshGlitchAmt > 0.001) {
        vec2 gCell = floor(cuv * meshGlitchRes);
        float gHash = hash(gCell.x * 13.1 + gCell.y * 7.3 + floor(TIME * 12.0));
        if (gHash > 1.0 - meshGlitchAmt) {
            vec3 jitter = vec3(hash(gHash + 1.0) - 0.5, hash(gHash + 2.0) - 0.5, hash(gHash + 3.0) - 0.5);
            bro += jitter * 0.18;
        }
    }

    // meshTwist: a second 3D corruption, genuinely different from meshGlitch -- rotates both
    // the ray origin AND direction together (a rigid transform, same idea as the spin
    // rotations above) around the bird's pivot per screen cell, so a triggered chunk reads
    // as a coherently twisted/sheared piece of the bird rather than a translated copy of it.
    // Reuses meshGlitchRes for the cell grid so the two effects can be layered at matching scale.
    if (meshTwistAmt > 0.001) {
        vec2 twCell = floor(cuv * meshGlitchRes);
        float twHash = hash(twCell.x * 19.3 + twCell.y * 5.9 + floor(TIME * 9.0));
        if (twHash > 1.0 - meshTwistAmt) {
            float twistAngle = (twHash - 0.5) * 6.283;
            bro -= basePivot;
            bro.xy = rot(twistAngle) * bro.xy; brd.xy = rot(twistAngle) * brd.xy;
            bro += basePivot;
        }
    }

    float bestT = 1e6;
    vec3 bestN = vec3(0.0);
    vec2 bestUV = vec2(0.0);
    // pigeonPose selects which baked geometry to raytrace against -- both share the same texture
    // atlas (same rig/UV layout, only vertex positions differ between animation poses)
    float hitFlag = (pigeonPose < 0.5) ? meshRayTest(bro, brd, bestT, bestN, bestUV) : meshRayTestWalk(bro, brd, bestT, bestN, bestUV);
    bool anyHit = hitFlag > 0.5;
    vec3 bestLro = bro;
    vec3 bestLrd = brd;

    vec3 bgColor = pigeonBackground(rd, style, bgSat, bgBright, bgIntensity, mediaAmt);
    // hitOut: lets renderMain mask screen-space effects (bgEcho) to background-only pixels, so
    // they can't paint over the bird itself. Set at both return points.
    hitOut = anyHit ? 1.0 : 0.0;
    if (!anyHit) return bgColor;

    float t = bestT;
    vec3 n = bestN;
    vec2 uv = bestUV;
    vec3 lro = bestLro;
    vec3 lrd = bestLrd;

    // Low-poly: blend toward the faceted normal rather than snapping, so the control sweeps
    // smoothly from the real mesh's shading into a flat-shaded one instead of popping between them.
    if (lowPolyAmt > 0.001) {
        n = normalize(mix(n, facetNormal(n), lowPolyAmt));
    }

    vec3 p = lro + lrd * t;
    vec3 shaded = shadeHit(p, n, uv, style, neckTurb, neckSpd);

    vec3 lightDir = normalize(vec3(0.6, 1.0, -0.5));
    float diff = max(dot(n, lightDir), 0.0);
    shaded = shaded * (0.42 + diff * 0.72);

    if (style < 0.5) {
        // Neon's base color is deliberately near-black, so a plain brightness multiply on top of it
        // barely moves -- pigeonColors was doing almost nothing here. Give it real range: rim light
        // (the style's dominant visible feature) now scales directly with pigBright, and the body
        // gets an additive blue lift as brightness rises past its default, instead of only ever
        // multiplying an already-tiny number.
        shaded = mix(shaded, shaded + vec3(0.07, 0.09, 0.15), clamp((pigBright - 1.0) / 2.0, 0.0, 1.0));
    }
    shaded = enhanceColor(shaded, pigBright, pigSat);

    if (style < 0.5) {
        float fres = pow(1.0 - max(dot(n, -lrd), 0.0), 2.5);
        shaded += vec3(0.20, 0.50, 1.0) * fres * (1.1 + syn_BassLevel * 0.9) * pigBright;
    }

    // pose-aware head reference -- shadeHit's own neck tint already branches on pigeonPose (see the
    // HEAD_APPROX_WALK bug note there); this shimmer boost needs the same branch, it was one of two
    // places that still only ever referenced the fly-pose HEAD_APPROX regardless of pigeonPose
    vec3 headRef = (pigeonPose >= 0.5) ? HEAD_APPROX_WALK : HEAD_APPROX;
    float neckT = 1.0 - smoothstep(0.18, 0.42, length(p - headRef));
    shaded += shaded * neckT * syn_HighHits * 0.35;

    // Distance fog removed -- at this scene's normal camera range (t roughly 2.5-6 units) the old
    // `1-exp(-t*0.05)` term was blending 10-25% background into the bird by default, which read as
    // semi-transparent rather than atmospheric haze. Sam: "should be opaque." The bird is a solid
    // hit now regardless of camera distance/zoom.
    return shaded;
}

vec4 renderMain() {
    vec2 uv = _uvc;

    float style = pigeonStyle;
    float pigSat = clamp(pigeonColors.x, 0.5, 3.0);
    float pigBright = clamp(pigeonColors.y, 0.5, 3.0);
    float bgSat = clamp(backgroundColors.x, 0.3, 3.0);
    float bgBright = clamp(backgroundColors.y, 0.1, 2.0);
    float bgIntensity = clamp(backgroundIntensity, 0.0, 2.0);
    float neckTurb = clamp(neckIridescence.x, 0.5, 10.0);
    float neckSpd = clamp(neckIridescence.y, 0.0, 3.0);
    float mediaAmt = clamp(backgroundMediaAmount, 0.0, 1.0);
    // resetModel: an obvious "panic button" pad -- snaps every 3D corruption amount to 0 instantly
    // (fast-attack envelope in script.js) and eases them back over about a second, regardless of
    // where their sliders are sitting. Useful live: crank the warp/distort/glitch sliders for a
    // moment, then hit one pad to instantly get a clean, recognizable bird back.
    float resetSuppress = 1.0 - clamp(resetModelEnv, 0.0, 1.0);
    float meshGlitchAmt = clamp(meshGlitch, 0.0, 1.0) * (0.3 + syn_BassHits * 1.7) * resetSuppress;
    float meshGlitchRes = clamp(meshGlitchResolution, 2.0, 24.0);
    float meshTwistAmt = clamp(meshTwist, 0.0, 1.0) * (0.3 + syn_BassHits * 1.7) * resetSuppress;
    float meshWarpAmt = clamp(meshWarp, 0.0, 1.0) * (0.3 + syn_BassHits * 1.7) * resetSuppress;
    // meshDistort is a continuous, full-mesh twist (not a probabilistic per-cell trigger like
    // meshGlitch/meshTwist), so the same 0.3-2.0x audio swing those use reads as way too violent
    // here -- doubling a twist angle across the WHOLE bird on every hit, instead of just raising the
    // odds a few chunks glitch. Toned down to a much gentler hit boost.
    float meshDistortAmt = clamp(meshDistort, 0.0, 1.0) * (0.85 + syn_BassHits * 0.3) * resetSuppress;
    float meshFoldAmt = clamp(meshFold, 0.0, 1.0) * (0.3 + syn_BassHits * 1.7) * resetSuppress;
    // Single low-poly control -- facet coarseness AND vertex-snap grid are both fixed constants
    // (LOW_POLY_FACETS, snapVertex) pushed toward N64/PS1-era chunkiness rather than tunable sliders.
    // lowPolyReactivity adds bass hits on top of the base slider, so the chunky look can pulse in
    // on beats instead of only ever being a static on/off amount.
    float lowPolyAmt = clamp(lowPolyAmount + clamp(lowPolyReactivity, 0.0, 1.0) * syn_BassHits, 0.0, 1.0);

    // CORRUPTION envelopes (smoothed in script.js from bang pads)
    float shatterAmt = clamp(shatterEnv, 0.0, 1.0);
    float blockGlitchAmt = clamp(blockGlitchEnv, 0.0, 1.0);
    float shiftAmt = clamp(shiftEnv, 0.0, 1.0);
    float rgbSplitAmt = clamp(rgbShiftEnv, 0.0, 1.0);
    float pixelSortAmt = clamp(pixelSort, 0.0, 0.2);
    float scanlineAmt = clamp(scanlines, 0.0, 2.0);
    float blockGlitchSlider = clamp(blockGlitchAmount, 0.0, 1.0);
    float screenShakeSlider = clamp(screenShake, 0.0, 1.0);
    float rgbSplitSlider = clamp(rgbSplitAmount, 0.0, 1.0);
    float audioBassCorrupt = syn_BassHits;
    float audioMidCorrupt = syn_MidHighHits;

    vec2 workingUV = uv;

    // Kaleidoscope, ported from Metal Shader: wraps the angle around the frame center into
    // `kaleidoSegments` repeating wedges (ported as-is, including a quirk in the source -- the
    // segment-index mirror-alternation branch there is dead code, since `angle` is already
    // reduced into a single segment's range before that branch runs, so segments repeat by
    // rotation rather than mirroring; kept faithful to Metal Shader's actual shipped look rather
    // than "fixing" behavior Sam hasn't asked to change).
    if (kaleidoscope > 0.5) {
        float kSeg = clamp(kaleidoSegments, 2.0, 16.0);
        float kAngle = atan(workingUV.y, workingUV.x);
        float kSegAngle = 6.28318530718 / kSeg;
        kAngle = mod(kAngle, kSegAngle);
        float kRadius = length(workingUV);
        workingUV = vec2(cos(kAngle), sin(kAngle)) * kRadius;
    }

    // zoomPunch: a quick impact zoom-in pulse (envelope smoothed in script.js, no hard cut).
    float zoomPunchAmt = clamp(zoomPunchEnv, 0.0, 1.0);
    if (zoomPunchAmt > 0.001) {
        workingUV *= 1.0 - zoomPunchAmt * 0.35;
    }

    if (shatterAmt > 0.01) {
        vec2 shardCoord = floor(workingUV * 8.0);
        float shardHash = hash(shardCoord.x * 10.0 + shardCoord.y + floor(TIME * 0.5));
        float shardAngle = shardHash * 6.28 * shatterAmt;
        float shardDist = (shardHash - 0.5) * 0.4 * shatterAmt;
        vec2 shardCenter = (shardCoord + 0.5) / 8.0;
        vec2 toCenter = workingUV - shardCenter;
        toCenter = rot(shardAngle) * toCenter;
        toCenter += vec2(cos(shardHash * 6.28), sin(shardHash * 6.28)) * shardDist;
        workingUV = shardCenter + toCenter;
        vec2 shardEdge = fract(workingUV * 8.0);
        float edgeDist = min(min(shardEdge.x, 1.0 - shardEdge.x), min(shardEdge.y, 1.0 - shardEdge.y));
        if (edgeDist < 0.05 * shatterAmt) {
            workingUV += vec2(hash(shardHash + 10.0) - 0.5, hash(shardHash + 20.0) - 0.5) * 0.1;
        }
    }

    float totalShake = shiftAmt + screenShakeSlider * audioBassCorrupt;
    if (totalShake > 0.01) {
        float shakeX = (hash(floor(TIME * 10.0)) - 0.5) * totalShake * 0.3;
        float shakeY = (hash(floor(TIME * 10.0) + 1.0) - 0.5) * totalShake * 0.2;
        workingUV += vec2(shakeX, shakeY);
    }

    float totalPixelSort = pixelSortAmt + pixelSortAmt * audioMidCorrupt * 2.0;
    if (totalPixelSort > 0.001) {
        // pixelSortWidth: column count the screen is sliced into -- lower = fewer, wider streaks,
        // higher = many thin ones. Was a hardcoded 15.0.
        float sortCols = clamp(pixelSortWidth, 2.0, 60.0);
        float sortLine = floor(workingUV.x * sortCols);
        float sortShift = hash(sortLine + floor(TIME * 5.0)) * totalPixelSort * 2.0;
        workingUV.y += sortShift;
    }

    float totalBlockGlitch = max(blockGlitchAmt, blockGlitchSlider * audioBassCorrupt);
    if (totalBlockGlitch > 0.01) {
        vec2 blockCoord = floor(workingUV * 12.0);
        float blockHash = hash(blockCoord.x + blockCoord.y * 10.0 + floor(TIME * 3.0));
        if (blockHash > (0.85 - totalBlockGlitch * 0.3)) {
            vec2 offset = vec2(hash(blockHash) - 0.5, hash(blockHash + 1.0) - 0.5) * 0.4 * totalBlockGlitch;
            workingUV += offset;
        }
    }

    // ----- camera -----
    float camZoom = clamp(cameraXY.x, 0.3, 3.0);
    float camHeightOff = clamp(cameraXY.y, -3.0, 5.0);
    // zoomDrag: right-click-drag zoom, studied from the same 3D Orbit Camera example scene as the
    // orbit drag below (that reference drives its own zoom off right-click too). Direct position
    // delta rather than the reference's hold-and-it-keeps-zooming joystick style, for the same
    // 1:1-with-the-mouse feel as the orbit drag. Sign is a guess (drag up = zoom in) -- flip this
    // subtraction to addition if it feels backwards once actually tested.
    float camDist = clamp(4.4 / camZoom - zoomDrag, 0.5, 20.0);

    vec3 lookAt = vec3(0.0, 0.75, 0.0);

    // View bangs (Front/Back/Left/Right/Top/Bottom/Perspective) orbit the camera around the bird
    // on a sphere -- yaw/pitch smoothed in script.js (viewYaw/viewPitch), not snapped, per the
    // "smooth transitions over hard cuts" preference. yaw=0,pitch=0 (the resting default) lands
    // exactly on the original fixed front view, so nothing changes until a bang is pressed. Pitch
    // clamped short of +-PI/2 to avoid the classic gimbal-lock singularity directly overhead/
    // underneath, where forward becomes parallel to the world-up reference and cross() degenerates.
    float camYaw = viewYaw;
    float camPitch = clamp(viewPitch, -1.4, 1.4);
    vec3 orbitDir = vec3(sin(camYaw) * cos(camPitch), sin(camPitch), -cos(camYaw) * cos(camPitch));
    // +0.55 reproduces the original static camera's height above lookAt (1.3 vs lookAt.y=0.75) at
    // the resting yaw=0/pitch=0 view; camHeightOff still nudges height on top of any preset angle.
    vec3 roStatic = lookAt + orbitDir * camDist + vec3(0.0, 0.55 + camHeightOff, 0.0);

    float autoSpeed = clamp(autoCameraSpeed, 0.1, 2.0);
    float autoTime = TIME * autoSpeed;
    float orbitAngle = autoTime * 0.3;
    float autoDist = camDist + sin(autoTime * 0.5) * 1.2 + syn_BassLevel * 1.0;
    float autoHeight = (1.3 + camHeightOff) + sin(autoTime * 0.7) * 0.6 + syn_MidLevel * 0.6 + syn_BassHits * 0.3;
    vec3 roAuto = vec3(cos(orbitAngle) * autoDist, autoHeight, sin(orbitAngle) * autoDist);

    vec3 ro = mix(roStatic, roAuto, clamp(autoCamera, 0.0, 1.0));

    vec3 forward = normalize(lookAt - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);

    // Idle spin/bob/wobble object-transform angles -- computed ONCE here rather than inside
    // renderChannel/silhouetteProbe, since they depend only on TIME and the controls, never on
    // which screen pixel/channel/probe is asking. renderChannel can run up to 3x per pixel (RGB
    // split) and silhouetteProbe up to 5x (edge detect's 4 neighbors + center); recomputing this
    // same shared block in each of up to 8 calls per pixel was pure waste. See silhouetteProbe/
    // renderChannel's own comments for how these are used.
    float spinSpd = clamp(idleSpin, 0.0, 2.0);
    float bobAmt = clamp(bobAmount, 0.0, 1.0);
    float wobbleAmt = clamp(wobbleAmount, 0.0, 1.0);
    float wobbleYaw = sin(TIME * 0.7) * wobbleAmt * 0.22;
    float wobblePitch = sin(TIME * 0.55 + 1.7) * wobbleAmt * 0.16;
    float objBaseYaw = TIME * spinSpd * 0.3 + wobbleYaw;
    float objPitchTotal = wobblePitch;
    float objBob = sin(TIME * 0.8) * bobAmt * 0.2;

    float totalRGBSplit = rgbSplitAmt + rgbSplitSlider * audioBassCorrupt;
    vec3 col;
    // hitMask: 1 where the bird was actually hit, 0 on background -- lets bgEcho below mask itself
    // to background-only pixels instead of painting over the bird. Captured from the G channel
    // (no split offset) as the representative mask; the R/B channels' hit masks are discarded since
    // the RGB-split offset is only a few pixels, not worth threading three separate masks for.
    float hitMask;

    if (totalRGBSplit > 0.01) {
        float splitOffset = totalRGBSplit * 0.015;
        float hitR, hitB;
        float colR = renderChannel(workingUV + vec2(splitOffset, 0.0), ro, forward, right, up, style, pigSat, pigBright, bgSat, bgBright, bgIntensity, neckTurb, neckSpd, mediaAmt, meshGlitchAmt, meshGlitchRes, meshTwistAmt, meshWarpAmt, meshDistortAmt, meshFoldAmt, lowPolyAmt, objBaseYaw, objPitchTotal, objBob, hitR).r;
        float colG = renderChannel(workingUV, ro, forward, right, up, style, pigSat, pigBright, bgSat, bgBright, bgIntensity, neckTurb, neckSpd, mediaAmt, meshGlitchAmt, meshGlitchRes, meshTwistAmt, meshWarpAmt, meshDistortAmt, meshFoldAmt, lowPolyAmt, objBaseYaw, objPitchTotal, objBob, hitMask).g;
        float colB = renderChannel(workingUV - vec2(splitOffset, 0.0), ro, forward, right, up, style, pigSat, pigBright, bgSat, bgBright, bgIntensity, neckTurb, neckSpd, mediaAmt, meshGlitchAmt, meshGlitchRes, meshTwistAmt, meshWarpAmt, meshDistortAmt, meshFoldAmt, lowPolyAmt, objBaseYaw, objPitchTotal, objBob, hitB).b;
        col = vec3(colR, colG, colB);
    } else {
        col = renderChannel(workingUV, ro, forward, right, up, style, pigSat, pigBright, bgSat, bgBright, bgIntensity, neckTurb, neckSpd, mediaAmt, meshGlitchAmt, meshGlitchRes, meshTwistAmt, meshWarpAmt, meshDistortAmt, meshFoldAmt, lowPolyAmt, objBaseYaw, objPitchTotal, objBob, hitMask);
    }

    if (scanlineAmt > 0.01) {
        float scanline = sin(uv.y * RENDERSIZE.y * 2.0) * 0.5 + 0.5;
        col *= 1.0 - (scanline * scanlineAmt * 0.4);
    }

    if (shatterAmt > 0.01) {
        vec2 shardEdge = fract(uv * 8.0);
        float edgeDist = min(min(shardEdge.x, 1.0 - shardEdge.x), min(shardEdge.y, 1.0 - shardEdge.y));
        if (edgeDist < 0.03) col *= 1.0 - shatterAmt * 0.5;
    }

    if (style < 0.5) {
        vec2 guv = uv;
        float lineX = min(abs(fract(guv.x * 1.5) - 0.5), abs(fract(guv.x * 1.5 + 0.5) - 0.5));
        float lineY = min(abs(fract(guv.y * 1.5) - 0.5), abs(fract(guv.y * 1.5 + 0.5) - 0.5));
        float grid = 1.0 - smoothstep(0.0, 0.0025, min(lineX, lineY));
        vec3 gridCol = vec3(1.0, 0.08, 0.08) * grid * 0.35 * bgIntensity;
        col += gridCol * (0.5 + 0.5 * syn_BassLevel);
    }

    // invert: quick color-inversion pulse (envelope smoothed in script.js -- a color-space flip,
    // not a brightness flash, so it doesn't run into the seizure-flashing concern a strobe would).
    float invertAmt = clamp(invertEnv, 0.0, 1.0);
    if (invertAmt > 0.001) {
        col = mix(col, 1.0 - col, invertAmt);
    }

    // afterimage/feedback trail -- off by default (feedbackAmount=0 leaves col untouched).
    // Real bug, found while chasing Sam's "needs work" on both this and bgEcho: screenBlend fixes
    // raw addition's complete lack of an upper bound, but it's still a one-way brightening operator
    // (screenBlend(a,b) >= a always) -- fed a persistent source every frame with no independent
    // decay, it still creeps toward white over enough frames at high trailAmt, just slower than raw
    // addition did. screenBlend is the right tool for compositing something transient onto a fading
    // base (a corruption spike, a one-off flash) but not for a sustained per-frame feedback read.
    // Switched to a classic phosphor-persistence mix: convex combination of old and new, which
    // structurally cannot exceed whichever input is brighter, so it's stable at any trailAmt up to 1.
    float trailAmt = clamp(feedbackAmount, 0.0, 0.97) * (1.0 + syn_BassHits * 0.15);
    trailAmt = min(trailAmt, 0.985);
    if (trailAmt > 0.001) {
        vec3 prevCol = texture2D(syn_FinalPass, _uv).rgb;
        col = mix(col, prevCol, trailAmt);
    }

    // Repeating echo trail -- v1/v2 of this tried to fake "multiple copies" by averaging 5 samples
    // of ONE frame at different offsets, inspired by media_key_&_cloner_fx's clone loop. Sam's
    // verdict on both attempts ("all of the above": washes out, doesn't look like copies, too
    // subtle) pointed at the real problem: averaging several samples together is a blur operation
    // by definition, no matter how far apart the samples are -- it can never look like distinct
    // repeating copies. That's not how the reference cloner (or real analog video feedback) gets
    // its look either: both build a receding/spiraling structure by applying a SMALL transform once
    // per frame and letting it COMPOUND over many frames through the feedback texture itself, not
    // by faking many copies out of one frame. Rebuilt on that basis: a single gentle zoom + rotation
    // + kaleido-fold (same angle-segment-mirror idea as Metal Shader's kaleidoscope) applied to the
    // sample of syn_FinalPass each frame. At 60fps, a 1.5%/frame zoom is already a ~2x shrink per
    // second, so nested copies build up and become clearly visible within a second or two of the
    // control being active, growing more elaborate the longer it runs -- rather than needing to be
    // instantly complete from a single frame's math. Composited with mix() (see feedbackAmount's
    // matching fix above) so it settles to a steady state instead of drifting toward white.
    // Ceiling raised 1.0 -> 2.0 per Sam's request. echoAmt itself still feeds the zoom-per-frame
    // rate uncapped (more zoom = a tighter, faster-compounding spiral at high settings), but the
    // actual mix() blend factor below is separately clamped to [0,1] -- mix() extrapolates past its
    // inputs for t>1, so without that clamp a bgEchoAmount above ~1.4 would overshoot color values
    // rather than just blending in more of the echo.
    float echoAmt = clamp(bgEchoAmount, 0.0, 2.0);
    if (echoAmt > 0.001) {
        vec2 base = _uv - 0.5;
        float zoom = mix(1.0, 0.965, clamp(echoAmt * 0.5, 0.0, 1.0));
        vec2 sp = base * zoom;
        sp = rot(TIME * 0.06) * sp;
        float ang = atan(sp.y, sp.x);
        float r = length(sp);
        float segAngle = 6.28318 / 5.0;
        ang = mod(ang, segAngle);
        if (ang > segAngle * 0.5) ang = segAngle - ang;
        sp = vec2(cos(ang), sin(ang)) * r;
        vec2 sampleUV = clamp(sp + 0.5, 0.0, 1.0);
        vec3 echoSample = texture2D(syn_FinalPass, sampleUV).rgb;
        // Masked to background-only pixels (hitMask==0) per Sam's request -- bgEcho was blending
        // over the bird itself, reading as if it were in front of it. feedbackAmount above is left
        // covering the whole frame (only bgEcho was named); mask that one the same way too if it
        // turns out to have the same issue.
        float echoBlend = clamp(echoAmt * (0.5 + syn_BassHits * 0.2), 0.0, 1.0) * (1.0 - hitMask);
        col = mix(col, echoSample, echoBlend);
    }

    // edgeDetect/Highlight -- real fix, not the previous version's bug. Sam correctly diagnosed it:
    // "detecting every single edge between 2 vertexes... instead of the outline from the camera's
    // perspective." The old version did a Sobel filter on syn_FinalPass's LUMINANCE, which cannot
    // tell a real silhouette (background meets bird) from two neighboring flat-shaded triangles
    // that simply have different normals -- both produce a real, legitimate luminance jump in the
    // 2D image, so it lit up every facet boundary on the whole mesh, not just the outline. The
    // correct signal is HIT/MISS and DEPTH, not color: a true silhouette is where the ray stops
    // hitting the mesh at all, or (for something like a wing crossing in front of the body) where
    // depth jumps sharply between two hits -- neither of those happens at an ordinary facet seam,
    // where neighboring points are still part of the same continuous surface at nearly the same
    // depth. Gets that signal from silhouetteProbe(), a cheap hit-test-only re-trace (no shading/
    // corruption) at 4 neighboring screen directions -- genuinely more expensive than the old
    // image-space version (adds up to 5 extra mesh tests per pixel), but only when this control is
    // actually turned on, and it's the only way to get a real outline rather than facet noise.
    float edgeAmt = clamp(edgeDetectAmount, 0.0, 1.0);
    if (edgeAmt > 0.001) {
        float pixelStep = 1.3 / RENDERSIZE.y;
        float tC, tL, tR, tU, tD;
        float hC = silhouetteProbe(workingUV, ro, forward, right, up, objBaseYaw, objPitchTotal, objBob, tC);
        float hL = silhouetteProbe(workingUV + vec2(-pixelStep, 0.0), ro, forward, right, up, objBaseYaw, objPitchTotal, objBob, tL);
        float hR = silhouetteProbe(workingUV + vec2(pixelStep, 0.0), ro, forward, right, up, objBaseYaw, objPitchTotal, objBob, tR);
        float hU = silhouetteProbe(workingUV + vec2(0.0, pixelStep), ro, forward, right, up, objBaseYaw, objPitchTotal, objBob, tU);
        float hD = silhouetteProbe(workingUV + vec2(0.0, -pixelStep), ro, forward, right, up, objBaseYaw, objPitchTotal, objBob, tD);

        // hit/miss flips across a real silhouette boundary
        float hitEdge = abs(hC - hL) + abs(hC - hR) + abs(hC - hU) + abs(hC - hD);

        // depth jumps between two REAL hits (e.g. a wing edge crossing in front of the body) --
        // gated to hit-hit pairs only so a miss's huge/undefined t can't swamp this term
        float depthEdge = 0.0;
        if (hC > 0.5 && hL > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tL));
        if (hC > 0.5 && hR > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tR));
        if (hC > 0.5 && hU > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tU));
        if (hC > 0.5 && hD > 0.5) depthEdge += smoothstep(0.05, 0.3, abs(tC - tD));

        float edge = clamp(hitEdge + depthEdge * 0.5, 0.0, 1.0);
        col = mix(col, col + edgeDetectColor * edge, edgeAmt);
    }

    // streak: a directional light-trail/comet smear -- the "something else" alongside edge detect,
    // deliberately a different trail CHARACTER from bgEcho's radial kaleidoscope spiral (linear
    // smear along a slowly-rotating direction instead). Same underlying principle as bgEcho's fix:
    // one small step per frame, left to compound through the syn_FinalPass feedback loop into a
    // real comet tail rather than faking it from one frame. Whole-frame (not masked to background)
    // since a trail dragging the bird's own motion/color is the point of this one.
    float streakAmt = clamp(streakAmount, 0.0, 1.0);
    if (streakAmt > 0.001) {
        float streakAngle = TIME * 0.15;
        vec2 streakDir = vec2(cos(streakAngle), sin(streakAngle));
        vec2 streakUV = clamp(_uv - streakDir * streakAmt * 0.02, 0.0, 1.0);
        vec3 streakSample = texture2D(syn_FinalPass, streakUV).rgb;
        col = mix(col, streakSample, streakAmt * (0.5 + syn_BassHits * 0.2));
    }

    return vec4(col, 1.0);
}
